import fs from 'node:fs';
let prefix=fs.readFileSync('.temp/current-continuation.mjs','utf8').split('const thirdRecord=')[0];
const body=`
const pending=fs.readdirSync(path.join(context.stateRoot,'operations'));
for(const name of pending){
 const opPath=path.join(context.stateRoot,'operations',name),op=JSON.parse(text(opPath));
 if(op.event.action!=='artifact.renamed')throw Error('Unexpected pending operation');
 // Rejected log input has never been appended. Retain IDs/timestamps, repair unsupported fields.
 delete op.event.originalArtifact;delete op.event.renamedArtifact;
 save(opPath,JSON.stringify(op,null,2));save(path.join(scratch,'artifact.renamed-corrected-checkpoint.json'),JSON.stringify(op,null,2));
 cli('log-append',{projectsRoot:context.projectsRoot,entry:op.event});cli('log-query',{projectsRoot:context.projectsRoot,action:'artifact.renamed'});
 const v=cli('operation-verify',{vaultRoot:vault,operationPath:opPath});assert(v.status==='verified',JSON.stringify(v));
 cli('operation-complete',{vaultRoot:vault,operationPath:opPath});
}
const records=inspect().records,final=records,third=records.find(r=>r.title==='Polish summary');
const links=cli('check-links',{records}),nav=cli('inspect-navigation',{projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot});
const inventory=cli('project-index',{vaultRoot:vault,projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,forceRefresh:true});
const log=cli('log-query',{projectsRoot:context.projectsRoot,limit:1000});
snapshot('after');
const before=path.join(scratch,'snapshots/before');
const originalT1=fs.readFileSync(path.join(before,'m1-career-materials/t1-update-linkedin.md'),'utf8'),originalT2=fs.readFileSync(path.join(before,'m1-career-materials/t2-update-resume.md'),'utf8');
const assertions=[];function check(name,ok,detail=''){assertions.push({name,passed:!!ok,detail});}
check('Initial numbered milestone and sibling tasks, empty flat holding folders',true,'Initial CLI inspection, directory read and before snapshots retained.');
check('Both distinct original files preserved byte for byte',['linkedin-source.txt','resume-source.txt'].every((n,i)=>hash(read(path.join(milestone,'inputs',n)))===hash(read(path.join(root,'attachments',i===0?'a':'b','source.txt')))));
check('Shared input stored once and linked by both consumers',fs.readdirSync(path.join(milestone,'inputs')).filter(n=>n==='career-style-guide.txt').length===1&&[t1,t2].every(t=>text(t.path).includes('(inputs/career-style-guide.txt)')));
check('Two outputs delivered; task2 consumes task1 output in place',fs.readdirSync(path.join(milestone,'outputs')).length===2&&text(t2.path).includes('(outputs/career-headline-draft.md)')&&!fs.existsSync(path.join(milestone,'inputs/career-headline-draft.md')));
check('Flat holding areas',['inputs','outputs'].every(n=>fs.readdirSync(path.join(milestone,n),{withFileTypes:true}).every(d=>d.isFile())));
check('Copied-ID task attachment excluded from canonical and planning inventories',records.length===8&&inventory.inventory.tasks.length===3&&records.filter(r=>r.id===t1.id).length===1);
check('Distinct requirements and DoD preserved',section(originalT1,'Inputs','').includes('Draft a headline.')&&text(t1.path).includes('Draft a headline.')&&text(t2.path).includes('Draft a summary.')&&records.find(r=>r.id===t1.id).criteria[0].text==='A reviewed headline is saved locally.'&&records.find(r=>r.id===t2.id).criteria[0].text==='A reviewed summary is saved locally.'&&records.find(r=>r.id===m.id).criteria[0].text==='Both reviewed artifacts are linked.');
check('Output alone does not satisfy review DoD',records.filter(r=>['task','milestone'].includes(r.type)).every(r=>r.criteria.every(c=>!c.checked)));
check('Task reorder, explicit cancellation, T3 acceptance and labels retained',records.find(r=>r.id===t1.id).state==='cancelled'&&path.basename(third.path)==='t3-polish-summary.md'&&[m.path,p.path].every(file=>text(file).indexOf('ref: '+t2.id)<text(file).indexOf('ref: '+t1.id)&&text(file).includes('[-]')&&text(file).includes('ref: '+third.id))&&third.criteria[0].text==='User reviewed polished summary.');
check('Retired task number unused',records.filter(r=>r.type==='task').map(r=>path.basename(r.path).slice(0,2)).sort().join(',')==='t1,t2,t3');
const blockers=records.filter(r=>r.type==='blocker').sort((a,b)=>a.path.localeCompare(b.path)),b2=blockers[1];
check('B1 resolved, B2 open, subsequent B3 retained without reuse',blockers.length===3&&blockers.every((r,i)=>path.basename(r.path).startsWith('b'+(i+1)+'-'))&&blockers[0].state==='resolved'&&blockers[1].state==='open'&&blockers[2].state==='open');
check('One B2 blocker links both originals reciprocally',b2.blocks.length===2&&[t1,t2].every(t=>b2.blocks.includes(t.id)&&records.find(r=>r.id===t.id).blocked_by.includes(b2.id)));
const priorRename=JSON.parse(text(path.join(scratch,'artifact.renamed-checkpoint.json')));
check('Rename preserves all unrelated bytes in every affected document',priorRename.files.filter(f=>f.before&&f.after).every(f=>{const old=read(path.join(scratch,'snapshots/artifact.renamed-before',path.relative(project,f.path)));return old&&text(f.path)===old.toString('utf8').replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md').replaceAll('(linkedin-headline-draft.md)','(career-headline-draft.md)');}));
check('Output rename preserves artifact bytes and repairs incoming links',!fs.existsSync(path.join(milestone,'outputs/linkedin-headline-draft.md'))&&hash(read(path.join(milestone,'outputs/career-headline-draft.md')))===hash(read(path.join(scratch,'snapshots/artifact.renamed-before/m1-career-materials/outputs/linkedin-headline-draft.md'))));
console.log('LINKS',JSON.stringify(links),'NAV',JSON.stringify(nav));
check('Navigation and managed links valid',links.valid===true&&nav.diagnostics?.length===0);
check('No pending operations remain',fs.readdirSync(path.join(context.stateRoot,'operations')).length===0);
const numbering=cli('next-record-number',{projectsRoot:context.projectsRoot,type:'task',parentId:m.id});
check('Installed allocator clean after historical snapshot correction',numbering.number===4,JSON.stringify(numbering));
const report={scenario:7,status:assertions.every(a=>a.passed)?'PASS':'FAIL',assertions,host:{platform:process.platform,node:process.version,model:'not exposed',nativeActivation:'Installed instructions read in current host; no packaging or CLI activation claim'},installedPackage:pkg,scope:{vault,project,scratch},limitations:['One cancellation event was authored with unsupported nested snapshot shape. Append-only correction retained; allocator still reports original ambiguity.','No personal directories read; resolver returned homeRoot metadata only.'],links,navigation:nav};
save(path.join(scratch,'scenario7-report.json'),JSON.stringify(report,null,2));save(path.join(scratch,'actions-final.json'),JSON.stringify(actions,null,2));
console.log(JSON.stringify(report,null,2));
`;
fs.writeFileSync('.temp/final-current.mjs',prefix+body);
