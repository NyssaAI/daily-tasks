# LinkedIn headline draft

Professional preparing career materials for a job search.

Draft based on the supplied synthetic LinkedIn source and shared style guide. Review pending.
