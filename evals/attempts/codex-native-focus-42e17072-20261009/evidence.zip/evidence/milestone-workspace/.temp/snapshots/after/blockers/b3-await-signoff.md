---
id: "01a121ab-7fb8-7e25-80e7-a5c6a6a4f32a"
type: blocker
record_version: 2
title: "Await signoff"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T17:17:29.957Z"
updated_at: "2026-10-09T17:17:29.957Z"
---
# Await signoff

External impediment: await signoff.

## Resolution condition

User supplies signoff.

## Resolution evidence

No resolution reported.

## Blocks


