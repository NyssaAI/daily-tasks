import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final/codex-home/plugins/cache/daily-tasks-runtime-guards-final/daily-tasks/0.3.3';
const project=path.join(vault,'Projects/job-search'), milestone=path.join(project,'m1-career-materials');
fs.mkdirSync(scratch,{recursive:true});
let seq=fs.readdirSync(scratch).filter(n=>/^\d+-.*-result.json$/.test(n)).length; const actions=[];
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>fs.existsSync(p)?fs.readFileSync(p):null;
const save=(p,b)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b);};
function cli(op,input){
 const stem=String(++seq).padStart(3,'0')+'-'+op, inputPath=path.join(scratch,stem+'-input.json');
 const args=[path.join(pkg,'bin/daily-tasks.mjs'),op];
 if(input!==undefined){save(inputPath,JSON.stringify(input,null,2));args.push('--input',inputPath);}
 const r=spawnSync(process.execPath,args,{encoding:'utf8'});
 save(path.join(scratch,stem+'-result.json'),JSON.stringify({command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2));
 if(r.status!==0)throw Error(op+': '+r.stderr);
 const value=JSON.parse(r.stdout);actions.push({op,inputPath:input===undefined?null:inputPath,result:stem+'-result.json'});return value;
}
function id(){const v=cli('new-id');return typeof v==='string'?v:v.id;}
const context=cli('resolve-context',{vaultRoot:vault});
save(path.join(scratch,'context.json'),JSON.stringify(context,null,2));
console.log('Context',JSON.stringify(context));
const inspect=()=>cli('inspect-records',{projectsRoot:context.projectsRoot});
const initial=inspect();save(path.join(scratch,'initial-inspection.json'),JSON.stringify(initial,null,2));
console.log('Initial inspection',JSON.stringify(initial));
save(path.join(scratch,'actions.json'),JSON.stringify(actions,null,2));
const t1=initial.records.find(r=>r.title==='Update LinkedIn'),t2=initial.records.find(r=>r.title==='Update resume'),m=initial.records.find(r=>r.type==='milestone'),p=initial.records.find(r=>r.type==='project');
const assert=(ok,msg)=>{if(!ok)throw Error(msg);};
assert(initial.diagnostics.length===0,'Initial diagnostics');
assert(fs.readdirSync(path.join(milestone,'inputs')).length===0 && fs.readdirSync(path.join(milestone,'outputs')).length===0,'Initial flat folders must be empty');
const snapshots=path.join(scratch,'snapshots');
function snapshot(label){for(const r of inspect().records)save(path.join(snapshots,label,path.relative(project,r.path)),read(r.path));}
snapshot('before');
function batch(label,changes,recordIds,details={}){
 const clock=cli('activity-time',{}),operationId=id(),eventId=id();
 const event={id:eventId,operation_id:operationId,action:label,record_ids:recordIds,actor:{kind:'agent',id:'codex'},...clock,original_words:'User explicitly authorized scenario 7 local workflow',...details};
 const files=changes.map(([file,bytes])=>({path:file,before:read(file)===null?null:hash(read(file)),after:bytes===null?null:hash(bytes)}));
 const checkpoint={schemaVersion:2,operation_id:operationId,contextBinding:context.planningBinding,event,files};
 const opPath=path.join(context.stateRoot,'operations',operationId+'.json');
 for(const [file] of changes){const b=read(file);if(b!==null)save(path.join(snapshots,label+'-before',path.relative(project,file)),b);}
 save(opPath,JSON.stringify(checkpoint,null,2));save(path.join(scratch,label+'-checkpoint.json'),JSON.stringify(checkpoint,null,2));
 changes.forEach(([file,bytes],i)=>{assert((read(file)===null?null:hash(read(file)))===files[i].before,'Concurrent edit');if(bytes===null)fs.unlinkSync(file);else save(file,bytes);});
 cli('invalidate-project-index',{vaultRoot:vault});
 const actual=inspect();const validation=cli('validate-records',{records:actual.records});
 save(path.join(scratch,label+'-validation.json'),JSON.stringify(validation,null,2));
 cli('log-append',{projectsRoot:context.projectsRoot,entry:event});
 cli('log-query',{projectsRoot:context.projectsRoot,action:label});
 const opts={vaultRoot:vault,operationPath:opPath};
 const verification=cli('operation-verify',opts);assert(verification.status==='verified',JSON.stringify(verification));
 const completion=cli('operation-complete',opts);console.log(label,JSON.stringify(completion));
 assert(!fs.existsSync(opPath),'Checkpoint remains pending');
 for(const [file,bytes] of changes)if(bytes!==null)save(path.join(snapshots,label+'-after',path.relative(project,file)),bytes);
 save(path.join(scratch,'actions.json'),JSON.stringify(actions,null,2));
}
const text=p=>read(p).toString('utf8');
const section=(s,name,body)=>s.replace(new RegExp('(## '+name+'\\r?\\n)[\\s\\S]*?(?=\\r?\\n## |$)'),'$1\n'+body+'\n');
const src1=path.join(milestone,'inputs/linkedin-source.txt'),src2=path.join(milestone,'inputs/resume-source.txt'),shared=path.join(milestone,'inputs/career-style-guide.txt');
const out1=path.join(milestone,'outputs/linkedin-headline-draft.md'),out2=path.join(milestone,'outputs/resume-summary-draft.md');
let a=section(text(t1.path),'Inputs','- [LinkedIn source](inputs/linkedin-source.txt) — original: attachments/a/source.txt.\n- [Shared style guide](inputs/career-style-guide.txt) — original: attachments/shared.txt.');
let b=section(text(t2.path),'Inputs','- [Resume source](inputs/resume-source.txt) — original: attachments/b/source.txt.\n- [Shared style guide](inputs/career-style-guide.txt) — original: attachments/shared.txt.\n- [Headline draft](outputs/linkedin-headline-draft.md) — consumed in its producing location; no input copy.');
a=section(a,'Output and delivery','Local draft: [LinkedIn headline](outputs/linkedin-headline-draft.md). Review is still required.');
b=section(b,'Output and delivery','Local draft: [Resume summary](outputs/resume-summary-draft.md). Review is still required.');
a=section(a,'Result','Draft produced: [LinkedIn headline](outputs/linkedin-headline-draft.md). No review has been reported.');
b=section(b,'Result','Draft produced: [Resume summary](outputs/resume-summary-draft.md), using the linked headline draft in place. No review has been reported.');
batch('workspace.import-and-draft',[[src1,read(path.join(root,'attachments/a/source.txt'))],[src2,read(path.join(root,'attachments/b/source.txt'))],[shared,read(path.join(root,'attachments/shared.txt'))],[out1,'# LinkedIn headline draft\n\nProfessional preparing career materials for a job search.\n\nDraft based on the supplied synthetic LinkedIn source and shared style guide. Review pending.\n'],[out2,'# Resume summary draft\n\nProfessional preparing career materials for a job search, with a consistent headline and concise resume summary.\n\nDraft uses the supplied synthetic resume source, shared style guide and [LinkedIn headline](linkedin-headline-draft.md) in place. Review pending.\n'],[t1.path,a],[t2.path,b]],[t1.id,t2.id]);
for(const task of [t1,t2]){const closure=cli('check-closure',{recordId:task.id,records:inspect().records});assert(closure.allowed===false,'Output must not satisfy review DoD');}
const attachment=path.join(milestone,'inputs/copied-task-reference.md');
batch('workspace.import-reference',[[attachment,text(t1.path)]],[t1.id]);
assert(inspect().records.filter(r=>r.id===t1.id).length===1,'Copied attachment became canonical');
const inventory=cli('project-index',{vaultRoot:vault,projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,forceRefresh:true});
assert(inventory.inventory.tasks.length===2,'Copied attachment entered planning inventory');
const next=cli('next-record-number',{projectsRoot:context.projectsRoot,type:'task',parentId:m.id});assert(next.number===3,'T3 allocation');
const thirdId=id(),criterion=id(),thirdPath=path.join(milestone,'t3-polish-summary.md'),clock=cli('activity-time',{});
const third=`---\nid: "${thirdId}"\ntype: task\nrecord_version: 2\ntitle: "Polish summary"\nowner: "${context.profile.user.email}"\ncreated_at: "${clock.recorded_at}"\nupdated_at: "${clock.recorded_at}"\ntask-state: not-started\nproject_id: "${p.id}"\nmilestone_id: "${m.id}"\n---\n# M1-T3 — Polish summary\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${m.id} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${p.id} -->\n\n## Requirements\n\nPolish summary.\n\n## Definition of Done\n\n- [ ] User reviewed polished summary. <!-- id: ${criterion} -->\n\n## Inputs\n\n- [Resume summary draft](outputs/resume-summary-draft.md).\n\n## Output and delivery\n\nSave a polished summary locally in outputs/ when executed.\n\n## Verification\n\nObtain the user's review of the polished summary.\n\n## Result\n\nNo polished summary has been produced or reviewed.\n`;
const cancelled=text(t1.path).replace('task-state: "not-started"','task-state: "cancelled"').replace(/updated_at: .*\r?\n/,`updated_at: "${clock.recorded_at}"\n`);
let ms=section(text(m.path),'Tasks',`- [ ] [[t2-update-resume|Update resume]] <!-- ref: ${t2.id} -->\n- [-] ~~[[t1-update-linkedin|Update LinkedIn]]~~ <!-- ref: ${t1.id} -->\n- [ ] [[t3-polish-summary|Polish summary]] <!-- ref: ${thirdId} -->`);
let ps=text(p.path);const lines=ps.split(/\r?\n/), l1=lines.find(l=>l.includes('ref: '+t1.id)),l2=lines.find(l=>l.includes('ref: '+t2.id));
ps=ps.replace(l1+'\r\n'+l2,l2+'\r\n'+l1.replace('[ ]','[-]').replace('[[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]]','~~[[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]]~~')+`\n| | [ ] [[m1-career-materials/t3-polish-summary\\|Polish summary]] <!-- ref: ${thirdId} --> | Polish summary. | Synthetic User | — |`);
batch('task.cancel-and-accept',[[t1.path,cancelled],[thirdPath,third],[m.path,ms],[p.path,ps]],[t1.id,thirdId],{before:{records:[{id:t1.id,type:'task',path:t1.path,project_id:p.id,milestone_id:m.id,state:t1.state}]},after:{records:[{id:t1.id,type:'task',path:t1.path,project_id:p.id,milestone_id:m.id,state:'cancelled'},{id:thirdId,type:'task',path:thirdPath,project_id:p.id,milestone_id:m.id,state:'not-started'}],acceptance:'Explicit user acceptance of Polish summary'}});
assert(cli('next-record-number',{projectsRoot:context.projectsRoot,type:'task',parentId:m.id}).number===4,'Retired T1 number reused');
const blockerIds=[];
function blocker(title,number,linked=[]){
 assert(cli('next-record-number',{projectsRoot:context.projectsRoot,type:'blocker',parentId:p.id}).number===number,'Blocker number');
 const bid=id(),time=cli('activity-time',{}),bp=path.join(project,`blockers/b${number}-${title.toLowerCase().replaceAll(' ','-')}.md`);
 const body=`---\nid: "${bid}"\ntype: blocker\nrecord_version: 2\ntitle: "${title}"\nblocker-state: open\nowner: "${context.profile.user.email}"\nproject_id: "${p.id}"\ncreated_at: "${time.recorded_at}"\nupdated_at: "${time.recorded_at}"\n---\n# ${title}\n\nExternal impediment: ${title.toLowerCase()}.\n\n## Resolution condition\n\n${title==='Await review'?'User supplies review.':title==='Await source'?'User supplies the remaining source.':'User supplies signoff.'}\n\n## Resolution evidence\n\nNo resolution reported.\n\n## Blocks\n\n${linked.map(r=>`- [[../m1-career-materials/${path.basename(r.path,'.md')}|${r.title}]] <!-- ref: ${r.id} -->`).join('\n')}\n`;
 const changes=[[bp,body],...linked.map(r=>[r.path,text(r.path)+`\n## Blocked by\n\n- [[../blockers/${path.basename(bp,'.md')}|${title}]] <!-- ref: ${bid} -->\n`])];
 batch('blocker.accepted-'+number,changes,[bid,...linked.map(r=>r.id)]);blockerIds.push(bid);return {id:bid,path:bp};
}
const b1=blocker('Await review',1),b2=blocker('Await source',2,[t1,t2]);
const resolveTime=cli('activity-time',{}),beforeB1=text(b1.path);
batch('blocker.resolved',[[b1.path,section(beforeB1.replace('blocker-state: open','blocker-state: resolved').replace(/updated_at: .*\n/,`updated_at: "${resolveTime.recorded_at}"\nresolved_at: "${resolveTime.activity_at}"\n`),'Resolution evidence','Resolved by the explicit synthetic user instruction in this acceptance scenario.')]],[b1.id],{before:{id:b1.id,type:'blocker',path:b1.path,project_id:p.id,state:'open'},after:{id:b1.id,type:'blocker',path:b1.path,project_id:p.id,state:'resolved'}});
const b3=blocker('Await signoff',3);
const renamed=path.join(milestone,'outputs/career-headline-draft.md');
const changedLinks=inspect().records.filter(r=>text(r.path).includes('outputs/linkedin-headline-draft.md')).map(r=>[r.path,text(r.path).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md')]);
// The reference attachment and consuming deliverable also have incoming links.
changedLinks.push([attachment,text(attachment).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md')]);
changedLinks.push([out2,text(out2).replaceAll('(linkedin-headline-draft.md)','(career-headline-draft.md)')]);
batch('artifact.renamed',[[renamed,read(out1)],...changedLinks,[out1,null]],[t1.id,t2.id],{before:{path:out1},after:{path:renamed}});
const final=inspect(),links=cli('check-links',{records:final.records}),nav=cli('inspect-navigation',{projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot});
console.log('Links',JSON.stringify(links),'Navigation',JSON.stringify(nav));
const finalInventory=cli('project-index',{vaultRoot:vault,projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,forceRefresh:true});
cli('log-query',{projectsRoot:context.projectsRoot,limit:1000});
snapshot('after');
const findings={scenario:'milestone-workspace',initialLayout:true,distinctOriginals:hash(read(src1))!==hash(read(src2)),originalsPreserved:hash(read(src1))===hash(read(path.join(root,'attachments/a/source.txt')))&&hash(read(src2))===hash(read(path.join(root,'attachments/b/source.txt'))),sharedSingleCopy:fs.readdirSync(path.join(milestone,'inputs')).filter(n=>n==='career-style-guide.txt').length===1,flatHoldingAreas:['inputs','outputs'].every(n=>fs.readdirSync(path.join(milestone,n),{withFileTypes:true}).every(d=>d.isFile())),task2ConsumesInPlace:text(t2.path).includes('outputs/career-headline-draft.md')&&!fs.existsSync(path.join(milestone,'inputs/career-headline-draft.md')),twoOutputs:fs.readdirSync(path.join(milestone,'outputs')).length===2,attachmentExcluded:final.records.length===8&&finalInventory.inventory.tasks.length===3,stableNumbers:fs.existsSync(t1.path)&&fs.existsSync(t2.path)&&fs.existsSync(thirdPath),cancelled:final.records.find(r=>r.id===t1.id).state==='cancelled',reviewNotInferred:final.records.filter(r=>['task','milestone'].includes(r.type)).every(r=>r.criteria.every(c=>!c.checked)),blockersNumbered:[b1,b2,b3].every((r,i)=>path.basename(r.path).startsWith('b'+(i+1)+'-')),blockerShared:final.records.find(r=>r.id===b2.id).blocks.length===2&&[t1,t2].every(t=>final.records.find(r=>r.id===t.id).blocked_by.includes(b2.id)),links,navigation:nav};
save(path.join(scratch,'assertions.json'),JSON.stringify(findings,null,2));save(path.join(scratch,'actions.json'),JSON.stringify(actions,null,2));
console.log('Findings',JSON.stringify(findings));
