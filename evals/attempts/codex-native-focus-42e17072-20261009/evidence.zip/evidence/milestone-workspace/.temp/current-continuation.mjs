import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final/codex-home/plugins/cache/daily-tasks-runtime-guards-final/daily-tasks/0.3.3';
const project=path.join(vault,'Projects/job-search'), milestone=path.join(project,'m1-career-materials');
fs.mkdirSync(scratch,{recursive:true});
let seq=fs.readdirSync(scratch).filter(n=>/^\d+-.*-result.json$/.test(n)).length; const actions=[];
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>fs.existsSync(p)?fs.readFileSync(p):null;
const save=(p,b)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b);};
function cli(op,input){
 const stem=String(++seq).padStart(3,'0')+'-'+op, inputPath=path.join(scratch,stem+'-input.json');
 const args=[path.join(pkg,'bin/daily-tasks.mjs'),op];
 if(input!==undefined){save(inputPath,JSON.stringify(input,null,2));args.push('--input',inputPath);}
 const r=spawnSync(process.execPath,args,{encoding:'utf8'});
 save(path.join(scratch,stem+'-result.json'),JSON.stringify({command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2));
 if(r.status!==0)throw Error(op+': '+r.stderr);
 const value=JSON.parse(r.stdout);actions.push({op,inputPath:input===undefined?null:inputPath,result:stem+'-result.json'});return value;
}
function id(){const v=cli('new-id');return typeof v==='string'?v:v.id;}
const context=cli('resolve-context',{vaultRoot:vault});
save(path.join(scratch,'context.json'),JSON.stringify(context,null,2));
console.log('Context',JSON.stringify(context));
const inspect=()=>cli('inspect-records',{projectsRoot:context.projectsRoot});
const initial=inspect();
console.log('Initial inspection',JSON.stringify(initial));
save(path.join(scratch,'actions.json'),JSON.stringify(actions,null,2));
const t1=initial.records.find(r=>r.title==='Update LinkedIn'),t2=initial.records.find(r=>r.title==='Update resume'),m=initial.records.find(r=>r.type==='milestone'),p=initial.records.find(r=>r.type==='project');
const assert=(ok,msg)=>{if(!ok)throw Error(msg);};
assert(initial.diagnostics.length===0,'Initial diagnostics');
const snapshots=path.join(scratch,'snapshots');
function snapshot(label){for(const r of inspect().records)save(path.join(snapshots,label,path.relative(project,r.path)),read(r.path));}

function batch(label,changes,recordIds,details={}){
 const clock=cli('activity-time',{}),operationId=id(),eventId=id();
 const event={id:eventId,operation_id:operationId,action:label,record_ids:recordIds,actor:{kind:'agent',id:'codex'},...clock,original_words:'User explicitly authorized scenario 7 local workflow',...details};
 const files=changes.map(([file,bytes])=>({path:file,before:read(file)===null?null:hash(read(file)),after:bytes===null?null:hash(bytes)}));
 const checkpoint={schemaVersion:2,operation_id:operationId,contextBinding:context.planningBinding,event,files};
 const opPath=path.join(context.stateRoot,'operations',operationId+'.json');
 for(const [file] of changes){const b=read(file);if(b!==null)save(path.join(snapshots,label+'-before',path.relative(project,file)),b);}
 save(opPath,JSON.stringify(checkpoint,null,2));save(path.join(scratch,label+'-checkpoint.json'),JSON.stringify(checkpoint,null,2));
 changes.forEach(([file,bytes],i)=>{assert((read(file)===null?null:hash(read(file)))===files[i].before,'Concurrent edit');if(bytes===null)fs.unlinkSync(file);else save(file,bytes);});
 cli('invalidate-project-index',{vaultRoot:vault});
 const actual=inspect();const validation=cli('validate-records',{records:actual.records});
 save(path.join(scratch,label+'-validation.json'),JSON.stringify(validation,null,2));
 cli('log-append',{projectsRoot:context.projectsRoot,entry:event});
 cli('log-query',{projectsRoot:context.projectsRoot,action:label});
 const opts={vaultRoot:vault,operationPath:opPath};
 const verification=cli('operation-verify',opts);assert(verification.status==='verified',JSON.stringify(verification));
 const completion=cli('operation-complete',opts);console.log(label,JSON.stringify(completion));
 assert(!fs.existsSync(opPath),'Checkpoint remains pending');
 for(const [file,bytes] of changes)if(bytes!==null)save(path.join(snapshots,label+'-after',path.relative(project,file)),bytes);
 save(path.join(scratch,'actions.json'),JSON.stringify(actions,null,2));
}
const text=p=>read(p).toString('utf8');
const section=(s,name,body)=>s.replace(new RegExp('(## '+name+'\\r?\\n)[\\s\\S]*?(?=\\r?\\n## |$)'),'$1\n'+body+'\n');

const thirdRecord=initial.records.find(r=>r.title==='Polish summary'),thirdId=thirdRecord.id,thirdPath=thirdRecord.path;
const src1=path.join(milestone,'inputs/linkedin-source.txt'),src2=path.join(milestone,'inputs/resume-source.txt'),shared=path.join(milestone,'inputs/career-style-guide.txt');
const out1=path.join(milestone,'outputs/linkedin-headline-draft.md'),out2=path.join(milestone,'outputs/resume-summary-draft.md'),attachment=path.join(milestone,'inputs/copied-task-reference.md');
const originalEvent=JSON.parse(fs.readFileSync(path.join(scratch,'task.cancel-and-accept-checkpoint.json'))).event;
const correctedClock=cli('activity-time',{});
cli('log-append',{projectsRoot:context.projectsRoot,entry:{id:id(),operation_id:id(),action:'history.snapshot-correction',record_ids:[t1.id,thirdId],actor:{kind:'agent',id:'codex'},...correctedClock,corrects:originalEvent.id,before:originalEvent.before.records,after:originalEvent.after.records}});
let projectText=text(p.path),rows=projectText.split(/\r?\n/);
const row1=rows.find(l=>l.includes('ref: '+t1.id)),row2=rows.find(l=>l.includes('ref: '+t2.id));
const retired=row1.replace('[ ]','[-]').replace('[[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]]','~~[[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]]~~');
const first=rows.indexOf(row1);rows=rows.filter(l=>l!==row1&&l!==row2);rows.splice(first,0,row2,retired,'| | [ ] [[m1-career-materials/t3-polish-summary\\|Polish summary]] <!-- ref: '+thirdId+' --> | Polish summary. | Synthetic User | — |');
batch('project.view-corrected',[[p.path,rows.join('\n')]],[t1.id,t2.id,thirdId]);
const numbering=cli('next-record-number',{projectsRoot:context.projectsRoot,type:'task',parentId:m.id});
save(path.join(scratch,'numbering-limitation.json'),JSON.stringify(numbering,null,2));
const blockerIds=[];
function blocker(title,number,linked=[]){
 cli('next-record-number',{projectsRoot:context.projectsRoot,type:'blocker',parentId:p.id}); // Use explicit user-supplied b1/b2/b3 labels; preserve allocator conflict.
 const bid=id(),time=cli('activity-time',{}),bp=path.join(project,`blockers/b${number}-${title.toLowerCase().replaceAll(' ','-')}.md`);
 const body=`---\nid: "${bid}"\ntype: blocker\nrecord_version: 2\ntitle: "${title}"\nblocker-state: open\nowner: "${context.profile.user.email}"\nproject_id: "${p.id}"\ncreated_at: "${time.recorded_at}"\nupdated_at: "${time.recorded_at}"\n---\n# ${title}\n\nExternal impediment: ${title.toLowerCase()}.\n\n## Resolution condition\n\n${title==='Await review'?'User supplies review.':title==='Await source'?'User supplies the remaining source.':'User supplies signoff.'}\n\n## Resolution evidence\n\nNo resolution reported.\n\n## Blocks\n\n${linked.map(r=>`- [[../m1-career-materials/${path.basename(r.path,'.md')}|${r.title}]] <!-- ref: ${r.id} -->`).join('\n')}\n`;
 const changes=[[bp,body],...linked.map(r=>[r.path,text(r.path)+`\n## Blocked by\n\n- [[../blockers/${path.basename(bp,'.md')}|${title}]] <!-- ref: ${bid} -->\n`])];
 batch('blocker.accepted-'+number,changes,[bid,...linked.map(r=>r.id)]);blockerIds.push(bid);return {id:bid,path:bp};
}
const b1=blocker('Await review',1),b2=blocker('Await source',2,[t1,t2]);
const resolveTime=cli('activity-time',{}),beforeB1=text(b1.path);
batch('blocker.resolved',[[b1.path,section(beforeB1.replace('blocker-state: open','blocker-state: resolved').replace(/updated_at: .*\n/,`updated_at: "${resolveTime.recorded_at}"\nresolved_at: "${resolveTime.activity_at}"\n`),'Resolution evidence','Resolved by the explicit synthetic user instruction in this acceptance scenario.')]],[b1.id],{before:{id:b1.id,type:'blocker',path:b1.path,project_id:p.id,state:'open'},after:{id:b1.id,type:'blocker',path:b1.path,project_id:p.id,state:'resolved'}});
const b3=blocker('Await signoff',3);
const renamed=path.join(milestone,'outputs/career-headline-draft.md');
const changedLinks=inspect().records.filter(r=>text(r.path).includes('outputs/linkedin-headline-draft.md')).map(r=>[r.path,text(r.path).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md')]);
// The reference attachment and consuming deliverable also have incoming links.
changedLinks.push([attachment,text(attachment).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md')]);
changedLinks.push([out2,text(out2).replaceAll('(linkedin-headline-draft.md)','(career-headline-draft.md)')]);
batch('artifact.renamed',[[renamed,read(out1)],...changedLinks,[out1,null]],[t1.id,t2.id],{before:{id:t1.id,type:'task',path:t1.path,project_id:p.id,milestone_id:m.id},after:{id:t1.id,type:'task',path:t1.path,project_id:p.id,milestone_id:m.id},originalArtifact:out1,renamedArtifact:renamed});
const final=inspect(),links=cli('check-links',{records:final.records}),nav=cli('inspect-navigation',{projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot});
console.log('Links',JSON.stringify(links),'Navigation',JSON.stringify(nav));
const finalInventory=cli('project-index',{vaultRoot:vault,projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,forceRefresh:true});
cli('log-query',{projectsRoot:context.projectsRoot,limit:1000});
snapshot('after');
const findings={scenario:'milestone-workspace',initialLayout:true,distinctOriginals:hash(read(src1))!==hash(read(src2)),originalsPreserved:hash(read(src1))===hash(read(path.join(root,'attachments/a/source.txt')))&&hash(read(src2))===hash(read(path.join(root,'attachments/b/source.txt'))),sharedSingleCopy:fs.readdirSync(path.join(milestone,'inputs')).filter(n=>n==='career-style-guide.txt').length===1,flatHoldingAreas:['inputs','outputs'].every(n=>fs.readdirSync(path.join(milestone,n),{withFileTypes:true}).every(d=>d.isFile())),task2ConsumesInPlace:text(t2.path).includes('outputs/career-headline-draft.md')&&!fs.existsSync(path.join(milestone,'inputs/career-headline-draft.md')),twoOutputs:fs.readdirSync(path.join(milestone,'outputs')).length===2,attachmentExcluded:final.records.length===8&&finalInventory.inventory.tasks.length===3,stableNumbers:fs.existsSync(t1.path)&&fs.existsSync(t2.path)&&fs.existsSync(thirdPath),cancelled:final.records.find(r=>r.id===t1.id).state==='cancelled',reviewNotInferred:final.records.filter(r=>['task','milestone'].includes(r.type)).every(r=>r.criteria.every(c=>!c.checked)),blockersNumbered:[b1,b2,b3].every((r,i)=>path.basename(r.path).startsWith('b'+(i+1)+'-')),blockerShared:final.records.find(r=>r.id===b2.id).blocks.length===2&&[t1,t2].every(t=>final.records.find(r=>r.id===t.id).blocked_by.includes(b2.id)),links,navigation:nav};
save(path.join(scratch,'assertions.json'),JSON.stringify(findings,null,2));save(path.join(scratch,'actions.json'),JSON.stringify(actions,null,2));
console.log('Findings',JSON.stringify(findings));
