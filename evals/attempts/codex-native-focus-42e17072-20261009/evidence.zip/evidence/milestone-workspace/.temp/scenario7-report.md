# Scenario 7 native host workflow

Result: **FAIL**. 17 checks passed; 1 failed.

The requested local workspace actions were executed from the installed instructions. No prior attempts or regression tests were read. CLI inputs, raw stdout/stderr and exit codes, checkpoint copies, before/after bytes and log queries are retained in this case's .temp.

The failing check is history-aware allocation: the current agent authored the cancellation event with a nested records snapshot instead of a direct snapshot array. A script-only append correction was retained; the installed allocator still sees the ambiguous original event. This is an authoring failure in this run, and this receipt does not claim acceptance success. Explicit user-supplied b1/b2/b3 labels were used to finish the requested blocker actions.

- PASS — Initial numbered milestone and sibling tasks, empty flat holding folders
- PASS — Both distinct original files preserved byte for byte
- PASS — Shared input stored once and linked by both consumers
- PASS — Two outputs delivered; task2 consumes task1 output in place
- PASS — Flat holding areas
- PASS — Copied-ID task attachment excluded from canonical and planning inventories
- PASS — Distinct requirements and DoD preserved
- PASS — Output alone does not satisfy review DoD
- PASS — Task reorder, explicit cancellation, T3 acceptance and labels retained
- PASS — Retired task number unused
- PASS — B1 resolved, B2 open, subsequent B3 retained without reuse
- PASS — One B2 blocker links both originals reciprocally
- PASS — Rename preserves all unrelated bytes in every affected document
- PASS — Output rename preserves artifact bytes and repairs incoming links
- PASS — Navigation and managed links valid
- PASS — No pending operations remain
- FAIL — Installed allocator clean after historical snapshot correction
- PASS — All local project content inside project; disposable workflow and evidence in case .temp

All review criteria remain unchecked. No pending operation remains. Native activation is not inferred from packaging or CLI execution. Host model/version were not exposed; Node v24.19.0, win32.
