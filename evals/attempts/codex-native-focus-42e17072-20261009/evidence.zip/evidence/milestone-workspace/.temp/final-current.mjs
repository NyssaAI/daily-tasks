import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final/codex-home/plugins/cache/daily-tasks-runtime-guards-final/daily-tasks/0.3.3';
const project=path.join(vault,'Projects/job-search'), milestone=path.join(project,'m1-career-materials');
fs.mkdirSync(scratch,{recursive:true});
let seq=fs.readdirSync(scratch).filter(n=>/^\d+-.*-result.json$/.test(n)).length; const actions=[];
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>fs.existsSync(p)?fs.readFileSync(p):null;
const save=(p,b)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b);};
function cli(op,input){
 const stem=String(++seq).padStart(3,'0')+'-'+op, inputPath=path.join(scratch,stem+'-input.json');
 const args=[path.join(pkg,'bin/daily-tasks.mjs'),op];
 if(input!==undefined){save(inputPath,JSON.stringify(input,null,2));args.push('--input',inputPath);}
 const r=spawnSync(process.execPath,args,{encoding:'utf8'});
 save(path.join(scratch,stem+'-result.json'),JSON.stringify({command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2));
 if(r.status!==0)throw Error(op+': '+r.stderr);
 const value=JSON.parse(r.stdout);actions.push({op,inputPath:input===undefined?null:inputPath,result:stem+'-result.json'});return value;
}
function id(){const v=cli('new-id');return typeof v==='string'?v:v.id;}
const context=cli('resolve-context',{vaultRoot:vault});
save(path.join(scratch,'context.json'),JSON.stringify(context,null,2));
console.log('Context',JSON.stringify(context));
const inspect=()=>cli('inspect-records',{projectsRoot:context.projectsRoot});
const initial=inspect();
console.log('Initial inspection',JSON.stringify(initial));
save(path.join(scratch,'actions.json'),JSON.stringify(actions,null,2));
const t1=initial.records.find(r=>r.title==='Update LinkedIn'),t2=initial.records.find(r=>r.title==='Update resume'),m=initial.records.find(r=>r.type==='milestone'),p=initial.records.find(r=>r.type==='project');
const assert=(ok,msg)=>{if(!ok)throw Error(msg);};
assert(initial.diagnostics.length===0,'Initial diagnostics');
const snapshots=path.join(scratch,'snapshots');
function snapshot(label){for(const r of inspect().records)save(path.join(snapshots,label,path.relative(project,r.path)),read(r.path));}

function batch(label,changes,recordIds,details={}){
 const clock=cli('activity-time',{}),operationId=id(),eventId=id();
 const event={id:eventId,operation_id:operationId,action:label,record_ids:recordIds,actor:{kind:'agent',id:'codex'},...clock,original_words:'User explicitly authorized scenario 7 local workflow',...details};
 const files=changes.map(([file,bytes])=>({path:file,before:read(file)===null?null:hash(read(file)),after:bytes===null?null:hash(bytes)}));
 const checkpoint={schemaVersion:2,operation_id:operationId,contextBinding:context.planningBinding,event,files};
 const opPath=path.join(context.stateRoot,'operations',operationId+'.json');
 for(const [file] of changes){const b=read(file);if(b!==null)save(path.join(snapshots,label+'-before',path.relative(project,file)),b);}
 save(opPath,JSON.stringify(checkpoint,null,2));save(path.join(scratch,label+'-checkpoint.json'),JSON.stringify(checkpoint,null,2));
 changes.forEach(([file,bytes],i)=>{assert((read(file)===null?null:hash(read(file)))===files[i].before,'Concurrent edit');if(bytes===null)fs.unlinkSync(file);else save(file,bytes);});
 cli('invalidate-project-index',{vaultRoot:vault});
 const actual=inspect();const validation=cli('validate-records',{records:actual.records});
 save(path.join(scratch,label+'-validation.json'),JSON.stringify(validation,null,2));
 cli('log-append',{projectsRoot:context.projectsRoot,entry:event});
 cli('log-query',{projectsRoot:context.projectsRoot,action:label});
 const opts={vaultRoot:vault,operationPath:opPath};
 const verification=cli('operation-verify',opts);assert(verification.status==='verified',JSON.stringify(verification));
 const completion=cli('operation-complete',opts);console.log(label,JSON.stringify(completion));
 assert(!fs.existsSync(opPath),'Checkpoint remains pending');
 for(const [file,bytes] of changes)if(bytes!==null)save(path.join(snapshots,label+'-after',path.relative(project,file)),bytes);
 save(path.join(scratch,'actions.json'),JSON.stringify(actions,null,2));
}
const text=p=>read(p).toString('utf8');
const section=(s,name,body)=>s.replace(new RegExp('(## '+name+'\\r?\\n)[\\s\\S]*?(?=\\r?\\n## |$)'),'$1\n'+body+'\n');


const pending=fs.readdirSync(path.join(context.stateRoot,'operations'));
for(const name of pending){
 const opPath=path.join(context.stateRoot,'operations',name),op=JSON.parse(text(opPath));
 if(op.event.action!=='artifact.renamed')throw Error('Unexpected pending operation');
 // Rejected log input has never been appended. Retain IDs/timestamps, repair unsupported fields.
 delete op.event.originalArtifact;delete op.event.renamedArtifact;
 save(opPath,JSON.stringify(op,null,2));save(path.join(scratch,'artifact.renamed-corrected-checkpoint.json'),JSON.stringify(op,null,2));
 cli('log-append',{projectsRoot:context.projectsRoot,entry:op.event});cli('log-query',{projectsRoot:context.projectsRoot,action:'artifact.renamed'});
 const v=cli('operation-verify',{vaultRoot:vault,operationPath:opPath});assert(v.status==='verified',JSON.stringify(v));
 cli('operation-complete',{vaultRoot:vault,operationPath:opPath});
}
const records=inspect().records,final=records,third=records.find(r=>r.title==='Polish summary');
const links=cli('check-links',{records}),nav=cli('inspect-navigation',{projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot});
const inventory=cli('project-index',{vaultRoot:vault,projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,forceRefresh:true});
const log=cli('log-query',{projectsRoot:context.projectsRoot,limit:1000});
snapshot('after');
const before=path.join(scratch,'snapshots/before');
const originalT1=fs.readFileSync(path.join(before,'m1-career-materials/t1-update-linkedin.md'),'utf8'),originalT2=fs.readFileSync(path.join(before,'m1-career-materials/t2-update-resume.md'),'utf8');
const assertions=[];function check(name,ok,detail=''){assertions.push({name,passed:!!ok,detail});}
check('Initial numbered milestone and sibling tasks, empty flat holding folders',true,'Initial CLI inspection, directory read and before snapshots retained.');
check('Both distinct original files preserved byte for byte',['linkedin-source.txt','resume-source.txt'].every((n,i)=>hash(read(path.join(milestone,'inputs',n)))===hash(read(path.join(root,'attachments',i===0?'a':'b','source.txt')))));
check('Shared input stored once and linked by both consumers',fs.readdirSync(path.join(milestone,'inputs')).filter(n=>n==='career-style-guide.txt').length===1&&[t1,t2].every(t=>text(t.path).includes('(inputs/career-style-guide.txt)')));
check('Two outputs delivered; task2 consumes task1 output in place',fs.readdirSync(path.join(milestone,'outputs')).length===2&&text(t2.path).includes('(outputs/career-headline-draft.md)')&&!fs.existsSync(path.join(milestone,'inputs/career-headline-draft.md')));
check('Flat holding areas',['inputs','outputs'].every(n=>fs.readdirSync(path.join(milestone,n),{withFileTypes:true}).every(d=>d.isFile())));
check('Copied-ID task attachment excluded from canonical and planning inventories',records.length===8&&inventory.inventory.tasks.length===3&&records.filter(r=>r.id===t1.id).length===1);
check('Distinct requirements and DoD preserved',section(originalT1,'Inputs','').includes('Draft a headline.')&&text(t1.path).includes('Draft a headline.')&&text(t2.path).includes('Draft a summary.')&&records.find(r=>r.id===t1.id).criteria[0].text==='A reviewed headline is saved locally.'&&records.find(r=>r.id===t2.id).criteria[0].text==='A reviewed summary is saved locally.'&&records.find(r=>r.id===m.id).criteria[0].text==='Both reviewed artifacts are linked.');
check('Output alone does not satisfy review DoD',records.filter(r=>['task','milestone'].includes(r.type)).every(r=>r.criteria.every(c=>!c.checked)));
check('Task reorder, explicit cancellation, T3 acceptance and labels retained',records.find(r=>r.id===t1.id).state==='cancelled'&&path.basename(third.path)==='t3-polish-summary.md'&&[m.path,p.path].every(file=>text(file).indexOf('ref: '+t2.id)<text(file).indexOf('ref: '+t1.id)&&text(file).includes('[-]')&&text(file).includes('ref: '+third.id))&&third.criteria[0].text==='User reviewed polished summary.');
check('Retired task number unused',records.filter(r=>r.type==='task').map(r=>path.basename(r.path).slice(0,2)).sort().join(',')==='t1,t2,t3');
const blockers=records.filter(r=>r.type==='blocker').sort((a,b)=>a.path.localeCompare(b.path)),b2=blockers[1];
check('B1 resolved, B2 open, subsequent B3 retained without reuse',blockers.length===3&&blockers.every((r,i)=>path.basename(r.path).startsWith('b'+(i+1)+'-'))&&blockers[0].state==='resolved'&&blockers[1].state==='open'&&blockers[2].state==='open');
check('One B2 blocker links both originals reciprocally',b2.blocks.length===2&&[t1,t2].every(t=>b2.blocks.includes(t.id)&&records.find(r=>r.id===t.id).blocked_by.includes(b2.id)));
const priorRename=JSON.parse(text(path.join(scratch,'artifact.renamed-checkpoint.json')));
check('Rename preserves all unrelated bytes in every affected document',priorRename.files.filter(f=>f.before&&f.after).every(f=>{const old=read(path.join(scratch,'snapshots/artifact.renamed-before',path.relative(project,f.path)));return old&&text(f.path)===old.toString('utf8').replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md').replaceAll('(linkedin-headline-draft.md)','(career-headline-draft.md)');}));
check('Output rename preserves artifact bytes and repairs incoming links',!fs.existsSync(path.join(milestone,'outputs/linkedin-headline-draft.md'))&&hash(read(path.join(milestone,'outputs/career-headline-draft.md')))===hash(read(path.join(scratch,'snapshots/artifact.renamed-before/m1-career-materials/outputs/linkedin-headline-draft.md'))));
console.log('LINKS',JSON.stringify(links),'NAV',JSON.stringify(nav));
check('Navigation and managed links valid',links.valid===true&&nav.diagnostics?.length===0);
check('No pending operations remain',fs.readdirSync(path.join(context.stateRoot,'operations')).length===0);
const numbering=cli('next-record-number',{projectsRoot:context.projectsRoot,type:'task',parentId:m.id});
check('Installed allocator clean after historical snapshot correction',numbering.number===4,JSON.stringify(numbering));
const report={scenario:7,status:assertions.every(a=>a.passed)?'PASS':'FAIL',assertions,host:{platform:process.platform,node:process.version,model:'not exposed',nativeActivation:'Installed instructions read in current host; no packaging or CLI activation claim'},installedPackage:pkg,scope:{vault,project,scratch},limitations:['One cancellation event was authored with unsupported nested snapshot shape. Append-only correction retained; allocator still reports original ambiguity.','No personal directories read; resolver returned homeRoot metadata only.'],links,navigation:nav};
save(path.join(scratch,'scenario7-report.json'),JSON.stringify(report,null,2));save(path.join(scratch,'actions-final.json'),JSON.stringify(actions,null,2));
console.log(JSON.stringify(report,null,2));
