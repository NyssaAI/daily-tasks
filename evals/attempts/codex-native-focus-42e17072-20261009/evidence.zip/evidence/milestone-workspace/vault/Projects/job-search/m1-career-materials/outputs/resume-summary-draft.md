# Resume summary draft

Professional preparing career materials for a job search, with a consistent headline and concise resume summary.

Draft uses the supplied synthetic resume source, shared style guide and [LinkedIn headline](career-headline-draft.md) in place. Review pending.
