import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=process.cwd();
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final/codex-home/plugins/cache/daily-tasks-runtime-guards-final/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const hash=x=>createHash('sha256').update(x).digest('hex');
const save=(p,x)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof x==='string'?x:JSON.stringify(x,null,2));};
for(const name of ['02-no-profile','03-explicit-legacy','04-vault-only-legacy']){
 const dir=path.join(root,name), evidence=path.join(dir,'.temp');fs.mkdirSync(evidence,{recursive:true});let seq=0;
 const call=(op,input)=>{const stem=String(++seq).padStart(2,'0')+'-'+op;const args=[cli,op];if(input!==undefined){const p=path.join(evidence,stem+'.input.json');save(p,input);args.push('--input',p);}const r=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8'});save(path.join(evidence,stem+'.result.json'),{command:[process.execPath,...args],cwd:dir,exit:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(name+' '+op+' '+r.stderr);return JSON.parse(r.stdout);};
 const vault=path.join(dir,'vault'), project=path.join(vault,'Projects/job-search/project-index.md');
 let profilePath=name.startsWith('01')||name.startsWith('02')?path.join(dir,'common/.nyssaai/daily-tasks/profile.json'):path.join(vault,'.nyssa/daily-tasks/profile.json');
 const oldProfile=fs.existsSync(profilePath)?fs.readFileSync(profilePath):null;
 const before=fs.readFileSync(project,'utf8');save(path.join(evidence,'before-project.md'),before);if(oldProfile)fs.writeFileSync(path.join(evidence,'before-profile.json'),oldProfile);
 const contextInput={vaultRoot:vault,homeRoot:path.join(dir,'synthetic-home'),stateRoot:path.join(vault,'.nyssaai/daily-tasks')};
 if(name!=='04-vault-only-legacy')contextInput.profilePath=profilePath;
 const initial=call('resolve-context',contextInput);
 if(!oldProfile){const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};const valid=call('validate-profile',profile);if(!valid.valid)throw Error(JSON.stringify(valid));save(profilePath,profile);}
 const ctx=call('resolve-context',contextInput);save(path.join(evidence,'resolved-context.json'),ctx);if(!ctx.configured)throw Error(JSON.stringify(ctx));
 const records=call('inspect-records',{projectsRoot:ctx.projectsRoot});
 const pid=/^id: "([^"]+)"/m.exec(before)[1];const number=call('next-record-number',{projectsRoot:ctx.projectsRoot,type:'milestone',parentId:pid});if(number.number!==1)throw Error(JSON.stringify(number));
 const id=call('new-id').id, criterion=call('new-id').id, operation=call('new-id').id,eventId=call('new-id').id;
 const time=call('activity-time',{});const title='Update LinkedIn and resume',slug='m1-update-linkedin-and-resume',folder=path.join(path.dirname(project),slug),file=path.join(folder,slug+'.md');
 const markdown=`---\nid: ${id}\ntype: milestone\nrecord_version: 2\ntitle: "${title}"\ndocument-maturity: reviewed\nmilestone-state: not-started\nowner: "synthetic@example.test"\nproject_id: "${pid}"\ncreated_at: "${time.recorded_at}"\nupdated_at: "${time.recorded_at}"\n---\n# M1 — ${title}\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${pid} -->\n\n## Outcome\n\nUpdate LinkedIn and resume for the job search.\n\n## Definition of Done\n\n- [ ] Reviewed career materials. <!-- id: ${criterion} -->\n\n## Tasks\n\nNo tasks accepted.\n`;
 const after=before.replace(/^updated_at:.*$/m,`updated_at: "${time.recorded_at}"`).replace('No milestones yet.',`- [[${slug}/${slug}|M1 — ${title}]] <!-- ref: ${id} -->`);
 const event={id:eventId,operation_id:operation,action:'create-milestone',record_ids:[id],actor:{kind:'person',id:'synthetic@example.test'},...time,original_words:'Create M1: update LinkedIn and resume in this project; DoD reviewed career materials; no extra tasks.',before:{milestone:null},after:{id,type:'milestone',path:file,project_id:pid,title,acceptance_source:'Direct accepted user request'}};
 const checkpoint={schemaVersion:2,operation_id:operation,contextBinding:ctx.planningBinding,event,files:[{path:project,before:hash(before),after:hash(after)},{path:file,before:null,after:hash(markdown)}]};
 const operationPath=path.join(ctx.stateRoot,'operations',operation+'.json');save(operationPath,checkpoint);save(path.join(evidence,'checkpoint.json'),checkpoint);
 if(fs.readFileSync(project,'utf8')!==before||fs.existsSync(file))throw Error('Concurrent change');
 save(file,markdown);fs.mkdirSync(path.join(folder,'inputs'),{recursive:true});fs.mkdirSync(path.join(folder,'outputs'),{recursive:true});save(project,after);
 call('inspect-records',{projectsRoot:ctx.projectsRoot});call('inspect-navigation',{projectsRoot:ctx.projectsRoot});
 call('log-append',{projectsRoot:ctx.projectsRoot,entry:event});call('log-query',{projectsRoot:ctx.projectsRoot,recordId:id});
 call('invalidate-project-index',{vaultRoot:ctx.vaultRoot});
 const verify=call('operation-verify',{...contextInput,operationPath});const complete=call('operation-complete',{...contextInput,operationPath});
 save(path.join(evidence,'after-project.md'),after);save(path.join(evidence,'after-milestone.md'),markdown);fs.copyFileSync(profilePath,path.join(evidence,'after-profile.json'));
 const summary={name,initial,configRoot:ctx.configRoot,stateRoot:ctx.stateRoot,projectsRoot:ctx.projectsRoot,dailyPlansRoot:ctx.dailyPlansRoot,profileBytesRetained:oldProfile?oldProfile.equals(fs.readFileSync(profilePath)):null,milestone:file,verify,complete};save(path.join(evidence,'summary.json'),summary);console.log(JSON.stringify(summary));
}
