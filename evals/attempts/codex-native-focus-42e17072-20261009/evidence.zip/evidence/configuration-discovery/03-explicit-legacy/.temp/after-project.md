---
id: "01a12125-84da-767f-85fe-ac147d7ce5e7"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:09.455Z"
updated_at: "2026-10-09T17:15:39.409Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — Update LinkedIn and resume]] <!-- ref: 01a121a9-cf5e-7cc5-84a7-fc9adcf665a2 -->
