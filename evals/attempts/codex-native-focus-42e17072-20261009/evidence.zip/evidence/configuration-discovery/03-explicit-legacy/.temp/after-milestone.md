---
id: 01a121a9-cf5e-7cc5-84a7-fc9adcf665a2
type: milestone
record_version: 2
title: "Update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-84da-767f-85fe-ac147d7ce5e7"
created_at: "2026-10-09T17:15:39.409Z"
updated_at: "2026-10-09T17:15:39.409Z"
---
# M1 — Update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-84da-767f-85fe-ac147d7ce5e7 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] Reviewed career materials. <!-- id: 01a121a9-cf89-7259-bd22-90555e65912d -->

## Tasks

No tasks accepted.
