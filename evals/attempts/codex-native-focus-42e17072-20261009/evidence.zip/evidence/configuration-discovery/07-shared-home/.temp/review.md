Open projects: 1          Open tasks: 1          Late tasks: 0

America/Chicago — 2026.10.09

Already selected: none.

## Available tasks

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | update LinkedIn and resume | Routing note | — |

Reply by row number and symbol or description:

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled

Decision supplied: select Routing note today.
