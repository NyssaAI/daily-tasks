---
id: 01a121aa-8bb6-73ff-91bb-19aaf07bc3f5
type: task
record_version: 2
title: "Routing note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
milestone_id: "01a121aa-8b89-7beb-a242-7c418e147d6b"
created_at: "2026-10-09T17:16:27.154Z"
updated_at: "2026-10-09T17:16:27.154Z"
---
# M1-T1 — Routing note

**Milestone:** [[m1-update-linkedin-and-resume|update LinkedIn and resume]] <!-- ref: 01a121aa-8b89-7beb-a242-7c418e147d6b -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Requirements

local routing test note

## Definition of Done

- [ ] reviewed routing note <!-- id: 01a121aa-8c12-7415-9ccf-e8cdae1f0590 -->

## Verification

Review the local routing test note against the requirement and record review evidence before completion.
