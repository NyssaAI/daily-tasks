---
id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:11.958Z"
updated_at: "2026-10-09T14:51:11.958Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

No milestones yet.
