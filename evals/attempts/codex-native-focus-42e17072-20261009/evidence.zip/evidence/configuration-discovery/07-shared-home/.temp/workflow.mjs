import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=process.cwd(), tmp=path.join(root,'.temp'), bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final/codex-home/plugins/cache/daily-tasks-runtime-guards-final/daily-tasks/0.3.3', cli=path.join(bundle,'bin/daily-tasks.mjs');
let seq=0;
export function write(p,s){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);}
export function json(p,o){write(p,JSON.stringify(o,null,2)+'\n');}
export function call(op,input){const stem=path.join(tmp,`${Date.now()}-${seq++}-${op}`); if(input)json(stem+'.input.json',input); const args=[cli,op,...(input?['--input',stem+'.input.json']:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});json(stem+'.execution.json',{args,status:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
export const id=()=>{const r=call('new-id');return typeof r==='string'?r:r.id;};
export const vault=path.join(root,'vault-a'), projects=path.join(vault,'Projects'), home=path.join(root,'synthetic-home'), config=path.join(home,'.nyssaai/daily-tasks'), profilePath=path.join(config,'profile.json');
export const ctxInput={vaultRoot:vault,homeRoot:home,profilePath};
