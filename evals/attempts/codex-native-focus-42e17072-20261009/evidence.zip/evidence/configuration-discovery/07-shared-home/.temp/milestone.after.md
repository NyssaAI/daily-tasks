---
id: 01a121aa-8b89-7beb-a242-7c418e147d6b
type: milestone
record_version: 2
title: "update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
created_at: "2026-10-09T17:16:27.154Z"
updated_at: "2026-10-09T17:16:27.154Z"
---
# M1 — update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] reviewed career materials <!-- id: 01a121aa-8be3-7655-b9bf-fddd42d6870a -->

## Tasks

- [ ] [[t1-routing-note|Routing note]] <!-- ref: 01a121aa-8bb6-73ff-91bb-19aaf07bc3f5 -->
