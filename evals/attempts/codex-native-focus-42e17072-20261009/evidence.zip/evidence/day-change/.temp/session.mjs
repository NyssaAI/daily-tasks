import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), evidence=path.join(root,'.temp'), pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final/codex-home/plugins/cache/daily-tasks-runtime-guards-final/daily-tasks/0.3.3';
let seq=fs.existsSync(path.join(evidence,'sequence.json'))?JSON.parse(fs.readFileSync(path.join(evidence,'sequence.json'))):0;
export const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
export const write=(p,t)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,t);};
export const hash=t=>t===null?null:crypto.createHash('sha256').update(t).digest('hex');
export function cli(op,input){const label=String(++seq).padStart(3,'0')+'-'+op; const f=path.join(evidence,label+'.input.json');if(input)write(f,JSON.stringify(input,null,2));const args=[pkg+'/bin/daily-tasks.mjs',op,...(input?['--input',f]:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(path.join(evidence,label+'.result.json'),JSON.stringify({args,exit:r.status,stdout:r.stdout,stderr:r.stderr},null,2));write(path.join(evidence,'sequence.json'),JSON.stringify(seq));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const id=()=>{const r=cli('new-id');return typeof r==='string'?r:r.id;};
export const monday='2026-10-05T16:00:00Z',tuesday='2026-10-06T16:00:00Z',friday='2026-10-09T16:00:00Z';
export const opts=(v,now)=>({vaultRoot:v,profilePath:path.join(v,'.nyssaai/daily-tasks/profile.json'),now});
export const prepare=(v,now)=>cli('planning-prepare',opts(v,now));
export function event(now,action,ids,after){const time=cli('activity-time',{now});return {id:id(),operation_id:id(),action,record_ids:ids,actor:{kind:'person',id:'synthetic@example.test'},...time,after};}
export function transaction(p,changes,ev,extra={}){const files=changes.map(c=>({path:c.path,before:hash(read(c.path)),after:hash(c.text)}));const op={schemaVersion:2,operation_id:ev.operation_id,contextBinding:p.context.planningBinding,event:ev,files,...extra};const opPath=path.join(p.context.stateRoot,'operations',ev.operation_id+'.json');write(opPath,JSON.stringify(op,null,2));write(path.join(evidence,ev.operation_id+'.checkpoint.json'),JSON.stringify(op,null,2));for(const c of changes){const before=read(c.path);write(path.join(evidence,ev.operation_id,path.basename(c.path)+'.before'),before??'<absent>');write(c.path,c.text);write(path.join(evidence,ev.operation_id,path.basename(c.path)+'.after'),c.text);}cli('invalidate-project-index',{vaultRoot:p.context.vaultRoot});return {op,opPath};}
export function finish(p,t,rollover=false){cli('log-append',{projectsRoot:p.context.projectsRoot,entry:t.op.event});cli('log-query',{projectsRoot:p.context.projectsRoot});cli('operation-verify',{...opts(p.context.vaultRoot,p.context.now),operationPath:t.opPath});const r=cli(rollover?'rollover-complete':'operation-complete',{...opts(p.context.vaultRoot,p.context.now),operationPath:t.opPath});console.log(JSON.stringify(r));return r;}
if(process.argv[2]==='prepare'){console.log(JSON.stringify(prepare(path.join(root,'vault'),monday),null,2));}
