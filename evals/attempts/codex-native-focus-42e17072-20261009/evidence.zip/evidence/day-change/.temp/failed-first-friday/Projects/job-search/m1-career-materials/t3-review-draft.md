---
id: "01a121a9-af49-728f-9c33-dc5daf6d291f"
type: "task"
record_version: 2
title: "Review draft"
owner: "synthetic@example.test"
assignee: "Reviewer"
created_at: "2026-10-05T16:00:00.000Z"
updated_at: "2026-10-05T16:00:00.000Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: "reviewed"
---
# M1-T3 — Review draft

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

inspect draft.

## Definition of Done

- [ ] recorded review. <!-- id: 01a121a9-af77-7f95-a59d-73126654f1c5 -->

## Inputs

Synthetic fixture; no supplied files.

## Output and delivery

Record the review in this task.

## Verification

Inspect the draft/result and record review evidence.

## Result

No execution or review reported.
