import path from 'node:path';import assert from 'node:assert/strict';
import {read,write,hash,cli,prepare,finish,opts} from './session.mjs';
const s=JSON.parse(read(path.resolve('.temp/stopped-operation.json'))),op=JSON.parse(read(s.opPath));const p=prepare(s.vault,s.now);
assert.ok(p.pendingOperations.length);assert.equal(read(p.state.rollover.path),null);
const actual={},changes=[];for(const f of op.files){actual[f.path]=hash(read(f.path));changes.push({key:f.path,before:{present:true,value:f.before},after:{present:true,value:f.after}});}
const recovered=cli('recover-operation',{operation:{changes},actual});write(path.resolve('.temp/process-recovery-classification.json'),JSON.stringify(recovered,null,2));
const prior=cli('log-query',{projectsRoot:p.context.projectsRoot});assert.equal(prior.entries.filter(e=>e.operation_id===op.operation_id).length,0);
const r=finish(p,{op,opPath:s.opPath},true);assert.equal(r.status,'completed');
const receiptBefore=read(p.state.rollover.path),q=prepare(s.vault,s.now);assert.equal(q.rollover.status,'complete');assert.equal(q.current.rows.length,2);assert.equal(new Set(q.current.rows.map(r=>r.id)).size,2);
const retry=cli('log-append',{projectsRoot:p.context.projectsRoot,entry:op.event});const logs=cli('log-query',{projectsRoot:p.context.projectsRoot});const entries=logs.entries.filter(e=>e.operation_id===op.operation_id);assert.equal(entries.length,1);assert.deepEqual(entries[0],op.event);assert.equal(read(p.state.rollover.path),receiptBefore);
write(path.resolve('.temp/process-interruption.assertions.json'),JSON.stringify({processExitedWithPendingCheckpoint:true,noPrematureReceipt:true,recovered,completion:r,retry,exactEvent:entries[0],sameReceiptAfterRetry:true,uniqueRows:2},null,2));
