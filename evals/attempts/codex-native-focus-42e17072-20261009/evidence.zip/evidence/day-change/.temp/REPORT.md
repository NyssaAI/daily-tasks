# Scenario 4 — Day change

All requested outcome assertions passed in the current-host, skill-authored synthetic workflows.

- Friday creates only the missing Friday managed plan after skipped days; A and delegated C carry from Monday. D/E stay historical on Monday; F stays out. No scheduling or duration fitting was performed.
- Independent Tuesday retains B and its original plan identity/creation time, carries A once, and preserves explicit A removal on repeat.
- A separate process exited after rollover destination persistence. Completion was rejected before logging; no false receipt existed. A new process recovered the saved operation and original event IDs/times. Retry retained two unique rows, one exact event, and the same receipt.
- Explicit future Tuesday removal remains in pending removedIds and is honored by Tuesday's no-change rollover receipt.

Two failed fixture/workflow attempts are retained with CLI errors and pending state: an incorrect missing-plan membership checkpoint, and an invalid dual-active-date fixture. Corrected independent runs are retained; failures were not erased or relabeled.

Evidence: numbered CLI input/result files, operation checkpoint copies, before/after bytes, state snapshots, log-query results, installed instruction hashes, and per-branch assertion JSON. Session code was authored during this request; no prior scripts or regression tests were read or run.

The unrelated original Friday checkbox remains an unaccepted candidate. Check-in state retains that pending decision. Host authentication/version and independent native discovery were not exposed, so this is current-host workflow evidence, not a release-level authenticated-host certification.
