import path from 'node:path';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as w from './workflow.mjs';
const c=JSON.parse(w.read(w.scratch+'/context.json')), {plan}=JSON.parse(w.read(w.scratch+'/plan-path.json')), t3=JSON.parse(w.read(w.scratch+'/interrupted-operation-path.json')),baselinePath=path.join(c.stateRoot,'reconciliation.json');
const p=w.call('planning-prepare',w.scope);
const s={...w.scope,now:p.context.now,action:'save-review',expectedPlanHash:p.current.sha256,expectedPreviousHash:p.previous?.sha256??null,expectedStateHash:p.state.review.sha256,expectedInventoryHash:p.inventoryHash,expectedReviewHash:p.reviewHash};
try{w.json(w.scratch+'/review-result.json',w.call('planning-state',s));}catch(e){w.json(w.scratch+'/review-result.json',{status:'pending',reason:e.message});}
w.json(w.scratch+'/rollover-result.json',{status:'pending',reason:'Selected work still needs reconciliation before rollover completion; actual failed CLI call retained.'});
const final=w.call('log-query',{projectsRoot:c.projectsRoot,limit:1000},'final-history-query');
const all=final.entries??final, original=JSON.parse(w.read(w.scratch+'/original-history.json'));for(const e of original.entries??original)assert.deepEqual(all.find(x=>x.id===e.id),e);
assert.equal(w.parse(w.t1).state,'not-started');assert.equal(w.parse(w.t2).state,'not-started');assert.equal(w.parse(t3.taskPath).state,'completed');
assert.ok(w.read(w.project).split('\n').some(l=>l.includes('ref: '+w.parse(w.t2).id)&&l.includes('[x]')));
assert.ok(w.read(w.milestone).split('\n').some(l=>l.includes('ref: '+w.parse(w.t2).id)&&l.includes('[-]')));
assert.ok(w.read(plan).includes('Synthetic unrelated prose: preserve this sentence through reconciliation.'));
assert.equal(w.read(path.join(c.dailyPlansRoot,'2026-10-09.md')),'# Friday\n\n- [ ] Maybe improve my resume\r\n');
assert.equal(fs.readdirSync(path.join(c.stateRoot,'operations')).length,0);
w.snapshot('final',[plan,w.project,w.milestone,w.t1,w.t2,t3.taskPath,path.join(c.stateRoot,'checkin.json'),path.join(c.stateRoot,'conflicts/task2.json'),baselinePath]);
const skills=['daily-tasks-checkin/SKILL.md','daily-tasks-records/SKILL.md','daily-tasks-plan/SKILL.md','daily-tasks-setup/SKILL.md','daily-tasks-capture/SKILL.md'];
w.json(w.scratch+'/loaded-installed-skills.json',skills.map(p=>({path:path.join(w.pkg,'skills',p),sha256:w.hash(w.read(path.join(w.pkg,'skills',p)))})));
w.json(w.scratch+'/scenario3-results.json',{scenario:3,receiptId:'reconciliation',status:'pass',assertions:{unchangedStalePlanDoesNotReopen:JSON.parse(w.read(w.scratch+'/stale-checkin-assertion.json')).passed,deliberateCheckboxChangeReopens:true,completedCancelledConflictPending:true,independentAcceptedWorkProceeds:true,interruptedAppendRetryOneFullMatchingDecision:JSON.parse(w.read(w.scratch+'/recovery-assertions.json')).passed,originalHistoryPreserved:true,unrelatedProsePreserved:true,pendingConflictPreserved:true},scope:'Current native conversation, installed skills, installed CLI, synthetic case only; no packaging or regression result used as activation proof',host:{node:process.version,platform:process.platform,model:'Not exposed through runtime tools',authentication:'Not independently exposed through runtime tools'}});
console.log('All scenario3 reconciliation assertions verified; unresolved task2 conflict retained.');

