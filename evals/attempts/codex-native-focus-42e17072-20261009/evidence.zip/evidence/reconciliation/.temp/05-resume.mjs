import path from 'node:path';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as w from './workflow.mjs';
const c=JSON.parse(w.read(w.scratch+'/context.json')),pending=JSON.parse(w.read(w.scratch+'/interrupted-operation-path.json')),op=JSON.parse(w.read(pending.operationPath));
const recovery=w.call('recover-operation',{operation:op,actual:{'task3.state':w.parse(pending.taskPath).state}},'resume-field-effects');assert.equal(recovery.status,'already-applied');
const beforeQuery=w.call('log-query',{projectsRoot:c.projectsRoot,recordId:pending.taskId,action:'complete',limit:1000},'resume-log-query');
const entries=beforeQuery.entries??beforeQuery;const matches=entries.filter(e=>e.operation_id===op.operation_id);assert.equal(matches.length,1);assert.deepEqual(matches[0],op.event);
// Exactly one explicit retry, preserving the entire saved event payload.
const retry=w.call('log-append',{projectsRoot:c.projectsRoot,entry:op.event},'exact-payload-retry-once');
const verify=w.call('operation-verify',{...w.scope,operationPath:pending.operationPath});assert.equal(verify.status,'verified');
const complete=w.call('operation-complete',{...w.scope,operationPath:pending.operationPath});assert.equal(complete.status,'completed');assert.equal(fs.existsSync(pending.operationPath),false);
const afterQuery=w.call('log-query',{projectsRoot:c.projectsRoot,recordId:pending.taskId,action:'complete',limit:1000},'after-retry-query');const after=afterQuery.entries??afterQuery;assert.equal(after.filter(e=>e.operation_id===op.operation_id).length,1);assert.deepEqual(after.find(e=>e.operation_id===op.operation_id),op.event);
w.json(w.scratch+'/recovery-assertions.json',{passed:true,recovery,retry,complete,matchingDecisionCount:1,fullPayloadMatched:true});
w.json(path.join(c.stateRoot,'candidates.json'),{schemaVersion:1,candidates:[{id:'maybe-improve-resume',source:path.join(c.dailyPlansRoot,'2026-10-09.md'),sourceKey:'Maybe improve my resume',title:'Maybe improve my resume',disposition:'pending acceptance',reason:'Original unidentified checkbox; does not create another accepted task.'}]});
w.json(path.join(c.stateRoot,'checkin.json'),{localDay:c.localDate,planningBinding:c.planningBinding,pendingOperationIds:[],unresolvedConflictIds:['task2-status-conflict'],unresolvedCandidateIds:['maybe-improve-resume'],nextStep:'Await explicit choice for task2 competing completed/cancelled edits; candidate remains unaccepted.',processedSourceVersions:{[w.project]:w.hash(w.read(w.project)),[w.milestone]:w.hash(w.read(w.milestone))}});
console.log('Resumed checkpoint; one exact matching decision remains after one full-payload retry.');
