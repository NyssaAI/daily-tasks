import path from 'node:path';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as w from './workflow.mjs';
const c=JSON.parse(w.read(w.scratch+'/context.json')), {plan}=JSON.parse(w.read(w.scratch+'/plan-path.json')), t3=JSON.parse(w.read(w.scratch+'/interrupted-operation-path.json'));
// Enroll the independent record without advancing task2's conflicted baseline.
const baselinePath=path.join(c.stateRoot,'reconciliation.json'),before=w.read(baselinePath),value=JSON.parse(before),r=w.parse(t3.taskPath),m=w.parse(w.milestone);
value.records[r.id]={canonical:{id:r.id,type:r.type,state:r.state},views:{}};
for(const p of [w.project,w.milestone])value.records[r.id].views[p]={hash:w.hash(w.read(p)),selected:true,checked:true};
value.records[m.id]={canonical:{id:m.id,type:m.type,state:m.state},views:{[w.project]:{hash:w.hash(w.read(w.project)),selected:true,checked:false}}};
const ev=w.event('enroll-independent-baselines',[r.id,m.id],{enrolled:false},{enrolled:true,reason:'Enroll accepted independent work and existing unchanged parent; preserve pending task2 baseline.'});
const op=w.checkpoint(c,ev,[[t3.taskPath,w.read(t3.taskPath)],[w.milestone,w.read(w.milestone)],[w.project,w.read(w.project)]],{beforeHash:w.hash(before),beforeText:before,value});w.finish(c,op);
const scan=w.call('inspect-records',{projectsRoot:c.projectsRoot});w.call('validate-records',{records:scan.records});w.call('check-links',{records:scan.records});w.call('inspect-navigation',{projectsRoot:c.projectsRoot,dailyPlansRoot:c.dailyPlansRoot});
w.call('maintenance-inspect',w.scope);
function state(action){const p=w.call('planning-prepare',w.scope);const s={...w.scope,now:p.context.now,action,expectedPlanHash:p.current.sha256,expectedPreviousHash:p.previous?.sha256??null,expectedStateHash:action==='save-review'?p.state.review.sha256:p.state.rollover.sha256,expectedInventoryHash:p.inventoryHash,...(action==='save-review'?{expectedReviewHash:p.reviewHash}:{})};return w.call('planning-state',s);}
w.json(w.scratch+'/rollover-result.json',state('complete-rollover'));w.json(w.scratch+'/review-result.json',state('save-review'));
const final=w.call('log-query',{projectsRoot:c.projectsRoot,limit:1000},'final-history-query');
const all=final.entries??final, original=JSON.parse(w.read(w.scratch+'/original-history.json'));for(const e of original.entries??original)assert.deepEqual(all.find(x=>x.id===e.id),e);
assert.equal(w.parse(w.t1).state,'not-started');assert.equal(w.parse(w.t2).state,'not-started');assert.equal(w.parse(t3.taskPath).state,'completed');
assert.ok(w.read(w.project).split('\n').some(l=>l.includes('ref: '+w.parse(w.t2).id)&&l.includes('[x]')));
assert.ok(w.read(w.milestone).split('\n').some(l=>l.includes('ref: '+w.parse(w.t2).id)&&l.includes('[-]')));
assert.ok(w.read(plan).includes('Synthetic unrelated prose: preserve this sentence through reconciliation.'));
assert.equal(w.read(path.join(c.dailyPlansRoot,'2026-10-09.md')),'# Friday\n\n- [ ] Maybe improve my resume\n\n'.replace(/\n/g,'\r\n'));
assert.equal(fs.readdirSync(path.join(c.stateRoot,'operations')).length,0);
w.snapshot('final',[plan,w.project,w.milestone,w.t1,w.t2,t3.taskPath,path.join(c.stateRoot,'checkin.json'),path.join(c.stateRoot,'conflicts/task2.json'),baselinePath]);
const skills=['daily-tasks-checkin/SKILL.md','daily-tasks-records/SKILL.md','daily-tasks-plan/SKILL.md','daily-tasks-setup/SKILL.md','daily-tasks-capture/SKILL.md'];
w.json(w.scratch+'/loaded-installed-skills.json',skills.map(p=>({path:path.join(w.pkg,'skills',p),sha256:w.hash(w.read(path.join(w.pkg,'skills',p)))})));
w.json(w.scratch+'/scenario3-results.json',{scenario:3,receiptId:'reconciliation',status:'pass',assertions:{unchangedStalePlanDoesNotReopen:JSON.parse(w.read(w.scratch+'/stale-checkin-assertion.json')).passed,deliberateCheckboxChangeReopens:true,completedCancelledConflictPending:true,independentAcceptedWorkProceeds:true,interruptedAppendRetryOneFullMatchingDecision:JSON.parse(w.read(w.scratch+'/recovery-assertions.json')).passed,originalHistoryPreserved:true,unrelatedProsePreserved:true,pendingConflictPreserved:true},scope:'Current native conversation, installed skills, installed CLI, synthetic case only; no packaging or regression result used as activation proof',host:{node:process.version,platform:process.platform,model:'Not exposed through runtime tools',authentication:'Not independently exposed through runtime tools'}});
console.log('All scenario3 reconciliation assertions verified; unresolved task2 conflict retained.');
