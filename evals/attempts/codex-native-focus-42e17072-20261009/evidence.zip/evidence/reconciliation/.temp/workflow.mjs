import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final/codex-home/plugins/cache/daily-tasks-runtime-guards-final/daily-tasks/0.3.3';
export const cli=path.join(pkg,'bin/daily-tasks.mjs');
export const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
export const hash=t=>t===null?null:crypto.createHash('sha256').update(t).digest('hex');
export function write(p,t){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,t);}
export const json=(p,o)=>write(p,JSON.stringify(o,null,2)+'\n');
export function call(name,input,label=name){const n=fs.readdirSync(scratch).filter(x=>/-execution[.]json$/.test(x)).length+1;const stem=path.join(scratch,`${String(n).padStart(3,'0')}-${label}`); const inp=stem+'-input.json';json(inp,input);const args=[cli,name,...(name==='new-id'?[]:['--input',inp])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});json(stem+'-execution.json',{executable:process.execPath,args,status:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const scope={vaultRoot:vault,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json')};
export const project=path.join(vault,'Projects/job-search/project-index.md'), milestone=path.join(vault,'Projects/job-search/m1-career-materials/m1-career-materials.md'), t1=path.join(path.dirname(milestone),'t1-update-linkedin.md'),t2=path.join(path.dirname(milestone),'t2-update-resume.md');
export const parse=p=>call('parse-record',{markdown:read(p),path:p});
export const id=()=>{const r=call('new-id',{});return r.id??r;};
export function snapshot(label,files){json(path.join(scratch,label+'.json'),Object.fromEntries(files.map(p=>[p,{sha256:hash(read(p)),text:read(p)}])));}
export function event(action,ids,before,after){const time=call('activity-time',{});return {id:id(),operation_id:id(),action,record_ids:ids,actor:{kind:'person',id:'synthetic@example.test'},...time,before,after};}
export function checkpoint(ctx,ev,edits,baseline){const files=edits.map(([p,t])=>({path:p,before:hash(read(p)),after:hash(t)}));const op={schemaVersion:2,operation_id:ev.operation_id,contextBinding:ctx.planningBinding,event:ev,files,...(baseline?{baseline}:{} )};const p=path.join(ctx.stateRoot,'operations',ev.operation_id+'.json');json(p,op);snapshot('before-'+ev.operation_id,edits.map(x=>x[0]));json(path.join(scratch,'checkpoint-'+ev.operation_id+'.json'),op);for(const [p,t]of edits){if(hash(read(p))!==files.find(f=>f.path===p).before)throw Error('changed source');write(p,t);}call('invalidate-project-index',{vaultRoot:vault});snapshot('after-'+ev.operation_id,edits.map(x=>x[0]));return p;}
export function finish(ctx,p){const op=JSON.parse(read(p));call('log-append',{projectsRoot:ctx.projectsRoot,entry:op.event});const v=call('operation-verify',{...scope,operationPath:p});if(v.status!=='verified')throw Error(JSON.stringify(v));return call('operation-complete',{...scope,operationPath:p});}

