import path from 'node:path';
import * as w from './workflow.mjs';
const c=JSON.parse(w.read(w.scratch+'/context.json')), a=w.parse(w.t1), b=w.parse(w.t2);
const history=w.call('log-query',{projectsRoot:c.projectsRoot,limit:1000});w.json(w.scratch+'/original-history.json',history);
const packet=w.call('planning-prepare',w.scope);w.json(w.scratch+'/initial-packet.json',packet);
const plan=path.join(c.dailyPlansRoot,c.localDate+'-daily-plan.md'), time=w.call('activity-time',{}), planId=w.id();
const text=`---\nid: "${planId}"\ntype: daily-plan\ntitle: "Daily plan ${c.localDate}"\ndocument-maturity: reviewed\ntimezone: "${c.timezone}"\ncreated_at: "${time.recorded_at}"\nupdated_at: "${time.recorded_at}"\n---\n# Daily plan — ${c.localDate}\n\n**Timezone:** ${c.timezone}\n\n## Selected for today\n\n### My work\n\n| # | Status | Project | Milestone | Task | Due Date |\n| --- | --- | --- | --- | --- | --- |\n| 1 | [ ] | Job Search | Career materials | [[../Projects/job-search/m1-career-materials/t1-update-linkedin\\|Update LinkedIn]] <!-- ref: ${a.id} --> | — |\n| 2 | [ ] | Job Search | Career materials | [[../Projects/job-search/m1-career-materials/t2-update-resume\\|Update resume]] <!-- ref: ${b.id} --> | — |\n\n### Delegated work\n\nNo delegated selections.\n\nLegend: [ ] not started · [>] in progress · [x] completed · [-] cancelled\n\n## Notes and references\n\nSynthetic unrelated prose: preserve this sentence through reconciliation.\n`;
const baseline={schemaVersion:1,records:{}};
for(const r of [a,b]){baseline.records[r.id]={canonical:{id:r.id,type:r.type,state:r.state},views:{}};for(const p of [w.project,w.milestone,plan]) baseline.records[r.id].views[p]={hash:w.hash(p===plan?text:w.read(p)),selected:true,checked:false,state:'not-started'};}
const ev=w.event('synthetic-plan-and-baseline',[a.id,b.id],{selected:[]},{selected:[a.id,b.id],acceptance:'User explicitly authorizes synthetic plan and baseline.'});
const p=w.checkpoint(c,ev,[[plan,text],[w.t1,w.read(w.t1)],[w.t2,w.read(w.t2)],[w.project,w.read(w.project)],[w.milestone,w.read(w.milestone)]],{beforeHash:null,value:baseline});
console.log(w.finish(c,p));w.json(w.scratch+'/plan-path.json',{plan});
w.call('maintenance-inspect',w.scope);
