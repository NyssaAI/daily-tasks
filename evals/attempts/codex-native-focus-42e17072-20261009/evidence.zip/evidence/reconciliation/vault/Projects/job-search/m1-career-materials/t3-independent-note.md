---
id: "01a121ab-bb46-7151-ab32-6521e925afb9"
type: task
record_version: 2
title: "Independent note"
document-maturity: reviewed
task-state: completed
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
created_at: "2026-10-09T17:17:45.244Z"
updated_at: "2026-10-09T17:17:45.586Z"
resolved_at: "2026-10-09T17:17:45.586Z"
---
# M1-T3 — Independent note

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Create a local note.

## Definition of Done

- [x] Reviewed note. <!-- id: 01a121ab-bb72-79db-9ca7-eaa3add60d55 -->

## Inputs

User explicitly accepts this synthetic task and attests reviewed synthetic evidence.

## Output and delivery

[Local note](outputs/independent-note.md).

## Verification

Confirm the local note exists and retain the supplied synthetic review attestation.

## Result

[Reviewed local note](outputs/independent-note.md). User attests reviewed synthetic evidence.
