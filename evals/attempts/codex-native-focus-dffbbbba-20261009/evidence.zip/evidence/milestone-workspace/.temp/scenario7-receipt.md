# Scenario 7 — Milestone workspace

Result: **PASS** (15/15 checks).

Skills supplied by the native host and loaded from the installed 0.3.3 bundle; no packaging or CLI execution is asserted to prove host activation. Host version/model are not exposed.

- PASS: Initial numbered milestone and sibling tasks; empty flat inputs/outputs
- PASS: Both different source originals preserved under meaningful names
- PASS: One shared copy linked by both original tasks
- PASS: Flat holding areas
- PASS: Two drafts delivered, task2 consumes task1 output in place
- PASS: Copied-ID task attachment excluded from record inspection and planning inventory
- PASS: Requirements and DoD distinct; output alone never satisfies review
- PASS: Reordered tasks preserve labels; t1 cancelled; t3 accepted; retired number unused
- PASS: b1 resolved, b2 open, b3 allocated without renumbering
- PASS: One b2 reciprocally blocks both original tasks
- PASS: Renamed output preserves bytes and repairs all affected links
- PASS: Unrelated prose preserved during rename
- PASS: Record integrity and navigation
- PASS: Project -> milestone -> tasks -> files
- PASS: All authored local work in project; scratch under case .temp

The initial accepted project/milestone/tasks were reused. Draft delivery did not check review criteria or complete tasks. Task 1 is cancelled; tasks 2 and 3 remain not started. Blocker b1 is resolved; b2 and b3 remain open.

Actual installed CLI arguments, structured inputs, exit codes, stdout/stderr and log queries are retained as numbered files here. Each committed batch has exact before/after bytes, checkpoint and independently verified completion. Full machine-readable evidence is in final-verification.json.

A label-history omission was corrected through an append-only log correction; the allocator then returned 4 with no diagnostics. Initial evidence-checker schema mistakes are retained in verification-before-schema-correction.json.

No prior attempts, regression tests, personal directories, or repository workflow code were read.
