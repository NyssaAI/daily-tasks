import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const cwd=process.cwd(), scratch=path.join(cwd,'.temp');
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-path-focus/codex-home/plugins/cache/daily-tasks-runtime-guards-path-focus/daily-tasks/0.3.3';
export const vault=path.join(cwd,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'job-search'), m=path.join(project,'m1-career-materials');
let seq=fs.existsSync(path.join(scratch,'sequence.txt'))?Number(fs.readFileSync(path.join(scratch,'sequence.txt'),'utf8')):0;
export function cli(op,input){const n=String(++seq).padStart(3,'0');fs.writeFileSync(path.join(scratch,'sequence.txt'),String(seq)); const args=[path.join(pkg,'bin/daily-tasks.mjs'),op];if(input){const p=path.join(scratch,`${n}-${op}-input.json`);fs.writeFileSync(p,JSON.stringify(input,null,2));args.push('--input',p);}const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(path.join(scratch,`${n}-${op}-result.json`),JSON.stringify({args,status:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
export const read=p=>fs.readFileSync(p,'utf8');
export const context=cli('resolve-context',{vaultRoot:vault});
export function id(){const r=cli('new-id');return typeof r==='string'?r:r.id;}
export function inspect(label){const r=cli('inspect-records',{projectsRoot:projects});fs.writeFileSync(path.join(scratch,`${label}-records.json`),JSON.stringify(r,null,2));return r;}
export function batch(label,changes,recordIds,action,words,beforeFacts,afterFacts){
 const operation_id=id(),eventId=id(),now=new Date().toISOString();
 const event={id:eventId,operation_id,action,record_ids:recordIds,actor:{kind:'agent',id:'Codex'},activity_at:now,recorded_at:now,time_defaulted:false,original_words:words,before:beforeFacts,after:afterFacts};
 const files=[];const dest=path.join(scratch,label);fs.mkdirSync(dest,{recursive:true});
 for(const [p,content] of changes){const old=fs.existsSync(p)?fs.readFileSync(p):null;files.push({path:p,before:old?hash(old):null,after:content===null?null:hash(content)});if(old)fs.writeFileSync(path.join(dest,path.basename(p)+'.before'),old);if(content!==null)fs.writeFileSync(path.join(dest,path.basename(p)+'.after'),content);}
 const op={schemaVersion:2,operation_id,contextBinding:context.planningBinding,event,files};
 const operationPath=path.join(context.stateRoot,'operations',operation_id+'.json');fs.mkdirSync(path.dirname(operationPath),{recursive:true});fs.writeFileSync(operationPath,JSON.stringify(op,null,2));fs.writeFileSync(path.join(dest,'checkpoint.json'),JSON.stringify(op,null,2));
 for(const [p,content] of changes){const f=files.find(f=>f.path===p);if((fs.existsSync(p)?hash(fs.readFileSync(p)):null)!==f.before)throw Error('Concurrent edit '+p);if(content===null)fs.unlinkSync(p);else{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,content);}}
 inspect(label);cli('log-append',{projectsRoot:projects,entry:event});cli('invalidate-project-index',{vaultRoot:vault});cli('log-query',{projectsRoot:projects,action});
 const input={vaultRoot:vault,operationPath};const v=cli('operation-verify',input);const c=cli('operation-complete',input);fs.writeFileSync(path.join(dest,'completion.json'),JSON.stringify({v,c},null,2));console.log(label,JSON.stringify(c));
}
