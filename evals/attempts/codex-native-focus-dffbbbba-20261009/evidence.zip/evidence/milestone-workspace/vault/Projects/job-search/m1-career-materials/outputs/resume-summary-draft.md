# Resume summary draft

Career professional preparing for the next opportunity, with a focus on clear, consistent career materials.

This draft uses the headline from career-headline-draft.md in place, the supplied resume source, and the shared style guide. No experience or qualifications were invented. User review and factual enrichment remain pending.
