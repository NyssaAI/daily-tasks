---
id: "01a121be-9d37-732b-bb82-4ece8d996eba"
type: blocker
record_version: 2
title: "Await signoff"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T17:38:22.652Z"
updated_at: "2026-10-09T17:38:22.652Z"
---
# Await signoff

Waiting for signoff.

## Resolution condition

Signoff is received.

## Resolution evidence

No evidence supplied.

## Blocks


