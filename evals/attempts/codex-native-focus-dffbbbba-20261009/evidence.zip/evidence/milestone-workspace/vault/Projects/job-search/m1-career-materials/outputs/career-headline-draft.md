# LinkedIn headline draft

Career professional preparing for the next opportunity

Draft based on the supplied LinkedIn source and shared style guide. The synthetic sources contain no experience details; review and factual enrichment remain pending.
