---
id: "01a121c9-9593-735e-b59a-6498a477a6c5"
type: blocker
record_version: 2
title: "Await signoff"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T17:50:21.547Z"
updated_at: "2026-10-09T17:50:21.547Z"
---
# Await signoff

Waiting for external signoff.

## Resolution condition

External signoff is received.

## Resolution evidence

Pending.

## Blocks


