---
id: "01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8"
type: "task"
record_version: 2
title: "Update LinkedIn"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T17:50:22.450Z"
task-state: "cancelled"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
resolved_at: "2026-10-09T17:50:18.810Z"
document-maturity: "reviewed"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a headline.

## Definition of Done

- [ ] A reviewed headline is saved locally. <!-- id: 01a1211c-fcde-77f4-84d8-63271f429f17 -->

## Inputs

- [[inputs/linkedin-source.txt|LinkedIn source]] — preserved from supplied attachments/a/source.txt.
- [[inputs/shared-style-guide.txt|Shared style guide]] — preserved once from supplied attachments/shared.txt.

## Output and delivery

Local draft: [[outputs/career-headline-draft.md|LinkedIn headline draft]]. Review is still required.

## Verification

Confirm the headline was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Produced [[outputs/career-headline-draft.md|LinkedIn headline draft]] locally under the user’s draft authorization. Review evidence is pending; the DoD remains unchecked.

## Cancellation

Explicitly cancelled by the user. Draft and review criterion retained for provenance.

## Blocked by

- [[../blockers/b2-await-source|Await source]] <!-- ref: 01a121c9-907b-7829-b90d-e0cb2e7d6baf -->
