# LinkedIn headline draft

Career-focused professional | Clear communication and thoughtful collaboration

Draft for user review. The supplied source identifies its purpose but provides no professional experience details; no credentials or employment history have been invented.
