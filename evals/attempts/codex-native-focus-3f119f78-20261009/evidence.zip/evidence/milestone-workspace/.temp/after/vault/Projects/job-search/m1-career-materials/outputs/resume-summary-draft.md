# Resume summary draft

Career-focused professional who values clear communication, thoughtful collaboration and practical contributions. Seeking an opportunity to apply verified experience and develop further.

Draft for user review. Confirm experience and target role before using this summary. Sources contain labels only, so no specific qualifications have been claimed.
