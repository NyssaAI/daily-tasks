import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=path.resolve('.');
export const scratch=path.join(root,'.temp');
export const vault=path.join(root,'vault');
export const projects=path.join(vault,'Projects');
export const project=path.join(projects,'job-search');
export const milestone=path.join(project,'m1-career-materials');
export const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-observed-focus/codex-home/plugins/cache/daily-tasks-runtime-guards-observed-focus/daily-tasks/0.3.3';
fs.mkdirSync(scratch,{recursive:true});
export const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
export const read=p=>fs.readFileSync(p,'utf8');
let seq=fs.readdirSync(scratch).filter(p=>/^\d+-.*input.json$/.test(p)).length;
export function cli(op,input){
 const n=String(++seq).padStart(3,'0'), prefix=path.join(scratch,`${n}-${op}`);
 const args=[path.join(bundle,'bin/daily-tasks.mjs'),op];
 if(input!==undefined){fs.writeFileSync(prefix+'-input.json',JSON.stringify(input,null,2));args.push('--input',prefix+'-input.json');}
 const r=spawnSync(process.execPath,args,{encoding:'utf8'});
 fs.writeFileSync(prefix+'-result.json',JSON.stringify({command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2));
 if(r.status!==0)throw Error(`${op}: ${r.stderr}`);
 return JSON.parse(r.stdout);
}
export function snapshot(name){
 const rows=[];
 function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.name==='.daily-tasks'||e.name==='.temp')continue;if(e.isDirectory())walk(p);else{const b=fs.readFileSync(p);rows.push({path:path.relative(root,p),sha256:hash(b),bytes:b.length});const dest=path.join(scratch,name,path.relative(root,p));fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,b);}}}
 walk(vault);walk(path.join(root,'attachments'));
 fs.writeFileSync(path.join(scratch,name+'-inventory.json'),JSON.stringify(rows,null,2));return rows;
}
if(process.argv[2]==='initial'){
 snapshot('before');
 const c=cli('resolve-context',{vaultRoot:vault});fs.writeFileSync(path.join(scratch,'context.json'),JSON.stringify(c,null,2));
 console.log(JSON.stringify(c));
 console.log(JSON.stringify(cli('inspect-records',{projectsRoot:projects})));
 console.log(JSON.stringify(cli('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:path.join(vault,'Daily')})));
 fs.writeFileSync(path.join(scratch,'initial-layout.json'),JSON.stringify({milestoneFiles:fs.readdirSync(milestone),inputs:fs.readdirSync(path.join(milestone,'inputs')),outputs:fs.readdirSync(path.join(milestone,'outputs'))},null,2));
}
