---
id: "01a121c9-8dc1-732b-9747-1158d2de82bd"
type: blocker
record_version: 2
title: "Await review"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T17:50:19.543Z"
updated_at: "2026-10-09T17:50:19.543Z"
---
# Await review

Waiting for external review.

## Resolution condition

External review has arrived.

## Resolution evidence

Pending.

## Blocks


