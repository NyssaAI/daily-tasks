# Scenario 7 — Milestone workspace

All 26 observed workflow checks pass. 8 skill-authored operations completed through installed CLI verification and completion, with no pending checkpoint.

- Numbered initial layout and empty flat inputs/outputs verified before writes.
- Both distinct originals preserved; shared input imported once with consumer links.
- Two local draft outputs delivered; resume consumes headline in place; review DoD remains unchecked.
- Copied-ID task-shaped reference excluded from canonical inspection and planning inventory.
- Views reordered, T1 explicitly cancelled, T3 accepted; existing labels preserved and next task label is T4.
- B1 review resolved; B2 source links reciprocally to both original tasks; B3 signoff accepted; next blocker label is B4.
- Headline renamed to career-headline-draft.md; producer and consumer links repaired; unrelated prose preserved.
- Navigation, distinct requirements/criteria, project-only effects, original sources and unchanged daily plan verified.

Evidence: before/, drafts/, before-rename/, after/, actions.jsonl, assertions.json, installed-instructions.json, each numbered CLI input/result, retained operation checkpoints and queried events. Logs were accessed only through installed CLI.

One verification expectation was corrected: planning inventory lists open T2/T3 and retains cancelled T1 in canonical sources. The initial failed assertion and actual CLI output remain retained; no operations were replayed.

Native installed instructions were used in this session. Host version/model and explicit plugin registration details were not exposed; these observations do not establish release-wide host coverage.
