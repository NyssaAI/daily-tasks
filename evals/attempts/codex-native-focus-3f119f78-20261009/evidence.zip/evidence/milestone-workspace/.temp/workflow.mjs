import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {root,scratch,vault,projects,project,milestone,bundle,hash,read,cli,snapshot} from './session.mjs';
const context=JSON.parse(read(path.join(scratch,'context.json')));
const ctx={vaultRoot:vault,profilePath:context.profilePath,stateRoot:context.stateRoot};
const initial=JSON.parse(read(path.join(scratch,'002-inspect-records-result.json'))).stdout;
const records=JSON.parse(initial).records;
const t1=records.find(r=>r.title==='Update LinkedIn'),t2=records.find(r=>r.title==='Update resume'),m1=records.find(r=>r.type==='milestone'),p1=records.find(r=>r.type==='project');
const id=()=>{const r=cli('new-id');return typeof r==='string'?r:r.id;};
const time=()=>cli('activity-time',{});
const stamp=(s,t)=>s.replace(/^updated_at:.*$/m,`updated_at: "${t}"`);
const checks=fs.existsSync(path.join(scratch,'assertions.json'))?JSON.parse(read(path.join(scratch,'assertions.json'))):[];
function check(name,value){assert.ok(value,name);checks.push({name,pass:true});fs.writeFileSync(path.join(scratch,'assertions.json'),JSON.stringify(checks,null,2));}
function inventory(){return cli('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,forceRefresh:true});}
function validate(){const r=cli('inspect-records',{projectsRoot:projects});assert.deepEqual(r.diagnostics,[]);const v=cli('validate-records',{records:r.records});const l=cli('check-links',{records:r.records});const nav=cli('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot});fs.writeFileSync(path.join(scratch,'latest-validation.json'),JSON.stringify({v,l,nav},null,2));assert.deepEqual(nav.diagnostics,[]);return r.records;}
function commit(action,changes,recordIds,words,before,after,timing=time()){
 const op=id(),event={id:id(),operation_id:op,action,record_ids:recordIds,actor:{kind:'person',id:context.profile.user.email},...timing,original_words:words,before,after};
 const effects=[...changes].map(([p,b])=>({path:p,before:fs.existsSync(p)?hash(fs.readFileSync(p)):null,after:b===null?null:hash(b)}));
 const opPath=path.join(context.stateRoot,'operations',op+'.json');fs.mkdirSync(path.dirname(opPath),{recursive:true});
 const checkpoint={schemaVersion:2,operation_id:op,contextBinding:context.planningBinding,event,files:effects};
 fs.writeFileSync(opPath,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(scratch,op+'-checkpoint.json'),JSON.stringify(checkpoint,null,2));
 for(const e of effects){const dest=path.join(scratch,'operation-before',op,path.relative(projects,e.path));if(e.before!==null){fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(e.path,dest);}}
 for(const [p,b]of changes){const e=effects.find(e=>e.path===p);assert.equal(fs.existsSync(p)?hash(fs.readFileSync(p)):null,e.before);fs.mkdirSync(path.dirname(p),{recursive:true});if(b===null)fs.unlinkSync(p);else fs.writeFileSync(p,b);}
 cli('invalidate-project-index',{vaultRoot:vault});
 validate();
 assert.equal(event.activity_at,timing.activity_at);assert.equal(event.recorded_at,timing.recorded_at);
 cli('log-append',{projectsRoot:projects,entry:event});
 const q=cli('log-query',{projectsRoot:projects,limit:1000});fs.writeFileSync(path.join(scratch,op+'-queried-event.json'),JSON.stringify(q,null,2));
 const v=cli('operation-verify',{...ctx,operationPath:opPath});assert.equal(v.status,'verified',JSON.stringify(v));
 const c=cli('operation-complete',{...ctx,operationPath:opPath});assert.ok(!fs.existsSync(opPath),JSON.stringify(c));
 fs.appendFileSync(path.join(scratch,'actions.jsonl'),JSON.stringify({action,operation:op,files:effects,words,result:c})+'\n');
}
export {context,ctx,t1,t2,m1,p1,id,time,stamp,check,inventory,validate,commit};
if(process.argv[2]==='drafts'){
const initialLayout=JSON.parse(read(path.join(scratch,'initial-layout.json')));
check('One matching numbered milestone file, sibling t1/t2 and empty flat holding folders',initialLayout.milestoneFiles.filter(n=>n==='m1-career-materials.md').length===1&&initialLayout.milestoneFiles.includes('t1-update-linkedin.md')&&initialLayout.milestoneFiles.includes('t2-update-resume.md')&&initialLayout.inputs.length===0&&initialLayout.outputs.length===0);
check('Distinct initial task requirements and three independently identified DoD criteria',read(t1.path).includes('Draft a headline.')&&read(t2.path).includes('Draft a summary.')&&new Set([t1.criteria[0].id,t2.criteria[0].id,m1.criteria[0].id]).size===3);
fs.writeFileSync(path.join(scratch,'installed-instructions.json'),JSON.stringify({node:process.version,bundle,host:'Codex native session; version/model not exposed',files:['skills/daily-tasks/SKILL.md','skills/daily-tasks-records/SKILL.md','skills/daily-tasks-setup/SKILL.md','skills/daily-tasks/references/records.md','skills/daily-tasks/references/operations.md','skills/daily-tasks/references/verification.md','skills/daily-tasks/references/cli.md','skills/daily-tasks/assets/task.md','skills/daily-tasks/assets/blocker.md'].map(p=>({path:path.join(bundle,p),sha256:hash(fs.readFileSync(path.join(bundle,p)))}))},null,2));
const input1=path.join(milestone,'inputs/linkedin-source.txt'),input2=path.join(milestone,'inputs/resume-source.txt'),shared=path.join(milestone,'inputs/shared-style-guide.txt');
const original1=fs.readFileSync(path.join(root,'attachments/a/source.txt')),original2=fs.readFileSync(path.join(root,'attachments/b/source.txt')),originalShared=fs.readFileSync(path.join(root,'attachments/shared.txt'));
const output1=path.join(milestone,'outputs/linkedin-headline-draft.md'),output2=path.join(milestone,'outputs/resume-summary-draft.md');
const draft1='# LinkedIn headline draft\n\nCareer-focused professional | Clear communication and thoughtful collaboration\n\nDraft for user review. The supplied source identifies its purpose but provides no professional experience details; no credentials or employment history have been invented.\n';
const draft2='# Resume summary draft\n\nCareer-focused professional who values clear communication, thoughtful collaboration and practical contributions. Seeking an opportunity to apply verified experience and develop further.\n\nDraft for user review. Confirm experience and target role before using this summary. Sources contain labels only, so no specific qualifications have been claimed.\n';
const timing=time();
let text1=stamp(read(t1.path),timing.recorded_at).replace('No source material has been supplied. Local working inputs belong in inputs/.','- [[inputs/linkedin-source.txt|LinkedIn source]] — preserved from supplied attachments/a/source.txt.\n- [[inputs/shared-style-guide.txt|Shared style guide]] — preserved once from supplied attachments/shared.txt.').replace('Save the headline locally in outputs/. Link the actual artifact here and from the milestone after review.','Local draft: [[outputs/linkedin-headline-draft.md|LinkedIn headline draft]]. Review is still required.').replace('Work has not started; no artifact has been produced or reviewed.','Produced [[outputs/linkedin-headline-draft.md|LinkedIn headline draft]] locally under the user’s draft authorization. Review evidence is pending; the DoD remains unchecked.');
let text2=stamp(read(t2.path),timing.recorded_at).replace('No source material has been supplied. Local working inputs belong in inputs/.','- [[inputs/resume-source.txt|Resume source]] — preserved from supplied attachments/b/source.txt.\n- [[inputs/shared-style-guide.txt|Shared style guide]] — the same shared working copy used by Update LinkedIn.\n- [[outputs/linkedin-headline-draft.md|LinkedIn headline draft]] — consumed in place to align the summary wording; no input copy.').replace('Save the summary locally in outputs/. Link the actual artifact here and from the milestone after review.','Local draft: [[outputs/resume-summary-draft.md|Resume summary draft]]. Review is still required.').replace('Work has not started; no artifact has been produced or reviewed.','Produced [[outputs/resume-summary-draft.md|Resume summary draft]] using the headline draft in its existing outputs/ location. Review evidence is pending; the DoD remains unchecked.');
const attachment=path.join(milestone,'inputs/task-shaped-reference.md');
commit('workspace.drafts-delivered',new Map([[input1,original1],[input2,original2],[shared,originalShared],[attachment,read(t1.path)],[output1,draft1],[output2,draft2],[t1.path,text1],[t2.path,text2]]),[t1.id,t2.id],'Import both originals and shared input; authorize two local drafts; task2 consumes task1 output in place; copied-ID task-shaped attachment is reference material.',undefined,{inputs:[input1,input2,shared,attachment],outputs:[output1,output2]},timing);
check('Both originals preserved byte-for-byte with meaningful distinct names',hash(fs.readFileSync(input1))===hash(original1)&&hash(fs.readFileSync(input2))===hash(original2)&&hash(original1)!==hash(original2));
check('Shared input exists once and both consumers link it',fs.readdirSync(path.dirname(shared)).filter(n=>hash(fs.readFileSync(path.join(path.dirname(shared),n)))===hash(originalShared)).length===1&&read(t1.path).includes('inputs/shared-style-guide.txt')&&read(t2.path).includes('inputs/shared-style-guide.txt'));
check('Two actual drafts and task2 consumes task1 output in place',fs.existsSync(output1)&&fs.existsSync(output2)&&read(t2.path).includes('[[outputs/linkedin-headline-draft.md|')&&!fs.existsSync(path.join(milestone,'inputs/linkedin-headline-draft.md')));
let live=validate();check('Copied-ID attachment excluded from inspect-records',live.filter(r=>r.id===t1.id).length===1&&live.length===4);
let inv=inventory();fs.writeFileSync(path.join(scratch,'attachment-inventory.json'),JSON.stringify(inv,null,2));check('Copied-ID attachment excluded from planning inventory',inv.inventory.tasks.length===2&&inv.inventory.tasks.filter(r=>r.id===t1.id).length===1);
for(const task of [t1,t2]){const c=cli('check-closure',{recordId:task.id,records:live});check(`Draft alone does not satisfy ${task.title} DoD`,c.allowed===false);}
snapshot('drafts');
console.log('Imports, draft delivery, attachment exclusion and closure checks complete.');
}
