import fs from 'node:fs';import path from 'node:path';
import {write,call,snapshot,root,evidence,home,a,now} from './scenario9.mjs';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const c=read(path.join(evidence,'custom-context.json'));
snapshot('16-before-filename-correction');
fs.renameSync(path.join(c.dailyPlansRoot,'2026.10.11.md'),path.join(c.dailyPlansRoot,'2026.10.11-daily-plan.md'));
const shared={vaultRoot:c.vaultRoot,homeRoot:c.homeRoot,stateRoot:c.stateRoot,configurationSources:c.configurationSources,now};
const unrelated=path.join(root,'.temp/unrelated'),cache=path.join(a,'.temp/daily-tasks');
let packet=call('corrected-custom-prepare','planning-prepare',shared,unrelated).value;
const save={...shared,now:packet.context.now,action:'save-review',expectedPlanHash:packet.current.sha256,expectedPreviousHash:packet.previous?.sha256??null,expectedInventoryHash:packet.inventoryHash,expectedReviewHash:packet.reviewHash,expectedStateHash:packet.state.review.sha256};
write(path.join(evidence,'corrected-interrupted-save.json'),save);snapshot('17-corrected-interruption');
call('corrected-custom-resume-save','planning-state',read(path.join(evidence,'corrected-interrupted-save.json')),cache);
packet=call('corrected-custom-recovery-prepare','planning-prepare',shared,cache).value;
call('corrected-custom-complete-rollover','planning-state',{...shared,action:'complete-rollover',expectedPlanHash:packet.current.sha256,expectedPreviousHash:packet.previous?.sha256??null,expectedInventoryHash:packet.inventoryHash,expectedStateHash:packet.state.rollover.sha256},cache);
snapshot('18-corrected-completed');
const legacy=path.join(a,'.nyssaai/daily-tasks'),canonical=c.stateRoot;
for(const dir of ['rollover','review']){const from=path.join(canonical,dir);if(fs.existsSync(from)){fs.mkdirSync(legacy,{recursive:true});fs.renameSync(from,path.join(legacy,dir));}}
call('corrected-legacy-completed-discovery','resolve-context',{homeRoot:home,vaultRoot:a,configurationSources:c.configurationSources,now},unrelated);snapshot('19-legacy-completed');
const receipt=path.join(legacy,'rollover/2026.10.11.json');
if(fs.existsSync(receipt)){
 const removed=call('corrected-synthetic-removed-id','new-id').value.id;let history=read(receipt);history.removedIds=[removed];write(receipt,history);
 call('corrected-legacy-removal-prepare','planning-prepare',{...shared,stateRoot:legacy},unrelated);snapshot('20-removal-preserved');
 write(path.join(canonical,'rollover/2026.10.11.json'),{...history,removedIds:[]});snapshot('21-divergent-before');
 call('corrected-divergent-auto-rejected','resolve-context',{homeRoot:home,vaultRoot:a,configurationSources:c.configurationSources,now},unrelated);
 call('corrected-divergent-resumed-rejected','resolve-context',{...shared,stateRoot:legacy},unrelated);
 call('corrected-divergent-prepare-rejected','planning-prepare',{...shared,stateRoot:legacy},unrelated);snapshot('22-divergent-after');
}
