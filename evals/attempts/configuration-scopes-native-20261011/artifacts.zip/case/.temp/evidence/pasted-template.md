# Synthetic personal format

**Timezone:** IANA_TIMEZONE

## My work

No selected work.

## Delegated work

No delegated work.
