import fs from 'node:fs';import path from 'node:path';
import {write,call,snapshot,root,evidence,home,a,b,up,ap,now} from './scenario9.mjs';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const ids=read(path.join(evidence,'id-shapes.json'));
const time=call('project-log-clock','activity-time',{now}).value;
const old=JSON.parse(read(path.join(evidence,'05-before-project.snapshot.json'))[path.relative(root,ap)]);
const entry={id:ids.id.id,operation_id:ids.op.id,action:'profile.updated',record_ids:[],actor:{kind:'person',id:'synthetic@example.test'},...time,before:old,after:read(ap)};
call('project-log-append','log-append',{projectsRoot:path.join(a,'1-projects'),entry});
call('project-log-query','log-query',{projectsRoot:path.join(a,'1-projects'),action:'profile.updated'});snapshot('07-project-after');
const c=read(path.join(evidence,'custom-context.json'));
const id=read(path.join(evidence,'plan-id-shape.json')).id;
const planPath=path.join(c.dailyPlansRoot,'2026.10.11.md');
write(planPath,`---\nid: ${id}\ntype: daily-plan\ntitle: "Daily plan 2026.10.11"\ndocument-maturity: reviewed\ntimezone: "Etc/GMT"\ncreated_at: "${now}"\nupdated_at: "${now}"\n---\n# Synthetic personal format\n\n**Timezone:** Etc/GMT\n\n## My work\n\nNo selected work.\n\n## Delegated work\n\nNo delegated work.\n`);
call('parse-authored-plan','parse-record',{markdown:fs.readFileSync(planPath,'utf8'),path:planPath});
const shared={vaultRoot:c.vaultRoot,homeRoot:c.homeRoot,stateRoot:c.stateRoot,configurationSources:c.configurationSources,now};
const unrelated=path.join(root,'.temp/unrelated');fs.mkdirSync(unrelated,{recursive:true});
const packet=call('custom-prepare','planning-prepare',shared,unrelated).value;
write(path.join(evidence,'preparation-packet.json'),packet);
if(packet?.current && packet?.state){
 const save={...shared,now:packet.context.now,action:'save-review',expectedPlanHash:packet.current.sha256,expectedPreviousHash:packet.previous?.sha256??null,expectedInventoryHash:packet.inventoryHash,expectedReviewHash:packet.reviewHash,expectedStateHash:packet.state.review.sha256};
 write(path.join(evidence,'interrupted-save.json'),save);snapshot('08-interrupted-before-save');
 // Saved continuation is resumed from disposable cache cwd, retaining all accepted roots and sources.
 const cache=path.join(a,'.temp/daily-tasks');fs.mkdirSync(cache,{recursive:true});
 call('custom-resume-save','planning-state',read(path.join(evidence,'interrupted-save.json')),cache);
 call('custom-recovery-prepare','planning-prepare',shared,cache);snapshot('09-recovered-save');
 const fresh=call('custom-rollover-prepare','planning-prepare',shared,unrelated).value;
 if(fresh?.state)call('custom-complete-rollover','planning-state',{...shared,action:'complete-rollover',expectedPlanHash:fresh.current.sha256,expectedPreviousHash:fresh.previous?.sha256??null,expectedInventoryHash:fresh.inventoryHash,expectedStateHash:fresh.state.rollover.sha256},cache);
}
// Create a legitimate completed receipt in legacy state through the CLI, then test discovery.
const legacy=path.join(a,'.nyssaai/daily-tasks');
const canonical=c.stateRoot;
// Preserve generated completion bytes, then move the authoritative state files only.
snapshot('10-before-legacy-location');
for(const dir of ['rollover','review']){const from=path.join(canonical,dir);if(fs.existsSync(from)){fs.mkdirSync(legacy,{recursive:true});fs.renameSync(from,path.join(legacy,dir));}}
let legacyContext=call('legacy-completed-discovery','resolve-context',{homeRoot:home,vaultRoot:a,configurationSources:c.configurationSources,now},unrelated).value;
write(path.join(evidence,'legacy-context.json'),legacyContext);snapshot('11-legacy-discovered');
// Synthetic explicit removal history augments the CLI-generated completion receipt.
const receipt=path.join(legacy,'rollover/2026.10.11.json');
if(fs.existsSync(receipt)){
 const removed=call('synthetic-removed-id','new-id').value.id;let history=read(receipt);history.removedIds=[removed];write(receipt,history);
 call('legacy-removal-prepare','planning-prepare',{...shared,stateRoot:legacy},unrelated);snapshot('12-removal-preserved');
 write(path.join(canonical,'rollover/2026.10.11.json'),{...history,removedIds:[]});snapshot('13-divergent-before');
 call('divergent-auto-rejected','resolve-context',{homeRoot:home,vaultRoot:a,configurationSources:c.configurationSources,now},unrelated);
 call('divergent-resumed-rejected','resolve-context',{...shared,stateRoot:legacy},unrelated);
 call('divergent-prepare-rejected','planning-prepare',{...shared,stateRoot:legacy},unrelated);snapshot('14-divergent-after');
}
// Invalid selected layer, preserved without replacing it with a good duplicate.
const bad=path.join(home,'invalid-selected/profile.json');write(bad,'{ malformed');
call('malformed-selected','resolve-context',{homeRoot:home,vaultRoot:a,now,configurationSources:{schemaVersion:1,user:{profilePath:bad},project:{profilePath:ap}}});
const badNull=path.join(home,'invalid-null/profile.json');write(badNull,{schema_version:2,user:null});
call('invalid-null-selected','resolve-context',{homeRoot:home,vaultRoot:a,now,configurationSources:{schemaVersion:1,user:{profilePath:badNull},project:{profilePath:ap}}});
snapshot('15-final');
