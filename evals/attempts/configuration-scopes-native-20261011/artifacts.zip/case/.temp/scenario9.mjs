import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=process.cwd();
const pkg='D:/repos/NyssaAI/daily-tasks/.worktrees/configuration-scopes/.temp/native-acceptance/configuration-scopes-035/codex-home/plugins/cache/configuration-scopes-eval/daily-tasks/0.3.5';
const cli=path.join(pkg,'bin/daily-tasks.mjs');
const evidence=path.join(root,'.temp/evidence'); fs.mkdirSync(evidence,{recursive:true});
const home=path.join(root,'synthetic-home'), a=path.join(root,'vault-a'), b=path.join(root,'vault-b');
const up=path.join(home,'.nyssa-ai/daily-tasks/profile.json'), ap=path.join(a,'.nyssa-ai/daily-tasks/profile.json');
const now='2026-10-11T18:00:00.000Z';
export function write(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
export function call(label,op,input,cwd=root){const ip=path.join(evidence,label+'.input.json');if(input!==undefined)write(ip,input);const args=[cli,op,...(input===undefined?[]:['--input',ip])];const r=spawnSync(process.execPath,args,{cwd,encoding:'utf8'});write(path.join(evidence,label+'.result.json'),{command:[process.execPath,...args],cwd,exitCode:r.status,stdout:r.stdout,stderr:r.stderr});let value;try{value=JSON.parse(r.stdout)}catch{}; console.log(label,r.status, r.status!==0?r.stderr.trim():'');return {status:r.status,value};}
export function snapshot(label){const out={};for(const base of [home,a,b]){function walk(dir){if(!fs.existsSync(dir))return;for(const d of fs.readdirSync(dir,{withFileTypes:true})){if(d.name==='.daily-tasks')continue;const p=path.join(dir,d.name);if(d.isDirectory())walk(p);else out[path.relative(root,p)]=fs.readFileSync(p,'utf8');}}walk(base);}write(path.join(evidence,label+'.snapshot.json'),out);}
export {root,pkg,cli,evidence,home,a,b,up,ap,now};
if(process.argv[2]==='initial'){
 call('installed-help','--help');
 write(path.join(evidence,'installed-manifest.json'),fs.readFileSync(path.join(pkg,'.codex-plugin/plugin.json'),'utf8'));
 write(path.join(evidence,'installed-skills.json'),['daily-tasks','daily-tasks-capture','daily-tasks-checkin','daily-tasks-plan','daily-tasks-records','daily-tasks-setup'].map(s=>path.join(pkg,'skills',s,'SKILL.md')));
 for(const v of [home,a,b])fs.mkdirSync(v,{recursive:true});for(const v of [a,b])fs.mkdirSync(path.join(v,'1-projects'),{recursive:true});
 const user={schema_version:2,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'Etc/GMT',priorities:['User priority'],templates:{dailyPlan:'~/.nyssa-ai/daily-tasks/templates/daily-plan.md'}};
 write(path.join(home,'.nyssa-ai/daily-tasks/templates/daily-plan.md'),'# Personal daily plan\n\n## My work\n\n## Delegated work\n');
 call('validate-user','validate-profile',{profile:user});write(up,user);
 const project={schema_version:2,vaultRoot:'.',projectsRoot:'./1-projects',priorities:[],templates:{dailyPlan:null}};
 call('validate-project','validate-profile',{profile:project});write(ap,project);snapshot('01-before');
 const ca=call('resolve-a-null','resolve-context',{homeRoot:home,vaultRoot:a,now}).value;
 const cb=call('resolve-b-inherits','resolve-context',{homeRoot:home,vaultRoot:b,now}).value;
 write(path.join(evidence,'contexts.json'),{ca,cb});
 delete project.templates.dailyPlan;write(ap,project);call('resolve-a-restored','resolve-context',{homeRoot:home,vaultRoot:a,now});snapshot('02-restored');
 call('personal-no-vault','resolve-context',{homeRoot:home,now});
 for(const [label,profile] of [['null-identity',{schema_version:2,user:null}],['null-binding',{schema_version:2,vaultRoot:null}],['null-container',{schema_version:2,templates:null}],['invalid-schema',{schema_version:99}]])call(label,'validate-profile',{profile});
 call('descriptor-mixed-profile','resolve-context',{homeRoot:home,vaultRoot:a,now,configurationSources:ca.configurationSources,profilePath:up});
 call('descriptor-mixed-config','resolve-context',{homeRoot:home,vaultRoot:a,now,configurationSources:ca.configurationSources,configRoot:path.dirname(up)});
 call('exclusive-profile','resolve-context',{homeRoot:home,vaultRoot:a,now,profilePath:up});
}
