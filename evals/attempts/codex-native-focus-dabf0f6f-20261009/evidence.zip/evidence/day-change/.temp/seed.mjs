import fs from 'node:fs';import path from 'node:path';
import {root,evidence,read,write,hash,cli,id,options,clock,snapshot} from './session.mjs';
const vault=path.join(root,'vault'),opt=options(vault,clock.monday);snapshot(vault,'original');
const p=cli('planning-prepare',opt),c=p.context,pr=c.projectsRoot,folder=path.join(pr,'job-search/m1-career-materials');
const A=p.inventory.tasks[0],B=p.inventory.tasks[1],project=A.projectId,milestone=A.milestoneId;
const changes=[],tasks=[A,B];
for(const [key,title,req,dod,state,assignee] of [['C','Review draft','inspect draft','recorded review','not-started','Reviewer'],['D','Past work','past result','reviewed result','completed',null],['E','Abandoned work','draft work','reviewed result','cancelled',null],['F','Deselected work','optional draft','reviewed draft','not-started',null]]){
 const number=cli('next-record-number',{projectsRoot:pr,type:'task',parentId:milestone}).number;
 // Batch allocation reserves the next consecutive labels within this accepted batch.
 const n=number+tasks.length-2,tid=id(),criterion=id(),slug=title.toLowerCase().replaceAll(' ','-'),file=path.join(folder,`t${n}-${slug}.md`);
 const t={id:tid,title,path:path.relative(pr,file).replaceAll('\\','/'),state,assignee,projectId:project,milestoneId:milestone,key};tasks.push(t);
 const body=`---\nid: "${tid}"\ntype: task\nrecord_version: 2\ntitle: "${title}"\nowner: "${c.profile.user.email}"\n${assignee?`assignee: "${assignee}"\n`:''}project_id: "${project}"\nmilestone_id: "${milestone}"\ntask-state: "${state}"\ncreated_at: "${c.now}"\nupdated_at: "${c.now}"\n${state==='completed'||state==='cancelled'?`resolved_at: "${c.now}"\n`:''}document-maturity: reviewed\n---\n# M1-T${n} — ${title}\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${milestone} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${project} -->\n\n## Requirements\n\n${req}\n\n## Definition of Done\n\n- [${state==='completed'?'x':' '}] ${dod} <!-- id: ${criterion} -->\n\n## Result\n\n${key==='D'?'User explicitly attests the past result was reviewed.':key==='E'?'User explicitly cancelled this work; DoD remains unsatisfied.':'No work or review has been reported.'}\n`;
 changes.push({path:file,text:body});
}
for(const name of ['inputs','outputs'])fs.mkdirSync(path.join(folder,name),{recursive:true});
const mark=t=>t.state==='completed'?'x':t.state==='cancelled'?'-':' ';
const mp=path.join(folder,'m1-career-materials.md'),pp=path.join(pr,'job-search/project-index.md');
changes.push({path:mp,text:read(mp)+'\n'+tasks.slice(2).map(t=>`- [${mark(t)}] [[${path.basename(t.path,'.md')}|${t.title}]] <!-- ref: ${t.id} -->`).join('\n')+'\n'});
changes.push({path:pp,text:read(pp)+'\n'+tasks.slice(2).map(t=>`- [${mark(t)}] [[${t.path.replace('job-search/','').replace(/\.md$/,'')}|${t.title}]] <!-- ref: ${t.id} -->`).join('\n')+'\n'});
const opid=id(),event={id:id(),operation_id:opid,action:'task.accepted',record_ids:tasks.slice(2).map(t=>t.id),actor:{kind:'person',id:c.profile.user.email},...cli('activity-time',{now:clock.monday}),original_words:'Explicitly accept C Review draft, D Past work with reviewed result attested, E Abandoned work explicitly cancelled, F Deselected work.',after:{records:tasks.slice(2)}};
const op={schemaVersion:2,operation_id:opid,contextBinding:c.planningBinding,event,files:changes.map(x=>({path:x.path,before:hash(read(x.path)),after:hash(x.text)}))};
const opPath=path.join(c.stateRoot,'operations',opid+'.json');write(opPath,op);write(path.join(evidence,'accepted-records-checkpoint.json'),op);
for(const x of changes){if(hash(read(x.path))!==op.files.find(f=>f.path===x.path).before)throw Error('before changed');write(x.path,x.text);}
cli('invalidate-project-index',{vaultRoot:vault});const records=cli('inspect-records',{projectsRoot:pr});write(path.join(evidence,'accepted-records-inspection.json'),records);
cli('log-append',{projectsRoot:pr,entry:event});console.log(cli('operation-complete',{...opt,operationPath:opPath}));
const planId=id(),date='2026.10.05';
function renderPlan(date,planId,selected,now){let n=0;const table=ts=>ts.length?'| # | Status | Project | Milestone | Task | Due Date |\n| --- | --- | --- | --- | --- | --- |\n'+ts.map(t=>`| ${++n} | [${mark(t)}] | Job Search | Career materials | ${t.state==='cancelled'?'~~':''}[[../Projects/${t.path.replace(/\.md$/,'')}\\|${t.title}]]${t.state==='cancelled'?'~~':''} <!-- ref: ${t.id} --> | — |`).join('\n'):'No selected work.';return `---\nid: "${planId}"\ntype: daily-plan\ntitle: "Daily plan ${date}"\nowner: "${c.profile.user.email}"\ntimezone: "America/Chicago"\ncreated_at: "${now}"\nupdated_at: "${now}"\ndocument-maturity: reviewed\n---\n# Daily plan — ${date}\n\n**Timezone:** America/Chicago\n\n## Selected for today\n\n### My work\n\n${table(selected.filter(t=>!t.assignee))}\n\n### Delegated work\n\n${table(selected.filter(t=>t.assignee))}\n\nLegend: [ ] not started · [>] in progress · [x] completed · [-] cancelled\n\n## Notes and references\n\nSynthetic fixture; preserve this prose. F was explicitly deselected and remains open.\n`;}
write(path.join(vault,'Daily',date+'-daily-plan.md'),renderPlan(date,planId,[tasks[0],...tasks.slice(2,5)],c.now));
// Authorized synthetic initial dated state records explicit Monday deselection, without a completion receipt.
write(path.join(c.stateRoot,'rollover',date+'.json'),{schemaVersion:1,date,planId,removedIds:[tasks[5].id]});
write(path.join(evidence,'tasks.json'),tasks);snapshot(vault,'seed-monday');
for(const branch of ['tuesday','interruption','future']){const dest=path.join(evidence,'branches',branch,'vault');function copy(dir){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){if(['.daily-tasks','.temp'].includes(ent.name))continue;const f=path.join(dir,ent.name);if(ent.isDirectory())copy(f);else write(path.join(dest,path.relative(vault,f)),read(f));}}copy(vault);fs.rmSync(path.join(dest,'.nyssaai/daily-tasks/project-index.json'),{force:true});}
write(path.join(evidence,'seed-details.json'),{planId,date,clock:clock.monday,accepted:tasks.slice(2),branches:['tuesday','interruption','future']});
