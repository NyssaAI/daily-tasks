---
id: "01a1211c-fc13-750e-993c-51e78d20ea25"
type: "milestone"
record_version: 2
title: "Career materials"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
milestone-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
document-maturity: "reviewed"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Outcome

Prepare a reviewed LinkedIn headline and resume summary, saved locally and linked.

## Definition of Done

- [ ] Both reviewed artifacts are linked. <!-- id: 01a1211c-fc9b-7027-a7db-a9c6f17740a9 -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->

- [ ] [[t3-review-draft|Review draft]] <!-- ref: 01a121d7-53d3-78b2-84b6-b35853426426 -->
- [x] [[t4-past-work|Past work]] <!-- ref: 01a121d7-5462-775c-bbb0-caa2696cdeb9 -->
- [-] [[t5-abandoned-work|Abandoned work]] <!-- ref: 01a121d7-54f2-756f-bb6a-78f076e27ae7 -->
- [ ] [[t6-deselected-work|Deselected work]] <!-- ref: 01a121d7-5582-70d9-8578-5cee306f98c2 -->
