---
id: "01a121d7-5462-775c-bbb0-caa2696cdeb9"
type: task
record_version: 2
title: "Past work"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
task-state: "completed"
created_at: "2026-10-05T16:00:00.000Z"
updated_at: "2026-10-05T16:00:00.000Z"
resolved_at: "2026-10-05T16:00:00.000Z"
document-maturity: reviewed
---
# M1-T4 — Past work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

past result

## Definition of Done

- [x] reviewed result <!-- id: 01a121d7-548e-75a7-bcb9-b54d61b08478 -->

## Result

User explicitly attests the past result was reviewed.
