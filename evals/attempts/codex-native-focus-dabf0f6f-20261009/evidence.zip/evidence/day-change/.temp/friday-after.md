---
id: "01a121d8-38d0-7850-965f-78089b5cadc4"
type: daily-plan
title: "Daily plan 2026.10.09"
owner: "synthetic@example.test"
timezone: "America/Chicago"
created_at: "2026-10-09T16:00:00.000Z"
updated_at: "2026-10-09T16:00:00.000Z"
document-maturity: reviewed
---
# Daily plan — 2026.10.09

**Timezone:** America/Chicago

## Selected for today

### My work

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | Career materials | ↺ [[../Projects/job-search/m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 --> | — |

### Delegated work

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 2 | [ ] | Job Search | Career materials | ↺ [[../Projects/job-search/m1-career-materials/t3-review-draft\|Review draft]] <!-- ref: 01a121d7-53d3-78b2-84b6-b35853426426 --> | — |

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled · ↺ carried forward

## Notes and references

Preserve this independent plan prose.
