import path from 'node:path';import fs from 'node:fs';
import {evidence,read,write,cli,options,clock,snapshot} from './session.mjs';
import {finishRollover,beginRollover,saveReview} from './workflow.mjs';
const ref=JSON.parse(read(path.join(evidence,'resume-reference.json'))),op=JSON.parse(read(ref.operationPath));
const recovery=cli('operation-verify',{...options(ref.v,clock.friday),operationPath:ref.operationPath});write(path.join(evidence,'interrupted-recovery-inspection.json'),recovery);
finishRollover({...ref,p:{context:ref.context},op,now:clock.friday});
// Retry original payload and dated planning under the original Tuesday simulation.
const retry=cli('log-append',{projectsRoot:ref.context.projectsRoot,entry:op.event});write(path.join(evidence,'interrupted-append-retry.json'),retry);
write(path.join(evidence,'interrupted-rollover-retry.json'),beginRollover(ref.v,clock.tuesday,'interrupted-retry'));
const queried=cli('log-query',{projectsRoot:ref.context.projectsRoot});write(path.join(evidence,'interrupted-final-events.json'),queried);snapshot(ref.v,'interrupted-final');saveReview(ref.v,clock.tuesday);
