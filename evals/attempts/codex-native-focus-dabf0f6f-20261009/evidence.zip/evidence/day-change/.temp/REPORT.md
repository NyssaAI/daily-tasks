# Scenario 4 — Day change

Observed workflow assertions: 19/19 passed. All scenario 4 behaviors executed.

- PASS — Only Friday created after skipped days
- PASS — Unfinished selected own A and delegated C carry once
- PASS — Saved responsibility sections
- PASS — Completed D and cancelled E remain historical and do not carry
- PASS — Explicitly deselected open F stays out
- PASS — Monday source preserved
- PASS — No timeframe fitting or manufactured targets
- PASS — Tuesday precreated B retained and A carried once
- PASS — Tuesday identity created_at and prose preserved
- PASS — Remove A then repeat Tuesday honors removal
- PASS — Actual interruption has checkpoint, persisted destination, no false receipt
- PASS — Resume and retry produce no duplicate rows or logs
- PASS — Recovery retains exact original event IDs payload and Tuesday times
- PASS — Successful recovery clears checkpoint and verifies receipt
- PASS — Explicit future Tuesday removal of B remains honored
- PASS — friday has no pending operation or duplicate planning diagnostics
- PASS — tuesday has no pending operation or duplicate planning diagnostics
- PASS — interruption has no pending operation or duplicate planning diagnostics
- PASS — future has no pending operation or duplicate planning diagnostics

## Retained evidence

Installed bundle: D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-log-migration-focus/codex-home/plugins/cache/daily-tasks-runtime-guards-log-migration-focus/daily-tasks/0.3.3

Loaded instruction paths and SHA256 values: loaded-instructions.json. CLI inputs/results are numbered *.input.json and *.result.json, including errors and retry deduplication. Skill-authored workflows are session.mjs, seed.mjs, workflow.mjs, branches.mjs, resume.mjs, removals.mjs and enroll.mjs. Their execution occurred in this conversation; they were not read from another attempt. Before/after bytes, actual checkpoints, snapshots and log-query results are retained. Logs were exclusively queried/appended through the installed CLI; raw log files were not read, copied or hashed.

## Original event identity and clocks

friday: profile.configured / 01a1211b-2098-79f9-9676-3a9bac7df7f4 / 01a1211b-2067-7339-a225-6e096d259d5c / 2026-10-09T14:39:48.278Z; profile.updated / 01a1211c-fde4-73bb-b439-f7d7e7096f0c / 01a1211c-fdba-701e-a078-9b4396630677 / 2026-10-09T14:41:50.392Z; batch.accepted / 01a1211c-fd64-7816-b6b7-971787378b78 / 01a1211c-fd8f-7cdc-bbc4-f17a703a97c7 / 2026-10-09T14:41:50.392Z; task.accepted / 01a121d7-55da-7f14-9663-82bc4b0f97ba / 01a121d7-5605-7e7a-8ff8-b41acdf77853 / 2026-10-05T16:00:00.000Z; plan.rollover / 01a121d8-392c-78b7-b73e-ea3f1dd9b669 / 01a121d8-3957-7007-8d88-ae237695b022 / 2026-10-09T16:00:00.000Z; views.enrolled / 01a121db-6e28-71cf-9af4-c60f1b2a23f2 / 01a121db-6e56-7739-83a2-cdf058ad68b0 / 2026-10-09T16:00:00.000Z

tuesday: plan.rollover / 01a121d9-660e-73b6-afde-415059e7a84c / 01a121d9-6647-72b5-9042-dc0a65f210aa / 2026-10-06T16:00:00.000Z; plan.deselected / 01a121da-84e9-7e9d-bb6d-a33af8432dca / 01a121da-8514-71b0-b13a-b8933ae0e748 / 2026-10-06T16:00:00.000Z

interruption: plan.rollover / 01a121d9-6a6f-7078-8dee-b335f9a4bf23 / 01a121d9-6a9c-7fea-a771-cbda7040cd5b / 2026-10-06T16:00:00.000Z

future: plan.deselected / 01a121da-88c1-7052-bb49-6b331e20fdef / 01a121da-88f4-7e1f-9b40-e0eee2f16171 / 2026-10-05T16:00:00.000Z; plan.rollover / 01a121da-8b7b-770c-b36d-c2bac416c1f1 / 01a121da-8ba5-7375-8566-3ce9dbe1e5f9 / 2026-10-06T16:00:00.000Z

Monday simulation: 2026-10-05T16:00:00Z. Tuesday: 2026-10-06T16:00:00Z. Friday: 2026-10-09T16:00:00Z. America/Chicago throughout. Interruption resumed under Friday clock and kept Tuesday event activity_at/recorded_at; receipts and original checkpoints are retained. Maintenance inspection used its actual host completion clock and did not advance worker success.

## Preserved failures and scope

The first recover-operation input used hashes instead of presence snapshots and was rejected. Initial Friday baseline enrollment was rejected for unrelated canonical fields, then for unsupported shape. Corrected observed canonical enrollment declared unchanged canonical file effects and accurate projection fields; the original plan/operation/event identities and event clocks remained intact. Every rejected input/result is retained, and no completion receipt was produced by those failures.

The interrupted branch separately stopped after destination persistence in branches.mjs; resume.mjs ran in a new process. Premature rollover-complete was pending with no event and no receipt. Resume logged one exact original event; append retry returned duplicate:true.

The original unmanaged Friday checkbox was preserved as an unresolved candidate; no acceptance or canonical work was inferred. checkin.json records that pending item. Rollover and selection assertions are complete; candidate disposition remains optional user work.

Current native conversation authored these workflows from installed skills. Host authentication, host version and model were not exposed, so no separate authenticated-host/discovery receipt is asserted.

Initial fixture creation and branch manual views are explicitly user-authorized. No previous attempts, authored operation scripts or regression tests were read.

Trusted worker unavailable in CLI; actual CLI maintenance inspection retained separately, with successAdvanced false.
