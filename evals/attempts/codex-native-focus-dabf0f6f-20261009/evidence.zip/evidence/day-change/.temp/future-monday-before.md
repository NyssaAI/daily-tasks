---
id: "01a121d7-573d-73fd-b795-1342ab0e5f0b"
type: daily-plan
title: "Daily plan 2026.10.05"
owner: "synthetic@example.test"
timezone: "America/Chicago"
created_at: "2026-10-05T16:00:00.000Z"
updated_at: "2026-10-05T16:00:00.000Z"
document-maturity: reviewed
---
# Daily plan — 2026.10.05

**Timezone:** America/Chicago

## Selected for today

### My work

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | Career materials | [[../Projects/job-search/m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 --> | — |
| 2 | [x] | Job Search | Career materials | [[../Projects/job-search/m1-career-materials/t4-past-work\|Past work]] <!-- ref: 01a121d7-5462-775c-bbb0-caa2696cdeb9 --> | — |
| 3 | [-] | Job Search | Career materials | ~~[[../Projects/job-search/m1-career-materials/t5-abandoned-work\|Abandoned work]]~~ <!-- ref: 01a121d7-54f2-756f-bb6a-78f076e27ae7 --> | — |

### Delegated work

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 4 | [ ] | Job Search | Career materials | [[../Projects/job-search/m1-career-materials/t3-review-draft\|Review draft]] <!-- ref: 01a121d7-53d3-78b2-84b6-b35853426426 --> | — |

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled

## Notes and references

Synthetic fixture; preserve this prose. F was explicitly deselected and remains open.
