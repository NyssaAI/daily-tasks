import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export const root=process.cwd(), evidence=path.join(root,'.temp');
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-log-migration-focus/codex-home/plugins/cache/daily-tasks-runtime-guards-log-migration-focus/daily-tasks/0.3.3';
fs.mkdirSync(evidence,{recursive:true});
export const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
export const hash=t=>t===null?null:createHash('sha256').update(t).digest('hex');
export const write=(p,t)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof t==='string'?t:JSON.stringify(t,null,2));};
let seq=fs.existsSync(path.join(evidence,'sequence.json'))?JSON.parse(read(path.join(evidence,'sequence.json'))):0;
export function cli(op,input){const label=String(++seq).padStart(3,'0')+'-'+op;write(path.join(evidence,'sequence.json'),seq);const ip=path.join(evidence,label+'.input.json');if(input)write(ip,input);const args=[path.join(pkg,'bin/daily-tasks.mjs'),op,...(input?['--input',ip]:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8',cwd:root});write(path.join(evidence,label+'.result.json'),{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(label+': '+r.stderr);return JSON.parse(r.stdout);}
export const id=()=>{const r=cli('new-id');return typeof r==='string'?r:r.id;};
export const clock={monday:'2026-10-05T16:00:00Z',tuesday:'2026-10-06T16:00:00Z',friday:'2026-10-09T16:00:00Z'};
export function options(vault,now){return {vaultRoot:vault,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json'),homeRoot:root,now};}
export function snapshot(vault,label){const dest=path.join(evidence,'snapshots',label);function walk(dir){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){if(ent.name==='.daily-tasks'||ent.name==='.temp')continue;const p=path.join(dir,ent.name);if(ent.isDirectory())walk(p);else write(path.join(dest,path.relative(vault,p)),read(p));}}walk(vault);}
