import fs from 'node:fs';import path from 'node:path';
import {root,evidence,read,write,hash,cli,id,options,clock,snapshot} from './session.mjs';
import {tasks,prepare,bound,planText,beginRollover,finishRollover,saveReview,baseline} from './workflow.mjs';
const v=path.join(root,'vault');
saveReview(v,clock.friday);const repeat=beginRollover(v,clock.friday,'friday-repeat');write(path.join(evidence,'friday-repeat.json'),repeat);snapshot(v,'friday-final');cli('maintenance-inspect',options(v,clock.friday));
const tv=path.join(evidence,'branches/tuesday/vault'),iv=path.join(evidence,'branches/interruption/vault'),fv=path.join(evidence,'branches/future/vault');
// Independent Tuesday fixtures contain only A on Monday; Tuesday B is already persisted.
for(const branch of [tv,iv,fv]){const monday=path.join(branch,'Daily/2026.10.05-daily-plan.md');const text=read(monday).split('\n').filter(line=>!tasks.slice(2).some(t=>line.includes('ref: '+t.id))).join('\n');write(path.join(evidence,path.basename(path.dirname(branch))+'-monday-before.md'),read(monday));write(monday,text);const p=prepare(branch,clock.tuesday),pid=id();write(p.current.path,planText(p,pid,[tasks[1]]));cli('invalidate-project-index',{vaultRoot:branch});snapshot(branch,path.basename(path.dirname(branch))+'-precreated');}
const tr=beginRollover(tv,clock.tuesday,'tuesday');finishRollover(tr);saveReview(tv,clock.tuesday);write(path.join(evidence,'tuesday-repeat-before-removal.json'),beginRollover(tv,clock.tuesday,'tuesday-repeat'));
// Actual interruption: checkpoint and destination persist in one process; no append or completion yet.
const interrupted=beginRollover(iv,clock.tuesday,'interrupted');write(path.join(evidence,'resume-reference.json'),{operationPath:interrupted.operationPath,v:iv,now:clock.tuesday,label:'interrupted',context:interrupted.p.context});
const premature=cli('rollover-complete',{...options(iv,clock.tuesday),operationPath:interrupted.operationPath});write(path.join(evidence,'interrupted-premature-completion.json'),premature);if(premature.status==='completed')throw Error('False completion');
write(path.join(evidence,'interrupted-state-before-resume.json'),{checkpointExists:fs.existsSync(interrupted.operationPath),receipt:read(path.join(interrupted.p.context.stateRoot,'rollover/2026.10.06.json')),events:cli('log-query',{projectsRoot:interrupted.p.context.projectsRoot})});
console.log('Destination persisted; interruption checkpoint retained. Next process resumes.');
