# Native session evidence

Only the current case, installed Daily Tasks 0.3.3 bundle and the authorized evals README were read. No prior attempts, existing operation scripts, regression tests or personal directories were opened. The installed context resolver reported a homeRoot field; the selected existing vault profile was reused and no home files were read.

The workflow.mjs file was newly authored in this session from the loaded skill instructions. It performs skill-owned fixture/Markdown/checkpoint writes and invokes the installed CLI for IDs, time, context, validation, allocation, recovery classification, log access and verified completion. Separate process invocations stopped at each boundary and later resumed the persisted checkpoint; the interruption is a deliberate process return, not an OS crash.

Actual workflow invocation order:

1. seed; refine-seed; prepare destination; destination destination; resume destination.
2. First destination resume removed verified milestone/task source copies, then migration-retirement refused retirement because other independent fixtures used the same bare wiki basename. The DoD remained live. The CLI refusal and action entry are retained.
3. qualify-fixture-links; resume destination; retry destination.
4. prepare removal; destination removal; remove removal; resume removal; retry removal.
5. prepare append; destination append; remove append; append append; resume append; retry append.
6. prepare edit; destination edit; remove edit; conflict-edit edit; resume edit.
7. prepare collision; conflict-collision collision; resume collision.
8. prepare competing was refused by number allocation amid the deliberately malformed unrelated collision document. No competing fixture migration occurred. competing competing executed the independent closure assertion against actual embedded and standalone criteria.
9. assess queried final records, links, navigation, closure and history.

The first evidence assessment reported 50/53 checks passing because its predicate looked for the raw frontmatter `task-state` field in parsed records. The installed parser returns `state`; actual saved completed records and history were unchanged. The evidence predicate was corrected to inspect `state` and raw record-version presence; lifecycle predicates were corrected similarly. Three explicit link/navigation assertions were added. Final assessment: 56/56 observed checks passed. This was an evidence-script correction, not an installed plugin fix or a Markdown change.

Missing task criteria were asked through the native host question tool. No reply was received by completion of this run; the requested acceptance assertions require retaining these tasks pending conversion, and that is their final state.

Native host version/model and separate plugin registration/authentication evidence were not exposed. Loaded installed skill paths and their hashes are in scenario8-result.json. CLI success is not claimed as proof of host activation or authentication.
