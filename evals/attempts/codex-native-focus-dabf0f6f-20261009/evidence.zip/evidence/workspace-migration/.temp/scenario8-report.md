# Scenario 8: workspace migration

Result: **PASS — 56/56 observed assertions passed.**

Actual Markdown workflows were authored from installed Daily Tasks 0.3.3 instructions in this native session. Node v24.19.0, Windows win32. Host model/version and separate registration/authentication evidence were not exposed; this report does not infer them from CLI success.

Three independently saved operations stopped after destination persistence, source removal, and log append. Each resumed from its saved checkpoint, completed through migration-complete, and retried with one exact migration event and no duplicate live identities.

Both deliberate conflicts preserve edited/unrelated bytes and pending checkpoints; neither has a migration event or completion. Embedded plus standalone milestone criteria block closure as competing sources.

Missing criteria were requested in the host conversation. Completed and unresolved tasks stay readable, unversioned and pending conversion; no criteria or satisfaction were inferred.

Evidence: [assertions](scenario8-result.json), [CLI transcripts](cli/), [final record inspection](final-inspection.json), [log query](final-history-query.json), [navigation diagnostics](final-navigation.json). Each fixture folder contains before/after bytes, authored checkpoint, action trace, retirement check and completion/conflict output. Backups are in each project’s .temp; log evidence was obtained only through CLI.

- Fresh agent-authored workflow; no prior operation scripts, attempts or regression tests read.
- Initial cross-fixture bare wiki links caused conservative retirement refusal; source was retained and other fixture links were qualified before further migration. Original refusal is retained in CLI results and destination actions.
- Competing-source preparation met ambiguous allocation caused by unrelated malformed collision fixture; no migration was performed. Direct closure check was executed on the independent competing-source fixture.

| Assertion | Result | Evidence |
| --- | --- | --- |
| destination: milestone and task identities preserved | Pass | destination/before.json; final-inspection.json |
| destination: milestone and task criteria text, checked state and UUIDs preserved | Pass | destination/before.json; final-inspection.json |
| destination: lifecycle and ownership preserved | Pass | final-inspection.json |
| destination: unchanged exact historical event | Pass | final-history-query.json |
| destination: evidence and non-criteria provenance preserved | Pass | destination/before.json; destination/after.json |
| destination: retirement allowed before source deletion | Pass | destination/actions.jsonl; destination/pre-removal-retirement.json |
| destination: blocker reciprocal with milestone and old DoD retired | Pass | final-inspection.json |
| destination: inbound criterion links retain UUID and navigate new owner | Pass | destination/after.json |
| destination: missing criteria not manufactured from completion | Pass | final-inspection.json; pending criteria question in host conversation |
| destination: unresolved legacy task readable and pending conversion | Pass | destination/authored-operation.json; final-inspection.json |
| destination: resume and retry exactly one matching event | Pass | final-history-query.json |
| destination: no duplicate live identities | Pass | final-inspection.json |
| destination: verified completion removes saved checkpoint | Pass | destination/completion.json |
| destination: exact planned effects and unrelated prose retained | Pass | destination/after.json |
| destination: empty flat holding areas | Pass | D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\runtime-guards-log-migration-focus\cases\workspace-migration\vault\Projects\migration-destination\m1-legacy-launch |
| destination: managed links, heading targets and evidence navigation verify | Pass | final-links.json; final-navigation.json |
| destination: independent interruption and saved-operation resume | Pass | destination/actions.jsonl |
| removal: milestone and task identities preserved | Pass | removal/before.json; final-inspection.json |
| removal: milestone and task criteria text, checked state and UUIDs preserved | Pass | removal/before.json; final-inspection.json |
| removal: lifecycle and ownership preserved | Pass | final-inspection.json |
| removal: unchanged exact historical event | Pass | final-history-query.json |
| removal: evidence and non-criteria provenance preserved | Pass | removal/before.json; removal/after.json |
| removal: retirement allowed before source deletion | Pass | removal/actions.jsonl; removal/pre-removal-retirement.json |
| removal: blocker reciprocal with milestone and old DoD retired | Pass | final-inspection.json |
| removal: inbound criterion links retain UUID and navigate new owner | Pass | removal/after.json |
| removal: missing criteria not manufactured from completion | Pass | final-inspection.json; pending criteria question in host conversation |
| removal: unresolved legacy task readable and pending conversion | Pass | removal/authored-operation.json; final-inspection.json |
| removal: resume and retry exactly one matching event | Pass | final-history-query.json |
| removal: no duplicate live identities | Pass | final-inspection.json |
| removal: verified completion removes saved checkpoint | Pass | removal/completion.json |
| removal: exact planned effects and unrelated prose retained | Pass | removal/after.json |
| removal: empty flat holding areas | Pass | D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\runtime-guards-log-migration-focus\cases\workspace-migration\vault\Projects\migration-removal\m1-legacy-launch |
| removal: managed links, heading targets and evidence navigation verify | Pass | final-links.json; final-navigation.json |
| removal: independent interruption and saved-operation resume | Pass | removal/actions.jsonl |
| append: milestone and task identities preserved | Pass | append/before.json; final-inspection.json |
| append: milestone and task criteria text, checked state and UUIDs preserved | Pass | append/before.json; final-inspection.json |
| append: lifecycle and ownership preserved | Pass | final-inspection.json |
| append: unchanged exact historical event | Pass | final-history-query.json |
| append: evidence and non-criteria provenance preserved | Pass | append/before.json; append/after.json |
| append: retirement allowed before source deletion | Pass | append/actions.jsonl; append/pre-removal-retirement.json |
| append: blocker reciprocal with milestone and old DoD retired | Pass | final-inspection.json |
| append: inbound criterion links retain UUID and navigate new owner | Pass | append/after.json |
| append: missing criteria not manufactured from completion | Pass | final-inspection.json; pending criteria question in host conversation |
| append: unresolved legacy task readable and pending conversion | Pass | append/authored-operation.json; final-inspection.json |
| append: resume and retry exactly one matching event | Pass | final-history-query.json |
| append: no duplicate live identities | Pass | final-inspection.json |
| append: verified completion removes saved checkpoint | Pass | append/completion.json |
| append: exact planned effects and unrelated prose retained | Pass | append/after.json |
| append: empty flat holding areas | Pass | D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\runtime-guards-log-migration-focus\cases\workspace-migration\vault\Projects\migration-append\m1-legacy-launch |
| append: managed links, heading targets and evidence navigation verify | Pass | final-links.json; final-navigation.json |
| append: independent interruption and saved-operation resume | Pass | append/actions.jsonl |
| edit: pending conflict, no false completion | Pass | edit/edit-conflict.json; final-history-query.json |
| edit: unexpected content preserved | Pass | edit/edit-conflict.json |
| collision: pending conflict, no false completion | Pass | collision/collision-conflict.json; final-history-query.json |
| collision: unexpected content preserved | Pass | collision/collision-conflict.json |
| Embedded and standalone DoD report competing sources | Pass | competing/competing-closure.json |
