---
id: "01a121d7-31c1-7481-8bb6-1572694445e1"
type: "daily-plan"
title: "Migration destination view"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
daily-plan-state: "not-started"
---
# Migration view

## Selected
- [ ] [[../Projects/migration-destination/m1-legacy-launch/t1-draft|Draft]] <!-- ref: 01a121d7-30b2-7301-9598-561df0246710 -->

## Criterion reference
- [[../Projects/migration-destination/m1-legacy-launch/m1-legacy-launch#Definition of Done|Review criterion]] <!-- ref: 01a121d7-3167-7fe0-a0b2-9634e45607b8 -->

Unrelated daily prose survives.
