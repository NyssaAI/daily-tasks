---
id: "01a121d7-3b23-718c-abec-45086ba7a947"
type: "daily-plan"
title: "Migration collision view"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
daily-plan-state: "not-started"
---
# Migration view

## Selected
- [ ] [[../Projects/migration-collision/draft|Draft]] <!-- ref: 01a121d7-3a15-77c7-a8a0-68d2dea5749d -->

## Criterion reference
- [[../Projects/migration-collision/definition-of-done#Definition of Done|Review criterion]] <!-- ref: 01a121d7-3ac7-7aa5-812d-e76096479fac -->

Unrelated daily prose survives.
