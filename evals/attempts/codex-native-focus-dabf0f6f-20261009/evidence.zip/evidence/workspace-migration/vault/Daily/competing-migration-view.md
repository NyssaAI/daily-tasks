---
id: "01a121d7-3d74-7807-82e2-0c7bde4dbe82"
type: "daily-plan"
title: "Migration competing view"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
daily-plan-state: "not-started"
---
# Migration view

## Selected
- [ ] [[../Projects/migration-competing/draft|Draft]] <!-- ref: 01a121d7-3c6e-781a-aa52-d29fdb983c8f -->

## Criterion reference
- [[../Projects/migration-competing/definition-of-done#Definition of Done|Review criterion]] <!-- ref: 01a121d7-3d18-78a3-bdcd-1ffa978c4e5c -->

Unrelated daily prose survives.
