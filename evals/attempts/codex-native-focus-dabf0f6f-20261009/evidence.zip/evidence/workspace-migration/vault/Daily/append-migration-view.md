---
id: "01a121d7-3677-7e92-9e5b-fee6cd44222e"
type: "daily-plan"
title: "Migration append view"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
daily-plan-state: "not-started"
---
# Migration view

## Selected
- [ ] [[../Projects/migration-append/m1-legacy-launch/t1-draft|Draft]] <!-- ref: 01a121d7-3569-74ff-bc88-faaa40b83c9b -->

## Criterion reference
- [[../Projects/migration-append/m1-legacy-launch/m1-legacy-launch#Definition of Done|Review criterion]] <!-- ref: 01a121d7-361f-745a-a952-421ebd0b210c -->

Unrelated daily prose survives.
