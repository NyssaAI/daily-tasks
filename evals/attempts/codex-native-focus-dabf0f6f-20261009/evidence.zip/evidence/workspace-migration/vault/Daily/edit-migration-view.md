---
id: "01a121d7-38db-7df9-9dd5-04228bb2aa6c"
type: "daily-plan"
title: "Migration edit view"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
daily-plan-state: "not-started"
---
# Migration view

## Selected
- [ ] [[../Projects/migration-edit/m1-legacy-launch/t1-draft|Draft]] <!-- ref: 01a121d7-37c1-7563-8759-8b848a652555 -->

## Criterion reference
- [[../Projects/migration-edit/m1-legacy-launch/m1-legacy-launch#Definition of Done|Review criterion]] <!-- ref: 01a121d7-387c-7acd-a141-0ccb35fe3568 -->

Unrelated daily prose survives.
