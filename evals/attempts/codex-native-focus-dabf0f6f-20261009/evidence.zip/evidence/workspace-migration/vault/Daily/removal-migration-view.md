---
id: "01a121d7-3420-7ec1-bbe6-fb7db2a94d5e"
type: "daily-plan"
title: "Migration removal view"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
daily-plan-state: "not-started"
---
# Migration view

## Selected
- [ ] [[../Projects/migration-removal/m1-legacy-launch/t1-draft|Draft]] <!-- ref: 01a121d7-3309-7155-b1fb-67f7ca70fdbf -->

## Criterion reference
- [[../Projects/migration-removal/m1-legacy-launch/m1-legacy-launch#Definition of Done|Review criterion]] <!-- ref: 01a121d7-33c1-7c82-a1c6-80f30b246f3f -->

Unrelated daily prose survives.
