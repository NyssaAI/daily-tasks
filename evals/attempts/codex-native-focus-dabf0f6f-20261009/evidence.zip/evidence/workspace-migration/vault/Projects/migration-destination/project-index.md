---
id: "01a121d7-3029-7367-983e-42f788d5a770"
type: "project"
record_version: 2
title: "Migration destination"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "in-progress"
---
# Migration destination

Unrelated project prose survives.

## Milestones
- [ ] [[m1-legacy-launch/m1-legacy-launch|Legacy launch]] <!-- ref: 01a121d7-3058-7d08-9c67-a281e11c0be2 -->
