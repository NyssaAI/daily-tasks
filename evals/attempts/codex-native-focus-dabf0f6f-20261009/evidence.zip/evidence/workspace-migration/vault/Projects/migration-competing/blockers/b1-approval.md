---
id: "01a121d7-3ced-79d8-b99e-c25adc8278a0"
type: "blocker"
title: "Approval"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
blocker-state: "open"
project_id: "01a121d7-3be7-71b8-a696-3de967b775dd"
---
# Approval

Approval is pending; written approval resolves it.

## Blocks
- [[../definition-of-done|Legacy acceptance]] <!-- ref: 01a121d7-3c43-7ccf-8ae4-0fce4a206efc -->
