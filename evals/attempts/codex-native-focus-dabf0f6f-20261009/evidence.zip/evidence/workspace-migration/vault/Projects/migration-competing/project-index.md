---
id: "01a121d7-3be7-71b8-a696-3de967b775dd"
type: "project"
record_version: 2
title: "Migration competing"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "in-progress"
---
# Migration competing

Unrelated project prose survives.

## Milestones
- [ ] [[milestone|Legacy launch]] <!-- ref: 01a121d7-3c16-702a-82df-d723882af985 -->
