---
id: "01a121d7-3c16-702a-82df-d723882af985"
type: "milestone"
title: "Legacy launch"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
milestone-state: "in-progress"
project_id: "01a121d7-3be7-71b8-a696-3de967b775dd"
---
# Legacy launch

## Project
- [[project-index|Project]] <!-- ref: 01a121d7-3be7-71b8-a696-3de967b775dd -->

## Definition
- [[./definition-of-done|Legacy acceptance]] <!-- ref: 01a121d7-3c43-7ccf-8ae4-0fce4a206efc -->

## Tasks
- [ ] [[draft|Draft]] <!-- ref: 01a121d7-3c6e-781a-aa52-d29fdb983c8f -->
- [x] [[completed|Completed without criteria]] <!-- ref: 01a121d7-3c98-7ccb-aa6a-a970a717e4ad -->
- [ ] [[unresolved|Unresolved legacy task]] <!-- ref: 01a121d7-3cc3-723d-bbeb-bd59f1aa8e3e -->

## Definition of Done
- [ ] Independent embedded source. <!-- id: 01a121d9-3539-73f9-9ff7-9af756789869 -->
