---
id: "01a121d7-372e-74be-a708-a7e47f176465"
type: "project"
record_version: 2
title: "Migration edit"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "in-progress"
---
# Migration edit

Unrelated project prose survives.

## Milestones
- [ ] [[m1-legacy-launch/m1-legacy-launch|Legacy launch]] <!-- ref: 01a121d7-375d-7b7a-9d09-c70ea09f0ffa -->
