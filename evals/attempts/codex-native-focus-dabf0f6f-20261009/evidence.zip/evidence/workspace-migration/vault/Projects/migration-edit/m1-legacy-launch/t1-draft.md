---
id: "01a121d7-37c1-7563-8759-8b848a652555"
type: "task"
record_version: 2
title: "Draft"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "in-progress"
project_id: "01a121d7-372e-74be-a708-a7e47f176465"
milestone_id: "01a121d7-375d-7b7a-9d09-c70ea09f0ffa"
---
# Draft

## Milestone
- [[m1-legacy-launch|Legacy launch]] <!-- ref: 01a121d7-375d-7b7a-9d09-c70ea09f0ffa -->

## Requirements
Prepare a draft for review.

## Definition of Done
- [ ] Draft is accepted by reviewer. <!-- id: 01a121d7-38aa-7512-9c40-feffbf91d0f4 -->

## Acceptance reference
- [[m1-legacy-launch#Definition of Done|Review criterion]] <!-- ref: 01a121d7-387c-7acd-a141-0ccb35fe3568 -->

Unrelated task prose survives.

Unexpected independent reviewer edit.
