---
id: "01a121d7-3309-7155-b1fb-67f7ca70fdbf"
type: "task"
record_version: 2
title: "Draft"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "in-progress"
project_id: "01a121d7-3281-76ea-aa43-f377d43ad94e"
milestone_id: "01a121d7-32ae-7a47-a0c4-8e75203c3692"
---
# Draft

## Milestone
- [[m1-legacy-launch|Legacy launch]] <!-- ref: 01a121d7-32ae-7a47-a0c4-8e75203c3692 -->

## Requirements
Prepare a draft for review.

## Definition of Done
- [ ] Draft is accepted by reviewer. <!-- id: 01a121d7-33f1-7bd7-9689-9832f46a056d -->

## Acceptance reference
- [[m1-legacy-launch#Definition of Done|Review criterion]] <!-- ref: 01a121d7-33c1-7c82-a1c6-80f30b246f3f -->

Unrelated task prose survives.
