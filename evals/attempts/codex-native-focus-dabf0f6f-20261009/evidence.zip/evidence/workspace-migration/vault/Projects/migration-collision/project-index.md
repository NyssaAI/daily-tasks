---
id: "01a121d7-3995-7080-b0e9-860f716febf9"
type: "project"
record_version: 2
title: "Migration collision"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "in-progress"
---
# Migration collision

Unrelated project prose survives.

## Milestones
- [ ] [[milestone|Legacy launch]] <!-- ref: 01a121d7-39bf-7914-86e1-bdf025922db6 -->
