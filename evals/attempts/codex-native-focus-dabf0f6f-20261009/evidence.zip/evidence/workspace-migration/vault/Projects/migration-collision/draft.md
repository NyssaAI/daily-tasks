---
id: "01a121d7-3a15-77c7-a8a0-68d2dea5749d"
type: "task"
title: "Draft"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "in-progress"
project_id: "01a121d7-3995-7080-b0e9-860f716febf9"
milestone_id: "01a121d7-39bf-7914-86e1-bdf025922db6"
---
# Draft

## Milestone
- [[milestone|Legacy launch]] <!-- ref: 01a121d7-39bf-7914-86e1-bdf025922db6 -->

## Requirements
Prepare a draft for review.

## Definition of Done
- [ ] Draft is accepted by reviewer. <!-- id: 01a121d7-3af6-75aa-bb36-d7bd9255d284 -->

## Acceptance reference
- [[./definition-of-done#Definition of Done|Review criterion]] <!-- ref: 01a121d7-3ac7-7aa5-812d-e76096479fac -->

Unrelated task prose survives.
