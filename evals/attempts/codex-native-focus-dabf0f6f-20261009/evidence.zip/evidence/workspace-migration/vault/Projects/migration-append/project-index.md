---
id: "01a121d7-34e1-75d5-b85d-7f16c2999da8"
type: "project"
record_version: 2
title: "Migration append"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "in-progress"
---
# Migration append

Unrelated project prose survives.

## Milestones
- [ ] [[m1-legacy-launch/m1-legacy-launch|Legacy launch]] <!-- ref: 01a121d7-3510-7fc1-94c2-eccda953550b -->
