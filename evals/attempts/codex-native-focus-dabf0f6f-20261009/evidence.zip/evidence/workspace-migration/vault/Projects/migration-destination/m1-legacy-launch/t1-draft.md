---
id: "01a121d7-30b2-7301-9598-561df0246710"
type: "task"
record_version: 2
title: "Draft"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "in-progress"
project_id: "01a121d7-3029-7367-983e-42f788d5a770"
milestone_id: "01a121d7-3058-7d08-9c67-a281e11c0be2"
---
# Draft

## Milestone
- [[m1-legacy-launch|Legacy launch]] <!-- ref: 01a121d7-3058-7d08-9c67-a281e11c0be2 -->

## Requirements
Prepare a draft for review.

## Definition of Done
- [ ] Draft is accepted by reviewer. <!-- id: 01a121d7-3194-79a3-b656-99f661f94594 -->

## Acceptance reference
- [[m1-legacy-launch#Definition of Done|Review criterion]] <!-- ref: 01a121d7-3167-7fe0-a0b2-9634e45607b8 -->

Unrelated task prose survives.
