---
id: "01a121d7-3a98-7a95-bb80-5ec7cf276c77"
type: "blocker"
title: "Approval"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
blocker-state: "open"
project_id: "01a121d7-3995-7080-b0e9-860f716febf9"
---
# Approval

Approval is pending; written approval resolves it.

## Blocks
- [[../definition-of-done|Legacy acceptance]] <!-- ref: 01a121d7-39ea-7d5f-a287-12be2d89bc3d -->
