---
id: "01a121d7-3281-76ea-aa43-f377d43ad94e"
type: "project"
record_version: 2
title: "Migration removal"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "in-progress"
---
# Migration removal

Unrelated project prose survives.

## Milestones
- [ ] [[m1-legacy-launch/m1-legacy-launch|Legacy launch]] <!-- ref: 01a121d7-32ae-7a47-a0c4-8e75203c3692 -->
