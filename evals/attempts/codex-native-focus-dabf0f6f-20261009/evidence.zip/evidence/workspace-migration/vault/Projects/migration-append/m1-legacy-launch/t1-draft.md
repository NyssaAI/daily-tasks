---
id: "01a121d7-3569-74ff-bc88-faaa40b83c9b"
type: "task"
record_version: 2
title: "Draft"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "in-progress"
project_id: "01a121d7-34e1-75d5-b85d-7f16c2999da8"
milestone_id: "01a121d7-3510-7fc1-94c2-eccda953550b"
---
# Draft

## Milestone
- [[m1-legacy-launch|Legacy launch]] <!-- ref: 01a121d7-3510-7fc1-94c2-eccda953550b -->

## Requirements
Prepare a draft for review.

## Definition of Done
- [ ] Draft is accepted by reviewer. <!-- id: 01a121d7-364b-7d5f-bc2b-2d087c79e22b -->

## Acceptance reference
- [[m1-legacy-launch#Definition of Done|Review criterion]] <!-- ref: 01a121d7-361f-745a-a952-421ebd0b210c -->

Unrelated task prose survives.
