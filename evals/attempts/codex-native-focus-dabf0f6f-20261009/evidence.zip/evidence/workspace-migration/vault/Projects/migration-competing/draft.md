---
id: "01a121d7-3c6e-781a-aa52-d29fdb983c8f"
type: "task"
title: "Draft"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "in-progress"
project_id: "01a121d7-3be7-71b8-a696-3de967b775dd"
milestone_id: "01a121d7-3c16-702a-82df-d723882af985"
---
# Draft

## Milestone
- [[milestone|Legacy launch]] <!-- ref: 01a121d7-3c16-702a-82df-d723882af985 -->

## Requirements
Prepare a draft for review.

## Definition of Done
- [ ] Draft is accepted by reviewer. <!-- id: 01a121d7-3d46-7d13-ae05-08fb118234b3 -->

## Acceptance reference
- [[./definition-of-done#Definition of Done|Review criterion]] <!-- ref: 01a121d7-3d18-78a3-bdcd-1ffa978c4e5c -->

Unrelated task prose survives.
