---
id: "01a121d7-39bf-7914-86e1-bdf025922db6"
type: "milestone"
title: "Legacy launch"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
milestone-state: "in-progress"
project_id: "01a121d7-3995-7080-b0e9-860f716febf9"
---
# Legacy launch

## Project
- [[project-index|Project]] <!-- ref: 01a121d7-3995-7080-b0e9-860f716febf9 -->

## Definition
- [[./definition-of-done|Legacy acceptance]] <!-- ref: 01a121d7-39ea-7d5f-a287-12be2d89bc3d -->

## Tasks
- [ ] [[draft|Draft]] <!-- ref: 01a121d7-3a15-77c7-a8a0-68d2dea5749d -->
- [x] [[completed|Completed without criteria]] <!-- ref: 01a121d7-3a40-79bc-88f5-d3017b3cde4c -->
- [ ] [[unresolved|Unresolved legacy task]] <!-- ref: 01a121d7-3a6c-75a0-a8ce-4711e2f46a57 -->
