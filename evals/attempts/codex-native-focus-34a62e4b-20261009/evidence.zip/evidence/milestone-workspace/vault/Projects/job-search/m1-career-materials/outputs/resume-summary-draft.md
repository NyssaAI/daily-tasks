# Resume summary draft

Career professional focused on clear communication and thoughtful collaboration. Seeking an opportunity to contribute practical skills and develop through purposeful work.

Aligned with the LinkedIn headline draft consumed in place. Synthetic sources contain no career facts; user review and factual tailoring remain required.
