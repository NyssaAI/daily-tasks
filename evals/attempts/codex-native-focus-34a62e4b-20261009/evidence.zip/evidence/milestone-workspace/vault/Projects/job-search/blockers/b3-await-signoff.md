---
id: "01a121b7-3305-7ae6-aa02-98d5162dfa06"
type: blocker
record_version: 2
title: "Await signoff"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T17:30:16.752Z"
updated_at: "2026-10-09T17:30:16.752Z"
---
# Await signoff

Await external user signoff.

## Resolution condition

User supplies signoff.

## Resolution evidence

Pending.

## Blocks
