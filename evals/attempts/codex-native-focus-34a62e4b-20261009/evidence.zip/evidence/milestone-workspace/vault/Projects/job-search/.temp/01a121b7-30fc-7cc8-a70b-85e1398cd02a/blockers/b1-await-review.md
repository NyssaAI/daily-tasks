---
id: "01a121b7-2b4c-7560-a783-186c81c54be4"
type: blocker
record_version: 2
title: "Await review"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T17:30:14.780Z"
updated_at: "2026-10-09T17:30:14.780Z"
---
# Await review

Await external user review.

## Resolution condition

User provides review.

## Resolution evidence

Pending.

## Blocks
