---
id: "01a121b7-2e3c-7f5d-8dd9-a0f39fdefa38"
type: blocker
record_version: 2
title: "Await source"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T17:30:15.531Z"
updated_at: "2026-10-09T17:30:15.531Z"
---
# Await source

Await external source material.

## Resolution condition

User supplies source material.

## Resolution evidence

Pending.

## Blocks
