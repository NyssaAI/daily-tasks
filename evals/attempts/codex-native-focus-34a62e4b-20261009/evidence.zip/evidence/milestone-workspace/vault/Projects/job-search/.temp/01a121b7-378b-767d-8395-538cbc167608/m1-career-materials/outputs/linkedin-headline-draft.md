# LinkedIn headline draft

Career professional | Clear communication and thoughtful collaboration

Synthetic draft for user review. Source identifies no role or achievements; no credentials are asserted.
