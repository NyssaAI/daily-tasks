---
id: "01a121b7-288b-715a-88f3-abfbcf8fcb25"
type: task
record_version: 2
title: "Polish summary"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
task-state: not-started
created_at: "2026-10-09T17:30:14.112Z"
updated_at: "2026-10-09T17:30:14.112Z"
---
# M1-T3 — Polish summary

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Polish summary.

## Definition of Done

- [ ] User reviewed polished summary. <!-- id: 01a121b7-28b6-7575-a66a-b5a2e102e245 -->

## Inputs

[Resume summary draft](outputs/resume-summary-draft.md).

## Output and delivery

Save a polished summary locally in outputs/ when executed.

## Verification

Obtain user review before satisfying the criterion.

## Result

Accepted; work has not started.
