import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-corrected-focus/codex-home/plugins/cache/daily-tasks-runtime-guards-corrected-focus/daily-tasks/0.3.3';
const entry=path.join(pkg,'bin/daily-tasks.mjs');
let sequence=0;
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>fs.readFileSync(p,'utf8');
const write=(p,b)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b);};
function cli(op,input){const stem=`${String(++sequence).padStart(3,'0')}-${op}`, inputPath=path.join(scratch,stem+'.input.json'); if(input)write(inputPath,JSON.stringify(input,null,2));const args=[entry,op,...(input?['--input',inputPath]:[])]; const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(path.join(scratch,stem+'.result.json'),JSON.stringify({command:[process.execPath,...args],status:r.status,stdout:r.stdout,stderr:r.stderr},null,2)); if(r.status!==0)throw Error(op+': '+r.stderr);return JSON.parse(r.stdout);}
const vault=path.join(root,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'job-search'), m=path.join(project,'m1-career-materials');
const context=cli('resolve-context',{vaultRoot:vault});write(path.join(scratch,'context.json'),JSON.stringify(context,null,2));
const t1=path.join(m,'t1-update-linkedin.md'),t2=path.join(m,'t2-update-resume.md'), milestone=path.join(m,'m1-career-materials.md'),index=path.join(project,'project-index.md');
const id=p=>read(p).match(/^id: "?([^"\r\n]+)"?$/m)[1];const pId=id(index),mId=id(milestone),aId=id(t1),bId=id(t2);
function snapshot(label){for(const p of [index,milestone,t1,t2])write(path.join(scratch,label,path.relative(project,p)),fs.readFileSync(p));}
snapshot('before');
const initial={files:fs.readdirSync(m),inputs:fs.readdirSync(path.join(m,'inputs')),outputs:fs.readdirSync(path.join(m,'outputs'))};write(path.join(scratch,'initial-layout.json'),JSON.stringify(initial,null,2));
if(initial.inputs.length||initial.outputs.length)throw Error('Initial holding areas not empty');
cli('inspect-records',{projectsRoot:projects});cli('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot});cli('log-query',{projectsRoot:projects});
const newId=()=>{const r=cli('new-id');return typeof r==='string'?r:r.id;};
async function batch(name,changes,records,before,after){
const time=cli('activity-time',{}),operation_id=newId(),eventId=newId();
const event={id:eventId,operation_id,action:name,record_ids:records,actor:{kind:'agent',id:'Codex'},...time,original_words:'Execute scenario7: '+name,before,after};
const files=changes.map(([p,b])=>({path:p,before:fs.existsSync(p)?hash(fs.readFileSync(p)):null,after:b===null?null:hash(Buffer.from(b))}));
const operation={schemaVersion:2,operation_id,contextBinding:context.planningBinding,event,files};
const opPath=path.join(context.stateRoot,'operations',operation_id+'.json');
for(const f of files)if(f.before)write(path.join(project,'.temp',operation_id,path.relative(project,f.path)),fs.readFileSync(f.path));
write(opPath,JSON.stringify(operation,null,2));write(path.join(scratch,name+'.checkpoint.json'),JSON.stringify(operation,null,2));
for(let i=0;i<changes.length;i++){const [p,b]=changes[i],f=files[i];if((fs.existsSync(p)?hash(fs.readFileSync(p)):null)!==f.before)throw Error('Concurrent edit');if(b!==null)write(p,b);}
// Verify destination and updated references before removal.
for(const [p,b] of changes)if(b===null)fs.unlinkSync(p);
cli('invalidate-project-index',{vaultRoot:vault});
cli('inspect-records',{projectsRoot:projects});cli('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot});
cli('log-append',{projectsRoot:projects,entry:event});cli('log-query',{projectsRoot:projects,recordId:records[0]});
const input={vaultRoot:vault,operationPath:opPath};const v=cli('operation-verify',input);write(path.join(scratch,name+'.verification.json'),JSON.stringify(v,null,2));
const c=cli('operation-complete',input);if(c.status!=='completed'&&c.status!=='complete') {if(fs.existsSync(opPath))throw Error('Pending completion '+JSON.stringify(c));}
}
const inputs=path.join(m,'inputs'),outputs=path.join(m,'outputs');
let a=read(t1),b=read(t2);
const shared='- [Shared style guide](inputs/shared-style-guide.txt) — source: supplied attachments/shared.txt.\n';
a=a.replace('No source material has been supplied. Local working inputs belong in inputs/.','- [LinkedIn source](inputs/linkedin-source.txt) — source: supplied attachments/a/source.txt.\n'+shared);
b=b.replace('No source material has been supplied. Local working inputs belong in inputs/.','- [Resume source](inputs/resume-source.txt) — source: supplied attachments/b/source.txt.\n'+shared);
await batch('import-inputs',[[path.join(inputs,'linkedin-source.txt'),read(path.join(root,'attachments/a/source.txt'))],[path.join(inputs,'resume-source.txt'),read(path.join(root,'attachments/b/source.txt'))],[path.join(inputs,'shared-style-guide.txt'),read(path.join(root,'attachments/shared.txt'))],[path.join(inputs,'task-shaped-attachment.md'),read(t1)],[t1,a],[t2,b]],[aId,bId],{inputs:[]},{inputs:['linkedin-source.txt','resume-source.txt','shared-style-guide.txt','task-shaped-attachment.md'],acceptance:'Explicit supplied request; attachment is not accepted work'});
const headline='# LinkedIn headline draft\n\nCareer professional | Clear communication and thoughtful collaboration\n\nSynthetic draft for user review. Source identifies no role or achievements; no credentials are asserted.\n';
const summary='# Resume summary draft\n\nCareer professional focused on clear communication and thoughtful collaboration. Seeking an opportunity to contribute practical skills and develop through purposeful work.\n\nAligned with the LinkedIn headline draft consumed in place. Synthetic sources contain no career facts; user review and factual tailoring remain required.\n';
a=read(t1).replace('## Output and delivery\n','## Output and delivery\n\nDraft: [LinkedIn headline](outputs/linkedin-headline-draft.md).\n').replace('Work has not started; no artifact has been produced or reviewed.','Local draft produced: [LinkedIn headline](outputs/linkedin-headline-draft.md). User review is pending; DoD remains unchecked.');
b=read(t2).replace('## Inputs\n','## Inputs\n\n- [LinkedIn headline draft](outputs/linkedin-headline-draft.md) — consumed in its existing output location to align the summary.\n').replace('## Output and delivery\n','## Output and delivery\n\nDraft: [Resume summary](outputs/resume-summary-draft.md).\n').replace('Work has not started; no artifact has been produced or reviewed.','Local draft produced: [Resume summary](outputs/resume-summary-draft.md). User review is pending; DoD remains unchecked.');
await batch('deliver-drafts',[[path.join(outputs,'linkedin-headline-draft.md'),headline],[path.join(outputs,'resume-summary-draft.md'),summary],[t1,a],[t2,b]],[aId,bId],{outputs:[]},{outputs:['linkedin-headline-draft.md','resume-summary-draft.md'],review:'pending'});
const scanned=cli('inspect-records',{projectsRoot:projects});write(path.join(scratch,'post-import-records.json'),JSON.stringify(scanned,null,2));
cli('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,forceRefresh:true});
const taskSnap=(p,state)=>({id:id(p),type:'task',path:p,project_id:pId,milestone_id:mId,state});
let mm=read(milestone),ii=read(index);
const rows=mm.match(/- \[ \] \[\[t[12][^\n]+/g);mm=mm.replace(rows.join('\n'),[rows[1],rows[0]].join('\n'));
await batch('reorder-tasks',[[milestone,mm]],[aId,bId],{order:[aId,bId]},{order:[bId,aId]});
const cancellation=cli('activity-time',{});
a=read(t1).replace('task-state: "not-started"','task-state: "cancelled"').replace(/^updated_at:.*$/m,`updated_at: "${cancellation.recorded_at}"`).replace('document-maturity:',`resolved_at: "${cancellation.activity_at}"\ndocument-maturity:`);
mm=read(milestone).replace(rows[0],rows[0].replace('- [ ]','- [-]').replace('|Update LinkedIn]]','|~~Update LinkedIn~~]]'));
ii=ii.replace('| [ ] [[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]]','| [-] [[m1-career-materials/t1-update-linkedin\\|~~Update LinkedIn~~]]');
await batch('cancel-task1',[[t1,a],[milestone,mm],[index,ii]],[aId],taskSnap(t1,'not-started'),taskSnap(t1,'cancelled'));
const num=cli('next-record-number',{projectsRoot:projects,type:'task',parentId:mId});if(num.number!==3)throw Error('Expected task3 '+JSON.stringify(num));
const cId=newId(),criterion=newId(),created=cli('activity-time',{}).recorded_at,t3=path.join(m,'t3-polish-summary.md');
const task3=`---\nid: "${cId}"\ntype: task\nrecord_version: 2\ntitle: "Polish summary"\nowner: "synthetic@example.test"\nproject_id: "${pId}"\nmilestone_id: "${mId}"\ntask-state: not-started\ncreated_at: "${created}"\nupdated_at: "${created}"\n---\n# M1-T3 — Polish summary\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${mId} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${pId} -->\n\n## Requirements\n\nPolish summary.\n\n## Definition of Done\n\n- [ ] User reviewed polished summary. <!-- id: ${criterion} -->\n\n## Inputs\n\n[Resume summary draft](outputs/resume-summary-draft.md).\n\n## Output and delivery\n\nSave a polished summary locally in outputs/ when executed.\n\n## Verification\n\nObtain user review before satisfying the criterion.\n\n## Result\n\nAccepted; work has not started.\n`;
mm=read(milestone)+`\n- [ ] [[t3-polish-summary|Polish summary]] <!-- ref: ${cId} -->\n`;
ii=read(index)+`| | [ ] [[m1-career-materials/t3-polish-summary\\|Polish summary]] <!-- ref: ${cId} --> | Polish summary. | Synthetic User | — |\n`;
await batch('accept-task3',[[t3,task3],[milestone,mm],[index,ii]],[cId],null,{id:cId,type:'task',path:t3,project_id:pId,milestone_id:mId,acceptance:'User explicitly accepted Polish summary and its requirement/DoD'});
const blockers=path.join(project,'blockers');let blockersIds=[];
for(const [title,slug] of [['Await review','await-review'],['Await source','await-source']]){
 const n=cli('next-record-number',{projectsRoot:projects,type:'blocker',parentId:pId}).number, bid=newId(),time=cli('activity-time',{}).recorded_at,bp=path.join(blockers,`b${n}-${slug}.md`);blockersIds.push(bid);
 const text=`---\nid: "${bid}"\ntype: blocker\nrecord_version: 2\ntitle: "${title}"\nblocker-state: open\nowner: "synthetic@example.test"\nproject_id: "${pId}"\ncreated_at: "${time}"\nupdated_at: "${time}"\n---\n# ${title}\n\n${title==='Await review'?'Await external user review.':'Await external source material.'}\n\n## Resolution condition\n\n${title==='Await review'?'User provides review.':'User supplies source material.'}\n\n## Resolution evidence\n\nPending.\n\n## Blocks\n`;
 await batch(`accept-blocker${n}`,[[bp,text]],[bid],null,{id:bid,type:'blocker',path:bp,project_id:pId,acceptance:'Explicit user acceptance'});
}
const bp1=path.join(blockers,'b1-await-review.md'),bp2=path.join(blockers,'b2-await-source.md'),resolved=cli('activity-time',{});
await batch('resolve-blocker1',[[bp1,read(bp1).replace('blocker-state: open','blocker-state: resolved').replace(/^updated_at:.*$/m,`updated_at: "${resolved.recorded_at}"\nresolved_at: "${resolved.activity_at}"`).replace('Pending.','Resolved by explicit user instruction in this synthetic scenario; task draft review criteria remain unchecked.') ]],[blockersIds[0]],{id:blockersIds[0],type:'blocker',path:bp1,project_id:pId,state:'open'},{id:blockersIds[0],type:'blocker',path:bp1,project_id:pId,state:'resolved'});
const bn=cli('next-record-number',{projectsRoot:projects,type:'blocker',parentId:pId}).number;if(bn!==3)throw Error('Expected b3');
const bid3=newId(),time3=cli('activity-time',{}).recorded_at,bp3=path.join(blockers,'b3-await-signoff.md');
await batch('accept-blocker3',[[bp3,`---\nid: "${bid3}"\ntype: blocker\nrecord_version: 2\ntitle: "Await signoff"\nblocker-state: open\nowner: "synthetic@example.test"\nproject_id: "${pId}"\ncreated_at: "${time3}"\nupdated_at: "${time3}"\n---\n# Await signoff\n\nAwait external user signoff.\n\n## Resolution condition\n\nUser supplies signoff.\n\n## Resolution evidence\n\nPending.\n\n## Blocks\n`]],[bid3],null,{id:bid3,type:'blocker',path:bp3,project_id:pId,acceptance:'Explicit user acceptance'});
const relation=`\n## Blocked by\n\n- [[../blockers/b2-await-source|Await source]] <!-- ref: ${blockersIds[1]} -->\n`;
await batch('link-shared-blocker',[[t1,read(t1)+relation],[t2,read(t2)+relation],[bp2,read(bp2)+`- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: ${aId} -->\n- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: ${bId} -->\n`]],[aId,bId,blockersIds[1]],{links:[]},{blocker:bp2,consumers:[aId,bId]});
const oldOutput=path.join(outputs,'linkedin-headline-draft.md'),newOutput=path.join(outputs,'career-headline-draft.md');
await batch('rename-headline-output',[[newOutput,read(oldOutput)],[t1,read(t1).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md')],[t2,read(t2).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md')],[oldOutput,null]],[aId,bId],{path:oldOutput},{path:newOutput});
snapshot('after');
const finalRecords=cli('inspect-records',{projectsRoot:projects});write(path.join(scratch,'final-records.json'),JSON.stringify(finalRecords,null,2));
const nav=cli('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot});write(path.join(scratch,'final-navigation.json'),JSON.stringify(nav,null,2));
const inv=cli('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,forceRefresh:true});write(path.join(scratch,'final-inventory.json'),JSON.stringify(inv,null,2));
cli('next-record-number',{projectsRoot:projects,type:'task',parentId:mId});cli('next-record-number',{projectsRoot:projects,type:'blocker',parentId:pId});cli('log-query',{projectsRoot:projects,limit:1000});
console.log(JSON.stringify({context,finalRecords,nav,inv},null,2));
