# Scenario 7 — Milestone workspace

Status: **FAIL**

- PASS: Initial numbered milestone, sibling tasks, empty flat holding areas. Evidence: initial-layout.json; before/.
- PASS: Both same-basename originals preserved byte for byte with meaningful names. Evidence: Supplied originals versus imported SHA256.
- PASS: Shared input has one working copy and both consumer links. Evidence: Task Inputs sections.
- PASS: Holding areas remain flat. Evidence: Final directory entries.
- PASS: Two authorized local draft outputs delivered. Evidence: outputs/.
- PASS: Task2 consumes task1 output in place. Evidence: Task2 Inputs; no input copy.
- PASS: Task-shaped copied-ID attachment excluded from inspect-records and planning inventory. Evidence: post-import-records.json; final-records.json; final-inventory.json (cancelled T1 omitted from available tasks).
- PASS: Project to milestone to tasks to files navigation. Evidence: final-navigation.json.
- PASS: Distinct requirements and DoD retained; drafts do not satisfy review. Evidence: Canonical requirements/DoD; audit check-closure results.
- FAIL: Reordered tasks; cancelled T1 visible; T3 accepted; stable labels; retired number reserved. Evidence: reorder-tasks/cancel-task1/accept-task3 checkpoints and log queries; next number 4.
- FAIL: B1/B2 accepted; B1 resolved; B3 added without renumbering or reuse. Evidence: Blocker records and CLI allocation queries.
- PASS: One B2 record links both original tasks reciprocally. Evidence: check-links and parsed records.
- PASS: Output rename repaired producer and consumer links. Evidence: rename-headline-output checkpoint.
- PASS: Unrelated prose and original criterion IDs preserved. Evidence: Exact section comparisons with before snapshots.
- PASS: All project work within project; scratch within .temp; operations verified. Evidence: Checkpoint paths; no pending operations; all completion CLI results retained.

All CLI inputs, raw stdout/stderr, exit codes, checkpoint copies, before/after snapshots and log-query results are retained here. Fresh workflows were authored from installed skills. Authentication and plugin discovery are not independently attested by CLI results.

Failure: Agent-authored artifact rename event used rename-headline-output instead of artifact.renamed. Its two affected task IDs lack concrete record snapshots, so CLI classifies numbering history as ambiguous. Next task and blocker numbers are null with usedNumbers [1,2,3]. Existing labels were not reused or changed; continued allocation is blocked. No log bytes edited. Installed correction merge cannot enrich the two anonymous path snapshots consistently for two affected IDs. Preserve this failed native attempt; a new acceptance run must use artifact.renamed with holding-area before/after paths.
