const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const packet = JSON.parse(fs.readFileSync('.temp/prepare-result.json', 'utf8'));
const before = fs.readFileSync('.temp/maintenance-before.bytes');
const after = fs.readFileSync('.temp/maintenance-after.bytes');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const checkin = {
  localDate: packet.context.localDate,
  planningBinding: packet.context.planningBinding,
  status: 'pending',
  pendingOperationIds: [],
  unresolvedConflictIds: ['missing-reconciliation-baseline'],
  unresolvedCandidates: [{
    source: 'Daily/2026-10-09.md',
    text: 'Maybe improve my resume',
    disposition: 'unaccepted-note',
    reason: 'Possible overlap with accepted Update resume; no creation or selection decision supplied'
  }],
  processedSourceVersions: packet.inventory.sources,
  nextStep: 'Resolve initial reconciliation baseline and review the existing daily note; then resume plan preparation. No maintenance success or check-in completion recorded.',
  worker: { available: false, launched: false, trustedEvidenceAdapter: false }
};
fs.writeFileSync(path.join(packet.context.stateRoot, 'checkin.json'), JSON.stringify(checkin, null, 2) + '\n');
const cli = 'D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-corrected-focus/codex-home/plugins/cache/daily-tasks-runtime-guards-corrected-focus/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const calls = [
 ['planning-prepare','prepare','prepare'],
 ['maintenance-inspect','maintenance','inspection'],
 ['log-query','log-query','log-query'],
 ['inspect-records','records','records'],
 ['inspect-navigation','navigation','navigation'],
 ['maintenance-status','maintenance','maintenance-status'],
 ['validate-records','validation','validation'],
 ['check-links','validation','links']
].map(([operation,input,output]) => ({
 argv: ['node',cli,operation,'--input',path.resolve('.temp',input+'-input.json')],
 input: input+'-input.json',stdout:output+'-result.json',stderr:output+'-stderr.txt',
 exitCode:Number(fs.readFileSync('.temp/'+output+'-exit.txt','utf8').trim())
}));
const evidence = {
 calls, workerLaunched:false, workerModelRun:null,
 historicalReceipt:{byteIdentical:before.equals(after),beforeSha256:hash(before),afterSha256:hash(after),beforeBase64:before.toString('base64'),afterBase64:after.toString('base64'),preservedFields:JSON.parse(after.toString('utf8'))},
 inspection:JSON.parse(fs.readFileSync('.temp/inspection-result.json','utf8')),
 maintenanceStatus:JSON.parse(fs.readFileSync('.temp/maintenance-status-result.json','utf8')),
 inspectionReceiptExists:fs.existsSync(path.join(packet.context.stateRoot,'maintenance-inspection.json')),
 checkin
};
fs.writeFileSync('.temp/evidence.json',JSON.stringify(evidence,null,2)+'\n');
console.log(JSON.stringify({byteIdentical:evidence.historicalReceipt.byteIdentical,sha256:hash(after),inspectionReceiptExists:evidence.inspectionReceiptExists,calls:calls.length}));
