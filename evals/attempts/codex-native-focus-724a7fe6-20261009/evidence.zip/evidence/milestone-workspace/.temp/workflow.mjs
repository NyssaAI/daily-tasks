import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), temp=path.join(root,'.temp');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final-focus/codex-home/plugins/cache/daily-tasks-runtime-guards-final-focus/daily-tasks/0.3.3';
const cli=path.join(pkg,'bin/daily-tasks.mjs'); let seq=0;
const vault=path.join(root,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'job-search'), m=path.join(project,'m1-career-materials');
const read=p=>fs.readFileSync(p,'utf8'); const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
function call(op,input){const stem=path.join(temp,`${String(++seq).padStart(3,'0')}-${op}`);const args=[cli,op];if(input){fs.writeFileSync(stem+'.input.json',JSON.stringify(input,null,2));args.push('--input',stem+'.input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(stem+'.result.json',JSON.stringify({command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const id=()=>{const r=call('new-id');return typeof r==='string'?r:r.id;};
const ctx=call('resolve-context',{vaultRoot:vault});fs.writeFileSync(path.join(temp,'context.json'),JSON.stringify(ctx,null,2));
console.log(JSON.stringify(ctx));
const inspect=()=>call('inspect-records',{projectsRoot:projects});
fs.cpSync(project,path.join(temp,'before'),{recursive:true});
const initial=inspect();fs.writeFileSync(path.join(temp,'initial-inspection.json'),JSON.stringify(initial,null,2));
console.log('initial',JSON.stringify(initial));
export {fs,path,root,temp,pkg,call,id,vault,projects,project,m,read,hash,ctx,inspect};
const p=initial.records.find(r=>r.type==='project'), mile=initial.records.find(r=>r.type==='milestone'), tasks=initial.records.filter(r=>r.type==='task'), [t1,t2]=tasks;
const assertions=[];function check(name,ok){assertions.push({name,pass:!!ok});if(!ok)throw Error(name);}
check('Initial numbered layout and sibling tasks',fs.existsSync(path.join(m,'m1-career-materials.md'))&&tasks.length===2);
check('Initial empty flat holding folders',['inputs','outputs'].every(n=>fs.statSync(path.join(m,n)).isDirectory()&&fs.readdirSync(path.join(m,n)).length===0));
async function commit(action,changes,recordIds,before,after,words){
 const op=id(), eid=id(), timing=call('activity-time',{});
 const event={id:eid,operation_id:op,action,record_ids:recordIds,actor:{kind:'person',id:ctx.profile.user.email},...timing,original_words:words,before,after};
 const files=changes.map(([file,text])=>({path:file,before:fs.existsSync(file)?hash(read(file)):null,after:text===null?null:hash(text)}));
 const checkpoint={schemaVersion:2,operation_id:op,contextBinding:ctx.planningBinding,event,files};
 const opPath=path.join(ctx.stateRoot,'operations',op+'.json');fs.mkdirSync(path.dirname(opPath),{recursive:true});
 const backup=path.join(temp,'operations',op);fs.mkdirSync(backup,{recursive:true});
 changes.forEach(([file,text],i)=>{if(fs.existsSync(file))fs.writeFileSync(path.join(backup,i+'.before'),read(file));if(text!==null)fs.writeFileSync(path.join(backup,i+'.after'),text);});
 fs.writeFileSync(opPath,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(backup,'checkpoint.json'),JSON.stringify(checkpoint,null,2));
 changes.forEach(([file,text],i)=>{check('Optimistic hash '+action+' '+i,(fs.existsSync(file)?hash(read(file)):null)===files[i].before);fs.mkdirSync(path.dirname(file),{recursive:true});if(text===null)fs.unlinkSync(file);else fs.writeFileSync(file,text);});
 call('invalidate-project-index',{vaultRoot:vault});
 const records=inspect().records;const val=call('validate-records',{records});fs.writeFileSync(path.join(backup,'validation.json'),JSON.stringify(val,null,2));
 call('log-append',{projectsRoot:projects,entry:event});call('log-query',{projectsRoot:projects});
 const input={vaultRoot:vault,operationPath:opPath};const verified=call('operation-verify',input);console.log(action,JSON.stringify(verified));check('Verified '+action,verified.status==='verified');
 const completed=call('operation-complete',input);console.log('completed',JSON.stringify(completed));
}
const sourceA=read(path.join(root,'attachments/a/source.txt')),sourceB=read(path.join(root,'attachments/b/source.txt')),shared=read(path.join(root,'attachments/shared.txt'));
check('Distinct original contents',sourceA!==sourceB);
const headline='# LinkedIn headline — local draft\n\nCareer professional preparing clear, consistent career materials.\n\nDraft for user review. The supplied LinkedIn source and shared style guide contain no career facts; this wording makes no experience claims.\n';
const summary='# Resume summary — local draft\n\nCareer professional presenting clear and consistent career materials, with a concise summary aligned to the LinkedIn headline.\n\nDraft for user review. Derived from the LinkedIn headline in its existing outputs location, the resume source, and the shared style guide. No career history was supplied.\n';
function enrich(r,input,output){return read(r.path).replace('No source material has been supplied. Local working inputs belong in inputs/.',input).replace('Work has not started; no artifact has been produced or reviewed.',`Local draft produced: [Draft](${output}). User review remains outstanding; Definition of Done is unchecked.`).replace('## Output and delivery\n','## Output and delivery\n\n[Local draft]('+output+').\n');}
await commit('workspace.inputs-and-drafts',[
 [path.join(m,'inputs/linkedin-source.txt'),sourceA],[path.join(m,'inputs/resume-source.txt'),sourceB],[path.join(m,'inputs/shared-style-guide.txt'),shared],
 [path.join(m,'inputs/task-shaped-attachment.md'),read(t1.path)],
 [path.join(m,'outputs/linkedin-headline-draft.md'),headline],[path.join(m,'outputs/resume-summary-draft.md'),summary],
 [t1.path,enrich(t1,'- [LinkedIn source](inputs/linkedin-source.txt), imported from attachments/a/source.txt.\n- [Shared style guide](inputs/shared-style-guide.txt), imported once from attachments/shared.txt.','outputs/linkedin-headline-draft.md')],
 [t2.path,enrich(t2,'- [Resume source](inputs/resume-source.txt), imported from attachments/b/source.txt.\n- [Shared style guide](inputs/shared-style-guide.txt), shared working copy.\n- [LinkedIn headline](outputs/linkedin-headline-draft.md), consumed in its original output location.','outputs/resume-summary-draft.md')]
],tasks.map(t=>t.id),{inputs:[],outputs:[]},{inputs:['linkedin-source.txt','resume-source.txt','shared-style-guide.txt','task-shaped-attachment.md'],outputs:['linkedin-headline-draft.md','resume-summary-draft.md']},'User authorizes two local draft outputs and importing supplied inputs; output alone does not satisfy DoD.');
const postDraft=inspect();check('Copied-ID attachment excluded from records',postDraft.records.length===4&&postDraft.diagnostics.length===0);
for(const t of tasks){const closure=call('check-closure',{recordId:t.id,records:postDraft.records});check('Draft alone cannot close '+t.title,closure.allowed===false);}
const inv=call('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:ctx.dailyPlansRoot,timezone:ctx.timezone,forceRefresh:true});fs.writeFileSync(path.join(temp,'draft-inventory.json'),JSON.stringify(inv,null,2));check('Attachment excluded from planning inventory',inv.inventory.tasks.length===2);
const n=call('next-record-number',{projectsRoot:projects,type:'task',parentId:mile.id});check('Next task label t3',n.number===3);
const t3id=id(),criterion=id(),tm=call('activity-time',{}).recorded_at;
const newTask=`---\nid: "${t3id}"\ntype: task\nrecord_version: 2\ntitle: "Polish summary"\nowner: "${p.owner}"\ncreated_at: "${tm}"\nupdated_at: "${tm}"\ntask-state: not-started\nproject_id: "${p.id}"\nmilestone_id: "${mile.id}"\n---\n# M1-T3 — Polish summary\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${mile.id} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${p.id} -->\n\n## Requirements\n\nPolish summary.\n\n## Definition of Done\n\n- [ ] User reviewed polished summary. <!-- id: ${criterion} -->\n\n## Inputs\n\n[Summary draft](outputs/resume-summary-draft.md).\n\n## Output and delivery\n\nSave a polished summary locally in outputs/ when authorized to execute.\n\n## Verification\n\nRetain user review evidence before satisfying the criterion.\n\n## Result\n\nAccepted; work has not started.\n`;
function reorder(text){const lines=text.split('\n'),one=lines.findIndex(l=>l.includes('<!-- ref: '+t1.id)),two=lines.findIndex(l=>l.includes('<!-- ref: '+t2.id));[lines[one],lines[two]]=[lines[two],lines[one]];return lines.join('\n');}
await commit('tasks.reordered-cancelled-accepted',[
 [t1.path,read(t1.path).replace('task-state: "not-started"','task-state: "cancelled"')],
 [path.join(m,'t3-polish-summary.md'),newTask],
 [mile.path,reorder(read(mile.path)).replace('- [ ] [[t1-update-linkedin|Update LinkedIn]]','- [-] ~~[[t1-update-linkedin|Update LinkedIn]]~~')+`\n- [ ] [[t3-polish-summary|Polish summary]] <!-- ref: ${t3id} -->\n`],
 [p.path,reorder(read(p.path)).replace('[ ] [[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]]','[-] ~~[[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]]~~')+`\n| | [ ] [[m1-career-materials/t3-polish-summary\\|Polish summary]] <!-- ref: ${t3id} --> | Polish summary. | Synthetic User | — |\n`]
],[t1.id,t2.id,t3id],{records:[t1,t2].map(t=>({id:t.id,type:t.type,path:t.path,milestone_id:mile.id,project_id:p.id}))},{records:[{id:t1.id,type:'task',path:t1.path,milestone_id:mile.id,project_id:p.id,state:'cancelled'},{id:t3id,type:'task',path:path.join(m,'t3-polish-summary.md'),milestone_id:mile.id,project_id:p.id}]},'Explicitly cancel task1 and accept task3 Polish summary; requirement polish summary; DoD user reviewed polished summary. Reorder tasks.');
check('Retired task number remains reserved',call('next-record-number',{projectsRoot:projects,type:'task',parentId:mile.id}).number===4);
const blockers=[];
for(const title of ['Await review','Await source']){
 const number=call('next-record-number',{projectsRoot:projects,type:'blocker',parentId:p.id}).number;const bid=id(),time=call('activity-time',{}).recorded_at;const file=path.join(project,'blockers',`b${number}-${title.toLowerCase().replaceAll(' ','-')}.md`);
 const text=`---\nid: "${bid}"\ntype: blocker\nrecord_version: 2\ntitle: "${title}"\nblocker-state: open\nowner: "${p.owner}"\nproject_id: "${p.id}"\ncreated_at: "${time}"\nupdated_at: "${time}"\n---\n# ${title}\n\nWaiting on ${title==='Await review'?'user review':'additional source material'} from the user.\n\n## Resolution condition\n\n${title==='Await review'?'User supplies review.':'User supplies the requested source material.'}\n\n## Resolution evidence\n\nNot yet supplied.\n\n## Blocks\n`;
 await commit('blocker.accepted',[[file,text]],[bid],null,{id:bid,type:'blocker',path:file,project_id:p.id},`Explicitly accept ${title} as b${number}.`);blockers.push({id:bid,path:file,number});
}
const b1=blockers[0],b2=blockers[1],resolved=call('activity-time',{}).activity_at;
await commit('blocker.resolved',[[b1.path,read(b1.path).replace('blocker-state: open',`blocker-state: resolved\nresolved_at: "${resolved}"`).replace('Not yet supplied.','User explicitly instructed resolution in this synthetic scenario.')]], [b1.id],{id:b1.id,type:'blocker',path:b1.path,project_id:p.id,state:'open'},{id:b1.id,type:'blocker',path:b1.path,project_id:p.id,state:'resolved'},'Resolve b1.');
const bn=call('next-record-number',{projectsRoot:projects,type:'blocker',parentId:p.id}).number;check('Resolved blocker label not reused',bn===3);const b3=id(),bt=call('activity-time',{}).recorded_at,b3path=path.join(project,'blockers/b3-await-signoff.md');
await commit('blocker.accepted',[[b3path,`---\nid: "${b3}"\ntype: blocker\nrecord_version: 2\ntitle: "Await signoff"\nblocker-state: open\nowner: "${p.owner}"\nproject_id: "${p.id}"\ncreated_at: "${bt}"\nupdated_at: "${bt}"\n---\n# Await signoff\n\nWaiting for user signoff.\n\n## Resolution condition\n\nUser provides signoff.\n\n## Resolution evidence\n\nPending.\n\n## Blocks\n`]], [b3],null,{id:b3,type:'blocker',path:b3path,project_id:p.id},'Explicitly accept Await signoff as b3.');
await commit('blocker.shared-linked',[
 [b2.path,read(b2.path)+tasks.map(t=>`\n- [[../m1-career-materials/${path.basename(t.path,'.md')}|${t.title}]] <!-- ref: ${t.id} -->`).join('')+'\n'],
 ...tasks.map(t=>[t.path,read(t.path)+`\n## Blocked by\n\n- [[../blockers/b2-await-source|Await source]] <!-- ref: ${b2.id} -->\n`])
],[b2.id,...tasks.map(t=>t.id)],{links:[]},{blocker:b2.id,blocks:tasks.map(t=>t.id)},'Link b2 reciprocally to both original tasks without duplicating its record.');
const old=path.join(m,'outputs/linkedin-headline-draft.md'),dest=path.join(m,'outputs/career-headline-draft.md');check('Rename destination collision absent',!fs.existsSync(dest));
const affected=inspect().records.filter(r=>read(r.path).includes('outputs/linkedin-headline-draft.md'));
await commit('artifact.renamed',[[dest,read(old)],...affected.map(r=>[r.path,read(r.path).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md')]),[old,null]],tasks.map(t=>t.id),{path:old},{path:dest},'Rename task1 output and fix every affected link; preserve unrelated prose.');
const final=inspect();const nav=call('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:ctx.dailyPlansRoot});const links=call('check-links',{records:final.records});console.log('navigation',JSON.stringify(nav),'links',JSON.stringify(links));
const finalInv=call('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:ctx.dailyPlansRoot,timezone:ctx.timezone,forceRefresh:true});
check('Final record integrity',final.diagnostics.length===0);check('No copied-ID planning task',finalInv.inventory.tasks.length===3);
check('Original bytes preserved',read(path.join(m,'inputs/linkedin-source.txt'))===sourceA&&read(path.join(m,'inputs/resume-source.txt'))===sourceB&&read(path.join(m,'inputs/shared-style-guide.txt'))===shared);
check('Holding areas flat',['inputs','outputs'].every(d=>fs.readdirSync(path.join(m,d),{withFileTypes:true}).every(e=>e.isFile())));
check('Two outputs with in-place consumption',fs.readdirSync(path.join(m,'outputs')).length===2&&read(t2.path).includes('outputs/career-headline-draft.md')&&!fs.existsSync(old));
check('Distinct original criteria preserved',tasks.every(t=>final.records.find(r=>r.id===t.id).criteria[0].id===t.criteria[0].id)&&final.records.find(r=>r.id===mile.id).criteria[0].id===mile.criteria[0].id);
check('Shared blocker exactly one reciprocal record',final.records.filter(r=>r.id===b2.id).length===1&&final.records.find(r=>r.id===b2.id).blocks.length===2);
check('Unrelated prose preserved',tasks.every(t=>read(t.path).includes(t.title==='Update LinkedIn'?'Draft a headline.':'Draft a summary.'))&&read(mile.path).includes('Prepare a reviewed LinkedIn headline and resume summary, saved locally and linked.'));
call('log-query',{projectsRoot:projects});fs.cpSync(project,path.join(temp,'after'),{recursive:true});fs.writeFileSync(path.join(temp,'assertions.json'),JSON.stringify(assertions,null,2));
console.log('assertions',assertions.length,'passed');
