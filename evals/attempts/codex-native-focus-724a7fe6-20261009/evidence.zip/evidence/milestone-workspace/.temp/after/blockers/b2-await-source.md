---
id: "01a121c3-e157-7f34-a1c5-484a72dad302"
type: blocker
record_version: 2
title: "Await source"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T17:44:07.811Z"
updated_at: "2026-10-09T17:44:07.811Z"
---
# Await source

Waiting on additional source material from the user.

## Resolution condition

User supplies the requested source material.

## Resolution evidence

Not yet supplied.

## Blocks

- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->
