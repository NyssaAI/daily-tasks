---
id: "01a121c3-e60e-726f-baf0-f9fc9c1f0ffe"
type: blocker
record_version: 2
title: "Await signoff"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T17:44:09.020Z"
updated_at: "2026-10-09T17:44:09.020Z"
---
# Await signoff

Waiting for user signoff.

## Resolution condition

User provides signoff.

## Resolution evidence

Pending.

## Blocks
