# Resume summary — local draft

Career professional presenting clear and consistent career materials, with a concise summary aligned to the LinkedIn headline.

Draft for user review. Derived from the LinkedIn headline in its existing outputs location, the resume source, and the shared style guide. No career history was supplied.
