import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), temp=path.join(root,'.temp');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final-focus/codex-home/plugins/cache/daily-tasks-runtime-guards-final-focus/daily-tasks/0.3.3';
const cli=path.join(pkg,'bin/daily-tasks.mjs'); let seq=400;
const vault=path.join(root,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'job-search'), m=path.join(project,'m1-career-materials');
const read=p=>fs.readFileSync(p,'utf8'); const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
function call(op,input){const stem=path.join(temp,`${String(++seq).padStart(3,'0')}-${op}`);const args=[cli,op];if(input){fs.writeFileSync(stem+'.input.json',JSON.stringify(input,null,2));args.push('--input',stem+'.input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(stem+'.result.json',JSON.stringify({command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const id=()=>{const r=call('new-id');return typeof r==='string'?r:r.id;};
const ctx=call('resolve-context',{vaultRoot:vault});fs.writeFileSync(path.join(temp,'context.json'),JSON.stringify(ctx,null,2));
console.log(JSON.stringify(ctx));
const inspect=()=>call('inspect-records',{projectsRoot:projects});
 
const initial=JSON.parse(read(path.join(temp,'initial-inspection.json')));
console.log('initial',JSON.stringify(initial));
export {fs,path,root,temp,pkg,call,id,vault,projects,project,m,read,hash,ctx,inspect};
const p=initial.records.find(r=>r.type==='project'), mile=initial.records.find(r=>r.type==='milestone'), tasks=initial.records.filter(r=>r.type==='task'), [t1,t2]=tasks;
const assertions=[];function check(name,ok){assertions.push({name,pass:!!ok});if(!ok)throw Error(name);}
check('Initial numbered layout and sibling tasks',fs.existsSync(path.join(m,'m1-career-materials.md'))&&tasks.length===2);

async function commit(action,changes,recordIds,before,after,words){
 const op=id(), eid=id(), timing=call('activity-time',{});
 const event={id:eid,operation_id:op,action,record_ids:recordIds,actor:{kind:'person',id:ctx.profile.user.email},...timing,original_words:words,before,after};
 const files=changes.map(([file,text])=>({path:file,before:fs.existsSync(file)?hash(read(file)):null,after:text===null?null:hash(text)}));
 const checkpoint={schemaVersion:2,operation_id:op,contextBinding:ctx.planningBinding,event,files};
 const opPath=path.join(ctx.stateRoot,'operations',op+'.json');fs.mkdirSync(path.dirname(opPath),{recursive:true});
 const backup=path.join(temp,'operations',op);fs.mkdirSync(backup,{recursive:true});
 changes.forEach(([file,text],i)=>{if(fs.existsSync(file))fs.writeFileSync(path.join(backup,i+'.before'),read(file));if(text!==null)fs.writeFileSync(path.join(backup,i+'.after'),text);});
 fs.writeFileSync(opPath,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(backup,'checkpoint.json'),JSON.stringify(checkpoint,null,2));
 changes.forEach(([file,text],i)=>{check('Optimistic hash '+action+' '+i,(fs.existsSync(file)?hash(read(file)):null)===files[i].before);fs.mkdirSync(path.dirname(file),{recursive:true});if(text===null)fs.unlinkSync(file);else fs.writeFileSync(file,text);});
 call('invalidate-project-index',{vaultRoot:vault});
 const records=inspect().records;const val=call('validate-records',{records});fs.writeFileSync(path.join(backup,'validation.json'),JSON.stringify(val,null,2));
 call('log-append',{projectsRoot:projects,entry:event});call('log-query',{projectsRoot:projects});
 const input={vaultRoot:vault,operationPath:opPath};const verified=call('operation-verify',input);console.log(action,JSON.stringify(verified));check('Verified '+action,verified.status==='verified');
 const completed=call('operation-complete',input);console.log('completed',JSON.stringify(completed));
}


const final=inspect(), nav=call('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:ctx.dailyPlansRoot}),links=call('check-links',{records:final.records});
const inv=call('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:ctx.dailyPlansRoot,timezone:ctx.timezone,forceRefresh:true});
check('Navigation and reciprocal links',nav.diagnostics.length===0&&links.diagnostics.length===0);
check('Canonical record count excludes copied attachment',final.records.length===8&&final.diagnostics.length===0);
check('Planning excludes copied attachment and cancelled task',inv.inventory.tasks.length===2&&inv.inventory.tasks.every(t=>[t2.id,final.records.find(r=>r.title==='Polish summary').id].includes(t.id)));
check('Original source bytes preserved and shared copy single',['linkedin-source.txt','resume-source.txt','shared-style-guide.txt'].every((name,i)=>read(path.join(m,'inputs',name))===read(path.join(root,['attachments/a/source.txt','attachments/b/source.txt','attachments/shared.txt'][i]))));
check('Flat holding folders',['inputs','outputs'].every(d=>fs.readdirSync(path.join(m,d),{withFileTypes:true}).every(e=>e.isFile())));
check('Two outputs, consumption in place and repaired links',fs.readdirSync(path.join(m,'outputs')).length===2&&read(t2.path).includes('outputs/career-headline-draft.md')&&!fs.existsSync(path.join(m,'outputs/linkedin-headline-draft.md'))&&final.records.every(r=>!read(r.path).includes('outputs/linkedin-headline-draft.md')));
check('Original criteria and requirements preserved',tasks.every(t=>final.records.find(r=>r.id===t.id).criteria[0].id===t.criteria[0].id&&read(t.path).includes(t.title==='Update LinkedIn'?'Draft a headline.':'Draft a summary.'))&&final.records.find(r=>r.id===mile.id).criteria[0].id===mile.criteria[0].id);
check('DoD remains unchecked',final.records.filter(r=>['task','milestone'].includes(r.type)).every(r=>r.criteria.every(c=>!c.checked)));
check('Cancelled t1 label stable and t3 accepted',final.records.find(r=>r.id===t1.id).state==='cancelled'&&fs.existsSync(path.join(m,'t3-polish-summary.md'))&&read(path.join(m,'t3-polish-summary.md')).includes('User reviewed polished summary.'));
check('Task order reversed and cancellation visible',read(mile.path).indexOf('[[t2-update-resume')<read(mile.path).indexOf('[[t1-update-linkedin')&&read(mile.path).includes('[-] ~~[[t1-update-linkedin'));
check('Task labels reserved',call('next-record-number',{projectsRoot:projects,type:'task',parentId:mile.id}).number===4);
const bs=final.records.filter(r=>r.type==='blocker');check('b1 resolved, b2 b3 open; labels stable',bs.length===3&&bs.find(b=>b.title==='Await review').state==='resolved'&&bs.filter(b=>b.state==='open').length===2&&call('next-record-number',{projectsRoot:projects,type:'blocker',parentId:p.id}).number===4);
const b2=bs.find(b=>b.title==='Await source');check('Shared b2 single record and both reciprocal consumers',b2.blocks.length===2&&tasks.every(t=>final.records.find(r=>r.id===t.id).blocked_by.includes(b2.id)));
check('All work inside project',final.records.every(r=>r.path.startsWith(project)));
check('No pending operations',fs.readdirSync(path.join(ctx.stateRoot,'operations')).length===0);
for(const t of tasks)check('Output alone cannot satisfy '+t.title,!call('check-closure',{recordId:t.id,records:final.records}).allowed);
const history=call('log-query',{projectsRoot:projects});fs.cpSync(project,path.join(temp,'after'),{recursive:true});
fs.writeFileSync(path.join(temp,'assertions.json'),JSON.stringify(assertions,null,2));
const skillFiles=['daily-tasks/SKILL.md','daily-tasks-records/SKILL.md','daily-tasks-capture/SKILL.md','daily-tasks-setup/SKILL.md','daily-tasks/references/records.md','daily-tasks/references/operations.md','daily-tasks/references/verification.md','daily-tasks/references/cli.md','daily-tasks/assets/task.md','daily-tasks/assets/blocker.md'];
fs.writeFileSync(path.join(temp,'loaded-instructions.json'),JSON.stringify(skillFiles.map(f=>({path:path.join(pkg,'skills',f),sha256:hash(read(path.join(pkg,'skills',f)))})),null,2));
fs.writeFileSync(path.join(temp,'scenario7-report.md'),'# Scenario 7 — milestone workspace\n\nAll scenario 7 workspace assertions passed in this current skill-authored run. Initial layout and inventory evidence are in initial-inspection.json and 016-project-index.result.json; final assertions are in assertions.json. Actual CLI commands, inputs, stdout, stderr and exit status are retained in numbered files. Operations retain before/after bytes and checkpoints in operations/. Full project before/after snapshots are retained.\n\nA cancellation batch initially lacked complete label history; allocation correctly halted. Append-only correction events supplied complete facts and allocation resumed. An initial final-inventory assertion expected three tasks; the actual inventory correctly contains two open tasks and excludes the cancelled task. Failures and subsequent checks are retained. No previous attempts or regression tests were used.\n\nInstalled skill paths and hashes are in loaded-instructions.json. This is the current native host skill-authored workflow with CLI integrity evidence. Host version, model and authentication status were not exposed; packaging and CLI results are not claimed as discovery or authentication proof. No personal-directory reads were performed.\n\nTwo local drafts remain unreviewed; all criteria remain unchecked. Task1 is cancelled; task2 and accepted task3 remain not-started. b1 is resolved; b2 and b3 are open.\n');
console.log(JSON.stringify({assertions:assertions.length,pass:assertions.every(a=>a.pass),events:history.total}));
