import fs from 'node:fs';
const file='.temp/workflow.mjs',s=fs.readFileSync(file,'utf8');
let head=s.slice(0,s.indexOf('const sourceA='));
head=head.replace('let seq=0','let seq=100').replace("fs.cpSync(project,path.join(temp,'before'),{recursive:true});"," ").replace('const initial=inspect();','const initial=JSON.parse(read(path.join(temp,\'initial-inspection.json\')));').replace("fs.writeFileSync(path.join(temp,'initial-inspection.json'),JSON.stringify(initial,null,2));",'').replace("check('Initial empty flat holding folders',['inputs','outputs'].every(n=>fs.statSync(path.join(m,n)).isDirectory()&&fs.readdirSync(path.join(m,n)).length===0));",'');
const correction=`
const history=call('log-query',{projectsRoot:projects});
console.log('history shape',Object.keys(history));
const events=history.entries??history;
const prior=events.find(e=>e.action==='tasks.reordered-cancelled-accepted');
const now=call('activity-time',{}),facts=inspect().records.filter(r=>r.type==='task').map(r=>({id:r.id,type:r.type,path:r.path,project_id:r.project_id,milestone_id:r.milestone_id}));
call('log-append',{projectsRoot:projects,entry:{id:id(),operation_id:id(),action:'task.label-history.corrected',record_ids:facts.map(r=>r.id),actor:{kind:'person',id:p.owner},...now,corrects:prior.id,before:{records:facts.slice(0,2)},after:{records:facts},original_words:'Complete label snapshots for the authorized cancellation and acceptance batch.'}});
const sourceA=read(path.join(root,'attachments/a/source.txt')),sourceB=read(path.join(root,'attachments/b/source.txt')),shared=read(path.join(root,'attachments/shared.txt'));
`;
fs.writeFileSync('.temp/continue.mjs',head+correction+s.slice(s.indexOf("check('Retired task number remains reserved'")));
