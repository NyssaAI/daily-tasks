import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), temp=path.join(root,'.temp');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-final-focus/codex-home/plugins/cache/daily-tasks-runtime-guards-final-focus/daily-tasks/0.3.3';
const cli=path.join(pkg,'bin/daily-tasks.mjs'); let seq=200;
const vault=path.join(root,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'job-search'), m=path.join(project,'m1-career-materials');
const read=p=>fs.readFileSync(p,'utf8'); const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
function call(op,input){const stem=path.join(temp,`${String(++seq).padStart(3,'0')}-${op}`);const args=[cli,op];if(input){fs.writeFileSync(stem+'.input.json',JSON.stringify(input,null,2));args.push('--input',stem+'.input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(stem+'.result.json',JSON.stringify({command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const id=()=>{const r=call('new-id');return typeof r==='string'?r:r.id;};
const ctx=call('resolve-context',{vaultRoot:vault});fs.writeFileSync(path.join(temp,'context.json'),JSON.stringify(ctx,null,2));
console.log(JSON.stringify(ctx));
const inspect=()=>call('inspect-records',{projectsRoot:projects});
 
const initial=JSON.parse(read(path.join(temp,'initial-inspection.json')));
console.log('initial',JSON.stringify(initial));
export {fs,path,root,temp,pkg,call,id,vault,projects,project,m,read,hash,ctx,inspect};
const p=initial.records.find(r=>r.type==='project'), mile=initial.records.find(r=>r.type==='milestone'), tasks=initial.records.filter(r=>r.type==='task'), [t1,t2]=tasks;
const assertions=[];function check(name,ok){assertions.push({name,pass:!!ok});if(!ok)throw Error(name);}
check('Initial numbered layout and sibling tasks',fs.existsSync(path.join(m,'m1-career-materials.md'))&&tasks.length===2);

async function commit(action,changes,recordIds,before,after,words){
 const op=id(), eid=id(), timing=call('activity-time',{});
 const event={id:eid,operation_id:op,action,record_ids:recordIds,actor:{kind:'person',id:ctx.profile.user.email},...timing,original_words:words,before,after};
 const files=changes.map(([file,text])=>({path:file,before:fs.existsSync(file)?hash(read(file)):null,after:text===null?null:hash(text)}));
 const checkpoint={schemaVersion:2,operation_id:op,contextBinding:ctx.planningBinding,event,files};
 const opPath=path.join(ctx.stateRoot,'operations',op+'.json');fs.mkdirSync(path.dirname(opPath),{recursive:true});
 const backup=path.join(temp,'operations',op);fs.mkdirSync(backup,{recursive:true});
 changes.forEach(([file,text],i)=>{if(fs.existsSync(file))fs.writeFileSync(path.join(backup,i+'.before'),read(file));if(text!==null)fs.writeFileSync(path.join(backup,i+'.after'),text);});
 fs.writeFileSync(opPath,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(backup,'checkpoint.json'),JSON.stringify(checkpoint,null,2));
 changes.forEach(([file,text],i)=>{check('Optimistic hash '+action+' '+i,(fs.existsSync(file)?hash(read(file)):null)===files[i].before);fs.mkdirSync(path.dirname(file),{recursive:true});if(text===null)fs.unlinkSync(file);else fs.writeFileSync(file,text);});
 call('invalidate-project-index',{vaultRoot:vault});
 const records=inspect().records;const val=call('validate-records',{records});fs.writeFileSync(path.join(backup,'validation.json'),JSON.stringify(val,null,2));
 call('log-append',{projectsRoot:projects,entry:event});call('log-query',{projectsRoot:projects});
 const input={vaultRoot:vault,operationPath:opPath};const verified=call('operation-verify',input);console.log(action,JSON.stringify(verified));check('Verified '+action,verified.status==='verified');
 const completed=call('operation-complete',input);console.log('completed',JSON.stringify(completed));
}

const history=call('log-query',{projectsRoot:projects});
console.log('history shape',Object.keys(history));
const events=history.entries??history;
const prior=events.find(e=>e.action==='tasks.reordered-cancelled-accepted');
const now=call('activity-time',{}),facts=inspect().records.filter(r=>r.type==='task').map(r=>({id:r.id,type:r.type,path:r.path,project_id:r.project_id,milestone_id:r.milestone_id}));
call('log-append',{projectsRoot:projects,entry:{id:id(),operation_id:id(),action:'task.label-history.corrected',record_ids:facts.map(r=>r.id),actor:{kind:'person',id:p.owner},...now,corrects:prior.id,before:{records:facts.map(r=>({...r, snapshot_kind: r.title === "Polish summary" ? "planned destination" : "label facts"}))},after:{records:facts},original_words:'Complete label snapshots for the authorized cancellation and acceptance batch.'}});
const sourceA=read(path.join(root,'attachments/a/source.txt')),sourceB=read(path.join(root,'attachments/b/source.txt')),shared=read(path.join(root,'attachments/shared.txt'));
check('Retired task number remains reserved',call('next-record-number',{projectsRoot:projects,type:'task',parentId:mile.id}).number===4);
const blockers=[];
for(const title of ['Await review','Await source']){
 const number=call('next-record-number',{projectsRoot:projects,type:'blocker',parentId:p.id}).number;const bid=id(),time=call('activity-time',{}).recorded_at;const file=path.join(project,'blockers',`b${number}-${title.toLowerCase().replaceAll(' ','-')}.md`);
 const text=`---\nid: "${bid}"\ntype: blocker\nrecord_version: 2\ntitle: "${title}"\nblocker-state: open\nowner: "${p.owner}"\nproject_id: "${p.id}"\ncreated_at: "${time}"\nupdated_at: "${time}"\n---\n# ${title}\n\nWaiting on ${title==='Await review'?'user review':'additional source material'} from the user.\n\n## Resolution condition\n\n${title==='Await review'?'User supplies review.':'User supplies the requested source material.'}\n\n## Resolution evidence\n\nNot yet supplied.\n\n## Blocks\n`;
 await commit('blocker.accepted',[[file,text]],[bid],null,{id:bid,type:'blocker',path:file,project_id:p.id},`Explicitly accept ${title} as b${number}.`);blockers.push({id:bid,path:file,number});
}
const b1=blockers[0],b2=blockers[1],resolved=call('activity-time',{}).activity_at;
await commit('blocker.resolved',[[b1.path,read(b1.path).replace('blocker-state: open',`blocker-state: resolved\nresolved_at: "${resolved}"`).replace('Not yet supplied.','User explicitly instructed resolution in this synthetic scenario.')]], [b1.id],{id:b1.id,type:'blocker',path:b1.path,project_id:p.id,state:'open'},{id:b1.id,type:'blocker',path:b1.path,project_id:p.id,state:'resolved'},'Resolve b1.');
const bn=call('next-record-number',{projectsRoot:projects,type:'blocker',parentId:p.id}).number;check('Resolved blocker label not reused',bn===3);const b3=id(),bt=call('activity-time',{}).recorded_at,b3path=path.join(project,'blockers/b3-await-signoff.md');
await commit('blocker.accepted',[[b3path,`---\nid: "${b3}"\ntype: blocker\nrecord_version: 2\ntitle: "Await signoff"\nblocker-state: open\nowner: "${p.owner}"\nproject_id: "${p.id}"\ncreated_at: "${bt}"\nupdated_at: "${bt}"\n---\n# Await signoff\n\nWaiting for user signoff.\n\n## Resolution condition\n\nUser provides signoff.\n\n## Resolution evidence\n\nPending.\n\n## Blocks\n`]], [b3],null,{id:b3,type:'blocker',path:b3path,project_id:p.id},'Explicitly accept Await signoff as b3.');
await commit('blocker.shared-linked',[
 [b2.path,read(b2.path)+tasks.map(t=>`\n- [[../m1-career-materials/${path.basename(t.path,'.md')}|${t.title}]] <!-- ref: ${t.id} -->`).join('')+'\n'],
 ...tasks.map(t=>[t.path,read(t.path)+`\n## Blocked by\n\n- [[../blockers/b2-await-source|Await source]] <!-- ref: ${b2.id} -->\n`])
],[b2.id,...tasks.map(t=>t.id)],{links:[]},{blocker:b2.id,blocks:tasks.map(t=>t.id)},'Link b2 reciprocally to both original tasks without duplicating its record.');
const old=path.join(m,'outputs/linkedin-headline-draft.md'),dest=path.join(m,'outputs/career-headline-draft.md');check('Rename destination collision absent',!fs.existsSync(dest));
const affected=inspect().records.filter(r=>read(r.path).includes('outputs/linkedin-headline-draft.md'));
await commit('artifact.renamed',[[dest,read(old)],...affected.map(r=>[r.path,read(r.path).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md')]),[old,null]],tasks.map(t=>t.id),{path:old},{path:dest},'Rename task1 output and fix every affected link; preserve unrelated prose.');
const final=inspect();const nav=call('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:ctx.dailyPlansRoot});const links=call('check-links',{records:final.records});console.log('navigation',JSON.stringify(nav),'links',JSON.stringify(links));
const finalInv=call('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:ctx.dailyPlansRoot,timezone:ctx.timezone,forceRefresh:true});
check('Final record integrity',final.diagnostics.length===0);check('No copied-ID planning task',finalInv.inventory.tasks.length===3);
check('Original bytes preserved',read(path.join(m,'inputs/linkedin-source.txt'))===sourceA&&read(path.join(m,'inputs/resume-source.txt'))===sourceB&&read(path.join(m,'inputs/shared-style-guide.txt'))===shared);
check('Holding areas flat',['inputs','outputs'].every(d=>fs.readdirSync(path.join(m,d),{withFileTypes:true}).every(e=>e.isFile())));
check('Two outputs with in-place consumption',fs.readdirSync(path.join(m,'outputs')).length===2&&read(t2.path).includes('outputs/career-headline-draft.md')&&!fs.existsSync(old));
check('Distinct original criteria preserved',tasks.every(t=>final.records.find(r=>r.id===t.id).criteria[0].id===t.criteria[0].id)&&final.records.find(r=>r.id===mile.id).criteria[0].id===mile.criteria[0].id);
check('Shared blocker exactly one reciprocal record',final.records.filter(r=>r.id===b2.id).length===1&&final.records.find(r=>r.id===b2.id).blocks.length===2);
check('Unrelated prose preserved',tasks.every(t=>read(t.path).includes(t.title==='Update LinkedIn'?'Draft a headline.':'Draft a summary.'))&&read(mile.path).includes('Prepare a reviewed LinkedIn headline and resume summary, saved locally and linked.'));
call('log-query',{projectsRoot:projects});fs.cpSync(project,path.join(temp,'after'),{recursive:true});fs.writeFileSync(path.join(temp,'assertions.json'),JSON.stringify(assertions,null,2));
console.log('assertions',assertions.length,'passed');
