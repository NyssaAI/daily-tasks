---
id: "01a12160-98c5-74a7-ac1b-3d64cbf47495"
record_version: 2
type: "task"
title: "Review materials"
owner: "synthetic@example.test"
created_at: "2026-10-09T15:55:41.080Z"
updated_at: "2026-10-09T15:55:41.080Z"
task-state: "in-progress"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
---
# Review materials

## Requirements
Review supplied materials.

## Milestone
[[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

Acceptance detail: [[m1-career-materials#Definition of Done|Criterion]] <!-- ref: 01a1211c-fc9b-7027-a7db-a9c6f17740a9 -->

## Definition of Done
- [ ] Review receipt is saved. <!-- id: 01a12160-986d-73f7-af4e-5dcc015e113a -->
