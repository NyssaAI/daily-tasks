---
id: "01a1211c-fc6d-7e56-b639-7133ec8fe4d6"
type: "task"
title: "Update resume"
owner: "synthetic@example.test"
created_at: "2026-10-09T15:55:41.080Z"
updated_at: "2026-10-09T15:55:41.080Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
---
# Update resume

## Requirements
Draft a summary; requirements await clarification.

## Milestone
[[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

Acceptance detail: [[m1-career-materials#Definition of Done|Criterion]] <!-- ref: 01a1211c-fc9b-7027-a7db-a9c6f17740a9 -->
