---
id: "01a1211c-fc13-750e-993c-51e78d20ea25"
record_version: 2
type: "milestone"
title: "Career materials"
owner: "synthetic@example.test"
created_at: "2026-10-09T15:55:41.080Z"
updated_at: "2026-10-09T15:55:41.080Z"
milestone-state: "in-progress"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
---
# Career materials

Legacy outcome and provenance stay intact.

## Definition of Done

- [x] Both reviewed artifacts are linked. [[inputs/evidence.txt|Review evidence]] <!-- id: 01a1211c-fc9b-7027-a7db-a9c6f17740a9 -->

Provenance: synthetic reviewer note, retain verbatim.

## Blocked by
- [[../blockers/b1-approval|Approval pending]] <!-- ref: 01a12160-9845-7394-b135-89e491ad8743 -->

## Tasks
- [x] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->
- [ ] [[t3-review-materials|Review materials]] <!-- ref: 01a12160-98c5-74a7-ac1b-3d64cbf47495 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->
