---
id: "01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8"
type: "task"
title: "Update LinkedIn"
owner: "synthetic@example.test"
created_at: "2026-10-09T15:55:41.080Z"
updated_at: "2026-10-09T15:55:41.080Z"
task-state: "completed"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
started_at: "2026-10-09T15:55:41.080Z"
resolved_at: "2026-10-09T15:55:41.080Z"
---
# Update LinkedIn

## Requirements
Draft a headline; historical completion predates task DoD.

## Milestone
[[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

Acceptance detail: [[m1-career-materials#Definition of Done|Criterion]] <!-- ref: 01a1211c-fc9b-7027-a7db-a9c6f17740a9 -->
