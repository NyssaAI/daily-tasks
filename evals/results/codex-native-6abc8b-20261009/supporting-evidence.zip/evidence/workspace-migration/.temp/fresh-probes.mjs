import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('.'),temp=path.join(root,'.temp'),source=path.join(root,'vault');
const pointer=JSON.parse(fs.readFileSync(path.join(temp,'evidence/main/operation-pointer.json'),'utf8'));
const op=JSON.parse(fs.readFileSync(pointer.opPath,'utf8'));
for(const name of ['destination-stop','source-stop','log-stop','unexpected-edit','case-collision','competing-sources']){
 const oldEvidence=path.join(temp,'evidence',name),archive=path.join(temp,'retained-first-pass',name);
 fs.mkdirSync(path.dirname(archive),{recursive:true});fs.renameSync(oldEvidence,archive);
 const vault=path.join(temp,'runs-fresh',name,'vault');
 fs.mkdirSync(path.join(vault,'.nyssaai/daily-tasks'),{recursive:true});fs.copyFileSync(path.join(source,'.nyssaai/daily-tasks/profile.json'),path.join(vault,'.nyssaai/daily-tasks/profile.json'));
 const seen=new Set();for(const e of op.effects){if(seen.has(e.path))continue;seen.add(e.path);if(e.before!==null){const target=path.join(vault,path.relative(source,e.path));fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,e.before);}}
}
console.log('Fresh independent synthetic copies recreated from retained exact pre-operation bytes; initial probe evidence retained.');
