import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=path.resolve('.'),temp=path.join(root,'.temp');
const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';
const fixture=JSON.parse(fs.readFileSync(path.join(temp,'fixture.json'),'utf8')),{ids}=fixture;
const results=[];
function read(f){return fs.readFileSync(f,'utf8');}
function json(f){return JSON.parse(read(f));}
function save(f,v){fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
function check(label,pass,evidence){results.push({label,pass:!!pass,evidence});}
function call(n,op,input){const base=path.join(temp,'evidence',n,'audit-'+op);save(base+'-input.json',input);const args=[path.join(bundle,'bin/daily-tasks.mjs'),op,'--input',base+'-input.json'];const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(base+'-result.json',{command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
function walk(d){return fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.name.startsWith('.')?[]:e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);}
const names=['main','destination-stop','source-stop','log-stop','unexpected-edit','case-collision','competing-sources'];
for(const n of names){
 const ev=path.join(temp,'evidence',n),context=json(path.join(ev,'context.json')),p=path.join(context.projectsRoot,'job-search'),dest=path.join(p,'m1-career-materials'),op=json(json(path.join(ev,'operation-pointer.json')).opPath);
 const queried=call(n,'log-query',{projectsRoot:context.projectsRoot});
 check(n+': historical event preserved exactly',queried.entries.some(e=>JSON.stringify(e)===JSON.stringify(fixture.historical)),`evidence/${n}/audit-log-query-result.json`);
 if(n==='competing-sources'){
  const dod=path.join(p,'legacy-career/definition-of-done.md'),milestone=path.join(p,'legacy-career/milestone.md');
  // Isolate competing authority from unrelated malformed legacy metadata/duplicate headings.
  if(!read(dod).includes('project_id:'))save(dod,read(dod).replace('type: "dod"',`type: "dod"\nproject_id: "${ids.project}"`));
  const generated=call(n,'new-id',{}),embeddedId=typeof generated==='string'?generated:generated.id;
  let m=read(milestone);if(m.match(/## Definition of Done/g)?.length>1)m=m.slice(0,m.lastIndexOf('\n## Definition of Done'));
  m=m.replace(/## Definition of Done\n[\s\S]*?\n## Tasks/,`## Definition of Done\n- [ ] Separate embedded acceptance. <!-- id: ${embeddedId} -->\n\n## Tasks`);save(milestone,m);
  const inspection=call(n,'inspect-records',{projectsRoot:context.projectsRoot});const closure=call(n,'check-closure',{records:inspection.records,recordId:ids.milestone});
  check('Closure rejects competing embedded/standalone DoD',!closure.allowed&&closure.reasons.some(r=>r.includes('both embedded and standalone')),`evidence/${n}/audit-check-closure-result.json`);
  check('Competing source records retained without migration event',fs.existsSync(dod)&&op.status==='pending'&&!queried.entries.some(e=>e.action==='workspace-migration'),`evidence/${n}/before`);
  continue;
 }
 if(n==='unexpected-edit'||n==='case-collision'){
  const target=n==='unexpected-edit'?path.join(dest,'t3-review-materials.md'):path.join(dest,'M1-CAREER-MATERIALS.MD');
  const injected=path.join(ev,'injected','Projects/job-search/m1-career-materials',path.basename(target));
  check(n+': preserves injected bytes and pending conflict; no false completion',read(target)===read(injected)&&op.status==='pending-conflict'&&!fs.existsSync(path.join(ev,'completion.json'))&&!queried.entries.some(e=>e.action==='workspace-migration'),`evidence/${n}/conflict-after`);
  check(n+': source and standalone DoD remain readable',fs.existsSync(path.join(p,'legacy-career/milestone.md'))&&fs.existsSync(path.join(p,'legacy-career/definition-of-done.md')),`runs/${n}/vault/Projects/job-search/legacy-career`);
  continue;
 }
 const inspect=call(n,'inspect-records',{projectsRoot:context.projectsRoot}),records=inspect.records;
 const matching=queried.entries.filter(e=>e.operation_id===op.operation_id);
 check(n+': exact one migration event after resume and retry',matching.length===1&&JSON.stringify(matching[0])===JSON.stringify(op.entry),`evidence/${n}/audit-log-query-result.json`);
 check(n+': no duplicate live identities',new Set(records.map(r=>r.id)).size===records.length&&records.length===6&&!inspect.diagnostics.length,`evidence/${n}/audit-inspect-records-result.json`);
 const m=records.find(r=>r.id===ids.milestone),a=records.find(r=>r.id===ids.a),b=records.find(r=>r.id===ids.b),c=records.find(r=>r.id===ids.c),blocker=records.find(r=>r.id===ids.blocker);
 check(n+': milestone/task identities and lifecycle preserved',!!m&&!!a&&!!b&&!!c&&a.state==='completed'&&a.started_at===fixture.time.activity_at&&a.resolved_at===fixture.time.activity_at&&b.state==='not-started'&&c.state==='in-progress',`evidence/${n}/audit-inspect-records-result.json`);
 check(n+': criterion IDs, states, text, evidence and provenance preserved',m.criteria[0].id===ids.criterion&&m.criteria[0].checked&&m.criteria[0].text==='Both reviewed artifacts are linked. [[inputs/evidence.txt|Review evidence]]'&&c.criteria[0].id===ids.taskCriterion&&!c.criteria[0].checked&&read(path.join(dest,'inputs/evidence.txt'))==='Synthetic review evidence. Original bytes must survive.\n'&&read(m.path).includes('Provenance: synthetic reviewer note, retain verbatim.'),`evidence/${n}/after`);
 check(n+': reciprocal blocker now targets milestone',m.blocked_by.includes(ids.blocker)&&blocker.blocks.includes(ids.milestone)&&!blocker.blocks.includes(ids.dod),`evidence/${n}/audit-inspect-records-result.json`);
 check(n+': missing task DoD not manufactured; unresolved task readable/pending',!a.record_version&&!b.record_version&&a.criteria.length===0&&b.criteria.length===0&&op.pendingCriteria.includes(ids.a)&&op.pendingCriteria.includes(ids.b)&&read(b.path).includes('requirements await clarification'),`evidence/${n}/completion.json`);
 const verification=json(path.join(ev,'retirement-verification.json'));
 check(n+': DoD retired only after copied content and ALL live incoming links verified',verification.verified&&verification.remainingIncoming.length===0&&!fs.existsSync(path.join(p,'legacy-career/definition-of-done.md'))&&op.retiredDoD.id===ids.dod&&op.entry.before.retired_dod_id===ids.dod,`evidence/${n}/retirement-verification.json`);
 const files=[...walk(p),...walk(context.dailyPlansRoot)].filter(f=>f.endsWith('.md'));let links=true,criterionLinks=0;
 for(const f of files){for(const line of read(f).split('\n')){for(const match of line.matchAll(/\[\[([^|\]]+)(?:\|[^\]]*)?\]\]/g)){
  const [relative,heading]=match[1].replace(/\\$/,'').split('#');let target=path.resolve(path.dirname(f),relative);if(!path.extname(target))target+='.md';
  if(!fs.existsSync(target)){links=false;continue;}if(heading&&!read(target).includes('## '+heading))links=false;
  if(line.includes(`ref: ${ids.criterion}`)){criterionLinks++;if(target!==m.path||heading!=='Definition of Done'||!read(target).includes(`id: ${ids.criterion}`))links=false;}
 }}}
 check(n+': criterion links retain UUID/navigate new owner; all navigation resolves',links&&criterionLinks===4,`evidence/${n}/after`);
 if(n!=='main'){
  const point=n==='destination-stop'?'destination':n==='source-stop'?'source':'log',interrupted=path.join(ev,'interrupted-'+point),cp=path.join(interrupted,'.nyssaai/daily-tasks/operations',op.operation_id+'.json');
  const pending=json(cp);check(n+': actual independent interruption persisted a pending saved operation',pending.status==='pending'&&pending.entry.id===op.entry.id&&pending.stage===({destination:'destination',source:'dod-retirement',log:'log-appended'}[point]),`evidence/${n}/interrupted-${point}`);
 }
}
const loaded=['daily-tasks/SKILL.md','daily-tasks-records/SKILL.md','daily-tasks-setup/SKILL.md','daily-tasks/references/workspace-migration.md','daily-tasks/references/operations.md','daily-tasks/references/cli.md','daily-tasks/references/records.md'].map(rel=>{const f=path.join(bundle,'skills',rel);return {path:f,sha256:crypto.createHash('sha256').update(read(f)).digest('hex')};});
const report={scenario:8,receipt:'workspace-migration',runtime:{node:process.version,platform:process.platform,arch:process.arch,host:'Current Codex native tool session',hostVersion:'not exposed',model:'not exposed',authenticatedHost:'not independently exposed',pluginDiscovery:'Installed skills exposed in session; actual loaded paths retained; packaging/CLI not used as discovery proof'},loaded,missingCriteriaRequest:'Actual asynchronous user question issued; no criteria response received at verification time',assertions:results,passed:results.filter(r=>r.pass).length,total:results.length};
save(path.join(temp,'assertions.json'),report);
save(path.join(temp,'REPORT.md'),`# Scenario 8: workspace migration\n\n${report.passed}/${report.total} evidence checks passed. ${report.passed===report.total?'All required workflow assertions passed.':'See failed assertions below.'}\n\nSkill-authored workflow executed in the current Codex session using the installed 0.3.3 CLI and actual file effects. Separate Node processes interrupted after destination persistence, source removal and log append; each resumed its saved operation and retried. Native host authentication/version/model were not exposed, so this evidence does not independently certify those host prerequisites. No prior attempts, operation scripts or regression tests were read.\n\nCompleted legacy Update LinkedIn and unresolved Update resume retain their identities and lifecycle, without invented task criteria; both remain pending conversion. Missing criteria were requested from the user.\n\n${results.map(r=>`- ${r.pass?'PASS':'FAIL'}: ${r.label} — ${r.evidence}`).join('\n')}\n\nActual actions: evidence/*/actions.jsonl. Exact before/after bytes and saved checkpoints: evidence/*/before, after, interrupted-*. Installed CLI inputs, command, exit, stdout and stderr: evidence/*/*-input.json and *-result.json. Loaded skill hashes and host visibility: assertions.json.\n`);
console.log(JSON.stringify({passed:report.passed,total:report.total,failures:results.filter(r=>!r.pass)}));
