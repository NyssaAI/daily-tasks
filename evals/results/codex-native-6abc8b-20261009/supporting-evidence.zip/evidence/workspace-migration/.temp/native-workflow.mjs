import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=path.resolve('.');
const scratch=path.join(root,'.temp');
const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';
const cli=path.join(bundle,'bin/daily-tasks.mjs');
const stage=process.argv[2], name=process.argv[3]||'main';
const evidence=path.join(scratch,'evidence',name); fs.mkdirSync(evidence,{recursive:true});
let seq=fs.readdirSync(evidence).filter(x=>x.endsWith('-input.json')).length;
function write(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
function read(p){return fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;}
function hash(v){return v===null?null:crypto.createHash('sha256').update(v).digest('hex');}
function call(op,input){const prefix=path.join(evidence,`${String(++seq).padStart(3,'0')}-${op}`);write(prefix+'-input.json',input??{});const args=[cli,op,...(input===undefined?[]:['--input',prefix+'-input.json'])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(prefix+'-result.json',{command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(`${op}: ${r.stderr}`);return JSON.parse(r.stdout);}
function id(){const r=call('new-id');return typeof r==='string'?r:r.id;}
function snapshot(v,label){const out=path.join(evidence,label);for(const rel of ['Projects/job-search','Daily','.nyssaai/daily-tasks']){const src=path.join(v,rel);if(fs.existsSync(src))fs.cpSync(src,path.join(out,rel),{recursive:true,filter:p=>!path.relative(src,p).split(path.sep).some(part=>part==='.daily-tasks'||part==='.temp')});}}
const vault=name==='main'?path.join(root,'vault'):path.join(scratch,'runs-fresh',name,'vault');
const manifestPath=path.join(scratch,'fixture.json');
if(stage==='seed'){
 snapshot(vault,'original');
 const context=call('resolve-context',{vaultRoot:vault});write(path.join(evidence,'context.json'),context);
 const p=path.join(vault,'Projects/job-search'), old=path.join(p,'m1-career-materials');
 const m=read(path.join(old,'m1-career-materials.md')),a=read(path.join(old,'t1-update-linkedin.md')),b=read(path.join(old,'t2-update-resume.md'));
 const getId=s=>s.match(/^id: "([^"]+)"/m)[1];
 const ids={project:getId(read(path.join(p,'project-index.md'))),milestone:getId(m),a:getId(a),b:getId(b),criterion:m.match(/<!-- id: ([^ ]+)/)[1],dod:id(),blocker:id(),taskCriterion:id()};
 const time=call('activity-time',{});
 const meta=(rid,type,title,state)=>`---\nid: "${rid}"\ntype: "${type}"\ntitle: "${title}"\nowner: "synthetic@example.test"\ncreated_at: "${time.activity_at}"\nupdated_at: "${time.recorded_at}"\n${type}-state: "${state}"\nproject_id: "${ids.project}"\n---\n`;
 const legacy=path.join(p,'legacy-career');fs.mkdirSync(legacy,{recursive:true});
 write(path.join(legacy,'milestone.md'),meta(ids.milestone,'milestone','Career materials','in-progress')+`# Career materials\n\nLegacy outcome and provenance stay intact.\n\n## Definition of Done\n\n[[definition-of-done|Acceptance]] <!-- ref: ${ids.dod} -->\n\n## Tasks\n- [x] [[linkedin|Update LinkedIn]] <!-- ref: ${ids.a} -->\n- [ ] [[resume|Update resume]] <!-- ref: ${ids.b} -->\n- [ ] [[review|Review materials]] <!-- ref: TASK_ID -->\n`);
 ids.c=id();write(path.join(legacy,'milestone.md'),read(path.join(legacy,'milestone.md')).replace('TASK_ID',ids.c));
 write(path.join(legacy,'definition-of-done.md'),`---\nid: "${ids.dod}"\ntype: "dod"\ntitle: "Career acceptance"\nowner: "synthetic@example.test"\ncreated_at: "${time.activity_at}"\nupdated_at: "${time.recorded_at}"\nmilestone_id: "${ids.milestone}"\n---\n# Acceptance\n\nProvenance: synthetic reviewer note, retain verbatim.\n\n## Definition of Done\n- [x] Both reviewed artifacts are linked. [[evidence.txt|Review evidence]] <!-- id: ${ids.criterion} -->\n\n## Blocked by\n- [[../blockers/b1-approval|Approval pending]] <!-- ref: ${ids.blocker} -->\n`);
 write(path.join(legacy,'evidence.txt'),'Synthetic review evidence. Original bytes must survive.\n');
 const task=(rid,title,state,body)=>meta(rid,'task',title,state).replace('---\n#','---\n#').replace(/\n---\n$/,`\nmilestone_id: "${ids.milestone}"\n${state==='completed'?`started_at: "${time.activity_at}"\nresolved_at: "${time.activity_at}"\n`:''}---\n`)+`# ${title}\n\n## Requirements\n${body}\n\n## Milestone\n[[milestone|Career materials]] <!-- ref: ${ids.milestone} -->\n\nAcceptance detail: [[definition-of-done#Definition of Done|Criterion]] <!-- ref: ${ids.criterion} -->\n`;
 write(path.join(legacy,'linkedin.md'),task(ids.a,'Update LinkedIn','completed','Draft a headline; historical completion predates task DoD.'));
 write(path.join(legacy,'resume.md'),task(ids.b,'Update resume','not-started','Draft a summary; requirements await clarification.'));
 write(path.join(legacy,'review.md'),task(ids.c,'Review materials','in-progress','Review supplied materials.')+`\n## Definition of Done\n- [ ] Review receipt is saved. <!-- id: ${ids.taskCriterion} -->\n`);
 write(path.join(p,'blockers/b1-approval.md'),meta(ids.blocker,'blocker','Approval pending','open')+`# Approval pending\n\nReviewer approval resolves this impediment.\n\n## Blocks\n- [[../legacy-career/definition-of-done|Career acceptance]] <!-- ref: ${ids.dod} -->\n`);
 let index=read(path.join(p,'project-index.md'));index=index.replaceAll('m1-career-materials/m1-career-materials','legacy-career/milestone').replaceAll('m1-career-materials/t1-update-linkedin','legacy-career/linkedin').replaceAll('m1-career-materials/t2-update-resume','legacy-career/resume');write(path.join(p,'project-index.md'),index);
 write(path.join(vault,'Daily/2026-10-09.md'),read(path.join(vault,'Daily/2026-10-09.md'))+`\nCriterion navigation: [[../Projects/job-search/legacy-career/definition-of-done#Definition of Done|Reviewed artifacts]] <!-- ref: ${ids.criterion} -->\nDoD navigation: [[../Projects/job-search/legacy-career/definition-of-done|Acceptance]] <!-- ref: ${ids.dod} -->\n- [x] [[../Projects/job-search/legacy-career/linkedin|Update LinkedIn]] <!-- ref: ${ids.a} -->\n`);
 // Remove only the exact superseded synthetic starting records, after legacy bytes exist.
 for(const file of ['m1-career-materials.md','t1-update-linkedin.md','t2-update-resume.md'])fs.unlinkSync(path.join(old,file));
 const historical={id:id(),operation_id:id(),action:'legacy-task-completed',record_ids:[ids.a],actor:{kind:'person',id:'synthetic@example.test'},...time,original_words:'Synthetic historical completion with no task DoD',after:{state:'completed'}};
 call('log-append',{projectsRoot:context.projectsRoot,entry:historical});
 write(manifestPath,{ids,time,historical});snapshot(vault,'legacy-before');
 // Each independent run gets only authorized synthetic records. History is copied via CLI.
 for(const n of ['destination-stop','source-stop','log-stop','unexpected-edit','case-collision','competing-sources']){
  const v=path.join(scratch,'runs',n,'vault');fs.mkdirSync(v,{recursive:true});
  for(const rel of ['Projects/job-search','Daily','.nyssaai/daily-tasks/profile.json'])fs.cpSync(path.join(vault,rel),path.join(v,rel),{recursive:true,filter:q=>!q.includes('.daily-tasks')});
 }
 console.log(JSON.stringify({stage,ids,context}));
} else {
 const fixture=JSON.parse(read(manifestPath)),{ids}=fixture;
 const context=call('resolve-context',{vaultRoot:vault});write(path.join(evidence,'context.json'),context);
 const p=path.join(context.projectsRoot,'job-search'),legacy=path.join(p,'legacy-career'),dest=path.join(p,'m1-career-materials');
 const pointer=path.join(evidence,'operation-pointer.json');
 if(stage==='prepare'){
  if(name!=='main')call('log-append',{projectsRoot:context.projectsRoot,entry:fixture.historical});
  snapshot(vault,'before');call('inspect-records',{projectsRoot:context.projectsRoot});call('log-query',{projectsRoot:context.projectsRoot});
  const mapping={'milestone.md':'m1-career-materials.md','linkedin.md':'t1-update-linkedin.md','resume.md':'t2-update-resume.md','review.md':'t3-review-materials.md','evidence.txt':'inputs/evidence.txt'};
  const dod=read(path.join(legacy,'definition-of-done.md'));
  const effects=[];
  const effect=(file,after,kind)=>effects.push({path:file,before:read(file),after,kind,beforeHash:hash(read(file)),afterHash:hash(after)});
  const retarget=s=>s.replaceAll('legacy-career/definition-of-done#Definition of Done','m1-career-materials/m1-career-materials#Definition of Done').replaceAll('legacy-career/definition-of-done','m1-career-materials/m1-career-materials#Definition of Done').replaceAll('definition-of-done#Definition of Done','m1-career-materials#Definition of Done').replaceAll('[[definition-of-done|','[[m1-career-materials#Definition of Done|').replaceAll(`ref: ${ids.dod}`,`ref: ${ids.milestone}`).replaceAll('legacy-career/milestone','m1-career-materials/m1-career-materials').replaceAll('legacy-career/linkedin','m1-career-materials/t1-update-linkedin').replaceAll('legacy-career/resume','m1-career-materials/t2-update-resume');
  for(const [src,target] of Object.entries(mapping)){
   let s=read(path.join(legacy,src));
   if(src==='milestone.md'){
    const criteria=dod.match(/## Definition of Done\n([\s\S]*?)\n## Blocked by/)[1].trim().replaceAll('[[evidence.txt|','[[inputs/evidence.txt|');
    s=s.replace('\ntype: "milestone"','\nrecord_version: 2\ntype: "milestone"').replace(/## Definition of Done\n[\s\S]*?\n## Tasks/,`## Definition of Done\n\n${criteria}\n\nProvenance: synthetic reviewer note, retain verbatim.\n\n## Blocked by\n- [[../blockers/b1-approval|Approval pending]] <!-- ref: ${ids.blocker} -->\n\n## Tasks`);
    s=s.replace('[[linkedin|','[[t1-update-linkedin|').replace('[[resume|','[[t2-update-resume|').replace('[[review|','[[t3-review-materials|');
    s+=`\n**Project:** [[../project-index|Job Search]] <!-- ref: ${ids.project} -->\n`;
   }else if(src.endsWith('.md')){
    s=retarget(s).replace('[[milestone|','[[m1-career-materials|');
    if(src==='review.md')s=s.replace('\ntype: "task"','\nrecord_version: 2\ntype: "task"');
   }
   effect(path.join(dest,target),s,'destination');
  }
  for(const file of [path.join(p,'project-index.md'),path.join(p,'blockers/b1-approval.md'),path.join(context.dailyPlansRoot,'2026-10-09.md')])effect(file,retarget(read(file)),'reference');
  // Old live task references are repaired as well, before any source retirement.
  for(const src of ['linkedin.md','resume.md','review.md']){
   const file=path.join(legacy,src);let s=read(file).replaceAll('[[definition-of-done#Definition of Done|','[[../m1-career-materials/m1-career-materials#Definition of Done|');effect(file,s,'source-reference');
  }
  const lm=path.join(legacy,'milestone.md');effect(lm,read(lm).replace('[[definition-of-done|','[[../m1-career-materials/m1-career-materials#Definition of Done|').replace(`ref: ${ids.dod}`,`ref: ${ids.milestone}`),'source-reference');
  for(const src of Object.keys(mapping)){
   const file=path.join(legacy,src),previous=effects.find(e=>e.path===file);effects.push({path:file,before:previous?.after??read(file),after:null,kind:'source-removal',beforeHash:hash(previous?.after??read(file)),afterHash:null});
  }
  effect(path.join(legacy,'definition-of-done.md'),null,'dod-retirement');
  const time=call('activity-time',{}),operation_id=id(),event_id=id();
  const entry={id:event_id,operation_id,action:'workspace-migration',record_ids:[ids.project,ids.milestone,ids.a,ids.b,ids.c,ids.blocker],actor:{kind:'agent',id:'codex'},...time,original_words:'Explicitly authorized scenario8 legacy workspace conversion',before:{retired_dod_id:ids.dod,criteria:[ids.criterion],mapping},after:{milestone:ids.milestone,criteria:[ids.criterion],pending_task_conversion:[ids.a,ids.b],mapping}};
  const operation={operation_id,status:'pending',planningBinding:context.planningBinding,context,effects,entry,stage:'prepared',retiredDoD:{id:ids.dod,content:dod},pendingCriteria:[ids.a,ids.b]};
  const opPath=path.join(context.stateRoot,'operations',operation_id+'.json');write(opPath,operation);write(pointer,{opPath});write(path.join(p,'.temp',operation_id,'before-after.json'),operation);
  console.log(JSON.stringify({stage,name,opPath,effects:effects.length}));
 }else{
  const {opPath}=JSON.parse(read(pointer)),op=JSON.parse(read(opPath));
  function save(){write(opPath,op);}
  if(stage==='inject'){
   if(name==='unexpected-edit')write(path.join(dest,'t3-review-materials.md'),read(path.join(dest,'t3-review-materials.md'))+'\nUnexpected independent reviewer edit.\n');
   if(name==='case-collision')write(path.join(dest,'M1-CAREER-MATERIALS.MD'),'Unrelated Windows case-insensitive destination. Preserve these bytes.\n');
   snapshot(vault,'injected');console.log('Injected '+name);
  } else if(stage==='competing'){
   const f=path.join(legacy,'milestone.md');write(f,read(f)+`\n## Definition of Done\n- [ ] Independently embedded acceptance. <!-- id: ${id()} -->\n`);
   const inspected=call('inspect-records',{projectsRoot:context.projectsRoot});write(path.join(evidence,'competing-inspect.json'),inspected);
   const records=inspected.records;const closure=call('check-closure',{recordId:ids.milestone,records});write(path.join(evidence,'competing-closure.json'),closure);console.log(JSON.stringify(closure));
  }else{
   const stop=stage.startsWith('stop-')?stage.slice(5):null;
   const allFiles=()=>{const result=[];function walk(dir){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){if(ent.name.startsWith('.'))continue;const f=path.join(dir,ent.name);if(ent.isDirectory())walk(f);else if(f.endsWith('.md'))result.push(f);}}walk(p);walk(context.dailyPlansRoot);return result;};
   const conflicts=[];
   const grouped=Object.groupBy(op.effects,e=>e.path);
   const changes=[],actualFields={};
   for(const [file,effects] of Object.entries(grouped)){
    const actual=read(file),values=[effects[0].before,...effects.map(e=>e.after)];
    const index=values.findIndex(v=>v===actual);
    const before=index>=0?actual:effects[0].before;
    changes.push({key:file,before:{present:before!==null,...(before!==null?{value:hash(before)}:{})},after:{present:effects.at(-1).after!==null,...(effects.at(-1).after!==null?{value:hash(effects.at(-1).after)}:{})}});
    if(actual!==null)actualFields[file]=hash(actual);
   }
   call('recover-operation',{operation:{changes},actual:actualFields});
   for(const e of op.effects){
    const actual=read(e.path);
    // A sequential effect may be superseded by a later applied deletion.
    const later=op.effects.slice(op.effects.indexOf(e)+1).filter(q=>q.path===e.path);
    const superseded=later.some(q=>actual===q.after&&op.applied?.includes(op.effects.indexOf(q)));
    if(actual===e.after||superseded)continue;
    if(actual!==e.before){conflicts.push({path:e.path,reason:'unexpected-content',actualHash:hash(actual),expectedBefore:e.beforeHash,expectedAfter:e.afterHash});continue;}
    if(e.after!==null&&e.before===null&&fs.existsSync(path.dirname(e.path))){const match=fs.readdirSync(path.dirname(e.path)).find(x=>x.toLowerCase()===path.basename(e.path).toLowerCase());if(match){conflicts.push({path:e.path,reason:'case-insensitive-unrelated-collision',existing:match});continue;}}
    if(conflicts.length)break;
    if(e.kind==='source-removal'){
     const target=op.effects.find(q=>q.kind==='destination'&&path.basename(q.path)==={'milestone.md':'m1-career-materials.md','linkedin.md':'t1-update-linkedin.md','resume.md':'t2-update-resume.md','review.md':'t3-review-materials.md','evidence.txt':'evidence.txt'}[path.basename(e.path)]);
     if(!target||read(target.path)!==target.after)throw Error('Destination verification failed before removing '+e.path);
    }
    if(e.kind==='dod-retirement'){
     const live=allFiles().filter(f=>f!==e.path);const refs=live.filter(f=>read(f).includes('definition-of-done')||read(f).includes(`ref: ${ids.dod}`));
     const owner=read(path.join(dest,'m1-career-materials.md'));
     const verified=refs.length===0&&owner.includes(ids.criterion)&&owner.includes('Provenance: synthetic reviewer note, retain verbatim.')&&owner.includes('[[inputs/evidence.txt|')&&read(path.join(dest,'inputs/evidence.txt'))==='Synthetic review evidence. Original bytes must survive.\n';
     write(path.join(evidence,'retirement-verification.json'),{liveFiles:live.map(f=>({path:f,hash:hash(read(f))})),remainingIncoming:refs,verified});
     if(!verified)throw Error('DoD cannot retire: content/incoming links unverified');
    }
    const current=read(e.path);if(current!==e.before)throw Error('Race before write');
    if(e.after===null)fs.unlinkSync(e.path);else write(e.path,e.after);
    if(read(e.path)!==e.after)throw Error('Effect verification failed');
    op.applied??=[];op.applied.push(op.effects.indexOf(e));op.stage=e.kind;save();
    fs.appendFileSync(path.join(evidence,'actions.jsonl'),JSON.stringify({at:new Date().toISOString(),path:e.path,kind:e.kind,before:e.beforeHash,after:e.afterHash})+'\n');
    if(stop==='destination'&&e===op.effects.filter(q=>q.kind==='destination').at(-1)){call('invalidate-project-index',{vaultRoot:vault});snapshot(vault,'interrupted-destination');console.log('Actual interruption after destination persistence');process.exit(0);}
    if(stop==='source'&&e.kind==='dod-retirement'){call('invalidate-project-index',{vaultRoot:vault});snapshot(vault,'interrupted-source');console.log('Actual interruption after source removal');process.exit(0);}
   }
   if(conflicts.length){op.status='pending-conflict';op.conflicts=conflicts;save();call('log-query',{projectsRoot:context.projectsRoot,action:'workspace-migration'});snapshot(vault,'conflict-after');console.log(JSON.stringify({status:op.status,conflicts}));process.exit(0);}
   fs.mkdirSync(path.join(dest,'inputs'),{recursive:true});fs.mkdirSync(path.join(dest,'outputs'),{recursive:true});
   call('invalidate-project-index',{vaultRoot:vault});
   const inspection=call('inspect-records',{projectsRoot:context.projectsRoot});write(path.join(evidence,'final-inspection.json'),inspection);
   call('check-links',{records:inspection.records});call('check-closure',{recordId:ids.milestone,records:inspection.records});
   const prior=call('log-query',{projectsRoot:context.projectsRoot,action:'workspace-migration'});
   call('log-append',{projectsRoot:context.projectsRoot,entry:op.entry});op.stage='log-appended';save();
   if(stop==='log'){snapshot(vault,'interrupted-log');console.log('Actual interruption after log append');process.exit(0);}
   const queried=call('log-query',{projectsRoot:context.projectsRoot,action:'workspace-migration'});write(path.join(evidence,'exact-event-query.json'),queried);
   const entries=Array.isArray(queried)?queried:queried.entries;const matches=entries.filter(e=>e.operation_id===op.operation_id);
   if(matches.length!==1||JSON.stringify(matches[0])!==JSON.stringify(op.entry))throw Error('Exact full event verification failed');
   const baselines={planningBinding:context.planningBinding,files:{}};for(const f of allFiles())baselines.files[f]={hash:hash(read(f)),markdown:read(f)};write(path.join(context.stateRoot,'reconciliation.json'),baselines);
   call('invalidate-project-index',{vaultRoot:vault});
   op.status='complete';op.stage='verified';save();snapshot(vault,'after');write(path.join(evidence,'completion.json'),{operation_id:op.operation_id,event_id:op.entry.id,exactEvents:matches.length,pendingTaskConversion:op.pendingCriteria});console.log(JSON.stringify({status:op.status,name,pendingTaskConversion:op.pendingCriteria}));
  }
 }
}
