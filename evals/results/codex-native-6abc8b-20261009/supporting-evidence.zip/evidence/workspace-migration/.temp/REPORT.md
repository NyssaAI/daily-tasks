# Scenario 8: workspace migration

48/48 evidence checks passed. All required workflow assertions passed.

Skill-authored workflow executed in the current Codex session using the installed 0.3.3 CLI and actual file effects. Separate Node processes interrupted after destination persistence, source removal and log append; each resumed its saved operation and retried. Native host authentication/version/model were not exposed, so this evidence does not independently certify those host prerequisites. No prior attempts, operation scripts or regression tests were read.

Completed legacy Update LinkedIn and unresolved Update resume retain their identities and lifecycle, without invented task criteria; both remain pending conversion. Missing criteria were requested from the user.

- PASS: main: historical event preserved exactly — evidence/main/audit-log-query-result.json
- PASS: main: exact one migration event after resume and retry — evidence/main/audit-log-query-result.json
- PASS: main: no duplicate live identities — evidence/main/audit-inspect-records-result.json
- PASS: main: milestone/task identities and lifecycle preserved — evidence/main/audit-inspect-records-result.json
- PASS: main: criterion IDs, states, text, evidence and provenance preserved — evidence/main/after
- PASS: main: reciprocal blocker now targets milestone — evidence/main/audit-inspect-records-result.json
- PASS: main: missing task DoD not manufactured; unresolved task readable/pending — evidence/main/completion.json
- PASS: main: DoD retired only after copied content and ALL live incoming links verified — evidence/main/retirement-verification.json
- PASS: main: criterion links retain UUID/navigate new owner; all navigation resolves — evidence/main/after
- PASS: destination-stop: historical event preserved exactly — evidence/destination-stop/audit-log-query-result.json
- PASS: destination-stop: exact one migration event after resume and retry — evidence/destination-stop/audit-log-query-result.json
- PASS: destination-stop: no duplicate live identities — evidence/destination-stop/audit-inspect-records-result.json
- PASS: destination-stop: milestone/task identities and lifecycle preserved — evidence/destination-stop/audit-inspect-records-result.json
- PASS: destination-stop: criterion IDs, states, text, evidence and provenance preserved — evidence/destination-stop/after
- PASS: destination-stop: reciprocal blocker now targets milestone — evidence/destination-stop/audit-inspect-records-result.json
- PASS: destination-stop: missing task DoD not manufactured; unresolved task readable/pending — evidence/destination-stop/completion.json
- PASS: destination-stop: DoD retired only after copied content and ALL live incoming links verified — evidence/destination-stop/retirement-verification.json
- PASS: destination-stop: criterion links retain UUID/navigate new owner; all navigation resolves — evidence/destination-stop/after
- PASS: destination-stop: actual independent interruption persisted a pending saved operation — evidence/destination-stop/interrupted-destination
- PASS: source-stop: historical event preserved exactly — evidence/source-stop/audit-log-query-result.json
- PASS: source-stop: exact one migration event after resume and retry — evidence/source-stop/audit-log-query-result.json
- PASS: source-stop: no duplicate live identities — evidence/source-stop/audit-inspect-records-result.json
- PASS: source-stop: milestone/task identities and lifecycle preserved — evidence/source-stop/audit-inspect-records-result.json
- PASS: source-stop: criterion IDs, states, text, evidence and provenance preserved — evidence/source-stop/after
- PASS: source-stop: reciprocal blocker now targets milestone — evidence/source-stop/audit-inspect-records-result.json
- PASS: source-stop: missing task DoD not manufactured; unresolved task readable/pending — evidence/source-stop/completion.json
- PASS: source-stop: DoD retired only after copied content and ALL live incoming links verified — evidence/source-stop/retirement-verification.json
- PASS: source-stop: criterion links retain UUID/navigate new owner; all navigation resolves — evidence/source-stop/after
- PASS: source-stop: actual independent interruption persisted a pending saved operation — evidence/source-stop/interrupted-source
- PASS: log-stop: historical event preserved exactly — evidence/log-stop/audit-log-query-result.json
- PASS: log-stop: exact one migration event after resume and retry — evidence/log-stop/audit-log-query-result.json
- PASS: log-stop: no duplicate live identities — evidence/log-stop/audit-inspect-records-result.json
- PASS: log-stop: milestone/task identities and lifecycle preserved — evidence/log-stop/audit-inspect-records-result.json
- PASS: log-stop: criterion IDs, states, text, evidence and provenance preserved — evidence/log-stop/after
- PASS: log-stop: reciprocal blocker now targets milestone — evidence/log-stop/audit-inspect-records-result.json
- PASS: log-stop: missing task DoD not manufactured; unresolved task readable/pending — evidence/log-stop/completion.json
- PASS: log-stop: DoD retired only after copied content and ALL live incoming links verified — evidence/log-stop/retirement-verification.json
- PASS: log-stop: criterion links retain UUID/navigate new owner; all navigation resolves — evidence/log-stop/after
- PASS: log-stop: actual independent interruption persisted a pending saved operation — evidence/log-stop/interrupted-log
- PASS: unexpected-edit: historical event preserved exactly — evidence/unexpected-edit/audit-log-query-result.json
- PASS: unexpected-edit: preserves injected bytes and pending conflict; no false completion — evidence/unexpected-edit/conflict-after
- PASS: unexpected-edit: source and standalone DoD remain readable — runs/unexpected-edit/vault/Projects/job-search/legacy-career
- PASS: case-collision: historical event preserved exactly — evidence/case-collision/audit-log-query-result.json
- PASS: case-collision: preserves injected bytes and pending conflict; no false completion — evidence/case-collision/conflict-after
- PASS: case-collision: source and standalone DoD remain readable — runs/case-collision/vault/Projects/job-search/legacy-career
- PASS: competing-sources: historical event preserved exactly — evidence/competing-sources/audit-log-query-result.json
- PASS: Closure rejects competing embedded/standalone DoD — evidence/competing-sources/audit-check-closure-result.json
- PASS: Competing source records retained without migration event — evidence/competing-sources/before

Actual actions: evidence/*/actions.jsonl. Exact before/after bytes and saved checkpoints: evidence/*/before, after, interrupted-*. Installed CLI inputs, command, exit, stdout and stderr: evidence/*/*-input.json and *-result.json. Loaded skill hashes and host visibility: assertions.json.

Snapshot capture correction: the first pass excluded paths because the case itself lives under .temp. Its evidence and fixtures remain in retained-first-pass/ and runs/. All interruption/conflict probes were repeated in runs-fresh/ with complete snapshots. Main before/after bytes are retained in the saved operation and project recovery copy; its final snapshot was captured on retry. The competing-source probe was repeated with valid metadata and a distinct embedded criterion ID, and closure still explicitly reported both sources.
