import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), temp=path.join(root,'.temp'), vault=path.join(root,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';
let serial=0;
const save=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2));};
function cli(op,input){const stem=path.join(temp,'cli',`${String(++serial).padStart(4,'0')}-${op}`); const args=[path.join(pkg,'bin/daily-tasks.mjs'),op];if(input!==undefined){save(stem+'.input.json',input);args.push('--input',stem+'.input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(stem+'.result.json',{command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const context=cli('resolve-context',{vaultRoot:vault});save(path.join(temp,'context.json'),context);
const projectsRoot=context.projectsRoot;
const inspect=()=>cli('inspect-records',{projectsRoot});
let records=inspect().records;
const byTitle=t=>records.find(r=>r.title===t);
const P=byTitle('Job Search').id,M=byTitle('Career materials').id,T=byTitle('Update LinkedIn').id,R=byTitle('Update resume').id;
const read=id=>fs.readFileSync(records.find(r=>r.id===id).path,'utf8');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const findings=[];
function verify(label,ok,details){findings.push({label,pass:!!ok,details});save(path.join(temp,'assertions.json'),findings);if(!ok)throw Error(label);}
function closure(id,allowed,label){records=inspect().records;const result=cli('check-closure',{recordId:id,records});verify(label,result.allowed===allowed,result);return result;}
function field(s,k,v){const line=`${k}: ${JSON.stringify(v)}`;return new RegExp(`^${k}:.*$`,'m').test(s)?s.replace(new RegExp(`^${k}:.*$`,'m'),line):s.replace(/^---\r?\n/,`---\n${line}\n`);}
function status(s,type,state,time){s=field(s,`${type}-state`,state);s=field(s,'updated_at',time);if(['completed','cancelled','resolved'].includes(state))s=field(s,'resolved_at',time);else s=s.replace(/^resolved_at:.*\r?\n/gm,'');return s;}
function criterion(s,checked){return s.replace(/(- )\[[ x]\](.*<!-- id:)/g,`$1[${checked?'x':' '}]$2`);}
function commit(label,changes){const time=cli('activity-time',{}),operation_id=cli('new-id').id??null; if(!operation_id)throw Error('new-id shape');const eventId=cli('new-id').id; const opPath=path.join(context.stateRoot,'operations',operation_id+'.json');const items=Object.entries(changes).map(([p,after])=>({path:p,before:fs.existsSync(p)?fs.readFileSync(p,'utf8'):null,after}));const event={id:eventId,operation_id,action:'scenario5.'+label,record_ids:[P,M,T,R,...(B?[B]:[])],actor:{kind:'agent',id:'codex'},...time,original_words:label,before:items.map(i=>({path:i.path,sha256:i.before===null?null:sha(i.before)})),after:items.map(i=>({path:i.path,sha256:sha(i.after)}))};delete event.activityTime;const checkpoint={operation_id,planningBinding:context.planningBinding,status:'pending',event,changes:items.map(i=>({...i,beforeHash:i.before===null?null:sha(i.before),afterHash:sha(i.after)}))};save(opPath,checkpoint);const evidence=path.join(temp,'actions',label);save(path.join(evidence,'checkpoint.json'),checkpoint);for(const [n,i] of items.entries()){save(path.join(evidence,`${n}-before.md`),i.before??'[absent]');if((fs.existsSync(i.path)?fs.readFileSync(i.path,'utf8'):null)!==i.before)throw Error('Concurrent edit');save(i.path,i.after);save(path.join(evidence,`${n}-after.md`),i.after);}cli('invalidate-project-index',{vaultRoot:vault});records=inspect().records;cli('validate-records',{records});cli('check-links',{records});cli('log-append',{projectsRoot,entry:event});const query=cli('log-query',{projectsRoot});if(!query.entries?.some(e=>JSON.stringify(e)===JSON.stringify(event)))throw Error('Log verification shape or payload');const base={records:Object.fromEntries(records.map(r=>[r.id,{canonical:r,sha256:sha(read(r.id)),views:Object.fromEntries(records.filter(v=>v.projections?.some(p=>p.id===r.id)).map(v=>[v.path,{projections:v.projections.filter(p=>p.id===r.id),sha256:sha(read(v.id))}]))}]))};save(path.join(context.stateRoot,'reconciliation.json'),base);checkpoint.status='complete';save(path.join(evidence,'completed.json'),checkpoint);fs.unlinkSync(opPath);}
let B=null;
function change(label,delta,propagate=[]){records=inspect().records;const time=cli('activity-time',{}).activity_at;let contents=Object.fromEntries(records.map(r=>[r.id,read(r.id)]));for(const [id,fn] of Object.entries(delta))contents[id]=fn(contents[id],time);if(propagate.length){const proposed=records.map(r=>cli('parse-record',{markdown:contents[r.id],path:r.path}));const result=cli('reopen-ancestors',{records:proposed,changedIds:propagate});save(path.join(temp,label+'-reopen.json'),result);for(const r of result.records){const original=proposed.find(x=>x.id===r.id);if(r.state!==original.state)contents[r.id]=status(contents[r.id],r.type,r.state,time);}}
 const parsed=records.map(r=>cli('parse-record',{markdown:contents[r.id],path:r.path}));for(const v of records){let s=contents[v.id];for(const row of v.projections??[]){const target=parsed.find(r=>r.id===row.id);const mark={completed:'x',cancelled:'-', 'in-progress':'>','not-started':' '}[target.state];s=s.split('\n').map(line=>line.includes(`<!-- ref: ${row.id} -->`)?line.replace(/\[[ x>\-]\]/,`[${mark}]`):line).join('\n');}contents[v.id]=s;}commit(label,Object.fromEntries(records.filter(r=>contents[r.id]!==read(r.id)).map(r=>[r.path,contents[r.id]])));}
function complete(id,label){closure(id,true,label+'-eligible');change(label,{[id]:(s,t)=>status(s,records.find(r=>r.id===id).type,'completed',t)});}
closure(T,false,'task-dod-gates');closure(M,false,'milestone-unresolved-children-gate');closure(P,false,'project-unresolved-milestone-gate');
save(path.join(temp,'ready.json'),{P,M,T,R});
B=cli('new-id').id;
const bp=path.join(projectsRoot,'job-search/blockers/b1-await-approval.md');
const now=cli('activity-time',{}).activity_at;
cli('log-query',{projectsRoot});
commit('shared-blocker-created',{
 [bp]:`---\nid: "${B}"\ntype: blocker\nrecord_version: 2\ntitle: "Await approval"\nblocker-state: open\nowner: "synthetic@example.test"\nproject_id: "${P}"\ncreated_at: "${now}"\nupdated_at: "${now}"\n---\n# Await approval\n\nAwait synthetic reviewer approval of both career artifacts.\n\n## Resolution condition\nExplicit synthetic review approval of both artifacts is recorded.\n\n## Resolution evidence\nApproval pending.\n\n## Blocks\n- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: ${T} -->\n- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: ${R} -->\n`,
 [records.find(r=>r.id===T).path]:read(T)+`\n## Blocked by\n- [[../blockers/b1-await-approval|Await approval]] <!-- ref: ${B} -->\n`,
 [records.find(r=>r.id===R).path]:read(R)+`\n## Blocked by\n- [[../blockers/b1-await-approval|Await approval]] <!-- ref: ${B} -->\n`
});
const output=path.join(projectsRoot,'job-search/m1-career-materials/outputs');
commit('reviewed-synthetic-artifacts',{
 [path.join(output,'reviewed-headline.md')]:'# Reviewed LinkedIn headline\n\nSoftware engineer building reliable products and thoughtful user experiences.\n\nSynthetic acceptance evidence: reviewed by Codex for a clear professional headline; approved for this local scenario by user authorization.\n',
 [path.join(output,'reviewed-summary.md')]:'# Reviewed resume summary\n\nSoftware engineer experienced in building reliable applications, collaborating across teams, and delivering maintainable solutions focused on user needs.\n\nSynthetic acceptance evidence: reviewed by Codex for a concise resume summary; approved for this local scenario by user authorization.\n'
});
change('task-criteria-reviewed',{[T]:s=>criterion(s,true).replace('Work has not started; no artifact has been produced or reviewed.','Synthetic reviewed headline: [artifact](outputs/reviewed-headline.md). Reviewed by Codex under the user-authorized synthetic evidence scope.'),[R]:s=>criterion(s,true).replace('Work has not started; no artifact has been produced or reviewed.','Synthetic reviewed summary: [artifact](outputs/reviewed-summary.md). Reviewed by Codex under the user-authorized synthetic evidence scope.')});
closure(T,false,'shared-blocker-gates-linkedin');closure(R,false,'shared-blocker-gates-resume');
change('approval-resolved',{[B]:(s,t)=>status(s,'blocker','resolved',t).replace('Approval pending.','Synthetic review approval recorded for both reviewed artifacts, authorized by the user for scenario 5.')});
change('cancel-dependency',{[R]:(s,t)=>status(s,'task','cancelled',t)+`\n## Required by\n- [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${T} -->\n`,[T]:s=>s+`\n## Depends on\n- [[t2-update-resume|Update resume]] <!-- ref: ${R} -->\n\nPrerequisite cancelled; dependency is informational.\n`});
complete(T,'linkedin-completed-with-cancelled-dependency');
closure(M,false,'milestone-dod-gates-with-terminal-children');
change('resume-explicitly-reopened',{[R]:(s,t)=>status(s,'task','not-started',t)},[R]);
change('milestone-criterion-reviewed',{[M]:s=>criterion(s,true)+ '\n## Review evidence\nBoth reviewed artifacts are linked: [headline](outputs/reviewed-headline.md), [summary](outputs/reviewed-summary.md). Synthetic review authorized by user.\n'});
closure(M,false,'unresolved-child-gates-with-satisfied-milestone-dod');
complete(R,'resume-completed');complete(M,'milestone-completed');complete(P,'project-completed');
change('approval-reopened',{[B]:(s,t)=>status(s,'blocker','open',t)},[B]);
records=inspect().records;
verify('blocker-reopens-parents-preserves-completed-tasks',records.find(r=>r.id===P).state!=='completed'&&records.find(r=>r.id===M).state!=='completed'&&records.filter(r=>[T,R].includes(r.id)).every(r=>r.state==='completed'),records.map(r=>({id:r.id,state:r.state})));
closure(M,false,'open-shared-blocker-gates-milestone');closure(P,false,'open-shared-blocker-gates-project');
change('approval-resolved-again',{[B]:(s,t)=>status(s,'blocker','resolved',t)});complete(M,'milestone-reclosed');complete(P,'project-reclosed');
change('milestone-dod-unchecked',{[M]:s=>criterion(s,false)},[M]);
records=inspect().records;verify('milestone-dod-reopens-parents-preserves-tasks',records.find(r=>r.id===M).state!=='completed'&&records.find(r=>r.id===P).state!=='completed'&&records.filter(r=>[T,R].includes(r.id)).every(r=>r.state==='completed'));
change('milestone-dod-restored',{[M]:s=>criterion(s,true)});complete(M,'milestone-reclosed-after-dod');complete(P,'project-reclosed-after-dod');
change('task-dod-unchecked',{[T]:s=>criterion(s,false)},[T]);
records=inspect().records;verify('task-dod-reopens-task-and-parents',records.filter(r=>[T,M,P].includes(r.id)).every(r=>r.state!=='completed')&&records.find(r=>r.id===R).state==='completed');
change('task-started-for-explicit-reopen-check',{[T]:(s,t)=>field(status(s,'task','in-progress',t),'started_at',t)});
change('explicit-reopen-not-started',{[T]:(s,t)=>status(s,'task','not-started',t)},[T]);
records=inspect().records;verify('explicit-not-started-overrides-started-at',records.find(r=>r.id===T).state==='not-started'&&!!records.find(r=>r.id===T).started_at);
const original=read(T);
change('temporary-missing-task-dod',{[T]:s=>s.replace(/## Definition of Done\r?\n[\s\S]*?(?=## Inputs)/,'')});closure(T,false,'missing-new-task-dod-cannot-complete');
change('temporary-empty-task-dod',{[T]:s=>s.replace('## Inputs','## Definition of Done\n\n## Inputs')});closure(T,false,'empty-new-task-dod-cannot-complete');
change('original-task-criterion-restored',{[T]:()=>original});
verify('original-criterion-id-restored',read(T).includes('01a1211c-fcde-77f4-84d8-63271f429f17'));
change('linkedin-criterion-resatisfied',{[T]:s=>criterion(s,true)});complete(T,'linkedin-final-completion');complete(M,'milestone-final-completion');complete(P,'project-final-completion');
records=inspect().records;verify('final-existing-work-closed',records.filter(r=>[P,M,T,R].includes(r.id)).every(r=>r.state==='completed'));
verify('sole-authorized-work-identities',records.length===5&&records.every(r=>[P,M,T,R,B].includes(r.id)));
save(path.join(temp,'final-log-query.json'),cli('log-query',{projectsRoot}));
save(path.join(temp,'receipt.md'),`# Scenario 5 closure\n\n${findings.length} assertions passed. Actual installed CLI calls, inputs, results, checkpoints and before/after Markdown are retained beside this receipt.\n\nAll four existing work records are completed; the sole shared blocker is resolved. Original task and milestone criterion IDs are retained. No alternate accepted work was created.\n\nThis is a skill-authored current native host workflow. Packaging and direct CLI execution alone are not claimed as proof of host activation.\n`);
