---
id: "01a12160-6f58-7a2d-b319-0fbef6abd285"
type: blocker
record_version: 2
title: "Await approval"
blocker-state: "open"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T15:55:30.562Z"
updated_at: "2026-10-09T15:55:38.990Z"
---
# Await approval

Await synthetic reviewer approval of both career artifacts.

## Resolution condition
Explicit synthetic review approval of both artifacts is recorded.

## Resolution evidence
Synthetic review approval recorded for both reviewed artifacts, authorized by the user for scenario 5.

## Blocks
- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->
