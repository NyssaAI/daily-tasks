import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';
const loaded=['daily-tasks/SKILL.md','daily-tasks-records/SKILL.md','daily-tasks-setup/SKILL.md','daily-tasks/references/cli.md','daily-tasks/references/operations.md','daily-tasks/references/records.md','daily-tasks/assets/blocker.md'].map(p=>{const absolute=path.join(pkg,'skills',p);return {path:absolute,sha256:crypto.createHash('sha256').update(fs.readFileSync(absolute)).digest('hex')};});
const checks=fs.readdirSync('.temp/cli').filter(p=>/-(validate-records|check-links)\.result\.json$/.test(p)).map(p=>{const r=JSON.parse(fs.readFileSync(path.join('.temp/cli',p)));return {path:p,exit:r.exit,diagnostics:JSON.parse(r.stdout).diagnostics};});
fs.writeFileSync('.temp/validation-summary.json',JSON.stringify(checks,null,2));
fs.writeFileSync('.temp/host-evidence.json',JSON.stringify({host:'Current Codex native conversation',model:'Not exposed',node:process.version,platform:process.platform,installedBundle:pkg,loaded,priorAttemptsRead:false,initialCliCorrection:'Two initial --input calls used relative paths and returned INVALID_OPERATION. Retried with absolute case .temp paths; no writes occurred in failed calls.',scope:'Only current case, installed bundle and referenced evals README accessed; no personal directories accessed.'},null,2));
console.log(JSON.stringify({validationCalls:checks.length,diagnosticCalls:checks.filter(c=>c.diagnostics.length).map(c=>({path:c.path,diagnostics:c.diagnostics})),assertions:JSON.parse(fs.readFileSync('.temp/assertions.json')).length}));
