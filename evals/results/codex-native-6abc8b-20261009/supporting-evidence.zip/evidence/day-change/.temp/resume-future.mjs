import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {cli,json,save,evidence,recover,snapshot} from './session.mjs';
import {removeSelection,stateInput,review} from './plans.mjs';
const tasks=json(evidence+'/tasks.json');
const future={vaultRoot:path.join(evidence,'future-removal/vault'),profilePath:path.join(evidence,'future-removal/vault/.nyssaai/daily-tasks/profile.json')};
const ops=path.join(future.vaultRoot,'.nyssaai/daily-tasks/operations');
for(const file of fs.readdirSync(ops)){const checkpoint=path.join(ops,file),cp=json(checkpoint);save(path.join(evidence,'checkpoints',cp.operation_id+'-rejected-log-payload.json'),cp);cp.event.record_ids=[...new Set(cp.event.record_ids)];save(checkpoint,cp);save(path.join(evidence,'checkpoints',cp.operation_id+'-schema-corrected.json'),cp);recover(checkpoint);}
const prep=now=>cli('planning-prepare',{...future,now},'future-prepare');
let p=prep('2026-10-06T16:00:00Z');save(evidence+'/future-before-packet.json',p);snapshot('future-before',future.vaultRoot);
removeSelection(p,[tasks.A.id],'User explicitly removes A from future Friday 2026.10.09, America/Chicago.','2026.10.09');
p=prep('2026-10-06T16:00:00Z');save(evidence+'/future-after-removal-packet.json',p);
p=prep('2026-10-09T16:00:00Z');save(evidence+'/future-friday-proposal.json',p);assert.deepEqual(p.rollover.selected.map(r=>r.id),[tasks.B.id]);assert.ok(p.state.rollover.value.removedIds.includes(tasks.A.id));assert.equal(p.state.rollover.value.completedAt,undefined);cli('planning-state',stateInput(p,'complete-rollover'),'future-no-change-rollover');p=prep('2026-10-09T16:00:00Z');assert.deepEqual(p.current.rows.map(r=>r.id),[tasks.B.id]);assert.ok(p.state.rollover.value.removedIds.includes(tasks.A.id));assert.equal(p.rollover.status,'complete');review(p,'future-friday');save(evidence+'/future-final-packet.json',prep('2026-10-09T16:00:00Z'));snapshot('future-final',future.vaultRoot);
save(evidence+'/branches.json',{tuesday:{vaultRoot:path.join(evidence,'tuesday/vault'),profilePath:path.join(evidence,'tuesday/vault/.nyssaai/daily-tasks/profile.json')},future});console.log('Future removal persisted; Friday keeps B and does not recarry A from Monday.');
