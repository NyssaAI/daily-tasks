# Scenario 4: day change

Executed through the current native host using installed Daily Tasks 0.3.3 instructions and the installed integrity/log CLI. Final assertion set: **17/17 verified**. This is a corrected run, not a clean first-pass acceptance receipt: actual authoring errors, rejected calls and corrections remain in the evidence. No release/matrix or authentication claim is made from CLI execution.

| Assertion | Final result |
| --- | --- |
| Skipped days: only Friday added to seeded Monday; no Tuesday/Wednesday/Thursday backfill | Verified |
| Friday carries exactly unfinished own A and delegated C, each once | Verified |
| Completed D and cancelled E remain visible Monday; neither carries | Verified |
| F remains open, explicitly deselected Monday, absent from Friday | Verified |
| No timeframe fitting or lifecycle/date mutation; A/B and manual note preserved | Verified |
| Pre-created Tuesday preserves UUID, original created_at and unrelated prose | Verified |
| Tuesday retains B and carries A exactly once | Verified |
| Removing A and repeating Tuesday retains B, removal and original rollover receipt | Verified |
| Actual interruption persisted destination, retained pending checkpoint, had no completion receipt | Verified |
| Interrupted rollover refuses false no-change completion | Verified |
| Resume has exactly A/C and correct original operation receipt | Verified |
| Original rollover event occurs once, full saved payload and GMT times retained | Verified |
| Recovery retry deduplicates log; repeat Friday leaves rows, log and receipt unchanged | Verified |
| Explicit future-day removal is durable before rollover, with no premature receipt | Verified |
| Future Friday preserves B and excludes removed A from historical Monday carry on repeated reads | Verified |
| Independent branch bindings and receipts never share active operations | Verified |
| No duplicate event or operation IDs in any vault log; all timestamps GMT strings | Verified |

Declared simulation clocks: Monday 2026-10-05T16:00:00Z, Tuesday 2026-10-06T16:00:00Z, Friday 2026-10-09T16:00:00Z. Timezone America/Chicago; each clock displays 11:00 AM CDT. Existing A/B IDs and bytes were preserved. C–F were explicitly accepted by the user; assignment did not imply a start. D completion used explicit review attestation and closure validation; E cancellation was explicit.

Friday has A under My work and C under Delegated work. Monday retains completed D and cancelled E. F stays deselected and open. The independent Tuesday branch keeps B after A is carried once and then removed. The independent future branch removes A from Friday on Tuesday, persists its removal, and excludes it from Friday carry while keeping B. No intervening dates were created or task dates/lifecycle changed to fit time.

## Actual interrupted rollover

- Operation: 01a12162-c2ea-7581-83a4-ca76df0ddbf1
- Event: 01a12162-c314-798a-b2d5-4c885f651aa5
- Original activity_at: 2026-10-09T16:00:00.000Z
- Original recorded_at: 2026-10-09T16:00:00.000Z
- Interrupted stage: destination-persisted; no log, baseline or completion receipt
- Exact persisted destination hash: a7e79ddc8f1473baf80e0619aa054c348eb0aba7de372a134c3916717ac9d730
- Completion receipt at interruption: absent

The attempted premature receipt was rejected. Recovery used the same saved IDs/times and full event payload. Final log query contains that operation exactly once; original-event retries deduplicated and completed receipt stayed unchanged. Pending and completed checkpoints and actual recovery results are retained under checkpoints/.

## Evidence

- [All assertion results](assertions.json), including original source hashes and current packet checks.
- [Actual action ledger and preserved corrections](actions.md).
- [Initial failed verification](assertions-before-snapshot-repair.json) and [snapshot evidence repair](snapshot-repair.json).
- [Installed instruction paths and hashes](installed-instructions.json). Host version/model were not exposed. Maintenance invocation requested gpt-6-luna through the actual subagent tool; actual worker model identity was not exposed.
- Numbered CLI input/result files retain exact installed command, stdout, stderr and exit status.
- [Root final log query](root-final-log-query.json), [Tuesday query](tuesday-final-log-query.json), [future query](future-final-log-query.json). Queries include original IDs and GMT timestamps. Log files were never opened/edited directly.
- snapshots/reconstructed-* preserve exact retained checkpoint bytes, hash checked against preparation packets; snapshots/actual-*-final-with-maintenance preserve final records/views/state. Log files and disposable cache are excluded.
- maintenance/ contains worker inputs/results, source comparisons, separate branch passes and parent verification. Verified maintenance receipts use the actual freshly captured GMT completion instant, separately from original simulated operation clocks.

The original ambiguous manual note “Maybe improve my resume” is preserved and queued as a potentially duplicate candidate. It was not accepted as extra work. Friday rollover is verified, but check-in progress is resumable pending that candidate, rather than falsely marked fully reconciled.
