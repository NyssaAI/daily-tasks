Open projects: 1          Open tasks: 4          Late tasks: 0

Timezone: America/Chicago

## Already selected

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | Career materials | Update resume | — |

## Available tasks

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 2 | [ ] | Job Search | Career materials | Update LinkedIn | — |
| 3 | [ ] | Job Search | Career materials | Review draft | — |
| 4 | [ ] | Job Search | Career materials | Deselected work | — |

Reply by row number and symbol or description:

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled · ↺ carried forward

Keep selections or explicitly add/remove work. Execution order belongs to the user.
