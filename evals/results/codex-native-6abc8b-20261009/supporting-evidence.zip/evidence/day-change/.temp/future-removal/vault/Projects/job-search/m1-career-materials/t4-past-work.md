---
id: "01a12160-85cb-7f68-a30f-ef5e0a1ea007"
type: task
record_version: 2
title: "Past work"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
created_at: "2026-10-05T16:00:00.000Z"
updated_at: "2026-10-05T16:00:00.000Z"
resolved_at: "2026-10-05T16:00:00.000Z"
task-state: completed
document-maturity: reviewed
---
# M1-T4 — Past work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

past result

## Definition of Done

- [x] reviewed result <!-- id: 01a12160-85f4-76d0-b7b3-b1c69103673f -->

## Verification

The user explicitly attested that the past result was reviewed.

## Result

Reviewed result explicitly attested by the user in this synthetic request.
