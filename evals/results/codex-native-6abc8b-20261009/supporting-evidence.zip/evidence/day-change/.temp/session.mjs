import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=process.cwd();
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';
export const vault=path.resolve('vault');
export const evidence=path.resolve('.temp');
fs.mkdirSync(evidence,{recursive:true});
export function save(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
export function read(p){return fs.readFileSync(p,'utf8');}
export function json(p){return JSON.parse(read(p));}
export function hash(p){return fs.existsSync(p)?crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'):null;}
export function cli(name,input,label=name){const n=fs.readdirSync(evidence).filter(x=>/^\d+-/.test(x)).length+1;const stem=path.join(evidence,`${String(n).padStart(3,'0')}-${label}`);if(input!==undefined)save(stem+'.input.json',input);const args=[path.join(pkg,'bin/daily-tasks.mjs'),name,...(input===undefined?[]:['--input',stem+'.input.json'])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(stem+'.result.json',{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const options={vaultRoot:vault,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json'),now:'2026-10-05T16:00:00Z'};
export function prepare(now=options.now,extra={}){return cli('planning-prepare',{...options,now,...extra});}
export function snapshot(name,source=vault){const out=path.join(evidence,'snapshots',name);fs.mkdirSync(out,{recursive:true});fs.cpSync(source,out,{recursive:true,filter:p=>{const parts=path.relative(source,p).split(path.sep);return !parts.includes('.daily-tasks')&&!parts.includes('.temp');}});return out;}
export const newId=()=>cli('new-id').id;
export function transaction(context,action,ids,files,words,now,extra={}){
 const time=cli('activity-time',{now});
 const operationId=newId(),eventId=newId();
 const effects=files.map(({path:p,content})=>({path:p,before:hash(p),after:crypto.createHash('sha256').update(content).digest('hex'),beforeContent:fs.existsSync(p)?read(p):null,content}));
 const event={id:eventId,operation_id:operationId,action,record_ids:ids,actor:{kind:'person',id:context.profile.user.email},...time,original_words:words,before:effects.map(x=>({path:x.path,sha256:x.before})),after:effects.map(x=>({path:x.path,sha256:x.after}))};
 const cp={schemaVersion:1,operation_id:operationId,planningBinding:context.planningBinding,context,event,effects,...extra};
 const checkpoint=path.join(context.stateRoot,'operations',operationId+'.json');
 save(checkpoint,cp);save(path.join(evidence,'checkpoints',operationId+'-pending.json'),cp);
 return {cp,checkpoint};
}
export function applyFiles(cp,limit=Infinity){let written=0;for(const e of cp.effects){const h=hash(e.path);if(h===e.after)continue;if(h!==e.before)throw Error('Optimistic conflict '+e.path);if(written>=limit)break;save(e.path,e.content);if(hash(e.path)!==e.after)throw Error('Write verification failed');written++;cli('invalidate-project-index',{vaultRoot:cp.context.vaultRoot});}return written;}
export function finish({cp,checkpoint}){
 for(const e of cp.effects)if(hash(e.path)!==e.after)throw Error('Incomplete effects');
 const queried=cli('log-query',{projectsRoot:cp.context.projectsRoot,limit:1000});
 const entries=queried.entries??queried;
 const match=entries.find(x=>x.operation_id===cp.event.operation_id);
 if(match&&JSON.stringify(match)!==JSON.stringify(cp.event))throw Error('Log payload conflict');
 cli('log-append',{projectsRoot:cp.context.projectsRoot,entry:cp.event});
 const q=cli('log-query',{projectsRoot:cp.context.projectsRoot,limit:1000});
 const found=(q.entries??q).filter(x=>x.operation_id===cp.event.operation_id);
 if(found.length!==1||JSON.stringify(found[0])!==JSON.stringify(cp.event))throw Error('Event verification failed');
 const bp=path.join(cp.context.stateRoot,'reconciliation.json');let b=fs.existsSync(bp)?json(bp):{schemaVersion:1,records:{},files:{}};
 for(const e of cp.effects){b.files??={};b.files[e.path]={sha256:e.after};if(e.path.endsWith('.md')){const parsed=cli('parse-record',{markdown:read(e.path),path:e.path});b.records??={};b.records[parsed.id]={canonical:parsed,sha256:e.after,path:e.path};}}
 save(bp,b);
 if(cp.receipt){if(hash(cp.receipt.path)!==cp.receipt.before)throw Error('Receipt state conflict');save(cp.receipt.path,cp.receipt.value);}
 save(path.join(evidence,'checkpoints',cp.operation_id+'-complete.json'),{...cp,status:'complete',verifiedEvent:found[0]});fs.unlinkSync(checkpoint);
}
export function recover(checkpoint){const cp=json(checkpoint);const changes=cp.effects.map(e=>({key:e.path,before:e.before===null?{present:false}:{present:true,value:e.before},after:{present:true,value:e.after}}));const actual={};for(const e of cp.effects)if(hash(e.path)!==null)actual[e.path]=hash(e.path);const result=cli('recover-operation',{operation:{changes},actual});save(path.join(evidence,'checkpoints',cp.operation_id+'-recovery.json'),result);if(result.status==='conflict')throw Error('Recovery conflict');applyFiles(cp);finish({cp,checkpoint});return cp;}
