import fs from 'node:fs';
import path from 'node:path';
import {cli,json,read,save,newId,transaction,applyFiles,finish,prepare,snapshot,evidence} from './session.mjs';
const packet=json(evidence+'/first-packet.json'),c=packet.context;
const records=cli('inspect-records',{projectsRoot:c.projectsRoot}).records;
const m=records.find(x=>x.type==='milestone'),p=records.find(x=>x.type==='project');
const tasks={A:records.find(x=>x.title==='Update LinkedIn'),B:records.find(x=>x.title==='Update resume')};
const specs=[['C','Review draft','inspect draft','recorded review','not-started','Reviewer'],['D','Past work','past result','reviewed result','completed'],['E','Abandoned work','draft work','reviewed result','cancelled'],['F','Deselected work','optional draft','reviewed draft','not-started']];
const files=[];
for(const [i,[key,title,requirement,dod,state,assignee]] of specs.entries()){
 const id=newId(),criterion=newId(),slug=title.toLowerCase().replaceAll(' ','-'),n=i+3;
 const file=path.join(path.dirname(m.path),`t${n}-${slug}.md`);
 const content=`---\nid: "${id}"\ntype: task\nrecord_version: 2\ntitle: "${title}"\nowner: "${c.profile.user.email}"\n${assignee?`assignee: "${assignee}"\n`:''}project_id: "${p.id}"\nmilestone_id: "${m.id}"\ncreated_at: "${c.now}"\nupdated_at: "${c.now}"\n${state==='completed'||state==='cancelled'?`resolved_at: "${c.now}"\n`:''}task-state: ${state}\ndocument-maturity: reviewed\n---\n# M1-T${n} — ${title}\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${m.id} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${p.id} -->\n\n## Requirements\n\n${requirement}\n\n## Definition of Done\n\n- [${state==='completed'?'x':' '}] ${dod} <!-- id: ${criterion} -->\n\n## Verification\n\n${key==='D'?'The user explicitly attested that the past result was reviewed.':key==='E'?'The user explicitly cancelled this draft work; review was not attested.':'Record explicit review evidence before closure.'}\n\n## Result\n\n${key==='D'?'Reviewed result explicitly attested by the user in this synthetic request.':key==='E'?'Cancelled by explicit user instruction.':'No result has been attested.'}\n`;
 tasks[key]={id,path:file,title,state,owner:c.profile.user.email,assignee:assignee??null};
 files.push({path:file,content});
}
let milestone=read(m.path),project=read(p.path);
for(const key of ['C','D','E','F']){const t=tasks[key],stem=path.basename(t.path,'.md'),status=t.state==='completed'?'x':t.state==='cancelled'?'-':' ',label=t.state==='cancelled'?`~~${t.title}~~`:t.title;milestone+=`\n- [${status}] [[${stem}|${label}]] <!-- ref: ${t.id} -->\n`;project+=`\n| | [${status}] [[m1-career-materials/${stem}\\|${label}]] <!-- ref: ${t.id} --> | ${key} synthetic accepted work. | Synthetic User | — |\n`;}
files.push({path:m.path,content:milestone},{path:p.path,content:project});
const proposed=[...records,...files.slice(0,4).map(f=>cli('parse-record',{markdown:f.content,path:f.path}))];
save(evidence+'/seed-validation.json',cli('validate-records',{records:proposed}));
const closure=cli('check-closure',{recordId:tasks.D.id,records:proposed});if(!closure.allowed)throw Error(JSON.stringify(closure));
const op=transaction(c,'task.accepted',['C','D','E','F'].map(k=>tasks[k].id),files,'Explicit batch acceptance C–F; C assigned Reviewer; D reviewed result explicitly attested and completed; E explicitly cancelled.',c.now);applyFiles(op.cp);finish(op);
save(evidence+'/tasks.json',tasks);
fs.mkdirSync(path.join(path.dirname(m.path),'inputs'),{recursive:true});fs.mkdirSync(path.join(path.dirname(m.path),'outputs'),{recursive:true});
save(evidence+'/seed-links.json',cli('check-links',{records:cli('inspect-records',{projectsRoot:c.projectsRoot}).records}));
save(evidence+'/after-records-packet.json',prepare());
snapshot('accepted-records');
