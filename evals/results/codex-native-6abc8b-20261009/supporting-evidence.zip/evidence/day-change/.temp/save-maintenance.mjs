import path from 'node:path';
import {cli,json,save,evidence,vault,hash,snapshot} from './session.mjs';
const completion=json(evidence+'/maintenance-completion.json');
const scopes={root:{vaultRoot:vault},...json(evidence+'/branches.json')};
for(const [name,b] of Object.entries(scopes)){
 const stateRoot=path.join(b.vaultRoot,'.nyssaai/daily-tasks');
 const inspected=cli('inspect-records',{projectsRoot:path.join(b.vaultRoot,'Projects')},name+'-maintenance-parent-verify');
 if(inspected.diagnostics.length)throw Error('Parent verification failed');
 const records=inspected.records;
 const validation=cli('validate-records',{records},name+'-maintenance-parent-validation');
 const links=cli('check-links',{records},name+'-maintenance-parent-links');
 if(validation.diagnostics.length||links.diagnostics.length)throw Error('Integrity failure');
 const baselinePath=path.join(stateRoot,'reconciliation.json'),baseline=json(baselinePath);
 for(const r of records){baseline.records??={};baseline.records[r.id]={canonical:{state:r.state,owner:r.owner,assignee:r.assignee??null,started_at:r.started_at??null,resolved_at:r.resolved_at??null,criteria:r.criteria.map(x=>({id:x.id,checked:x.checked}))},sha256:hash(r.path),path:r.path};}
 save(baselinePath,baseline);
 save(path.join(stateRoot,'maintenance.json'),{schemaVersion:1,lastFullReconcileAt:completion.completedAt,worker:{task:completion.workerTask,requestedModel:completion.requestedModel,reportedRuntimeModel:null,fork_turns:'none'},evidence:path.join(evidence,'maintenance'),verifiedSourceHashes:records.map(r=>({path:r.path,sha256:hash(r.path)})),result:'verified broad pass; initial canonical baselines enrolled where absent; ambiguous root candidate retained separately'});
 save(path.join(evidence,name+'-maintenance-status.json'),cli('maintenance-status',{now:completion.completedAt,lastFullReconcileAt:completion.completedAt},name+'-maintenance-gate-verification'));
 snapshot('actual-'+name+'-final-with-maintenance',b.vaultRoot);
}
console.log('Verified maintenance completion persisted with actual GMT clock; each binding remains separate.');
