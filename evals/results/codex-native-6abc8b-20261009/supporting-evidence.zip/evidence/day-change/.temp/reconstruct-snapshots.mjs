import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {json,save,read,hash,evidence,vault,snapshot} from './session.mjs';
const packets=['monday-final-packet','friday-interrupted-packet','friday-resumed-packet','friday-final-packet','tuesday-before-packet','tuesday-carried-packet','tuesday-final-packet','future-before-packet','future-friday-proposal','future-final-packet'];
const cps=fs.readdirSync(path.join(evidence,'checkpoints')).filter(x=>x.endsWith('-complete.json')).map(x=>json(path.join(evidence,'checkpoints',x)));
const first=json(evidence+'/first-packet.json');
const dest=path.join(evidence,'snapshots/original');
for(const source of first.inventory.sources){const file=path.join(first.context.projectsRoot,source.path);let bytes=read(file);if(hash(file)!==source.sha256){const effect=cps.flatMap(c=>c.effects).find(e=>e.path===file&&e.before===source.sha256);if(!effect)throw Error('Missing original content');bytes=effect.beforeContent;}save(path.join(dest,'Projects',source.path),bytes);assert.equal(hash(path.join(dest,'Projects',source.path)),source.sha256);}
save(path.join(dest,'.nyssaai/daily-tasks/profile.json'),first.context.profile);
save(path.join(dest,'Daily/2026-10-09.md'),read(path.join(vault,'Daily/2026-10-09.md')));
for(const name of packets){const p=json(evidence+'/'+name+'.json'),base=path.join(evidence,'snapshots/reconstructed-'+name);for(const plan of [p.previous,p.current]){if(!plan?.sha256)continue;let content;if(hash(plan.path)===plan.sha256)content=read(plan.path);else {const effects=cps.flatMap(c=>c.effects);const after=effects.find(e=>e.path===plan.path&&e.after===plan.sha256);const before=effects.find(e=>e.path===plan.path&&e.before===plan.sha256);content=after?.content??before?.beforeContent;if(content===undefined)throw Error('No exact saved bytes '+plan.path);}const out=path.join(base,'Daily',path.basename(plan.path));save(out,content);assert.equal(hash(out),plan.sha256);}for(const [key,state] of Object.entries(p.state))if(state.value)save(path.join(base,'.nyssaai/daily-tasks',key,p.context.localDate+'.json'),state.value);}
snapshot('actual-root-final');
const branches=json(evidence+'/branches.json');for(const [name,b]of Object.entries(branches))snapshot('actual-'+name+'-final',b.vaultRoot);
save(evidence+'/snapshot-repair.json',{problem:'Original snapshot exclusion tested the absolute path, which contains the authorized ancestor .temp, leaving empty snapshot directories.',repair:'Retained exact before/after checkpoint bytes and packet fingerprints were used to reconstruct plan snapshots and original canonical records, hash verified. Final snapshots now filter relative path segments. Original empty snapshot directories retained.'});
console.log('Original record and staged plan byte snapshots reconstructed and verified against original hashes.');
