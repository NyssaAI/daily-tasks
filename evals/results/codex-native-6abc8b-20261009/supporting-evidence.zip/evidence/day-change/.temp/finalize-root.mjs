import fs from 'node:fs';
import path from 'node:path';
import {cli,prepare,save,json,read,evidence,hash,newId,pkg,snapshot} from './session.mjs';
const p=prepare('2026-10-09T16:00:00Z'),c=p.context;
const records=cli('inspect-records',{projectsRoot:c.projectsRoot}).records;
const validation=cli('validate-records',{records}),links=cli('check-links',{records});
if(validation.diagnostics.length||links.diagnostics.length)throw Error('Final integrity diagnostics');
const baselinePath=path.join(c.stateRoot,'reconciliation.json'),b=json(baselinePath);
for(const r of records){const canonical={state:r.state,owner:r.owner,assignee:r.assignee??null,started_at:r.started_at??null,resolved_at:r.resolved_at??null,criteria:r.criteria.map(x=>({id:x.id,checked:x.checked}))};b.records[r.id]={canonical,sha256:hash(r.path),path:r.path};}
save(baselinePath,b);
const note=path.join(c.dailyPlansRoot,'2026-10-09.md');
const candidate={id:newId(),sourceKey:'Daily/2026-10-09.md:Maybe improve my resume',sourcePath:note,sourceHash:hash(note),title:'Maybe improve my resume',disposition:'unresolved',matchingTaskId:records.find(r=>r.title==='Update resume').id,reason:'Ambiguous manual checkbox may refer to accepted Update resume; no new record or selection authorized.'};
save(path.join(c.stateRoot,'candidates.json'),{schemaVersion:1,candidates:[candidate]});
save(path.join(c.stateRoot,'checkin.json'),{schemaVersion:1,planningBinding:c.planningBinding,localDate:c.localDate,pendingOperationIds:[],unresolvedCandidateIds:[candidate.id],unresolvedConflictIds:[],processedSourceVersions:[...p.inventory.sources,{path:note,sha256:hash(note)}],nextStep:'Existing manual note retained for clarification; Friday plan and rollover verified. No implicit task acceptance.',rolloverVerified:true,fullyReconciled:false});
const loaded=['daily-tasks/SKILL.md','daily-tasks-plan/SKILL.md','daily-tasks-checkin/SKILL.md','daily-tasks-records/SKILL.md','daily-tasks-setup/SKILL.md','daily-tasks-capture/SKILL.md','daily-tasks/references/planning-flow.md','daily-tasks/references/operations.md','daily-tasks/references/records.md','daily-tasks/references/cli.md','daily-tasks/references/response-conventions.md','daily-tasks/assets/daily-plan.md','daily-tasks/assets/task.md','daily-tasks/assets/plan-day-select-tasks-screen.md'];
save(evidence+'/installed-instructions.json',{packageRoot:pkg,hostVersion:null,hostModel:null,hostEvidence:'Installed skills exposed in current native-host catalog and loaded from their installed paths; current file-tool/CLI workflow; no packaging or regression suite used.',nodeVersion:process.version,loaded:loaded.map(relative=>({path:path.join(pkg,'skills',relative),sha256:hash(path.join(pkg,'skills',relative))})),maintenanceInvocation:{tool:'collaboration.spawn_agent',task:'/root/maintenance',modelRequested:'gpt-6-luna',fork_turns:'none',reportedModelIdentity:null},clocks:{monday:'2026-10-05T16:00:00Z',tuesday:'2026-10-06T16:00:00Z',friday:'2026-10-09T16:00:00Z'},timezone:c.timezone});
save(evidence+'/friday-final-packet.json',prepare('2026-10-09T16:00:00Z'));snapshot('root-final-with-checkin');
console.log('Final canonical validation/link checks passed; check-in retains one ambiguous manual candidate.');
