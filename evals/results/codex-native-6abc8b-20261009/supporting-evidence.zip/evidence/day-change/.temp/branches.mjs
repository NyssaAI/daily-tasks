import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {vault,evidence,save,json,read,cli,transaction,applyFiles,finish,snapshot,hash} from './session.mjs';
import {render,rollover,removeSelection,stateInput,review} from './plans.mjs';
const tasks=json(evidence+'/tasks.json');
export function branch(name){const v=path.join(evidence,name,'vault');fs.mkdirSync(v,{recursive:true});fs.cpSync(path.join(vault,'Projects'),path.join(v,'Projects'),{recursive:true,filter:p=>!p.includes(`${path.sep}.daily-tasks`)});save(path.join(v,'.nyssaai/daily-tasks/profile.json'),json(path.join(vault,'.nyssaai/daily-tasks/profile.json')));return {vaultRoot:v,profilePath:path.join(v,'.nyssaai/daily-tasks/profile.json')};}
export function prep(b,now){return cli('planning-prepare',{...b,now},path.basename(path.dirname(b.vaultRoot))+'-prepare');}
export function seedPlans(b,dates){let monday=prep(b,'2026-10-05T16:00:00Z');const files=[];for(const [date,ids] of dates){const packet={...monday,context:{...monday.context,localDate:date},current:{path:path.join(monday.context.dailyPlansRoot,date+'-daily-plan.md')}};files.push({path:packet.current.path,content:render(packet,ids)});}const tx=transaction(monday.context,'plan.fixture-selected',[...new Set(dates.flatMap(x=>x[1]))],files,'User-authorized independent synthetic manual views; preserve original accepted task IDs.',monday.context.now);applyFiles(tx.cp);finish(tx);return monday;}
const tuesday=branch('tuesday');
seedPlans(tuesday,[['2026.10.05',[tasks.A.id]],['2026.10.06',[tasks.B.id]]]);
snapshot('tuesday-before',tuesday.vaultRoot);
let p=prep(tuesday,'2026-10-06T16:00:00Z');save(evidence+'/tuesday-before-packet.json',p);assert.equal(p.current.rows.length,1);assert.equal(p.current.rows[0].id,tasks.B.id);const id=p.current.id,created=cli('parse-record',{markdown:read(p.current.path)}).created_at;
rollover(p);p=prep(tuesday,'2026-10-06T16:00:00Z');assert.equal(p.current.id,id);assert.equal(cli('parse-record',{markdown:read(p.current.path)}).created_at,created);assert.deepEqual(new Set(p.current.rows.map(r=>r.id)),new Set([tasks.A.id,tasks.B.id]));
const afterHash=p.current.sha256;rollover(p);p=prep(tuesday,'2026-10-06T16:00:00Z');assert.equal(p.current.sha256,afterHash);save(evidence+'/tuesday-carried-packet.json',p);review(p,'tuesday-carried');snapshot('tuesday-carried',tuesday.vaultRoot);
p=prep(tuesday,'2026-10-06T16:00:00Z');removeSelection(p,[tasks.A.id],'User explicitly removes A from Tuesday; repeat must retain removal.');p=prep(tuesday,'2026-10-06T16:00:00Z');const removedHash=p.current.sha256,receipt=p.state.rollover.value;rollover(p);p=prep(tuesday,'2026-10-06T16:00:00Z');assert.equal(p.current.sha256,removedHash);assert.deepEqual(p.current.rows.map(r=>r.id),[tasks.B.id]);assert.ok(p.state.rollover.value.removedIds.includes(tasks.A.id));assert.equal(p.state.rollover.value.operationId,receipt.operationId);review(p,'tuesday-removed');save(evidence+'/tuesday-final-packet.json',prep(tuesday,'2026-10-06T16:00:00Z'));snapshot('tuesday-final',tuesday.vaultRoot);
const future=branch('future-removal');
seedPlans(future,[['2026.10.05',[tasks.A.id]],['2026.10.09',[tasks.A.id,tasks.B.id]]]);
// Tuesday is the recording day: Monday is historical, Friday is future.
// No Tuesday plan is created for this explicit future selection operation.
p=prep(future,'2026-10-06T16:00:00Z');save(evidence+'/future-before-packet.json',p);snapshot('future-before',future.vaultRoot);
removeSelection(p,[tasks.A.id],'User explicitly removes A from future Friday 2026.10.09, America/Chicago.','2026.10.09');
p=prep(future,'2026-10-06T16:00:00Z');save(evidence+'/future-after-removal-packet.json',p);
p=prep(future,'2026-10-09T16:00:00Z');save(evidence+'/future-friday-proposal.json',p);assert.deepEqual(p.rollover.selected.map(r=>r.id),[tasks.B.id]);assert.ok(p.state.rollover.value.removedIds.includes(tasks.A.id));assert.equal(p.state.rollover.value.completedAt,undefined);cli('planning-state',stateInput(p,'complete-rollover'),'future-no-change-rollover');p=prep(future,'2026-10-09T16:00:00Z');assert.deepEqual(p.current.rows.map(r=>r.id),[tasks.B.id]);assert.ok(p.state.rollover.value.removedIds.includes(tasks.A.id));assert.equal(p.rollover.status,'complete');review(p,'future-friday');save(evidence+'/future-final-packet.json',prep(future,'2026-10-09T16:00:00Z'));snapshot('future-final',future.vaultRoot);
save(evidence+'/branches.json',{tuesday,future});console.log('Tuesday merge/repeat/removal and future Friday removal verified.');
