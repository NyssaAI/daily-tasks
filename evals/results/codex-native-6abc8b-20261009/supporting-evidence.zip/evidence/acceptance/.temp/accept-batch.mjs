import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), out=path.join(root,'.temp','accepted-batch');
fs.mkdirSync(out,{recursive:true});
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const save=(name,data)=>fs.writeFileSync(path.join(out,name),JSON.stringify(data,null,2)+'\n');
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
let seq=0;
function call(operation,input){
 const name=String(++seq).padStart(2,'0')+'-'+operation;
 const args=[cli,operation];
 if(input!==undefined){const file=path.join(out,name+'.input.json');save(name+'.input.json',input);args.push('--input',file);}
 const r=spawnSync(process.execPath,args,{encoding:'utf8'});
 save(name+'.result.json',{command:process.execPath,args,exitCode:r.status,stdout:r.stdout,stderr:r.stderr});
 if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);
}
const c=call('resolve-context',{vaultRoot:path.join(root,'vault')});
const beforeRecords=call('inspect-records',{projectsRoot:c.projectsRoot});
const beforeLog=call('log-query',{projectsRoot:c.projectsRoot,limit:1000});
save('records.before.json',beforeRecords);save('log.before.json',beforeLog);
if(beforeRecords.records.length!==0)throw Error('Unexpected accepted records: review needed');
const note=path.join(c.dailyPlansRoot,'2026-10-09.md'),noteBefore=fs.readFileSync(note);
fs.writeFileSync(path.join(out,'manual-plan.before.md'),noteBefore);
const stateFiles=['candidates.json','checkin.json','reconciliation.json'];
const stateBefore={};
for(const name of stateFiles){const file=path.join(c.stateRoot,name);stateBefore[name]=fs.existsSync(file)?{present:true,content:fs.readFileSync(file,'utf8')}:{present:false};}
save('state.before.json',stateBefore);
const ids={};
for(const name of ['project','milestone','linkedin','resume','milestoneCriterion','linkedinCriterion','resumeCriterion','event','operation'])ids[name]=call('new-id').id;
save('ids.json',ids);
const timing=call('activity-time',{}),stamp=timing.recorded_at;
const owner='synthetic@example.test';
if(c.profile.user.email!==owner)throw Error('Owner mismatch');
const projectDir=path.join(c.projectsRoot,'job-search');
const milestoneDir=path.join(projectDir,'m1-career-materials');
const milestoneStem='m1-career-materials';
const front=(id,type,title,extras)=>`---\nid: ${id}\ntype: ${type}\nrecord_version: 2\ntitle: ${JSON.stringify(title)}\n${type}-state: not-started\nowner: "${owner}"\n${extras}created_at: "${stamp}"\nupdated_at: "${stamp}"\n---\n`;
const project=front(ids.project,'project','Job Search','')+`# Job Search\n\nPrepare career materials for the job search.\n\n## Project Summary\n\n| Milestone | Task | Description | Owner | Due Date |\n| --- | --- | --- | --- | --- |\n| [ ] [[m1-career-materials/m1-career-materials\\|Career materials]] <!-- ref: ${ids.milestone} --> | | Both reviewed artifacts linked. | ${owner} | — |\n| | [ ] [[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]] <!-- ref: ${ids.linkedin} --> | Update headline. | ${owner} | — |\n| | [ ] [[m1-career-materials/t2-update-resume\\|Update resume]] <!-- ref: ${ids.resume} --> | Update summary. | ${owner} | — |\n`;
const milestone=front(ids.milestone,'milestone','Career materials',`project_id: "${ids.project}"\n`)+`# M1 — Career materials\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${ids.project} -->\n\n## Outcome\n\nUpdate the LinkedIn headline and resume summary.\n\n## Definition of Done\n\n- [ ] Both reviewed artifacts linked. <!-- id: ${ids.milestoneCriterion} -->\n\n## Tasks\n\n- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${ids.linkedin} -->\n- [ ] [[t2-update-resume|Update resume]] <!-- ref: ${ids.resume} -->\n`;
function task(id,title,number,requirement,criterion,criterionId){return front(id,'task',title,`project_id: "${ids.project}"\nmilestone_id: "${ids.milestone}"\n`)+`# M1-T${number} — ${title}\n\n**Milestone:** [[${milestoneStem}|Career materials]] <!-- ref: ${ids.milestone} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${ids.project} -->\n\n## Requirements\n\n${requirement}\n\n## Definition of Done\n\n- [ ] ${criterion} <!-- id: ${criterionId} -->\n\n## Inputs\n\nWorking inputs belong in [inputs/](inputs/). No input artifact supplied yet.\n\n## Output and delivery\n\nLink the reviewed artifact from this task and the milestone when available. Local artifacts belong directly in [outputs/](outputs/).\n\n## Verification\n\nRecord the owner's review of the ${number===1?'headline':'summary'} before checking the criterion.\n`}
const files=[{path:path.join(projectDir,'project-index.md'),content:project},{path:path.join(milestoneDir,milestoneStem+'.md'),content:milestone},{path:path.join(milestoneDir,'t1-update-linkedin.md'),content:task(ids.linkedin,'Update LinkedIn',1,'Update headline.','Reviewed headline.',ids.linkedinCriterion)},{path:path.join(milestoneDir,'t2-update-resume.md'),content:task(ids.resume,'Update resume',2,'Update summary.','Reviewed summary.',ids.resumeCriterion)}];
save('records.proposed.json',files);
const proposed=files.map(f=>call('parse-record',{markdown:f.content,path:f.path}));
save('parsed.proposed.json',proposed);
const proposedValidation=call('validate-records',{records:proposed});
const proposedLinks=call('check-links',{records:proposed});
save('validation.proposed.json',proposedValidation);save('links.proposed.json',proposedLinks);
function clean(result){if(result.valid===false||result.errors?.length||result.diagnostics?.length)throw Error('Validation requires resolution: '+JSON.stringify(result));}
clean(proposedValidation);clean(proposedLinks);
const words='I explicitly accept this batch: create Job Search project, M1 Career materials milestone, Update LinkedIn task (requirement: update headline; DoD: reviewed headline), and Update resume task (requirement: update summary; DoD: reviewed summary). Milestone DoD: both reviewed artifacts linked. Owner synthetic@example.test; all accepted work not started and unchecked. Accept no other work. Preserve the existing manually added checkbox.';
const entry={id:ids.event,operation_id:ids.operation,action:'records.accepted',record_ids:[ids.project,ids.milestone,ids.linkedin,ids.resume],actor:{kind:'person',id:owner},...timing,original_words:words,before:{acceptedRecords:[]},after:{acceptedRecords:proposed,acceptanceSource:'Current explicit user batch acceptance',states:'not-started',criteriaChecked:false}};
if(entry.activity_at!==timing.activity_at||entry.recorded_at!==timing.recorded_at)throw Error('Timestamp mismatch');
const checkpoint={schema_version:1,operation_id:ids.operation,planningBinding:c.planningBinding,vaultRoot:c.vaultRoot,projectsRoot:c.projectsRoot,dailyPlansRoot:c.dailyPlansRoot,stateRoot:c.stateRoot,event:entry,status:'pending',files:files.map(f=>({path:f.path,before:{present:false},after:{present:true,sha256:hash(f.content),content:f.content}})),changes:proposed.map(r=>({key:r.id,before:{present:false},after:{present:true,value:r}}))};
const operationDir=path.join(c.stateRoot,'operations');fs.mkdirSync(operationDir,{recursive:true});
const checkpointPath=path.join(operationDir,ids.operation+'.json');
for(const f of files)if(fs.existsSync(f.path))throw Error('Destination already exists: '+f.path);
fs.writeFileSync(checkpointPath,JSON.stringify(checkpoint,null,2)+'\n');save('operation.pending.json',checkpoint);
fs.mkdirSync(path.join(milestoneDir,'inputs'),{recursive:true});fs.mkdirSync(path.join(milestoneDir,'outputs'),{recursive:true});
for(const f of files){if(fs.existsSync(f.path))throw Error('Destination changed');fs.writeFileSync(f.path,f.content);}
call('invalidate-project-index',{vaultRoot:c.vaultRoot});
const actual=call('inspect-records',{projectsRoot:c.projectsRoot});
save('records.after.json',actual);
const validation=call('validate-records',{records:actual.records});
const links=call('check-links',{records:actual.records});clean(validation);clean(links);clean(actual);
if(actual.records.length!==4)throw Error('Wrong accepted count');
for(const r of actual.records){if(r.owner!==owner||r.state!=='not-started'||r.started_at||r.resolved_at||r.criteria.some(x=>x.checked)||r.projections.some(x=>x.checked))throw Error('State mismatch');}
const append=call('log-append',{projectsRoot:c.projectsRoot,entry});save('log.append.json',append);
const afterLog=call('log-query',{projectsRoot:c.projectsRoot,limit:1000});save('log.after.json',afterLog);
const recorded=afterLog.entries.find(e=>e.operation_id===ids.operation);
const stable=v=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
if(stable(recorded)!==stable(entry))throw Error('Logged event payload mismatch');
for(const id of entry.record_ids)call('log-query',{projectsRoot:c.projectsRoot,recordId:id,limit:1000});
if(afterLog.total!==beforeLog.total+1||beforeLog.entries.some(e=>e.record_ids.length))throw Error('Acceptance history mismatch');
const queuePath=path.join(c.stateRoot,'candidates.json');
const queue=JSON.parse(stateBefore['candidates.json'].content);
for(const item of queue.candidates){let recordId;if(item.title==='Update LinkedIn')recordId=ids.linkedin;else if(item.title==='Update resume')recordId=ids.resume;else continue;item.accepted=true;item.status='accepted';item.recordId=recordId;item.parentProject=ids.project;item.parentMilestone=ids.milestone;item.acceptance={source:'Current explicit user batch acceptance',operation_id:ids.operation,recorded_at:stamp};}
fs.writeFileSync(queuePath,JSON.stringify(queue,null,2)+'\n');
const progress=JSON.parse(stateBefore['checkin.json'].content);progress.unresolvedCandidateIds=queue.candidates.filter(x=>x.status==='unresolved').map(x=>x.id);progress.nextStep='Accepted batch created; manual daily note preserved. No daily selection requested.';progress.status='accepted-batch-saved';
fs.writeFileSync(path.join(c.stateRoot,'checkin.json'),JSON.stringify(progress,null,2)+'\n');
const baseline={schema_version:1,planningBinding:c.planningBinding,records:{}};
for(const r of actual.records){const f=files.find(f=>f.path===r.path);baseline.records[r.id]={canonical:{path:r.path,sha256:hash(f.content),fields:r},views:{}};for(const view of actual.records){const projection=view.projections?.find(p=>p.id===r.id);if(projection)baseline.records[r.id].views[view.path]={fields:projection,sha256:hash(files.find(f=>f.path===view.path).content)};}}
fs.writeFileSync(path.join(c.stateRoot,'reconciliation.json'),JSON.stringify(baseline,null,2)+'\n');
for(const f of files){const content=fs.readFileSync(f.path,'utf8');if(content!==f.content)throw Error('Record changed');fs.writeFileSync(path.join(out,path.basename(f.path)+'.after.md'),content);}
const noteAfter=fs.readFileSync(note);fs.writeFileSync(path.join(out,'manual-plan.after.md'),noteAfter);if(!noteBefore.equals(noteAfter))throw Error('Manual plan changed');
for(const name of stateFiles)save(name+'.after.json',JSON.parse(fs.readFileSync(path.join(c.stateRoot,name),'utf8')));
checkpoint.status='complete';save('operation.complete.json',checkpoint);fs.unlinkSync(checkpointPath);
const proof={acceptedBefore:beforeRecords.records.length,acceptedAfter:actual.records.length,newAcceptanceEvents:afterLog.total-beforeLog.total,exactEventPayloadVerified:true,manualPlanByteIdentical:true,owner,allStatesNotStarted:true,allCriteriaAndProjectionsUnchecked:true,validation,links,relationships:{project:ids.project,milestone:{id:ids.milestone,project_id:ids.project},tasks:[ids.linkedin,ids.resume].map(id=>({id,project_id:ids.project,milestone_id:ids.milestone}))},uniqueRecordAndCriterionIds:new Set(Object.values(ids).slice(0,7)).size===7,pendingOperationRemoved:true};
save('proof.json',proof);
save('actions.json',['Resolved existing vault configuration','Queried records and decision log before acceptance','Generated fresh UUIDv7 record, criterion and operation identities with installed CLI','Authored exactly four records from installed templates','Validated proposed metadata and links','Saved pending operation before Markdown writes','Created records with unchecked criteria and projections, flat inputs and outputs','Invalidated inventory cache','Validated actual records and links','Appended explicit current batch acceptance','Queried log and verified exact event payload and each record history','Resolved only the two candidate dispositions','Saved reconciliation baselines','Verified manual note bytes and removed completed checkpoint']);
console.log(JSON.stringify(proof,null,2));
