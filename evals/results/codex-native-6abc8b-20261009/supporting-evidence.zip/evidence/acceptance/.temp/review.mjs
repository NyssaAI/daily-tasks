import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), evidence=path.join(root,'.temp');
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const vault=path.join(root,'vault'), note=path.join(vault,'Daily','2026-10-09.md');
const save=(name,data)=>fs.writeFileSync(path.join(evidence,name),JSON.stringify(data,null,2)+'\n');
function call(name,operation,input){
 const file=path.join(evidence,name+'.input.json'); save(name+'.input.json',input);
 const result=spawnSync(process.execPath,[cli,operation,'--input',file],{encoding:'utf8'});
 save(name+'.result.json',{operation,inputFile:file,exitCode:result.status,stdout:result.stdout,stderr:result.stderr});
 if(result.status!==0)throw Error(result.stderr);return JSON.parse(result.stdout);
}
const before=fs.readFileSync(note);
fs.writeFileSync(path.join(evidence,'manual-plan.before.md'),before);
const context=call('context','resolve-context',{vaultRoot:vault});
save('resolved-context.json',context);
const recordsBefore=call('records-before','inspect-records',{projectsRoot:context.projectsRoot});
const logBefore=call('log-before','log-query',{projectsRoot:context.projectsRoot,limit:1000});
const rows=call('manual-checkbox','parse-checklist',{markdown:before.toString()});
save('parsed-checkboxes.json',rows);
const queuePath=path.join(context.stateRoot,'candidates.json');
save('state-before.json',{candidates:{present:fs.existsSync(queuePath)},checkin:{present:fs.existsSync(path.join(context.stateRoot,'checkin.json'))}});
if(fs.existsSync(queuePath))throw Error('Existing candidate queue needs review before writing');
const candidates=[
 {id:'candidate-linkedin',title:'Update LinkedIn',kind:'idea',status:'unresolved',accepted:false,owner:context.profile.user.email,parentProject:null,parentMilestone:null,sourceKeys:['request:acceptance:linkedin'],sources:[{key:'request:acceptance:linkedin',reference:'Current user request',text:'I might want to update LinkedIn and resume sometime.'}],unresolvedFacts:['Acceptance','Project and milestone','Scope and definition of done']},
 {id:'candidate-resume',title:'Update resume',kind:'idea',status:'unresolved',accepted:false,owner:context.profile.user.email,parentProject:null,parentMilestone:null,sourceKeys:['request:acceptance:resume','vault:Daily/2026-10-09.md:checkbox:maybe-improve-my-resume'],sources:[{key:'request:acceptance:resume',reference:'Current user request',text:'I might want to update LinkedIn and resume sometime.'},{key:'vault:Daily/2026-10-09.md:checkbox:maybe-improve-my-resume',reference:'Daily/2026-10-09.md:3',text:'Maybe improve my resume',sha256:crypto.createHash('sha256').update(before).digest('hex')}],unresolvedFacts:['Acceptance','Project and milestone','Scope and definition of done']}
];
const queue={schema_version:1,planningBinding:context.planningBinding,candidates};
fs.writeFileSync(queuePath,JSON.stringify(queue,null,2)+'\n');
const progress={schema_version:1,localDate:context.localDate,planningBinding:context.planningBinding,vaultRoot:context.vaultRoot,pendingOperationIds:[],unresolvedCandidateIds:candidates.map(c=>c.id),unresolvedConflictIds:[],processedSourceVersions:[{path:note,sha256:crypto.createHash('sha256').update(before).digest('hex')}],nextStep:'Await explicit candidate acceptance or disposition; do not create accepted work or alter manual plan.',status:'resumable'};
fs.writeFileSync(path.join(context.stateRoot,'checkin.json'),JSON.stringify(progress,null,2)+'\n');
save('candidates.after.json',JSON.parse(fs.readFileSync(queuePath,'utf8')));
save('checkin.after.json',JSON.parse(fs.readFileSync(path.join(context.stateRoot,'checkin.json'),'utf8')));
const recordsAfter=call('records-after','inspect-records',{projectsRoot:context.projectsRoot});
call('validate-after','validate-records',{records:recordsAfter.records});
call('links-after','check-links',{records:recordsAfter.records});
const logAfter=call('log-after','log-query',{projectsRoot:context.projectsRoot,limit:1000});
const after=fs.readFileSync(note);fs.writeFileSync(path.join(evidence,'manual-plan.after.md'),after);
const proof={acceptedRecordCountBefore:recordsBefore.records.length,acceptedRecordCountAfter:recordsAfter.records.length,manualPlanByteIdentical:before.equals(after),logUnchanged:JSON.stringify(logBefore)===JSON.stringify(logAfter),unresolvedCandidates:candidates.length,sourceMentions:3,actions:['Resolved existing vault-only profile','Inspected records and queried log via installed CLI','Parsed manual checkbox via installed CLI','Persisted two unaccepted candidates with three deduplicated source mentions','Saved resumable review state','Validated records and links and queried log after writes'],markdownWrites:0,logAppends:0};
save('proof.json',proof);
fs.writeFileSync(path.join(evidence,'review.md'),'Reviewed possible commitments: Update LinkedIn; Update resume. Resume has both request and manual checkbox provenance. No acceptance supplied. No projects, milestones or tasks created. Manual note preserved byte for byte. Candidate parents and definitions remain unresolved. No dates inferred from "sometime". Installed CLI inputs and outputs retained alongside before/after snapshots and proof.json.\n');
console.log(JSON.stringify(proof,null,2));
