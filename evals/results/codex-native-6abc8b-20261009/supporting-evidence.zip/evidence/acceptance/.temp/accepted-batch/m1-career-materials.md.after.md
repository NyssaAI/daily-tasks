---
id: 01a12161-6a34-7fbd-b395-13467dec03b5
type: milestone
record_version: 2
title: "Career materials"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12161-6a0d-70ba-ab4a-fae41231271d"
created_at: "2026-10-09T15:56:35.071Z"
updated_at: "2026-10-09T15:56:35.071Z"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12161-6a0d-70ba-ab4a-fae41231271d -->

## Outcome

Update the LinkedIn headline and resume summary.

## Definition of Done

- [ ] Both reviewed artifacts linked. <!-- id: 01a12161-6aae-7846-9b3e-4051297c6d2e -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a12161-6a5c-78e9-bba3-6dfefe34b68a -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a12161-6a86-7d64-bb07-e3c5743ac340 -->
