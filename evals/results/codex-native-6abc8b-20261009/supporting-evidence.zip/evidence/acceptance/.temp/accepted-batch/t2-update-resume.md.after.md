---
id: 01a12161-6a86-7d64-bb07-e3c5743ac340
type: task
record_version: 2
title: "Update resume"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12161-6a0d-70ba-ab4a-fae41231271d"
milestone_id: "01a12161-6a34-7fbd-b395-13467dec03b5"
created_at: "2026-10-09T15:56:35.071Z"
updated_at: "2026-10-09T15:56:35.071Z"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a12161-6a34-7fbd-b395-13467dec03b5 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12161-6a0d-70ba-ab4a-fae41231271d -->

## Requirements

Update summary.

## Definition of Done

- [ ] Reviewed summary. <!-- id: 01a12161-6b00-72fb-92d1-4f59054b160d -->

## Inputs

Working inputs belong in [inputs/](inputs/). No input artifact supplied yet.

## Output and delivery

Link the reviewed artifact from this task and the milestone when available. Local artifacts belong directly in [outputs/](outputs/).

## Verification

Record the owner's review of the summary before checking the criterion.
