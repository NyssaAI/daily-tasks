---
id: 01a12161-6a0d-70ba-ab4a-fae41231271d
type: project
record_version: 2
title: "Job Search"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T15:56:35.071Z"
updated_at: "2026-10-09T15:56:35.071Z"
---
# Job Search

Prepare career materials for the job search.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a12161-6a34-7fbd-b395-13467dec03b5 --> | | Both reviewed artifacts linked. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a12161-6a5c-78e9-bba3-6dfefe34b68a --> | Update headline. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a12161-6a86-7d64-bb07-e3c5743ac340 --> | Update summary. | synthetic@example.test | — |
