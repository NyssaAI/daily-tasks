---
id: 01a12161-6a5c-78e9-bba3-6dfefe34b68a
type: task
record_version: 2
title: "Update LinkedIn"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12161-6a0d-70ba-ab4a-fae41231271d"
milestone_id: "01a12161-6a34-7fbd-b395-13467dec03b5"
created_at: "2026-10-09T15:56:35.071Z"
updated_at: "2026-10-09T15:56:35.071Z"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a12161-6a34-7fbd-b395-13467dec03b5 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12161-6a0d-70ba-ab4a-fae41231271d -->

## Requirements

Update headline.

## Definition of Done

- [ ] Reviewed headline. <!-- id: 01a12161-6ad7-71e3-927b-ff9ff5d655ce -->

## Inputs

Working inputs belong in [inputs/](inputs/). No input artifact supplied yet.

## Output and delivery

Link the reviewed artifact from this task and the milestone when available. Local artifacts belong directly in [outputs/](outputs/).

## Verification

Record the owner's review of the headline before checking the criterion.
