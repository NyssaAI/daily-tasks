---
id: 01a12160-266a-7c0e-a409-50746f9daf57
type: milestone
record_version: 2
title: "Draft"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12160-2640-7146-bf9c-9079d90b0329"
created_at: "2026-10-09T15:55:12.113Z"
updated_at: "2026-10-09T15:55:12.113Z"
---
# M1 — Draft

**Project:** [[../project-index|Demo]] <!-- ref: 01a12160-2640-7146-bf9c-9079d90b0329 -->

## Outcome

Draft and review the note.

## Definition of Done

- [ ] Both task definitions of done are satisfied. <!-- id: 01a12160-26ec-7a5e-811a-d04ef8d1aaad -->

## Tasks

- [>] [[t1-draft-note|Draft note]] <!-- ref: 01a12160-2696-76d2-8901-c8921a2ce068 -->
- [ ] [[t2-review-note|Review note]] <!-- ref: 01a12160-26c1-7429-ae6c-e307d38ee200 -->
