---
id: 01a12160-2640-7146-bf9c-9079d90b0329
type: project
title: "Demo"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T15:55:12.113Z"
updated_at: "2026-10-09T15:55:12.113Z"
---
# Demo

Create and review the note.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-draft/m1-draft\|Draft]] <!-- ref: 01a12160-266a-7c0e-a409-50746f9daf57 --> | | Draft milestone. | Synthetic User | — |
| | [>] [[m1-draft/t1-draft-note\|Draft note]] <!-- ref: 01a12160-2696-76d2-8901-c8921a2ce068 --> | Write paragraph. | Synthetic User | — |
| | [ ] [[m1-draft/t2-review-note\|Review note]] <!-- ref: 01a12160-26c1-7429-ae6c-e307d38ee200 --> | Inspect paragraph. | Synthetic User | — |
