---
id: 01a12160-2696-76d2-8901-c8921a2ce068
type: task
record_version: 2
title: "Draft note"
task-state: in-progress
started_at: "2026-10-09T15:55:12.496Z"
owner: "synthetic@example.test"
project_id: "01a12160-2640-7146-bf9c-9079d90b0329"
milestone_id: "01a12160-266a-7c0e-a409-50746f9daf57"
created_at: "2026-10-09T15:55:12.113Z"
updated_at: "2026-10-09T15:55:12.496Z"
---
# M1-T1 — Draft note

**Milestone:** [[m1-draft|Draft]] <!-- ref: 01a12160-266a-7c0e-a409-50746f9daf57 -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a12160-2640-7146-bf9c-9079d90b0329 -->

## Requirements

Write a paragraph.

## Definition of Done

- [ ] Reviewed paragraph. <!-- id: 01a12160-2717-7656-b6d7-58aa8c66dfd3 -->

## Inputs

Local inputs: [inputs](inputs/).

## Output and delivery

Local output destination: [outputs](outputs/).

## Verification

Inspect the stated task criterion and record satisfaction only when explicitly confirmed.
