---
id: 01a12160-26c1-7429-ae6c-e307d38ee200
type: task
record_version: 2
title: "Review note"
task-state: not-started
owner: "synthetic@example.test"
assignee: "Editor"
project_id: "01a12160-2640-7146-bf9c-9079d90b0329"
milestone_id: "01a12160-266a-7c0e-a409-50746f9daf57"
created_at: "2026-10-09T15:55:12.113Z"
updated_at: "2026-10-09T15:55:12.851Z"
---
# M1-T2 — Review note

**Milestone:** [[m1-draft|Draft]] <!-- ref: 01a12160-266a-7c0e-a409-50746f9daf57 -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a12160-2640-7146-bf9c-9079d90b0329 -->

## Requirements

Inspect the paragraph.

## Definition of Done

- [ ] Recorded review. <!-- id: 01a12160-2742-75a5-8a8d-18bacc323c01 -->

## Inputs

Local inputs: [inputs](inputs/).

## Output and delivery

Local output destination: [outputs](outputs/).

## Verification

Inspect the stated task criterion and record satisfaction only when explicitly confirmed.
