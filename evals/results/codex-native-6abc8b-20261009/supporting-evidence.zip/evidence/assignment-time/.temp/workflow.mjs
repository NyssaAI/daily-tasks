import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';

const base=process.cwd(), evidence=path.join(base,'.temp');
const vault=path.join(base,'vault'), projects=path.join(vault,'1-projects');
const state=path.join(vault,'.nyssaai','daily-tasks');
const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';
const entry=path.join(bundle,'bin/daily-tasks.mjs');
let seq=Math.max(0,...fs.readdirSync(evidence).map(n=>Number(n.match(/^(\d+)-/)?.[1]||0)));
const save=(file,value)=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');};
const hash=s=>s===null?null:crypto.createHash('sha256').update(s).digest('hex');
function cli(op,input){
  const prefix=path.join(evidence,`${String(++seq).padStart(3,'0')}-${op}`);
  const args=[entry,op];
  if(input!==undefined){save(prefix+'.input.json',input);args.push('--input',prefix+'.input.json');}
  const r=spawnSync(process.execPath,args,{encoding:'utf8'});
  save(prefix+'.result.json',{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});
  if(r.status!==0)throw Error(r.stderr);
  const result=JSON.parse(r.stdout);save(prefix+'.output.json',result);return result;
}
const id=()=>cli('new-id').id;
const time=reported=>cli('activity-time',reported===undefined?{}:{reported});
const owner='synthetic@example.test';
const profile={schema_version:1,user:{name:'Synthetic User',email:owner},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./1-projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
if(!fs.existsSync(path.join(evidence,'before.json')))save(path.join(evidence,'before.json'),{vaultEntries:fs.readdirSync(vault),profile:null,records:[]});
save(path.join(evidence,'loaded-instructions.json'),{bundle,skills:['daily-tasks','daily-tasks-setup','daily-tasks-records'],references:['references/cli.md','references/operations.md','references/records.md','assets/project-index.md','assets/milestone.md','assets/task.md'].map(p=>path.join(bundle,'skills/daily-tasks',p)),readme:'D:/repos/NyssaAI/daily-tasks/evals/README.md',node:process.version,hostVersion:null,model:null});
const validation=cli('validate-profile',profile);if(!validation.valid)throw Error(JSON.stringify(validation));
const pendingDir=path.join(state,'operations');
const pendingSetup=fs.existsSync(pendingDir)?fs.readdirSync(pendingDir).map(n=>JSON.parse(fs.readFileSync(path.join(pendingDir,n),'utf8'))).find(c=>c.event.action==='profile.configured'):null;
const profileTime=pendingSetup?.event||time();
const setupEvent=pendingSetup?.event||{id:id(),operation_id:id(),action:'profile.configured',record_ids:[],actor:{kind:'person',id:owner},...profileTime,original_words:'configure this vault only for Synthetic User synthetic@example.test America/Chicago, empty priorities',before:null,after:profile};
// The setup checkpoint uses the explicitly authorized conventional vault scope.
const setupCheckpoint=path.join(state,'operations',setupEvent.operation_id+'.json');
if(!pendingSetup){save(setupCheckpoint,{status:'pending',event:setupEvent,paths:{vaultRoot:vault,projectsRoot:projects,stateRoot:state},changes:[{path:path.join(state,'profile.json'),beforeHash:null,afterHash:hash(JSON.stringify(profile,null,2)+'\n'),before:null,after:profile}]});save(path.join(state,'profile.json'),profile);}
const context=cli('resolve-context',{vaultRoot:vault,configRoot:state});
save(path.join(evidence,'context.json'),context);
function append(event){
  cli('log-append',{projectsRoot:projects,entry:event});
  const q=cli('log-query',{projectsRoot:projects});
  const entries=Array.isArray(q)?q:q.entries;
  const actual=entries?.find(e=>e.id===event.id);
  if(JSON.stringify(actual)!==JSON.stringify(event)){
    // Object property order is irrelevant; exact scalar values and fields are not.
    const stable=x=>JSON.stringify(x,(k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b))):v);
    if(stable(actual)!==stable(event))throw Error('Log payload mismatch '+JSON.stringify(q));
  }
}
fs.mkdirSync(projects,{recursive:true});
append(setupEvent);save(path.join(evidence,'setup.completed.json'),{event:setupEvent,status:'complete',recovered:!!pendingSetup});fs.unlinkSync(setupCheckpoint);
const ids={project:id(),milestone:id(),draft:id(),review:id(),milestoneCriterion:id(),draftCriterion:id(),reviewCriterion:id()};
save(path.join(evidence,'ids.json'),ids);
const dir=path.join(projects,'demo','m1-draft');
const files={project:path.join(projects,'demo','project-index.md'),milestone:path.join(dir,'m1-draft.md'),draft:path.join(dir,'t1-draft-note.md'),review:path.join(dir,'t2-review-note.md')};
const created=time();
function meta(type,title,identity,extra,t){return `---\nid: ${identity}\ntype: ${type}\n${type==='project'?'':'record_version: 2\n'}title: "${title}"\n${type}-state: not-started\nowner: "${owner}"\n${extra}created_at: "${t.activity_at}"\nupdated_at: "${t.recorded_at}"\n---\n`;}
const project=meta('project','Demo',ids.project,'',created)+`# Demo\n\nCreate and review the note.\n\n## Project Summary\n\n| Milestone | Task | Description | Owner | Due Date |\n| --- | --- | --- | --- | --- |\n| [ ] [[m1-draft/m1-draft\\|Draft]] <!-- ref: ${ids.milestone} --> | | Draft milestone. | Synthetic User | — |\n| | [ ] [[m1-draft/t1-draft-note\\|Draft note]] <!-- ref: ${ids.draft} --> | Write paragraph. | Synthetic User | — |\n| | [ ] [[m1-draft/t2-review-note\\|Review note]] <!-- ref: ${ids.review} --> | Inspect paragraph. | Synthetic User | — |\n`;
const milestone=meta('milestone','Draft',ids.milestone,`project_id: "${ids.project}"\n`,created)+`# M1 — Draft\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${ids.project} -->\n\n## Outcome\n\nDraft and review the note.\n\n## Definition of Done\n\n- [ ] Both task definitions of done are satisfied. <!-- id: ${ids.milestoneCriterion} -->\n\n## Tasks\n\n- [ ] [[t1-draft-note|Draft note]] <!-- ref: ${ids.draft} -->\n- [ ] [[t2-review-note|Review note]] <!-- ref: ${ids.review} -->\n`;
function task(title,key,number,requirement,dod,assignee){return meta('task',title,ids[key],`${assignee?`assignee: "${assignee}"\n`:''}project_id: "${ids.project}"\nmilestone_id: "${ids.milestone}"\n`,created)+`# M1-T${number} — ${title}\n\n**Milestone:** [[m1-draft|Draft]] <!-- ref: ${ids.milestone} -->\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${ids.project} -->\n\n## Requirements\n\n${requirement}\n\n## Definition of Done\n\n- [ ] ${dod} <!-- id: ${ids[key+'Criterion']} -->\n\n## Inputs\n\nLocal inputs: [inputs](inputs/).\n\n## Output and delivery\n\nLocal output destination: [outputs](outputs/).\n\n## Verification\n\nInspect the stated task criterion and record satisfaction only when explicitly confirmed.\n`;}
function inspect(label){const r=cli('inspect-records',{projectsRoot:projects});save(path.join(evidence,label+'.records.json'),r);return r;}
function transact(label,changes,event,fields){
  const cp=path.join(state,'operations',event.operation_id+'.json');
  const effects=Object.entries(changes).map(([file,after])=>{const before=fs.existsSync(file)?fs.readFileSync(file,'utf8'):null;return {path:file,before,after,beforeHash:hash(before),afterHash:hash(after)};});
  const checkpoint={status:'pending',operation_id:event.operation_id,planningBinding:context.planningBinding,event,fields,effects};
  save(cp,checkpoint);save(path.join(evidence,label+'.before-after.json'),checkpoint);
  for(const e of effects){const actual=fs.existsSync(e.path)?fs.readFileSync(e.path,'utf8'):null;if(hash(actual)!==e.beforeHash)throw Error('Concurrent change');save(e.path,e.after);}
  cli('invalidate-project-index',{vaultRoot:vault});
  const inspected=inspect(label);
  if(inspected.diagnostics?.length)throw Error(JSON.stringify(inspected.diagnostics));
  const links=cli('check-links',{records:inspected.records});
  save(path.join(evidence,label+'.links.json'),links);
  if(links.diagnostics?.length)throw Error(JSON.stringify(links));
  append(event);
  const baselines={};
  for(const [name,file] of Object.entries(files)){const text=fs.readFileSync(file,'utf8');const record=inspected.records.find(r=>r.id===ids[name]);baselines[ids[name]]={canonical:record,views:{},fingerprint:{path:file,sha256:hash(text)}};}
  save(path.join(state,'reconciliation.json'),{schema_version:1,records:baselines});
  for(const e of effects)if(hash(fs.readFileSync(e.path,'utf8'))!==e.afterHash)throw Error('Postwrite mismatch');
  save(path.join(evidence,label+'.completed.json'),{...checkpoint,status:'complete'});fs.unlinkSync(cp);
}
const createEvent={id:id(),operation_id:id(),action:'records.accepted',record_ids:[ids.project,ids.milestone,ids.draft,ids.review],actor:{kind:'person',id:owner},...created,original_words:'Explicitly create project Demo, M1 Draft, Draft note (requirement paragraph; DoD reviewed paragraph) and Review note (requirement inspect paragraph; DoD recorded review), milestone DoD both satisfied. Omit assignee for Draft note; assign Review note to Reviewer without starting it.',before:null,after:{owner,review_assignee:'Reviewer',states:'not-started'}};
fs.mkdirSync(path.join(dir,'inputs'),{recursive:true});fs.mkdirSync(path.join(dir,'outputs'),{recursive:true});
transact('create',{[files.draft]:task('Draft note','draft',1,'Write a paragraph.','Reviewed paragraph.'),[files.review]:task('Review note','review',2,'Inspect the paragraph.','Recorded review.','Reviewer'),[files.milestone]:milestone,[files.project]:project},createEvent,{acceptance:'direct named user instruction'});
const started=time('earlier this morning');save(path.join(evidence,'start-exact-time.json'),started);
if(!started.time_defaulted)throw Error('Expected vague start fallback');
const startEvent={id:id(),operation_id:id(),action:'task.started',record_ids:[ids.draft],actor:{kind:'person',id:owner},...started,original_words:'earlier this morning',before:{'task-state':'not-started'},after:{'task-state':'in-progress',started_at:started.activity_at}};
let draft=fs.readFileSync(files.draft,'utf8').replace('task-state: not-started',`task-state: in-progress\nstarted_at: "${started.activity_at}"`).replace(`updated_at: "${created.recorded_at}"`,`updated_at: "${started.recorded_at}"`);
let m=fs.readFileSync(files.milestone,'utf8').replace('- [ ] [[t1-draft-note','- [>] [[t1-draft-note');
let p=fs.readFileSync(files.project,'utf8').replace('| | [ ] [[m1-draft/t1-draft-note','| | [>] [[m1-draft/t1-draft-note');
transact('start',{[files.draft]:draft,[files.milestone]:m,[files.project]:p},startEvent,{started_at:{before:{present:false},after:{present:true,value:started.activity_at}}});
const assigned=time();
const assignEvent={id:id(),operation_id:id(),action:'task.reassigned',record_ids:[ids.review],actor:{kind:'agent',id:'Codex'},...assigned,original_words:'Acting as agent reassign Review note to Editor; human ownership cannot change autonomously.',before:{owner,assignee:'Reviewer','task-state':'not-started'},after:{owner,assignee:'Editor','task-state':'not-started'},};
const review=fs.readFileSync(files.review,'utf8').replace('assignee: "Reviewer"','assignee: "Editor"').replace(`updated_at: "${created.recorded_at}"`,`updated_at: "${assigned.recorded_at}"`);
transact('reassign',{[files.review]:review},assignEvent,{owner:{before:owner,after:owner},assignee:{before:'Reviewer',after:'Editor'}});
const final=inspect('final');
const log=cli('log-query',{projectsRoot:projects});
const startLog=cli('log-query',{projectsRoot:projects,recordId:ids.draft,action:'task.started'});
const assignLog=cli('log-query',{projectsRoot:projects,recordId:ids.review,action:'task.reassigned'});
const display=cli('format-time',{time:started.activity_at,timezone:context.timezone});
save(path.join(evidence,'local-display.json'),display);
save(path.join(evidence,'after.json'),{profile,files:Object.fromEntries(Object.entries(files).map(([k,f])=>[k,{path:f,content:fs.readFileSync(f,'utf8')}])),records:final,log,startLog,assignLog,display});
console.log(JSON.stringify({ids,context,final,display,log},null,2));
