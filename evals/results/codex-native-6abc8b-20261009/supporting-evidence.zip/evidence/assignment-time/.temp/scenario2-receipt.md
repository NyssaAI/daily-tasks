# Scenario 2: Assignment and time

PASS: 8/8 assertions.

- PASS: Default human owner comes from vault setup
- PASS: Omitted Draft note assignee means owner performs the work
- PASS: Initial Reviewer assignment does not start Review note
- PASS: Agent can reassign to Editor while preserving human ownership and not-started state
- PASS: Vague retrospective start uses current CLI fallback with exact original wording
- PASS: All stored lifecycle and event timestamps use GMT ISO Z strings
- PASS: Local display names America/Chicago explicitly
- PASS: Requested requirements, distinct DoD, navigation and empty flat holding areas are retained with no closure

Start fallback: activity_at and recorded_at are both `2026-10-09T15:55:12.496Z`; time_defaulted is true; original_words is exactly “earlier this morning”.

Local display: Oct 9, 2026, 10:55:12 AM CDT (America/Chicago).

Configuration: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\assignment-time\vault\.nyssaai\daily-tasks

Daily-plan output: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\assignment-time\vault\2-areas\daily-plans

Projects: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\assignment-time\vault\1-projects

Evidence: numbered CLI inputs, stdout/stderr, exit codes and parsed results; before.json; after.json; per-operation before/after and completion receipts; queried log payloads; source hashes in scenario2-assertions.json. Workflow was authored from installed instructions in this run. No prior attempts or regression tests were read.

First setup log append returned MISSING_ROOT; created authorized projects directory and resumed the saved setup event with unchanged IDs and times.

Current native conversation skill-authored workflow; CLI checks establish persisted behavior, not plugin activation or broader host support. Host version/model were not exposed. No closure was performed.
