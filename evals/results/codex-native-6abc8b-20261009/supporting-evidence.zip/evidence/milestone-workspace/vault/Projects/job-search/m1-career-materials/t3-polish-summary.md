---
id: "01a12160-071b-7263-b503-3447fc03e004"
type: task
record_version: 2
title: "Polish summary"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
created_at: "2026-10-09T15:55:03.919Z"
updated_at: "2026-10-09T15:55:03.919Z"
task-state: not-started
---
# M1-T3 — Polish summary

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Polish summary.

## Definition of Done

- [ ] User reviewed polished summary. <!-- id: 01a12160-0745-7e83-9dbc-47a20178d143 -->

## Inputs

- [Summary draft](outputs/resume-summary-draft.md)

## Output and delivery

Save a polished summary locally in outputs/ when executed.

## Result

Accepted; not started.
