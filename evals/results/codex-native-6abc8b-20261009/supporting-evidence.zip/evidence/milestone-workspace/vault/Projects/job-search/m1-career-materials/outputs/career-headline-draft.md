# LinkedIn headline draft

Career professional preparing for the next opportunity

Draft for user review. Supplied source contains no career facts.
