# Resume summary draft

Career professional preparing for the next opportunity, with career materials being refined for a focused job search.

Draft for user review. Uses the LinkedIn headline draft; supplied source contains no verified experience details.
