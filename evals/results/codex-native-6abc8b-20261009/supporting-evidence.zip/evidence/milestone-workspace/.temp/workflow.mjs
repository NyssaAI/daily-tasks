import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';
const vault=path.join(root,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'job-search'), milestone=path.join(project,'m1-career-materials');
let seq=0;
const save=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2));};
function cli(op,input){const stem=path.join(scratch,`${String(++seq).padStart(3,'0')}-${op}`);const args=[path.join(pkg,'bin/daily-tasks.mjs'),op];if(input!==undefined){save(stem+'.input.json',input);args.push('--input',stem+'.input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(stem+'.result.json',{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const id=()=>{const r=cli('new-id');return typeof r==='string'?r:r.id;};
const hash=v=>v===null?null:crypto.createHash('sha256').update(v).digest('hex');
const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
const ctx=cli('resolve-context',{vaultRoot:vault});save(path.join(scratch,'context.json'),ctx);
const state=ctx.stateRoot;
const before=cli('inspect-records',{projectsRoot:projects});save(path.join(scratch,'before-inspection.json'),before);
cli('log-query',{projectsRoot:projects});
const files=['project-index.md','m1-career-materials/m1-career-materials.md','m1-career-materials/t1-update-linkedin.md','m1-career-materials/t2-update-resume.md'];
save(path.join(scratch,'before.json'),Object.fromEntries(files.map(f=>[f,read(path.join(project,f))])));
save(path.join(scratch,'initial-layout.json'),{milestone:fs.readdirSync(milestone),inputs:fs.readdirSync(path.join(milestone,'inputs')),outputs:fs.readdirSync(path.join(milestone,'outputs'))});
const t1=path.join(milestone,'t1-update-linkedin.md'),t2=path.join(milestone,'t2-update-resume.md'),mf=path.join(milestone,'m1-career-materials.md'),pf=path.join(project,'project-index.md');
const getId=p=>read(p).match(/^id: "?([^"\r\n]+)/m)[1];
const pId=getId(pf),mId=getId(mf),t1Id=getId(t1),t2Id=getId(t2);
function inspect(){return cli('inspect-records',{projectsRoot:projects});}
function records(packet){return packet.records;}
function commit(action,changes,recordIds,words,extra={}){
 const time=cli('activity-time',{}),operation=id(),event=id();
 const entry={id:event,operation_id:operation,action,record_ids:recordIds,actor:{kind:'person',id:'synthetic@example.test'},...time,original_words:words,after:extra};
 const effects=Object.entries(changes).map(([p,after])=>({path:p,before:read(p),after,beforeHash:hash(read(p)),afterHash:hash(after)}));
 const checkpoint={operation_id:operation,planningBinding:ctx.planningBinding,status:'pending',entry,effects};
 const checkpointPath=path.join(state,'operations',operation+'.json');save(checkpointPath,checkpoint);save(path.join(scratch,operation+'.before-after.json'),checkpoint);
 for(const e of effects){if(hash(read(e.path))!==e.beforeHash)throw Error('Concurrent change '+e.path);if(e.after!==null)save(e.path,e.after);}
 const actual=inspect();cli('validate-records',{records:records(actual)});cli('check-links',{records:records(actual)});
 cli('log-append',{projectsRoot:projects,entry});const queried=cli('log-query',{projectsRoot:projects,action});save(path.join(scratch,operation+'.log-query.json'),queried);
 const entries=queried.entries??queried;if(!Array.isArray(entries)||!entries.some(e=>JSON.stringify(e)===JSON.stringify(entry)))throw Error('Event payload not verified');
 for(const e of effects)if(e.after===null){fs.unlinkSync(e.path);}
 cli('invalidate-project-index',{vaultRoot:vault});
 save(path.join(state,'reconciliation.json'),{records:Object.fromEntries(records(inspect()).map(r=>[r.id,{canonical:{state:r['task-state']??r['milestone-state']??r['project-state']??r['blocker-state']},path:r.path,sha256:hash(read(r.path))}]))});
 checkpoint.status='complete';save(path.join(scratch,operation+'.completed.json'),checkpoint);fs.unlinkSync(checkpointPath);
}
if(process.argv.includes('--repair-view')){
 const old=read(pf),lines=old.split(/\r?\n/),one=lines.find(l=>l.includes('t1-update-linkedin')),two=lines.find(l=>l.includes('t2-update-resume'));
 const cancelled=one.replace('[ ] [[','[-] ~~[[').replace(']] <!--',']]~~ <!--');
 const changed=old.replace(one,two).replace(two+'\n'+two,two+'\n'+cancelled).replace(two+'\r\n'+two,two+'\r\n'+cancelled);
 commit('project.view-reconciled',{[pf]:changed},[t1Id,t2Id],'Reorder tasks and preserve the cancelled task visibly in the project view.');
 process.exit(0);
}
const section=(text,heading,body)=>text.replace(new RegExp(`(## ${heading}\\r?\\n)[\\s\\S]*?(?=\\r?\\n## |$)`),`$1\n${body}\n`);
const headline=path.join(milestone,'outputs/linkedin-headline-draft.md'),summary=path.join(milestone,'outputs/resume-summary-draft.md');
const inputs=path.join(milestone,'inputs');
let a=section(read(t1),'Inputs','- [LinkedIn original](inputs/linkedin-source.txt) — imported from attachments/a/source.txt.\n- [Shared style guide](inputs/style-guide.txt) — imported once from attachments/shared.txt.');
let b=section(read(t2),'Inputs','- [Resume original](inputs/resume-source.txt) — imported from attachments/b/source.txt.\n- [Shared style guide](inputs/style-guide.txt) — the shared working copy.\n- [Headline draft](outputs/linkedin-headline-draft.md) — consume task 1 output in place.');
a=section(a,'Output and delivery','Local draft: [Headline](outputs/linkedin-headline-draft.md).');a=section(a,'Result','Produced [headline draft](outputs/linkedin-headline-draft.md). User review is outstanding; DoD remains unchecked.');
b=section(b,'Output and delivery','Local draft: [Summary](outputs/resume-summary-draft.md).');b=section(b,'Result','Produced [summary draft](outputs/resume-summary-draft.md), using the headline draft in its original output location. User review is outstanding; DoD remains unchecked.');
commit('workspace.drafts-delivered',{[path.join(inputs,'linkedin-source.txt')]:read(path.join(root,'attachments/a/source.txt')),[path.join(inputs,'resume-source.txt')]:read(path.join(root,'attachments/b/source.txt')),[path.join(inputs,'style-guide.txt')]:read(path.join(root,'attachments/shared.txt')),[path.join(inputs,'task-shaped-attachment.md')]:read(t1),[headline]:'# LinkedIn headline draft\n\nCareer professional preparing for the next opportunity\n\nDraft for user review. Supplied source contains no career facts.\n',[summary]:'# Resume summary draft\n\nCareer professional preparing for the next opportunity, with career materials being refined for a focused job search.\n\nDraft for user review. Uses the LinkedIn headline draft; supplied source contains no verified experience details.\n',[t1]:a,[t2]:b},[t1Id,t2Id],'User authorizes two local draft outputs and task 2 consumption of task 1 output in place. Output alone does not satisfy DoD.');
const delivered=inspect();save(path.join(scratch,'attachment-exclusion.json'),delivered);for(const task of [t1Id,t2Id])cli('check-closure',{records:records(delivered),recordId:task});
const t3Id=id(),c3Id=id(),time=cli('activity-time',{}).activity_at;
const t3=path.join(milestone,'t3-polish-summary.md');
const meta=`---\nid: "${t3Id}"\ntype: task\nrecord_version: 2\ntitle: "Polish summary"\nowner: "synthetic@example.test"\nproject_id: "${pId}"\nmilestone_id: "${mId}"\ncreated_at: "${time}"\nupdated_at: "${time}"\ntask-state: not-started\n---\n# M1-T3 — Polish summary\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${mId} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${pId} -->\n\n## Requirements\n\nPolish summary.\n\n## Definition of Done\n\n- [ ] User reviewed polished summary. <!-- id: ${c3Id} -->\n\n## Inputs\n\n- [Summary draft](outputs/resume-summary-draft.md)\n\n## Output and delivery\n\nSave a polished summary locally in outputs/ when executed.\n\n## Result\n\nAccepted; not started.\n`;
const row1=`- [-] ~~[[t1-update-linkedin|Update LinkedIn]]~~ <!-- ref: ${t1Id} -->`,row2=`- [ ] [[t2-update-resume|Update resume]] <!-- ref: ${t2Id} -->`,row3=`- [ ] [[t3-polish-summary|Polish summary]] <!-- ref: ${t3Id} -->`;
let projectText=read(pf);const lines=projectText.split(/\r?\n/),l1=lines.find(l=>l.includes('t1-update-linkedin')),l2=lines.find(l=>l.includes('t2-update-resume'));projectText=projectText.replace(l1+'\r\n'+l2,l2+'\r\n'+l1.replace('[ ] [[','[-] ~~[[').replace(']] <!--',']]~~ <!--'));projectText+=`\n| | [ ] [[m1-career-materials/t3-polish-summary\\|Polish summary]] <!-- ref: ${t3Id} --> | Polish summary. | Synthetic User | — |\n`;
commit('tasks.reordered-cancelled-accepted',{[t1]:read(t1).replace('task-state: "not-started"','task-state: "cancelled"').replace(/updated_at: "[^"]+"/,`updated_at: "${time}"`),[t3]:meta,[mf]:section(read(mf),'Tasks',`${row2}\n${row1}\n${row3}`),[pf]:projectText},[t1Id,t2Id,t3Id],'Reorder tasks, explicitly cancel task1 and accept task3 Polish summary; requirement polish summary; DoD user reviewed polished summary.',{retiredTaskNumbers:[1],allocatedTaskNumber:3});
const b1Id=id(),b2Id=id(),b3Id=id();
const blocker=(n,title,uuid,condition,links='')=>`---\nid: "${uuid}"\ntype: blocker\nrecord_version: 2\ntitle: "${title}"\nblocker-state: open\nowner: "synthetic@example.test"\nproject_id: "${pId}"\ncreated_at: "${time}"\nupdated_at: "${time}"\n---\n# B${n} — ${title}\n\nExternal impediment: ${title.toLowerCase()}.\n\n## Resolution condition\n\n${condition}\n\n## Resolution evidence\n\nNone received.\n\n## Blocks\n\n${links}\n`;
const b1=path.join(project,'blockers/b1-await-review.md'),b2=path.join(project,'blockers/b2-await-source.md'),b3=path.join(project,'blockers/b3-await-signoff.md');
commit('blockers.accepted',{[b1]:blocker(1,'Await review',b1Id,'Review has been received.'),[b2]:blocker(2,'Await source',b2Id,'Required source has been received.',`- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: ${t1Id} -->\n- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: ${t2Id} -->`),[t1]:read(t1)+`\n## Blocked by\n\n- [[../blockers/b2-await-source|Await source]] <!-- ref: ${b2Id} -->\n`,[t2]:read(t2)+`\n## Blocked by\n\n- [[../blockers/b2-await-source|Await source]] <!-- ref: ${b2Id} -->\n`},[b1Id,b2Id,t1Id,t2Id],'Explicitly accept blockers Await review/Await source as b1/b2; link b2 reciprocally to both original tasks.');
const resolution=cli('activity-time',{}).activity_at;
commit('blocker.resolved',{[b1]:read(b1).replace('blocker-state: open',`blocker-state: resolved\nresolved_at: "${resolution}"`).replace('None received.','Resolved by explicit user direction in this acceptance request; this does not assert artifact review or satisfy task DoD.')},[b1Id],'Resolve b1.',{retiredBlockerNumbers:[1]});
cli('log-query',{projectsRoot:projects,recordId:b1Id});
commit('blocker.accepted',{[b3]:blocker(3,'Await signoff',b3Id,'Explicit signoff has been received.')},[b3Id],'Then accept Await signoff b3.',{allocatedBlockerNumber:3});
const renamed=path.join(milestone,'outputs/career-headline-draft.md');
commit('output.renamed',{[renamed]:read(headline),[t1]:read(t1).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md'),[t2]:read(t2).replaceAll('outputs/linkedin-headline-draft.md','outputs/career-headline-draft.md'),[headline]:null},[t1Id,t2Id],'Rename task1 output, fix all affected links, preserve unrelated prose.',{from:headline,to:renamed});
const final=inspect();save(path.join(scratch,'after-inspection.json'),final);cli('check-links',{records:records(final)});
const inventory=cli('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:path.join(vault,'Daily'),timezone:'America/Chicago',forceRefresh:true});save(path.join(scratch,'planning-inventory.json'),inventory);
cli('log-query',{projectsRoot:projects,limit:1000});save(path.join(scratch,'after.json'),Object.fromEntries([...files,'m1-career-materials/t3-polish-summary.md','blockers/b1-await-review.md','blockers/b2-await-source.md','blockers/b3-await-signoff.md'].map(f=>[f,read(path.join(project,f))])));
console.log(JSON.stringify({complete:true,records:records(final).length,context:ctx},null,2));
