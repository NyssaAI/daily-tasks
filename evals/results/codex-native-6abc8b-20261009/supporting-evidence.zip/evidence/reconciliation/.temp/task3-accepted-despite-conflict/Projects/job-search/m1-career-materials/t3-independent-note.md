---
id: "01a12161-5792-70b1-b3c9-8252000a46f1"
type: task
record_version: 2
title: "Independent note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
created_at: "2026-10-09T15:56:29.929Z"
updated_at: "2026-10-09T15:56:29.929Z"
---
# M1-T3 — Independent note

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Create a local note.

## Definition of Done

- [ ] Reviewed note. <!-- id: 01a12161-57bc-7601-9f2d-249b913ef9d0 -->

## Scope and constraints

Synthetic local acceptance work; preserve unrelated prose and pending task2 conflict.

## Output and delivery

Local Markdown note in outputs/independent-note.md.

## Verification

The local note exists and the user attests reviewed synthetic evidence.

## Result

Accepted; note pending.
