import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
export const root=process.cwd(), vault=path.join(root,'vault'), bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';
export const read=p=>fs.readFileSync(p,'utf8');
export const write=(p,s)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);};
export const json=(p,o)=>write(p,JSON.stringify(o,null,2)+'\n');
export const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
import crypto from 'node:crypto';
export function cli(label,op,input){const f=path.join(root,'.temp',label+'.input.json');if(input!==undefined)json(f,input);const args=[path.join(bundle,'bin/daily-tasks.mjs'),op,...(input===undefined?[]:['--input',f])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});json(path.join(root,'.temp',label+'.result.json'),{args,status:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export function snapshot(label){const dest=path.join(root,'.temp',label);fs.mkdirSync(dest,{recursive:true});for(const p of ['Daily','Projects/job-search','.nyssaai/daily-tasks'])fs.cpSync(path.join(vault,p),path.join(dest,p),{recursive:true});}
