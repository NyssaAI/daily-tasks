# Scenario 3: pass

- PASS staleUnchangedPlanDoesNotReopen
- PASS deliberateCheckboxChangeReopens
- PASS task2ConflictingEditsRemainPending
- PASS unrelatedAcceptedTask3Proceeds
- PASS interruptedAppendRetryExactlyOneMatchingDecision
- PASS originalHistoryPreserved
- PASS originalNotePreserved
- PASS unrelatedProsePreserved
- PASS pendingConflictBaselinePreserved
- PASS recoveryCheckpointCompletedOnlyAfterVerification
- PASS finalRecordAndLinkIntegrity

Actual CLI inputs/results, including the rejected rollover save, are retained beside this report. Before/after and intermediate snapshots preserve the original note, task2 conflict and interrupted checkpoint. The exact retry returned duplicate:true.

Task1 is reopened, task3 completed, and task2 awaits a user choice. Check-in remains resumable. Host version/model were not exposed; no packaging or test claim substitutes for skill activation.
