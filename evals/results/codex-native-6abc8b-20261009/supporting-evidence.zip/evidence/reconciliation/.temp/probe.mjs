import {cli,read,json,root} from './evidence.mjs';import path from 'node:path';
const c=JSON.parse(read(path.join(root,'.temp/context.json')));
console.log(JSON.stringify(cli('04-inspect','inspect-records',{projectsRoot:c.projectsRoot})));
console.log(JSON.stringify(cli('05-reconcile-probe','reconcile-record',{base:{'task-state':'not-started'},current:{'task-state':'completed'},views:[{'task-state':'not-started'}]})));
