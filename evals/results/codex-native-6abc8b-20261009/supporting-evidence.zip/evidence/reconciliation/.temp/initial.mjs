import {cli,vault,snapshot,json,root} from './evidence.mjs';
import path from 'node:path';
snapshot('before');
const c=cli('01-context','resolve-context',{vaultRoot:vault});json(path.join(root,'.temp/context.json'),c);
console.log(JSON.stringify(c));
console.log(JSON.stringify(cli('02-history-before','log-query',{projectsRoot:c.projectsRoot,limit:1000})));
console.log(JSON.stringify(cli('03-prepare','planning-prepare',{vaultRoot:vault})));
