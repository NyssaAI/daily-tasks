# Current native acceptance results

Four direct accepted requests completed using the installed skills and CLI. Each created M1 — update LinkedIn and resume, with unchecked DoD reviewed career materials, and no tasks.

## 01-common-root

- Milestone: [M1](../01-common-root/vault/Projects/job-search/m1-update-linkedin-and-resume/m1-update-linkedin-and-resume.md)
- Configuration: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\01-common-root\common\.nyssaai\daily-tasks
- Operating state: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\01-common-root\vault\.nyssaai\daily-tasks
- Daily output: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\01-common-root\vault\Daily
- Projects: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\01-common-root\vault\Projects
- Existing profile bytes retained: true
- Evidence: ../01-common-root/.temp (CLI command/cwd/input/result, before/after snapshots, checkpoint, validation, and log-query results).

## 02-no-profile

- Milestone: [M1](../02-no-profile/vault/Projects/job-search/m1-update-linkedin-and-resume/m1-update-linkedin-and-resume.md)
- Configuration: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\02-no-profile\common\.nyssaai\daily-tasks
- Operating state: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\02-no-profile\vault\.nyssaai\daily-tasks
- Daily output: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\02-no-profile\vault\2-areas\daily-plans
- Projects: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\02-no-profile\vault\Projects
- Existing profile bytes retained: new profile with empty priorities
- Evidence: ../02-no-profile/.temp (CLI command/cwd/input/result, before/after snapshots, checkpoint, validation, and log-query results).

## 03-explicit-legacy

- Milestone: [M1](../03-explicit-legacy/vault/Projects/job-search/m1-update-linkedin-and-resume/m1-update-linkedin-and-resume.md)
- Configuration: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\03-explicit-legacy\vault\.nyssa\daily-tasks
- Operating state: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\03-explicit-legacy\vault\.nyssaai\daily-tasks
- Daily output: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\03-explicit-legacy\vault\Daily
- Projects: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\03-explicit-legacy\vault\Projects
- Existing profile bytes retained: true
- Evidence: ../03-explicit-legacy/.temp (CLI command/cwd/input/result, before/after snapshots, checkpoint, validation, and log-query results).

## 04-vault-only-legacy

- Milestone: [M1](../04-vault-only-legacy/vault/Projects/job-search/m1-update-linkedin-and-resume/m1-update-linkedin-and-resume.md)
- Configuration: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\04-vault-only-legacy\vault\.nyssa\daily-tasks
- Operating state: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\04-vault-only-legacy\vault\.nyssaai\daily-tasks
- Daily output: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\04-vault-only-legacy\vault\Daily
- Projects: D:\repos\NyssaAI\daily-tasks\.temp\native-acceptance\iteration2\cases\configuration-discovery\04-vault-only-legacy\vault\Projects
- Existing profile bytes retained: true
- Evidence: ../04-vault-only-legacy/.temp (CLI command/cwd/input/result, before/after snapshots, checkpoint, validation, and log-query results).

The first case retained a failed log append caused by an ID result object being used in place of its string. The repair retained the originally generated IDs and activity timestamps, passed integrity checks, and verified the entire logged event payload. No pending checkpoints remain. Legacy profiles were reused without migration; operating state is under .nyssaai as requested. No daily plan was requested or created; its output directory was resolved separately from configuration. The installed bundle has no README.md. No previous attempts or regression tests were read.
