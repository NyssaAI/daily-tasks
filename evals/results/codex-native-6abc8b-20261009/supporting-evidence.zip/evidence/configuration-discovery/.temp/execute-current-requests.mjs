import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=process.cwd();
const cli=path.resolve(root,'../../codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3/bin/daily-tasks.mjs');
const hash=s=>createHash('sha256').update(s).digest('hex');
const save=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
for(const name of ['02-no-profile','03-explicit-legacy','04-vault-only-legacy']){
 const dir=path.join(root,name), evidence=path.join(dir,'.temp'), vault=path.join(dir,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'job-search'), index=path.join(project,'project-index.md');
 fs.mkdirSync(evidence,{recursive:true});let seq=0;
 const call=(op,input)=>{const prefix=path.join(evidence,String(++seq).padStart(2,'0')+'-'+op);const args=[cli,op];if(input!==undefined){save(prefix+'.input.json',input);args.push('--input',prefix+'.input.json');}const r=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8'});save(prefix+'.result.json',{command:[process.execPath,...args],cwd:dir,exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);};
 save(path.join(evidence,'runtime.json'),{node:process.version,help:call('--help')});
 const profilePath=path.join(dir,name.startsWith('01')||name.startsWith('02')?'common/.nyssaai/daily-tasks/profile.json':'vault/.nyssa/daily-tasks/profile.json');
 const beforeProfile=fs.existsSync(profilePath)?fs.readFileSync(profilePath):null;
 if(beforeProfile)fs.writeFileSync(path.join(evidence,'profile.before.json'),beforeProfile);
 const beforeIndex=fs.readFileSync(index,'utf8');save(path.join(evidence,'project.before.md'),beforeIndex);
 const stateRoot=path.join(vault,'.nyssaai/daily-tasks');
 const discovery={vaultRoot:vault,homeRoot:path.join(dir,'synthetic-home'),stateRoot};
 if(!name.startsWith('04'))discovery.profilePath=profilePath;
 save(path.join(evidence,'discovery-decision.json'),{source:name.startsWith('01')||name.startsWith('02')?'accepted common .nyssaai root':name.startsWith('03')?'explicit legacy pointer':'exact vault conventional lookup then legacy lookup',request:'Create M1: update LinkedIn and resume in this project',DoD:'reviewed career materials',noExtraTasks:true,operatingState:'vault .nyssaai per explicit request'});
 let context=call('resolve-context',discovery);
 let setup=false;
 if(!context.configured){
  const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
  const validation=call('validate-profile',profile);if(!validation.valid)throw Error(JSON.stringify(validation));save(profilePath,profile);setup=true;context=call('resolve-context',discovery);
 }
 if(context.projectsRoot!==projects||context.profile.user.email!=='synthetic@example.test')throw Error('Scope conflict');
 const before=call('inspect-records',{projectsRoot:projects});save(path.join(evidence,'records.before.json'),before);
 const history=call('log-query',{projectsRoot:projects});if(JSON.stringify(history).includes('m1-update-linkedin-and-resume'))throw Error('Retired number conflict');
 const id=()=>call('new-id').id;const milestoneId=id(),criterionId=id(),operationId=id(),eventId=id();const timing=call('activity-time',{});
 const projectId=beforeIndex.match(/id: "([^"]+)"/)[1];
 const stem='m1-update-linkedin-and-resume',folder=path.join(project,stem),file=path.join(folder,stem+'.md');if(fs.existsSync(folder))throw Error('Destination exists');
 const milestone=`---\nid: "${milestoneId}"\ntype: milestone\nrecord_version: 2\ntitle: "update LinkedIn and resume"\ndocument-maturity: reviewed\nmilestone-state: not-started\nowner: "synthetic@example.test"\nproject_id: "${projectId}"\ncreated_at: "${timing.activity_at}"\nupdated_at: "${timing.activity_at}"\n---\n# M1 — update LinkedIn and resume\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${projectId} -->\n\n## Outcome\n\nUpdate LinkedIn and resume for the job search.\n\n## Definition of Done\n\n- [ ] reviewed career materials <!-- id: ${criterionId} -->\n\n## Tasks\n\nNo tasks accepted.\n`;
 const afterIndex=beforeIndex.replace(/updated_at: "[^"]+"/,`updated_at: "${timing.activity_at}"`).replace('No milestones yet.',`- [ ] [[${stem}/${stem}|M1 — update LinkedIn and resume]] <!-- ref: ${milestoneId} -->`);
 const event={id:eventId,operation_id:operationId,action:'milestone.accepted',record_ids:[milestoneId],actor:{kind:'person',id:'synthetic@example.test'},...timing,original_words:'Create M1: update LinkedIn and resume in this project; DoD reviewed career materials; no extra tasks.',before:{milestone:null},after:{title:'update LinkedIn and resume',project_id:projectId,'milestone-state':'not-started',definitionOfDone:'reviewed career materials',path:file,number:1}};
 const checkpoint={operation_id:operationId,planningBinding:context.planningBinding,event,acceptanceSource:'direct user request',files:[{path:index,beforeHash:hash(beforeIndex),afterHash:hash(afterIndex)},{path:file,beforeHash:null,afterHash:hash(milestone)}]};
 const pending=path.join(stateRoot,'operations',operationId+'.json');save(pending,checkpoint);save(path.join(evidence,'checkpoint.json'),checkpoint);
 if(fs.readFileSync(index,'utf8')!==beforeIndex||fs.existsSync(file))throw Error('Concurrent change');
 save(file,milestone);fs.mkdirSync(path.join(folder,'inputs'));fs.mkdirSync(path.join(folder,'outputs'));save(index,afterIndex);
 const after=call('inspect-records',{projectsRoot:projects});save(path.join(evidence,'records.after.json'),after);
 const records=after.records;const validation=call('validate-records',{records});const links=call('check-links',{records});save(path.join(evidence,'validation.json'),{validation,links});if(after.diagnostics.length||validation.diagnostics.length||links.diagnostics.length)throw Error('Integrity diagnostics');
 call('log-append',{projectsRoot:projects,entry:event});
 if(setup){const st=call('activity-time',{});call('log-append',{projectsRoot:projects,entry:{id:id(),operation_id:id(),action:'profile.configured',record_ids:[],actor:{kind:'person',id:'synthetic@example.test'},...st,original_words:'Initialize accepted conventional common scope with empty priorities',after:{profilePath,profile:context.profile}}});}
 const queried=call('log-query',{projectsRoot:projects,recordId:milestoneId});save(path.join(evidence,'log-verification.json'),queried);
 const serialized=JSON.stringify(queried);if(!serialized.includes(JSON.stringify(event)))throw Error('Log payload verification failed');
 save(path.join(stateRoot,'reconciliation.json'),{schema_version:1,records:{[milestoneId]:{canonical:{title:'update LinkedIn and resume',owner:'synthetic@example.test','milestone-state':'not-started'},fingerprint:hash(milestone),views:{[index]:{rendered:{title:'update LinkedIn and resume',state:'not-started'},fingerprint:hash(afterIndex)}}}}});
 call('invalidate-project-index',{vaultRoot:vault});fs.unlinkSync(pending);
 save(path.join(evidence,'milestone.after.md'),milestone);save(path.join(evidence,'project.after.md'),afterIndex);
 const afterProfile=fs.readFileSync(profilePath);fs.writeFileSync(path.join(evidence,'profile.after.json'),afterProfile);if(beforeProfile&&!beforeProfile.equals(afterProfile))throw Error('Profile changed');
 save(path.join(evidence,'outcome.json'),{completed:true,milestone:file,configRoot:context.configRoot,stateRoot:context.stateRoot,projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot,profileBytesRetained:beforeProfile?true:null,priorities:context.profile.priorities,timezone:context.timezone,tasksCreated:0});
 console.log(JSON.stringify({case:name,milestone:file,validation,links}));
}
