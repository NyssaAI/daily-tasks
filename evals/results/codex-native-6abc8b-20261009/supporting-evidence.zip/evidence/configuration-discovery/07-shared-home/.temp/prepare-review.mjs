import fs from 'node:fs';import path from 'node:path';import {root,temp,write,hash,cli} from './helpers.mjs';
const ctx=JSON.parse(fs.readFileSync(path.join(temp,'context.json'))),opPath=fs.readFileSync(path.join(temp,'records-pending-path.txt'),'utf8'),op=JSON.parse(fs.readFileSync(opPath)),ins=JSON.parse(fs.readFileSync(path.join(temp,'record-inspection.json')));
for(const cmd of ['validate-records','check-links']){const r=cli(cmd,{records:ins.records});console.log(cmd,JSON.stringify(r));}
const q=cli('log-query',{projectsRoot:ctx.projectsRoot});if(JSON.stringify(q.entries.find(e=>e.id===op.entry.id))!==JSON.stringify(op.entry))throw Error('log payload mismatch');
for(const f of op.files)if(hash(fs.readFileSync(f.path))!==f.afterHash)throw Error('after mismatch');
const baselines={schemaVersion:1,records:{}};for(const r of ins.records)baselines.records[r.id]={canonical:{state:r.state,owner:r.owner,updated_at:r.updated_at},path:r.path,sha256:hash(fs.readFileSync(r.path)),views:{}};
const task=ins.records.find(r=>r.type==='task');for(const r of ins.records.filter(r=>r.projections.length))baselines.records[task.id].views[r.path]={fields:{state:'not-started'},source:{state:'not-started'},sha256:hash(fs.readFileSync(r.path))};
write(path.join(ctx.stateRoot,'reconciliation.json'),JSON.stringify(baselines,null,2));write(path.join(temp,'records-completed-operation.json'),JSON.stringify({...op,completed:true},null,2));fs.unlinkSync(opPath);
const packet=cli('planning-prepare',{vaultRoot:ctx.vaultRoot,profilePath:ctx.profilePath,homeRoot:ctx.homeRoot});write(path.join(temp,'prepare.json'),JSON.stringify(packet,null,2));console.log(JSON.stringify(packet,null,2));
