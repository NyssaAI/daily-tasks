import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';import crypto from 'node:crypto';
const root=process.cwd(),temp=path.join(root,'.temp'),pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';let seq=100;
const write=(f,s)=>{fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,s);};const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
function cli(op,input){const n=++seq,args=[path.join(pkg,'bin/daily-tasks.mjs'),op];if(input){const f=path.join(temp,`${n}-${op}-input.json`);write(f,JSON.stringify(input,null,2));args.push('--input',f);}const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(path.join(temp,`${n}-${op}-result.json`),r.stdout||r.stderr);fs.appendFileSync(path.join(temp,'cli-transcript.jsonl'),JSON.stringify({args,status:r.status,stdout:r.stdout,stderr:r.stderr})+'\n');if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const ctx=JSON.parse(fs.readFileSync(path.join(temp,'context.json'))),opts={vaultRoot:ctx.vaultRoot,homeRoot:ctx.homeRoot,profilePath:ctx.profilePath};
const id=()=>{const r=cli('new-id');return r.id;};
console.log(cli('new-id'));
write(path.join(temp,'helpers.mjs'),fs.readFileSync(new URL(import.meta.url),'utf8').split("const ctx=")[0]+'\nexport {root,temp,write,hash,cli};\n');
