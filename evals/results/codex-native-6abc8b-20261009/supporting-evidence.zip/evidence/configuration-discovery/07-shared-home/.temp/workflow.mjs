import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import crypto from 'node:crypto';
const root=process.cwd(), pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration2/codex-home/plugins/cache/daily-tasks-native-eval-iteration2/daily-tasks/0.3.3';
const temp=path.join(root,'.temp'), vault=path.join(root,'vault-a'), home=path.join(root,'synthetic-home'), config=path.join(home,'.nyssaai/daily-tasks');
let seq=0;
export function cli(op,input){let args=[path.join(pkg,'bin/daily-tasks.mjs'),op];const n=String(++seq).padStart(3,'0');if(input){const f=path.join(temp,`${n}-${op}-input.json`);fs.writeFileSync(f,JSON.stringify(input,null,2));args.push('--input',f);}const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(path.join(temp,`${n}-${op}-result.json`),r.stdout||r.stderr);fs.appendFileSync(path.join(temp,'cli-transcript.jsonl'),JSON.stringify({args,status:r.status,stdout:r.stdout,stderr:r.stderr})+'\n');if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
export const write=(f,s)=>{fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,s);};
const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
const valid=cli('validate-profile',profile);if(valid.valid===false)throw Error(JSON.stringify(valid));write(path.join(config,'profile.json'),JSON.stringify(profile,null,2));
const ctx=cli('resolve-context',{vaultRoot:vault,homeRoot:home,configRoot:config});write(path.join(temp,'context.json'),JSON.stringify(ctx,null,2));console.log(JSON.stringify(ctx,null,2));
