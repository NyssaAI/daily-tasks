Open projects: 1          Open tasks: 1          Late tasks: 0

Daily review — 2026.10.09 (America/Chicago)

## Already selected

None.

## Available tasks

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | update LinkedIn and resume | Routing note | — |

Reply by row number and symbol or description:

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled

Authorized decision: add 1 to today.
