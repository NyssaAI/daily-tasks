---
id: 01a1215f-af72-7b08-9d97-e6fda4cf1f47
type: task
record_version: 2
title: "Routing note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
milestone_id: "01a1215f-af49-72fd-bf3d-0194a78764ed"
created_at: "2026-10-09T15:54:41.312Z"
updated_at: "2026-10-09T15:54:41.312Z"
---
# M1-T1 — Routing note

**Milestone:** [[m1-update-linkedin-and-resume|update LinkedIn and resume]] <!-- ref: 01a1215f-af49-72fd-bf3d-0194a78764ed -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Requirements

local routing test note

## Definition of Done

- [ ] reviewed routing note <!-- id: 01a1215f-afce-7471-97b6-6ab89fd20c5c -->

## Output and delivery

Local routing note in [outputs/](outputs/).

## Verification

Owner reviews the routing note against the requirement.
