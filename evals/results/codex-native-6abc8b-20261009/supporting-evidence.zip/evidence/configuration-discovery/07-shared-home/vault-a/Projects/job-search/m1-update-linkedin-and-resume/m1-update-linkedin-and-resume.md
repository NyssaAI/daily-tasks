---
id: 01a1215f-af49-72fd-bf3d-0194a78764ed
type: milestone
record_version: 2
title: "update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
created_at: "2026-10-09T15:54:41.312Z"
updated_at: "2026-10-09T15:54:41.312Z"
---
# M1 — update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] reviewed career materials <!-- id: 01a1215f-af9e-7876-9e3b-8e22c22df3ce -->

## Tasks

- [ ] [[t1-routing-note|Routing note]] <!-- ref: 01a1215f-af72-7b08-9d97-e6fda4cf1f47 -->
