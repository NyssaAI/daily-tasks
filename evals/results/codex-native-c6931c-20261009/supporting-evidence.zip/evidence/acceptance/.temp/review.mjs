import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), evidence=path.join(root,'.temp'), vault=path.join(root,'vault');
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration1/codex-home/plugins/cache/daily-tasks-native-eval-iteration1/daily-tasks/0.3.3/bin/daily-tasks.mjs';
function call(label,operation,input){
 const file=path.join(evidence,label+'.input.json');fs.writeFileSync(file,JSON.stringify(input,null,2));
 const args=[cli,operation,'--input',file];const r=spawnSync(process.execPath,args,{encoding:'utf8'});
 fs.writeFileSync(path.join(evidence,label+'.result.json'),JSON.stringify({args,exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2));
 if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);
}
const context=call('resolve','resolve-context',{vaultRoot:vault});
fs.writeFileSync(path.join(evidence,'context.json'),JSON.stringify(context,null,2));
console.log(JSON.stringify(context,null,2));
const records=call('records-before','inspect-records',{projectsRoot:context.projectsRoot});
call('log-before','log-query',{projectsRoot:context.projectsRoot,limit:1000});
const note=path.join(vault,'Daily','2026-10-09.md');
fs.copyFileSync(note,path.join(evidence,'plan-before.md'));
call('checkboxes','parse-checklist',{markdown:fs.readFileSync(note,'utf8')});
console.log(JSON.stringify(records,null,2));
const queuePath=path.join(context.stateRoot,'candidates.json');
const before=fs.existsSync(queuePath)?fs.readFileSync(queuePath,'utf8'):null;
fs.writeFileSync(path.join(evidence,'candidates-before.json'),JSON.stringify({exists:before!==null,content:before},null,2));
if(before!==null)throw Error('Existing queue requires review before modification');
const candidates=[
 {id:'candidate-linkedin',title:'Update LinkedIn',kind:'idea',disposition:'pending',accepted:false,owner:context.profile.user.email,assignee:null,target_date:null,parent_project:null,parent_milestone:null,source_keys:['request:acceptance:linkedin'],sources:[{key:'request:acceptance:linkedin',reference:'Current user request',text:'I might want to update LinkedIn and resume sometime.'}],unresolved:['Acceptance','Parent project/milestone','Scope and definition of done']},
 {id:'candidate-resume',title:'Update resume',kind:'idea',disposition:'pending',accepted:false,owner:context.profile.user.email,assignee:null,target_date:null,parent_project:null,parent_milestone:null,source_keys:['request:acceptance:resume','note:Daily/2026-10-09.md:maybe-improve-my-resume'],sources:[{key:'request:acceptance:resume',reference:'Current user request',text:'I might want to update LinkedIn and resume sometime.'},{key:'note:Daily/2026-10-09.md:maybe-improve-my-resume',reference:'Daily/2026-10-09.md:3',text:'Maybe improve my resume'}],unresolved:['Acceptance','Parent project/milestone','Scope and definition of done']}
];
fs.writeFileSync(queuePath,JSON.stringify({schema_version:1,vaultRoot:context.vaultRoot,updated_at:context.now,candidates},null,2)+'\n');
fs.copyFileSync(queuePath,path.join(evidence,'candidates-after.json'));
const afterRecords=call('records-after','inspect-records',{projectsRoot:context.projectsRoot});
const afterLog=call('log-after','log-query',{projectsRoot:context.projectsRoot,limit:1000});
fs.copyFileSync(note,path.join(evidence,'plan-after.md'));
const samePlan=fs.readFileSync(path.join(evidence,'plan-before.md')).equals(fs.readFileSync(note));
const priorLog=JSON.parse(JSON.parse(fs.readFileSync(path.join(evidence,'log-before.result.json'),'utf8')).stdout);
const proof={acceptedRecordsBefore:records.records.length,acceptedRecordsAfter:afterRecords.records.length,planBytesUnchanged:samePlan,logQueryUnchanged:JSON.stringify(priorLog)===JSON.stringify(afterLog),candidateCount:candidates.length};
fs.writeFileSync(path.join(evidence,'verification.json'),JSON.stringify(proof,null,2));
fs.writeFileSync(path.join(evidence,'actions.md'),'# Candidate review\n\nReused the existing vault-only profile. Inspected accepted records and queried the log through the installed CLI before and after. Parsed the manual checkbox through the installed CLI. Combined the resume mentions into one candidate with two stable source keys; retained LinkedIn separately. Saved two pending candidates in vault state. Created zero accepted work and appended zero log events. Preserved the manual note byte-for-byte. CLI arguments, structured inputs, exit codes and results are retained beside this file.\n');
console.log(JSON.stringify(proof,null,2));
