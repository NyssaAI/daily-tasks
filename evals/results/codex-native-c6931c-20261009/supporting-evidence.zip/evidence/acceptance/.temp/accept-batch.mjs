import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const base=process.cwd(), dir=path.join(base,'.temp','accepted-batch');fs.mkdirSync(dir,{recursive:true});
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration1/codex-home/plugins/cache/daily-tasks-native-eval-iteration1/daily-tasks/0.3.3/bin/daily-tasks.mjs';
let sequence=0;
function call(op,input){const label=String(++sequence).padStart(2,'0')+'-'+op;const args=[cli,op];if(input!==undefined){const file=path.join(dir,label+'.input.json');fs.writeFileSync(file,JSON.stringify(input,null,2));args.push('--input',file);}const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(path.join(dir,label+'.result.json'),JSON.stringify({args,exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const c=call('resolve-context',{vaultRoot:path.join(base,'vault')});
const before=call('inspect-records',{projectsRoot:c.projectsRoot});
const logBefore=call('log-query',{projectsRoot:c.projectsRoot,limit:1000});
if(before.records.length)throw Error('Unexpected existing records: review required');
call('validate-records',{records:before.records});call('check-links',{records:before.records});
const plan=path.join(c.dailyPlansRoot,'2026-10-09.md'), planBytes=fs.readFileSync(plan);
fs.writeFileSync(path.join(dir,'plan-before.md'),planBytes);
const queuePath=path.join(c.stateRoot,'candidates.json'),queueBytes=fs.readFileSync(queuePath);fs.writeFileSync(path.join(dir,'candidates-before.json'),queueBytes);
const reconciliation=path.join(c.stateRoot,'reconciliation.json');if(fs.existsSync(reconciliation))throw Error('Existing baseline requires inspection');
const ids={};for(const name of ['project','milestone','linkedin','resume','milestoneCriterion','linkedinCriterion','resumeCriterion','operation','event']){const r=call('new-id');ids[name]=typeof r==='string'?r:r.id;if(!ids[name])throw Error(JSON.stringify(r));}
const time=call('activity-time',{});
const owner='synthetic@example.test',slug='m1-career-materials';
const project=path.join(c.projectsRoot,'job-search'),milestone=path.join(project,slug);
const meta=(id,type,title,extra)=>`---\nid: ${id}\ntype: ${type}\nrecord_version: 2\ntitle: ${JSON.stringify(title)}\n${type}-state: not-started\nowner: "${owner}"\n${extra}created_at: "${time.recorded_at}"\nupdated_at: "${time.recorded_at}"\n---\n`;
const files=[
 [path.join(project,'project-index.md'),meta(ids.project,'project','Job Search','')+`# Job Search\n\nPrepare the accepted career materials.\n\n## Project Summary\n\n| Milestone | Task | Description | Owner | Due Date |\n| --- | --- | --- | --- | --- |\n| [ ] [[${slug}/${slug}\\|Career materials]] <!-- ref: ${ids.milestone} --> | | Career materials. | ${owner} | — |\n| | [ ] [[${slug}/t1-update-linkedin\\|Update LinkedIn]] <!-- ref: ${ids.linkedin} --> | Update headline. | ${owner} | — |\n| | [ ] [[${slug}/t2-update-resume\\|Update resume]] <!-- ref: ${ids.resume} --> | Update summary. | ${owner} | — |\n`],
 [path.join(milestone,slug+'.md'),meta(ids.milestone,'milestone','Career materials',`project_id: "${ids.project}"\n`)+`# M1 — Career materials\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${ids.project} -->\n\n## Outcome\n\nLinkedIn headline and resume summary reviewed, with both reviewed artifacts linked.\n\n## Definition of Done\n\n- [ ] Both reviewed artifacts linked. <!-- id: ${ids.milestoneCriterion} -->\n\n## Tasks\n\n- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${ids.linkedin} -->\n- [ ] [[t2-update-resume|Update resume]] <!-- ref: ${ids.resume} -->\n`]
];
for(const [key,n,title,requirement,dod] of [['linkedin',1,'Update LinkedIn','Update headline.','Reviewed headline.'],['resume',2,'Update resume','Update summary.','Reviewed summary.']])files.push([path.join(milestone,`t${n}-update-${key}.md`),meta(ids[key],'task',title,`project_id: "${ids.project}"\nmilestone_id: "${ids.milestone}"\n`)+`# M1-T${n} — ${title}\n\n**Milestone:** [[${slug}|Career materials]] <!-- ref: ${ids.milestone} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${ids.project} -->\n\n## Requirements\n\n${requirement}\n\n## Definition of Done\n\n- [ ] ${dod} <!-- id: ${ids[key+'Criterion']} -->\n\n## Inputs\n\nWorking inputs belong in [inputs](inputs/). None supplied yet.\n\n## Output and delivery\n\nLink the reviewed artifact from [outputs](outputs/) when available.\n\n## Verification\n\nRecord explicit review of the ${key==='linkedin'?'headline':'summary'} and link its evidence.\n\n## Result\n\nPending.\n`]);
const words='I explicitly accept this batch: create Job Search project, M1 Career materials milestone, Update LinkedIn task (requirement: update headline; DoD: reviewed headline), and Update resume task (requirement: update summary; DoD: reviewed summary). Milestone DoD: both reviewed artifacts linked. Owner synthetic@example.test; all accepted work not started and unchecked. Accept no other work.';
const entry={id:ids.event,operation_id:ids.operation,action:'batch.accepted',record_ids:[ids.project,ids.milestone,ids.linkedin,ids.resume],actor:{kind:'person',id:owner},...time,original_words:words,before:{accepted_record_count:0,candidates:'pending'},after:{accepted_record_count:4,records:files.map(([file,content])=>({path:file,sha256:hash(content),state:'not-started'})),acceptance_source:'Current explicit user batch acceptance'}};
const checkpoint={operation_id:ids.operation,planningBinding:c.planningBinding,vaultRoot:c.vaultRoot,projectsRoot:c.projectsRoot,dailyPlansRoot:c.dailyPlansRoot,stateRoot:c.stateRoot,status:'pending',event:entry,files:files.map(([file,content])=>({path:file,before:{present:false},after:{present:true,sha256:hash(content)}})),changes:files.map(([file,content])=>({key:file,before:{present:false},after:{present:true,value:hash(content)}}))};
const operations=path.join(c.stateRoot,'operations');fs.mkdirSync(operations,{recursive:true});const pending=path.join(operations,ids.operation+'.json');fs.writeFileSync(pending,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(dir,'operation-before.json'),JSON.stringify(checkpoint,null,2));
fs.mkdirSync(path.join(milestone,'inputs'),{recursive:true});fs.mkdirSync(path.join(milestone,'outputs'),{recursive:true});fs.mkdirSync(path.join(project,'blockers'),{recursive:true});
for(const [file,content] of files){if(fs.existsSync(file))throw Error('Collision '+file);fs.writeFileSync(file,content,{flag:'wx'});}
call('invalidate-project-index',{vaultRoot:c.vaultRoot});
const after=call('inspect-records',{projectsRoot:c.projectsRoot});
const validation=call('validate-records',{records:after.records}),links=call('check-links',{records:after.records});
console.log(JSON.stringify({ids,time,after,validation,links},null,2));
fs.writeFileSync(path.join(dir,'stage.json'),JSON.stringify({c,ids,time,entry,pending,files,queuePath,plan,planHash:hash(planBytes),after,validation,links},null,2));
