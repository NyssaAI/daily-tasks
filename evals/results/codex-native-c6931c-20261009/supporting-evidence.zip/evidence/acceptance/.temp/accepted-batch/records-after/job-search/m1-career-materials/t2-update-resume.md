---
id: 01a12153-fc07-76fc-9614-57edaab89ebf
type: task
record_version: 2
title: "Update resume"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12153-fb8e-7c46-98e3-baa5cf17b124"
milestone_id: "01a12153-fbb6-7c31-9137-f6f11573326a"
created_at: "2026-10-09T15:41:54.804Z"
updated_at: "2026-10-09T15:41:54.804Z"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a12153-fbb6-7c31-9137-f6f11573326a -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12153-fb8e-7c46-98e3-baa5cf17b124 -->

## Requirements

Update summary.

## Definition of Done

- [ ] Reviewed summary. <!-- id: 01a12153-fc7d-764a-bc9a-c2ed78e9a038 -->

## Inputs

Working inputs belong in [inputs](inputs/). None supplied yet.

## Output and delivery

Link the reviewed artifact from [outputs](outputs/) when available.

## Verification

Record explicit review of the summary and link its evidence.

## Result

Pending.
