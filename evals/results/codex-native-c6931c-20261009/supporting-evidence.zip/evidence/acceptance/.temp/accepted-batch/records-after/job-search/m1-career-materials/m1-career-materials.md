---
id: 01a12153-fbb6-7c31-9137-f6f11573326a
type: milestone
record_version: 2
title: "Career materials"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12153-fb8e-7c46-98e3-baa5cf17b124"
created_at: "2026-10-09T15:41:54.804Z"
updated_at: "2026-10-09T15:41:54.804Z"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12153-fb8e-7c46-98e3-baa5cf17b124 -->

## Outcome

LinkedIn headline and resume summary reviewed, with both reviewed artifacts linked.

## Definition of Done

- [ ] Both reviewed artifacts linked. <!-- id: 01a12153-fc2d-7b20-a72b-4554188dc9cd -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a12153-fbdf-7f74-afe8-8ea7775d5d0e -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a12153-fc07-76fc-9614-57edaab89ebf -->
