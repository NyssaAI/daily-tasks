---
id: 01a12153-fb8e-7c46-98e3-baa5cf17b124
type: project
record_version: 2
title: "Job Search"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T15:41:54.804Z"
updated_at: "2026-10-09T15:41:54.804Z"
---
# Job Search

Prepare the accepted career materials.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a12153-fbb6-7c31-9137-f6f11573326a --> | | Career materials. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a12153-fbdf-7f74-afe8-8ea7775d5d0e --> | Update headline. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a12153-fc07-76fc-9614-57edaab89ebf --> | Update summary. | synthetic@example.test | — |
