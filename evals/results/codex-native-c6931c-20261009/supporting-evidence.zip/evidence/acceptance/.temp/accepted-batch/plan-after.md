# Friday

- [ ] Maybe improve my resume
