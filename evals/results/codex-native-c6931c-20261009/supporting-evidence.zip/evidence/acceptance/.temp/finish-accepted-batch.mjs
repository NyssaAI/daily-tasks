import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const dir=path.join(process.cwd(),'.temp','accepted-batch'),s=JSON.parse(fs.readFileSync(path.join(dir,'stage.json'),'utf8'));
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration1/codex-home/plugins/cache/daily-tasks-native-eval-iteration1/daily-tasks/0.3.3/bin/daily-tasks.mjs';
let n=30;function call(op,input){const label=++n+'-'+op,file=path.join(dir,label+'.input.json');fs.writeFileSync(file,JSON.stringify(input,null,2));const args=[cli,op,'--input',file],r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(path.join(dir,label+'.result.json'),JSON.stringify({args,exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
assert.deepEqual(s.validation.diagnostics,[]);assert.deepEqual(s.links.diagnostics,[]);
assert.equal(s.after.records.length,4);assert.equal(new Set(s.after.records.map(r=>r.id)).size,4);
for(const r of s.after.records){assert.equal(r.owner,'synthetic@example.test');assert.equal(r.state,'not-started');assert.equal(r.created_at,s.time.recorded_at);assert.equal(r.updated_at,s.time.recorded_at);assert(!r.started_at);assert(!r.resolved_at);assert(r.criteria.every(x=>!x.checked));assert(r.projections.every(x=>!x.checked));}
for(const [file,content] of s.files)assert.equal(fs.readFileSync(file,'utf8'),content);
const savedTime=JSON.parse(JSON.parse(fs.readFileSync(path.join(dir,'15-activity-time.result.json'),'utf8')).stdout);
assert.equal(s.entry.activity_at,savedTime.activity_at);assert.equal(s.entry.recorded_at,savedTime.recorded_at);
call('log-append',{projectsRoot:s.c.projectsRoot,entry:s.entry});
const full=call('log-query',{projectsRoot:s.c.projectsRoot,limit:1000});
console.log(JSON.stringify(full,null,2));
const filtered=call('log-query',{projectsRoot:s.c.projectsRoot,action:'batch.accepted',since:s.time.recorded_at,limit:1000});
const entries=Array.isArray(full)?full:full.entries;
assert(entries,'No query entries');const event=entries.find(e=>e.id===s.entry.id);assert.deepEqual(event,s.entry);
const queue=JSON.parse(fs.readFileSync(s.queuePath,'utf8'));
for(const candidate of queue.candidates){const key=candidate.id==='candidate-linkedin'?'linkedin':candidate.id==='candidate-resume'?'resume':null;if(!key)continue;assert.equal(candidate.accepted,false);candidate.accepted=true;candidate.disposition='accepted';candidate.accepted_at=s.time.recorded_at;candidate.acceptance_source=s.entry.original_words;candidate.record_id=s.ids[key];candidate.parent_project=s.ids.project;candidate.parent_milestone=s.ids.milestone;candidate.unresolved=[];}
queue.updated_at=s.time.recorded_at;fs.writeFileSync(s.queuePath,JSON.stringify(queue,null,2)+'\n');fs.copyFileSync(s.queuePath,path.join(dir,'candidates-after.json'));
const records={};for(const r of s.after.records){records[r.id]={canonical:{type:r.type,title:r.title,owner:r.owner,state:r.state,project_id:r.project_id??null,milestone_id:r.milestone_id??null,created_at:r.created_at,updated_at:r.updated_at,criteria:r.criteria.map(x=>({id:x.id,checked:x.checked}))},views:{},fingerprint:hash(fs.readFileSync(r.path))};for(const view of s.after.records){const projection=view.projections.find(x=>x.id===r.id);if(projection)records[r.id].views[view.path]={checked:projection.checked,state:r.state,sha256:hash(fs.readFileSync(view.path))};}}
fs.writeFileSync(path.join(s.c.stateRoot,'reconciliation.json'),JSON.stringify({schema_version:1,planningBinding:s.c.planningBinding,records},null,2));
const final=call('inspect-records',{projectsRoot:s.c.projectsRoot});call('validate-records',{records:final.records});call('check-links',{records:final.records});
assert.equal(hash(fs.readFileSync(s.plan)),s.planHash);fs.copyFileSync(s.plan,path.join(dir,'plan-after.md'));
for(const [file]of s.files){const destination=path.join(dir,'records-after',path.relative(s.c.projectsRoot,file));fs.mkdirSync(path.dirname(destination),{recursive:true});fs.copyFileSync(file,destination);}
const prior=JSON.parse(JSON.parse(fs.readFileSync(path.join(dir,'03-log-query.result.json'),'utf8')).stdout);assert.equal(prior.entries.length,0);assert.equal(entries.length,1);
fs.writeFileSync(path.join(dir,'verification.json'),JSON.stringify({beforeRecordCount:0,afterRecordCount:4,beforeLogCount:0,afterLogCount:1,exactEventPayloadVerified:true,acceptanceOnlyAtCurrentDecision:true,allNotStarted:true,allUnchecked:true,manualPlanBytesUnchanged:true,recordDiagnostics:s.validation.diagnostics,linkDiagnostics:s.links.diagnostics},null,2));
fs.writeFileSync(path.join(dir,'actions.md'),'# Accepted batch\n\nCreated Job Search, M1 Career materials, Update LinkedIn and Update resume only, following the current explicit batch acceptance. Before inspection found zero records and zero log entries; prior candidate state retained both ideas as pending. Generated every record, criterion, operation and event identity through the installed CLI. Wrote a pending operation before Markdown, then validated records and links with no diagnostics. Appended one batch.accepted decision and queried both full history and the action filtered by the exact current decision time; verified the entire event payload against the checkpoint. Saved source-preserving accepted candidate dispositions and reconciliation baselines. Invalidated the project inventory. All work and DoD criteria remain not started and unchecked. The manual daily note is byte-for-byte unchanged. Exact CLI inputs, arguments, outputs, before/after candidates, records and plan bytes are retained here.\n');
const checkpoint=JSON.parse(fs.readFileSync(s.pending,'utf8'));checkpoint.status='complete';fs.writeFileSync(path.join(dir,'operation-after.json'),JSON.stringify(checkpoint,null,2));fs.unlinkSync(s.pending);
console.log('Verified complete');
