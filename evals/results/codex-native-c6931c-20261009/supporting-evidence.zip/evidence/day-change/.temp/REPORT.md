# Scenario 4 — day change

All 12 retained behavioral assertions pass in `acceptance-result.json`. This is a current-session, installed-skill-authored run. It is not a clean native acceptance receipt: two operation-protocol deviations occurred and are retained below. No packaging or direct CLI success is offered as proof of automatic host activation or authentication. Host version/model/authentication were not exposed; Node was v24.19.0.

The installed Daily Tasks Check-in, Plan, Records and their referenced instructions were read from the 0.3.3 installed bundle. Actual paths and SHA-256 values are in `acceptance-result.json`. No earlier attempts, operation scripts, regression tests or personal directories were read. The resolver returned a homeRoot, but no personal files were accessed.

Declared clocks were Monday 2026-10-05T16:00:00Z, Tuesday 2026-10-06T16:00:00Z and Friday 2026-10-09T16:00:00Z; America/Chicago. Original A/B IDs and bytes survive. C/F are open, C is assigned to Reviewer, D is completed with explicitly attested reviewed result, E explicitly cancelled. Creation and selection decisions use installed CLI-generated UUIDv7s and activity-time results.

| Assertion | Observed result |
| --- | --- |
| Check in after skipped days; create only today | Only Monday and Friday managed plans exist in the main vault; no Tuesday–Thursday backfill. Original unrelated Friday note survives. |
| Unfinished selected own/delegated carry | Friday selects A in My work and C in Delegated work. |
| Completed/cancelled history remains | Monday retains checked D and cancelled E; neither enters Friday. Monday bytes/hash are unchanged. |
| Explicit deselection | F remains open but unselected and does not carry. |
| No timeframe fitting | No slots, estimates, time budgets, ranking or inferred targets were added. |
| Precreated Tuesday retains B | Existing plan UUID, original created_at, prose and B survive; A appears once. |
| Remove A/repeat Tuesday | Tuesday contains B only; removedIds contains A; one rollover event remains. |
| Actual interruption boundary | Separate rollover process exited after destination persistence and inventory invalidation. Pending checkpoint retained; no log event or completion receipt existed. |
| Resume/retry | recover-operation returned already-applied for destination bytes; log-query verified original payload; resume completed the missing log/baseline/state effects. Identical log retry deduplicated; repeat rollover retained one A/C row each. |
| Future removal | In future-valid, Tuesday removes A from precreated Friday with a conflict-free CLI proposal. Pending Friday removedIds survives; Friday carries only C. |
| IDs/times preserved | Recovery uses the checkpoint's original plan/operation/event IDs, creation timestamp and full exact event payload. |
| Final integrity | inspect-records, validate-records and check-links returned no diagnostics in each successful branch. |

Evidence: `before/` contains untouched initial fixture; `seeded/` contains Monday fixture; `after/` contains final Markdown/state excluding decision log files. Numbered `*.input.json` and `*.result.json` retain every installed CLI invocation, stdout/stderr and exit status. `*-checkpoint.json`, `*-destination-persisted.json`, `*-verified.json` and `*-query.json` retain actual transaction boundaries/events. Original log files were never edited; queries are retained from installed log-query. `actions.mjs`, `seed.mjs`, `branches.mjs`, `rollover.mjs`, `remove.mjs`, `resume.mjs` were authored during this request and retain the actual file/CLI actions. `verify.mjs` asserts actual resulting artifacts, not repository regression tests.

The read-only maintenance worker was actually invoked with gpt-6-luna, fork_turns none, bounded to this case. Its instructions/results/manifest are retained in `maintenance/`; parent revalidated records/links afterward. No maintenance-success timestamp is advanced because its pass included a prohibited direct decision-log hash. The old success was absent and remains absent.

## Retained deviations and execution errors

1. Initial future branch precreated Friday A while Monday A was still an active date. The installed plan-selection CLI reported missing-invalid-or-ambiguous-task. The writer incorrectly applied removal despite that conflict. That branch and its event/query evidence remain in `future/`; they are excluded from passing-branch verification. A separate future-valid fixture uses Tuesday's declared clock, making Monday historical and Friday the sole active date. Its removal proposal has no conflicts and its Friday result honors removedIds.
2. The maintenance worker directly hashed a decision log instead of using only log-query. This is a protocol violation even though it did not mutate the log. Acceptance assertions use log-query outputs exclusively.
3. Seed branch-copy filtering initially matched the ancestor `.temp`, resulting in an ENOENT for the branch profile after successful seed decisions. The copy was corrected to filter relative vault components. Existing seed decisions were not replayed.
4. The first evidence verifier assumed planning-prepare retains previous after a completed rollover; it returns previous null on that path. Its two failed checks are retained in first-verification-result.json. The verifier was corrected to read Monday and compare it with the original Friday initial packet. Final 12/12 assertions pass. These were evidence-check failures, not erased results.

No clean all-protocol native receipt is claimed. Behavioral coverage is complete; the two protocol deviations remain visible.
