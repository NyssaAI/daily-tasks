import fs from 'node:fs';import path from 'node:path';
import {base,evidence,save,read,cli,id,monday,friday,prepare,event,tx,writeChange,invalidate,finish,plan} from './actions.mjs';
const v=path.join(base,'vault');
const root=path.join(v,'Projects/job-search/m1-career-materials');
const a=cli('parse-record',{markdown:read(path.join(root,'t1-update-linkedin.md')),path:path.join(root,'t1-update-linkedin.md')});save(path.join(evidence,'parsed-a.json'),a);
const b=cli('parse-record',{markdown:read(path.join(root,'t2-update-resume.md')),path:path.join(root,'t2-update-resume.md')});save(path.join(evidence,'parsed-b.json'),b);
const ar=a.record??a,br=b.record??b;
const changes=[], tasks=[ar,br];
for(const [letter,title,req,dod,state,assignee] of [['C','Review draft','inspect draft','recorded review','not-started','Reviewer'],['D','Past work','past result','reviewed result','completed',null],['E','Abandoned work','draft work','reviewed result','cancelled',null],['F','Deselected work','optional draft','reviewed draft','not-started',null]]){
const tid=id(),criterion=id(),p=path.join(root,`t${tasks.length+1}-${title.toLowerCase().replaceAll(' ','-')}.md`);
const md=`---\nid: "${tid}"\ntype: task\nrecord_version: 2\ntitle: "${title}"\nowner: "synthetic@example.test"\n${assignee?`assignee: "${assignee}"\n`:''}created_at: "${monday}"\nupdated_at: "${monday}"\ntask-state: "${state}"\n${state==='completed'||state==='cancelled'?`resolved_at: "${monday}"\n`:''}project_id: "${ar.project_id}"\nmilestone_id: "${ar.milestone_id}"\n---\n# ${title}\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${ar.milestone_id} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${ar.project_id} -->\n\n## Requirements\n\n${req}\n\n## Definition of Done\n\n- [${state==='completed'?'x':' '}] ${dod} <!-- id: ${criterion} -->\n\n## Result\n\n${state==='completed'?'User explicitly attests reviewed result.':state==='cancelled'?'User explicitly cancelled draft work.':'No execution reported.'}\n`;
changes.push({path:p,before:null,after:md});tasks.push(cli('parse-record',{markdown:md,path:p}));
}
const mp=path.join(root,'m1-career-materials.md'),pp=path.join(v,'Projects/job-search/project-index.md');
const additions=tasks.slice(2).map(r=>`- [${r.state==='completed'?'x':r.state==='cancelled'?'-':' '}] [[${path.basename(r.path,'.md')}|${r.title}]] <!-- ref: ${r.id} -->`).join('\n');
changes.push({path:mp,before:read(mp),after:read(mp)+'\n'+additions+'\n'});
changes.push({path:pp,before:read(pp),after:read(pp)+'\n## Accepted synthetic work\n\n'+additions.replaceAll('[[t','[[m1-career-materials/t')+'\n'});
const log=event(v,'task.accepted',tasks.slice(2).map(r=>r.id),monday,{acceptance:'Explicit user batch C/D/E/F',terminalAttestation:'D reviewed result; E cancelled',tasks:tasks.slice(2).map(r=>({id:r.id,state:r.state}))});
const t=tx(v,'accepted-cdef',changes,log);for(const c of changes)writeChange(c);invalidate(v);
const inspected=cli('inspect-records',{projectsRoot:path.join(v,'Projects')});save(path.join(evidence,'seed-records.json'),inspected);
cli('check-closure',{recordId:tasks[3].id,records:inspected.records});finish(v,t,'accepted-cdef');
const mon=path.join(v,'Daily/2026.10.05-daily-plan.md');
const selected=[tasks[0].id,tasks[2].id,tasks[3].id,tasks[4].id];
const md=plan(v,'2026.10.05',selected,tasks,monday);
const selection=event(v,'plan.selection',selected,monday,{date:'2026.10.05',selected,removedIds:[tasks[5].id],reason:'Explicit Monday seed and F deselection'});
const st=tx(v,'monday-selection',[{path:mon,before:null,after:md}],selection,[{path:path.join(v,'.nyssaai/daily-tasks/rollover/2026.10.05.json'),after:{schemaVersion:1,date:'2026.10.05',planId:cli('parse-record',{markdown:md}).id,removedIds:[tasks[5].id]}}]);writeChange(st.checkpoint.changes[0]);invalidate(v);finish(v,st,'monday-selection');
save(path.join(evidence,'tasks.json'),Object.fromEntries(tasks.map((r,i)=>['ABCDEF'[i],r])));
fs.cpSync(v,path.join(evidence,'seeded'),{recursive:true,filter:p=>!p.includes('.daily-tasks')&&!p.includes('/.temp/')&&!p.includes('\\.temp\\')});
for(const branch of ['tuesday','interruption','future']){const dest=path.join(evidence,branch,'vault');fs.cpSync(v,dest,{recursive:true,filter:p=>!p.includes('.daily-tasks')&&!p.includes('\\.temp\\')});const profile=JSON.parse(read(path.join(dest,'.nyssaai/daily-tasks/profile.json')));profile.vaultRoot='.';save(path.join(dest,'.nyssaai/daily-tasks/profile.json'),profile);}
console.log(JSON.stringify({seeded:tasks.map(r=>({id:r.id,title:r.title,state:r.state})),selected}));
