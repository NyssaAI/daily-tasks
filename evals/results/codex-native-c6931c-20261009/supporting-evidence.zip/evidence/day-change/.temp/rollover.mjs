import fs from 'node:fs';import path from 'node:path';
import {base,evidence,save,read,json,hash,cli,id,prepare,event,tx,writeChange,invalidate,finish,plan,friday,tuesday,opts,query} from './actions.mjs';
const branch=process.argv[2]??'friday',mode=process.argv[3]??'complete';
const v=branch==='friday'?path.join(base,'vault'):path.join(evidence,branch,'vault');
const now=branch==='tuesday'?tuesday:friday;
const records=cli('inspect-records',{projectsRoot:path.join(v,'Projects')}).records;
let p=prepare(v,now);save(path.join(evidence,branch+'-before-packet.json'),p);
const planId=p.current.id??id();
const proposal=cli('plan-rollover',{vaultRoot:v,projectsRoot:p.context.projectsRoot,dailyPlansRoot:p.context.dailyPlansRoot,contextBinding:p.context.planningBinding,inventoryBinding:p.context.planningBinding,today:p.context.localDate,planId,userEmail:p.context.profile.user.email,currentRows:p.current.rows,state:p.state.rollover.value,previousDate:p.previous?.date,previousRows:p.previous?.rows,records,inventory:p.inventory});
save(path.join(evidence,branch+'-rollover-proposal.json'),proposal);console.log(JSON.stringify(proposal));
if(proposal.status==='complete'){save(path.join(evidence,branch+'-retry-no-change.json'),{planHash:p.current.sha256,state:p.state.rollover.value,query:query(v)});process.exit(0);}
if(proposal.unresolved?.length)throw Error('unresolved carry');
const selected=proposal.selected.map(r=>r.id);
let after;
if(p.current.id){after=read(p.current.path);for(const r of proposal.selected.filter(r=>!p.current.rows.some(c=>c.id===r.id))){const record=records.find(c=>c.id===r.id);const row=`| ${p.current.rows.length+1} | [ ] | Job Search | Career materials | ↪ [[../Projects/${path.relative(p.context.projectsRoot,record.path).replaceAll('\\','/').replace(/\.md$/,'')}\\|${record.title}]] <!-- ref: ${r.id} --> | — |\n`;const section=record.assignee?'### Delegated work':'### My work';const pos=after.indexOf('| --- |',after.indexOf(section));const end=after.indexOf('\n',pos);after=after.slice(0,end+1)+row+after.slice(end+1);}}
else {after=plan(v,p.context.localDate,selected,records,now,planId);for(const r of proposal.selected.filter(r=>r.carriedFrom))after=after.replace(`[[../Projects/job-search/m1-career-materials/${path.basename(records.find(c=>c.id===r.id).path,'.md')}`,`↪ [[../Projects/job-search/m1-career-materials/${path.basename(records.find(c=>c.id===r.id).path,'.md')}`);}
const log=event(v,'plan.rollover',selected,now,{date:p.context.localDate,previousDate:p.previous?.date,selected:proposal.selected});
const state={schemaVersion:1,date:p.context.localDate,planId,operationId:log.entry.operation_id,completedAt:log.entry.recorded_at,...(p.state.rollover.value?.removedIds?{removedIds:p.state.rollover.value.removedIds}:{})};
const t=tx(v,branch+'-rollover',[{path:p.current.path,before:p.current.id?read(p.current.path):null,after}],log,[{path:p.state.rollover.path,before:p.state.rollover.value,after:state}]);
t.checkpoint.contextBinding=p.context.planningBinding;t.checkpoint.planIdentity={id:planId,created_at:p.current.id?cli('parse-record',{markdown:read(p.current.path)}).created_at:now};save(t.cp,t.checkpoint);save(path.join(evidence,branch+'-rollover-checkpoint.json'),t.checkpoint);
writeChange(t.checkpoint.changes[0]);invalidate(v);
save(path.join(evidence,branch+'-destination-persisted.json'),{plan:read(p.current.path),checkpoint:json(t.cp),receiptExists:fs.existsSync(p.state.rollover.path),query:query(v)});
if(mode==='interrupt'){console.log('INTERRUPTED after destination persistence; no log append, baseline or completion receipt');process.exit(0);}
finish(v,t,branch+'-rollover');p=prepare(v,now);
const shared={...opts(v,now),expectedPlanHash:p.current.sha256,expectedPreviousHash:p.previous?.sha256??null,expectedInventoryHash:p.inventoryHash};
cli('planning-state',{...shared,action:'save-review',expectedStateHash:p.state.review.sha256,expectedReviewHash:p.reviewHash});
save(path.join(v,'.nyssaai/daily-tasks/checkin.json'),{localDay:p.context.localDate,pendingOperationIds:[],processedSourceVersions:{[p.current.path]:p.current.sha256},nextStep:'review saved',rolloverVerified:true});
save(path.join(evidence,branch+'-after-packet.json'),prepare(v,now));
