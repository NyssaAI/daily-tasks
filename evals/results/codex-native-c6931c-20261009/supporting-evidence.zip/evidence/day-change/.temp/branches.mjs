import fs from 'node:fs';import path from 'node:path';
import {base,evidence,save,read,json,cli,id,monday,tuesday,friday,prepare,event,tx,writeChange,invalidate,finish,plan,opts} from './actions.mjs';
const name=process.argv[2],v=path.join(evidence,name,'vault'),tasks=Object.values(json(path.join(evidence,'tasks.json'))).map(r=>({...r,path:path.join(v,'Projects/job-search/m1-career-materials',path.basename(r.path))}));
const date=name==='tuesday'?'2026.10.06':'2026.10.09',selected=name==='tuesday'?[tasks[1].id]:[tasks[0].id];
const fixtureNow=name==='future-valid'?tuesday:monday;
const p=prepare(v,fixtureNow);const changes=[];
if(name==='tuesday'){const mp=path.join(v,'Daily/2026.10.05-daily-plan.md'),before=read(mp);changes.push({path:mp,before,after:before.split('\n').filter(l=>!tasks.slice(2,5).some(r=>l.includes('ref: '+r.id))).join('\n')});}
const dest=path.join(v,`Daily/${date}-daily-plan.md`),md=plan(v,date,selected,tasks,fixtureNow);changes.push({path:dest,before:null,after:md});
const log=event(v,'plan.selection',selected,fixtureNow,{date,selected,reason:'Authorized independent synthetic precreated plan'});
const t=tx(v,name+'-precreated',changes,log);t.checkpoint.contextBinding=p.context.planningBinding;save(t.cp,t.checkpoint);for(const c of changes)writeChange(c);invalidate(v);finish(v,t,name+'-precreated');
save(path.join(evidence,name+'-precreated-plan.md'),md);
console.log(JSON.stringify(prepare(v,name==='tuesday'?tuesday:monday).context));
