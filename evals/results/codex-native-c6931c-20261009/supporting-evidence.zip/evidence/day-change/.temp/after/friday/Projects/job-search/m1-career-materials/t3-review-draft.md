---
id: "01a1214e-d69e-77ef-9934-f32817607c39"
type: task
record_version: 2
title: "Review draft"
owner: "synthetic@example.test"
assignee: "Reviewer"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
---
# Review draft

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

inspect draft

## Definition of Done

- [ ] recorded review <!-- id: 01a1214e-d6c6-7aaf-beea-1a3c06770a55 -->

## Result

No execution reported.
