---
id: "01a1214e-d719-7c0c-956c-6df213e6eead"
type: task
record_version: 2
title: "Past work"
owner: "synthetic@example.test"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
task-state: "completed"
resolved_at: "2026-10-05T16:00:00Z"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
---
# Past work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

past result

## Definition of Done

- [x] reviewed result <!-- id: 01a1214e-d748-7e88-9c79-436acdf10dc8 -->

## Result

User explicitly attests reviewed result.
