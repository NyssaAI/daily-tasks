import path from 'node:path';
import {evidence,save,read,json,cli,monday,tuesday,prepare,event,tx,writeChange,invalidate,finish} from './actions.mjs';
const branch=process.argv[2],v=path.join(evidence,branch,'vault'),now=branch==='future'?monday:tuesday,date=branch.startsWith('future')?'2026.10.09':'2026.10.06';
const a=json(path.join(evidence,'tasks.json')).A.id,p=prepare(v,now);
const proposal=cli('plan-selection',{vaultRoot:v,projectsRoot:p.context.projectsRoot,dailyPlansRoot:p.context.dailyPlansRoot,contextBinding:p.context.planningBinding,inventoryBinding:p.context.planningBinding,inventory:p.inventory,taskIds:[a],action:'remove',today:p.context.localDate,date});
save(path.join(evidence,branch+'-removal-proposal.json'),proposal);console.log(JSON.stringify(proposal));
if(proposal.conflicts.length)throw Error('removal proposal conflict; no writes permitted');
const target=path.join(v,`Daily/${date}-daily-plan.md`),before=read(target),after=before.split('\n').filter(l=>!l.includes('ref: '+a)).join('\n');
const statePath=path.join(v,`.nyssaai/daily-tasks/rollover/${date}.json`);let prior=null;try{prior=json(statePath);}catch{}
const parsed=cli('parse-record',{markdown:before,path:target});
const state={...(prior??{schemaVersion:1,date,planId:parsed.id}),removedIds:[...new Set([...(prior?.removedIds??[]),a])]};
const log=event(v,'plan.deselection',[a],now,{date,removedIds:[a],reason:branch==='future'?'Explicit future-day removal':'Explicit Tuesday removal'});
const t=tx(v,branch+'-removal',[{path:target,before,after}],log,[{path:statePath,before:prior,after:state}]);t.checkpoint.contextBinding=p.context.planningBinding;save(t.cp,t.checkpoint);writeChange(t.checkpoint.changes[0]);invalidate(v);finish(v,t,branch+'-removal');save(path.join(evidence,branch+'-after-removal-packet.json'),prepare(v,now));
