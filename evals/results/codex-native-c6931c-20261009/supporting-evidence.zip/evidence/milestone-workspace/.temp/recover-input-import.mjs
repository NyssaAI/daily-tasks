import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';import crypto from 'node:crypto';
const root=process.cwd(),s=path.join(root,'.temp'),state=path.join(root,'vault/.nyssaai/daily-tasks');
const file=path.join(state,'operations/[object Object].json'),op=JSON.parse(fs.readFileSync(file));
op.operation_id=op.operation_id.id;op.event.operation_id=op.operation_id;op.event.id=op.event.id.id;
for(const e of op.files){if(crypto.createHash('sha256').update(fs.readFileSync(e.path)).digest('hex')!==e.after)throw Error('Recovery conflict');}
fs.writeFileSync(file,JSON.stringify(op,null,2));
const entry='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration1/codex-home/plugins/cache/daily-tasks-native-eval-iteration1/daily-tasks/0.3.3/bin/daily-tasks.mjs';
function cli(operation,input){const f=path.join(s,'recovery-'+operation+'-input.json');fs.writeFileSync(f,JSON.stringify(input,null,2));const r=spawnSync(process.execPath,[entry,operation,'--input',f],{encoding:'utf8'});fs.writeFileSync(path.join(s,'recovery-'+operation+'-result.json'),JSON.stringify(r,null,2));if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
cli('log-append',{projectsRoot:path.join(root,'vault/Projects'),entry:op.event});
const q=cli('log-query',{projectsRoot:path.join(root,'vault/Projects')});fs.writeFileSync(path.join(s,'recovered-input-import.json'),JSON.stringify({op,query:q},null,2));fs.unlinkSync(file);
