---
id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
type: "project"
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
project-state: "not-started"
---
# Job Search

Prepare career materials for the job search.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 --> | | Both reviewed artifacts linked. | Synthetic User | — |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 --> | Draft a summary. | Synthetic User | — |
| | [-] [[m1-career-materials/t1-update-linkedin\|~~Update LinkedIn~~]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 --> | Draft a headline. | Synthetic User | — |

| | [ ] [[m1-career-materials/t3-polish-summary\|Polish summary]] <!-- ref: 01a1214f-57f4-7530-b44d-9344b8c98b2f --> | Polish summary. | Synthetic User | — |

## External blockers

- [x] [[blockers/b1-await-review|Await review]] <!-- ref: 01a1214f-59ca-736a-9822-c89819faceba -->
- [ ] [[blockers/b2-await-source|Await source]] <!-- ref: 01a1214f-59f5-7779-8f51-5ad1a3794a61 -->
- [ ] [[blockers/b3-await-signoff|Await signoff]] <!-- ref: 01a1214f-5d10-7690-b9d3-89a156051698 -->
