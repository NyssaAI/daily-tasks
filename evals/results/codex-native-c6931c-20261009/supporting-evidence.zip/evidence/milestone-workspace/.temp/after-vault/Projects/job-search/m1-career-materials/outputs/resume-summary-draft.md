# Resume summary draft

Career professional seeking the next opportunity, with an emphasis on clear communication and thoughtful execution.

Draft for review. Wording aligns with the [LinkedIn headline](career-headline-draft.md). The supplied synthetic source contains no experience facts; role, achievements and credentials await user input.
