---
id: "01a1214f-5d10-7690-b9d3-89a156051698"
type: blocker
record_version: 2
title: "Await signoff"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T15:36:51.767Z"
updated_at: "2026-10-09T15:36:51.767Z"
---
# B3 — Await signoff

External impediment: await signoff.

## Resolution condition

Signoff received.

## Resolution evidence

Pending.

## Blocks


