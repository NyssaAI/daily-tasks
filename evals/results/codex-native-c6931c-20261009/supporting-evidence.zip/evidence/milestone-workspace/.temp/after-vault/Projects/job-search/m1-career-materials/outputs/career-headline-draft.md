# LinkedIn headline draft

Career professional | Bringing clear communication and thoughtful execution to the next opportunity

Draft for review. The supplied synthetic source contains no role or experience facts; this headline makes no specific credential claims.
