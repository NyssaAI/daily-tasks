import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration1/codex-home/plugins/cache/daily-tasks-native-eval-iteration1/daily-tasks/0.3.3';
const cli=path.join(pkg,'bin/daily-tasks.mjs'), projects=path.join(vault,'1-projects'), state=path.join(vault,'.nyssaai/daily-tasks');
fs.mkdirSync(scratch,{recursive:true});
let sequence=Math.max(0,...fs.readdirSync(scratch).map(n=>Number(n.match(/^(\d+)-/)?.[1]??0)));
const save=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2));};
function call(op,input){const tag=String(++sequence).padStart(3,'0')+'-'+op; const p=path.join(scratch,tag+'.input.json');if(input!==undefined)save(p,input);const args=[cli,op,...(input===undefined?[]:['--input',p])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(path.join(scratch,tag+'.result.json'),{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const id=()=>{const v=call('new-id');return typeof v==='string'?v:v.id;};
const hash=s=>s===null?null:createHash('sha256').update(s).digest('hex');
if(!fs.existsSync(path.join(scratch,'before.json')))save(path.join(scratch,'before.json'),{vaultContents:fs.readdirSync(vault),profilePresent:fs.existsSync(path.join(state,'profile.json'))});
fs.mkdirSync(projects,{recursive:true});
const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:vault,projectsRoot:projects,dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
const validation=call('validate-profile',profile);if(validation.valid===false)throw Error(JSON.stringify(validation));
save(path.join(state,'profile.json'),profile);
const context=call('resolve-context',{vaultRoot:vault,configRoot:state});save(path.join(scratch,'context.json'),context);
const P=id(),M=id(),D=id(),R=id(),DC=id(),RC=id(),MC=id();
const project=path.join(projects,'demo/project-index.md'), milestone=path.join(projects,'demo/m1-draft/m1-draft.md'), draft=path.join(projects,'demo/m1-draft/t1-draft-note.md'),review=path.join(projects,'demo/m1-draft/t2-review-note.md');
const snapshot=()=>Object.fromEntries([project,milestone,draft,review].map(p=>[p,fs.existsSync(p)?fs.readFileSync(p,'utf8'):null]));
function commit(action,recordIds,actor,timing,changes,before,after,words){
 const previous=fs.existsSync(path.join(scratch,action+'.checkpoint.json'))?JSON.parse(fs.readFileSync(path.join(scratch,action+'.checkpoint.json'),'utf8')):null;
 const entry=previous?.event??{id:id(),operation_id:id(),action,record_ids:recordIds,actor,...timing,before,after,...(words?{original_words:words}:{})};
 if(previous)timing={activity_at:entry.activity_at,recorded_at:entry.recorded_at,time_defaulted:entry.time_defaulted};
 const old=snapshot();const checkpoint={operation_id:entry.operation_id,planningBinding:context.planningBinding,event:entry,files:Object.entries(changes).map(([p,s])=>({path:p,beforeHash:hash(old[p]??null),afterHash:hash(s),before:old[p]??null,after:s})),changes:[]};
 const pending=path.join(state,'operations',entry.operation_id+'.json');save(pending,checkpoint);save(path.join(scratch,action+'.before.json'),old);save(path.join(scratch,action+'.checkpoint.json'),checkpoint);
 for(const [p,s] of Object.entries(changes)){const actual=fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;if(hash(actual)!==hash(old[p]??null))throw Error('Concurrent edit');save(p,s);}
 if(Object.keys(changes).length)call('invalidate-project-index',{vaultRoot:vault});
 const inspected=call('inspect-records',{projectsRoot:projects});save(path.join(scratch,action+'.inspection.json'),inspected);
 const logInput={projectsRoot:projects,entry};if(entry.activity_at!==timing.activity_at||entry.recorded_at!==timing.recorded_at)throw Error('Time changed');call('log-append',logInput);
 const query=call('log-query',{projectsRoot:projects,action});const serialized=JSON.stringify(query);if(!serialized.includes(entry.id))throw Error('Missing event');
 save(path.join(scratch,action+'.after.json'),snapshot());
 save(path.join(state,'reconciliation.json'),{records:Object.fromEntries(inspected.records.map(r=>[r.id,{canonical:r.metadata??r,files:Object.fromEntries(Object.entries(snapshot()).filter(([,s])=>s?.includes(r.id)).map(([p,s])=>[p,{sha256:hash(s)}]))}]))});
 fs.unlinkSync(pending);return entry;
}
const person={kind:'person',id:'synthetic@example.test'},agent={kind:'agent',id:'Codex'};
commit('profile.configured',[],person,call('activity-time',{}),{},null,profile,'Configure this vault only');
const time=call('activity-time',{}),stamp=time.recorded_at;
function meta(type,title,uuid,extra=''){return `---\nid: ${uuid}\ntype: ${type}\n${type==='project'?'':'record_version: 2\n'}title: "${title}"\n${type}-state: not-started\nowner: "synthetic@example.test"\n${extra}created_at: "${stamp}"\nupdated_at: "${stamp}"\n---\n`;}
const changes={
 [project]:meta('project','Demo',P)+`# Demo\n\nDraft and review a note.\n\n## Project Summary\n\n- [ ] [[m1-draft/m1-draft|M1 Draft]] <!-- ref: ${M} -->\n- [ ] [[m1-draft/t1-draft-note|Draft note]] <!-- ref: ${D} -->\n- [ ] [[m1-draft/t2-review-note|Review note]] <!-- ref: ${R} -->\n`,
 [milestone]:meta('milestone','Draft',M,`project_id: "${P}"\n`)+`# M1 Draft\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${P} -->\n\n## Outcome\n\nDraft and review the paragraph.\n\n## Definition of Done\n\n- [ ] Both task definitions of done are satisfied. <!-- id: ${MC} -->\n\n## Tasks\n\n- [ ] [[t1-draft-note|Draft note]] <!-- ref: ${D} -->\n- [ ] [[t2-review-note|Review note]] <!-- ref: ${R} -->\n`,
 [draft]:meta('task','Draft note',D,`project_id: "${P}"\nmilestone_id: "${M}"\n`)+`# M1-T1 Draft note\n\n**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: ${M} -->\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${P} -->\n\n## Requirements\n\nWrite a paragraph.\n\n## Definition of Done\n\n- [ ] Reviewed paragraph. <!-- id: ${DC} -->\n`,
 [review]:meta('task','Review note',R,`assignee: "Reviewer"\nproject_id: "${P}"\nmilestone_id: "${M}"\n`)+`# M1-T2 Review note\n\n**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: ${M} -->\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${P} -->\n\n## Requirements\n\nInspect the paragraph.\n\n## Definition of Done\n\n- [ ] Recorded review. <!-- id: ${RC} -->\n`
};
for(const dir of ['inputs','outputs'])fs.mkdirSync(path.join(path.dirname(milestone),dir),{recursive:true});
commit('records.accepted',[P,M,D,R],person,time,changes,null,{project:'Demo',milestone:'M1 Draft',tasks:['Draft note','Review note'],reviewAssignee:'Reviewer'},'Explicitly create project Demo, M1 Draft, Draft note and Review note');
const start=call('activity-time',{reported:'earlier this morning'});save(path.join(scratch,'start-exact-time.json'),start);
const started=fs.readFileSync(draft,'utf8').replace('task-state: not-started','task-state: in-progress').replace(`updated_at: "${stamp}"`,`updated_at: "${start.recorded_at}"\nstarted_at: "${start.activity_at}"`);
const views={};for(const p of [project,milestone])views[p]=fs.readFileSync(p,'utf8').replace('- [ ] [['+(p===project?'m1-draft/':'')+'t1-draft-note','- [>] [['+(p===project?'m1-draft/':'')+'t1-draft-note');
commit('task.started',[D],person,start,{[draft]:started,...views},{'task-state':'not-started'},{'task-state':'in-progress',started_at:start.activity_at},'earlier this morning');
const reassignedTime=call('activity-time',{});commit('task.reassigned',[R],agent,reassignedTime,{[review]:fs.readFileSync(review,'utf8').replace('assignee: "Reviewer"','assignee: "Editor"').replace(`updated_at: "${stamp}"`,`updated_at: "${reassignedTime.recorded_at}"`)},{assignee:'Reviewer',owner:'synthetic@example.test','task-state':'not-started'},{assignee:'Editor',owner:'synthetic@example.test','task-state':'not-started'},'Acting as agent reassign Review note to Editor; human ownership cannot change autonomously.');
const final=call('inspect-records',{projectsRoot:projects});save(path.join(scratch,'final-records.json'),final);call('validate-records',{records:final.records});call('check-links',{records:final.records});call('log-query',{projectsRoot:projects});const display=call('format-time',{time:start.activity_at,timezone:'America/Chicago'});save(path.join(scratch,'local-display.json'),display);
save(path.join(scratch,'ids.json'),{P,M,D,R,DC,RC,MC});console.log(JSON.stringify({display,final},null,2));
