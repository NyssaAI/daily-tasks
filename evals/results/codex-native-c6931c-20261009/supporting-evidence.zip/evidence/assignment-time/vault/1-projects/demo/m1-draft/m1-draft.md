---
id: 01a1214d-f946-7694-9278-3812fb57ff6a
type: milestone
record_version: 2
title: "Draft"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a1214d-f91e-7f07-b2e9-0b9cd9e9baf2"
created_at: "2026-10-09T15:35:21.066Z"
updated_at: "2026-10-09T15:35:21.066Z"
---
# M1 Draft

**Project:** [[../project-index|Demo]] <!-- ref: 01a1214d-f91e-7f07-b2e9-0b9cd9e9baf2 -->

## Outcome

Draft and review the paragraph.

## Definition of Done

- [ ] Both task definitions of done are satisfied. <!-- id: 01a1214d-fa0a-7349-9795-57ecc495c8bc -->

## Tasks

- [>] [[t1-draft-note|Draft note]] <!-- ref: 01a1214d-f96d-7308-b171-7d739bcc240d -->
- [ ] [[t2-review-note|Review note]] <!-- ref: 01a1214d-f994-75f3-b89b-19e5fa76fb7c -->
