---
id: 01a1214d-f96d-7308-b171-7d739bcc240d
type: task
record_version: 2
title: "Draft note"
task-state: in-progress
owner: "synthetic@example.test"
project_id: "01a1214d-f91e-7f07-b2e9-0b9cd9e9baf2"
milestone_id: "01a1214d-f946-7694-9278-3812fb57ff6a"
created_at: "2026-10-09T15:35:21.066Z"
updated_at: "2026-10-09T15:35:21.378Z"
started_at: "2026-10-09T15:35:21.378Z"
---
# M1-T1 Draft note

**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: 01a1214d-f946-7694-9278-3812fb57ff6a -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a1214d-f91e-7f07-b2e9-0b9cd9e9baf2 -->

## Requirements

Write a paragraph.

## Definition of Done

- [ ] Reviewed paragraph. <!-- id: 01a1214d-f9bc-72e1-b443-ff7466495d5a -->
