---
id: 01a1214d-f91e-7f07-b2e9-0b9cd9e9baf2
type: project
title: "Demo"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T15:35:21.066Z"
updated_at: "2026-10-09T15:35:21.066Z"
---
# Demo

Draft and review a note.

## Project Summary

- [ ] [[m1-draft/m1-draft|M1 Draft]] <!-- ref: 01a1214d-f946-7694-9278-3812fb57ff6a -->
- [>] [[m1-draft/t1-draft-note|Draft note]] <!-- ref: 01a1214d-f96d-7308-b171-7d739bcc240d -->
- [ ] [[m1-draft/t2-review-note|Review note]] <!-- ref: 01a1214d-f994-75f3-b89b-19e5fa76fb7c -->
