---
id: "01a1214f-87d5-735b-9d6d-2ddb90617c52"
type: task
record_version: 2
title: "Independent note"
owner: "synthetic@example.test"
task-state: completed
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
created_at: "2026-10-09T15:37:02.756Z"
updated_at: "2026-10-09T15:37:02.756Z"
document-maturity: reviewed
---
# M1-T3 — Independent note

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Create a local note.

## Definition of Done

- [x] Reviewed note. <!-- id: 01a1214f-87fc-7c91-accf-c96c1beff4c8 -->

## Inputs

User-authorized synthetic evidence.

## Output and delivery

Local note in outputs/independent-note.md.

## Verification

User attests reviewed synthetic evidence. Verify local note exists and link it.

## Result

Delivered [[outputs/independent-note|Independent note]]. User attests reviewed synthetic evidence.
