﻿import {cli,parse,t1,projects,temp,json,id} from './session.mjs';
console.log('id',id()); console.log(JSON.stringify(parse(t1),null,2));console.log(JSON.stringify(cli('inspect-records',{projectsRoot:projects}),null,2));
