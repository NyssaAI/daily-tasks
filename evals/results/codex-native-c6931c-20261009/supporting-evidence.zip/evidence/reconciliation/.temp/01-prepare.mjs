﻿import {cli,vault,json,temp,snapshot} from './session.mjs';
snapshot('00-before');const p=cli('planning-prepare',{vaultRoot:vault});json(`${temp}/initial-packet.json`,p);console.log(JSON.stringify(p,null,2));
