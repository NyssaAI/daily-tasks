﻿import {cli} from './session.mjs';
console.log(cli('reconcile-record',{base:{state:'not-started'},current:{state:'completed'},views:[{state:'not-started'}]}));
