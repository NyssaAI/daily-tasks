﻿import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export const root=process.cwd(), temp=path.join(root,'.temp'), vault=path.join(root,'vault'), pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration1/codex-home/plugins/cache/daily-tasks-native-eval-iteration1/daily-tasks/0.3.3';
export const read=p=>fs.readFileSync(p,'utf8'), write=(p,s)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s)}, json=(p,v)=>write(p,JSON.stringify(v,null,2)), hash=s=>createHash('sha256').update(s).digest('hex');
let seq=fs.existsSync(path.join(temp,'sequence.json'))?JSON.parse(read(path.join(temp,'sequence.json'))):0;
export function cli(op,input){const n=String(++seq).padStart(3,'0'), f=path.join(temp,`${n}-${op}-input.json`); if(input!==undefined)json(f,input); const args=[`${pkg}/bin/daily-tasks.mjs`,op,...(input===undefined?[]:['--input',f])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});json(path.join(temp,`${n}-${op}-result.json`),{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});json(path.join(temp,'sequence.json'),seq);if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout)}
export const id=()=>cli('new-id').id;
export const state=path.join(vault,'.nyssaai/daily-tasks'), projects=path.join(vault,'Projects'), m=path.join(projects,'job-search/m1-career-materials'), t1=path.join(m,'t1-update-linkedin.md'),t2=path.join(m,'t2-update-resume.md'),mil=path.join(m,'m1-career-materials.md'),project=path.join(projects,'job-search/project-index.md');
export const parse=p=>cli('parse-record',{markdown:read(p),path:p});
export function snapshot(name){for(const p of [t1,t2,mil,project,...fs.readdirSync(path.join(vault,'Daily')).map(f=>path.join(vault,'Daily',f))])write(path.join(temp,name,path.relative(vault,p)),read(p));}
