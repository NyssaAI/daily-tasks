﻿import {cli,json,read,hash,state,temp,t1,parse,snapshot} from './session.mjs';
import {commit} from './transactions.mjs';
const {plan,a}=JSON.parse(read(`${temp}/case-context.json`)),baseline=JSON.parse(read(`${state}/reconciliation.json`)),current=parse(t1);
const unchanged=hash(read(plan))===baseline.records[a].views[plan].sha256;
const result=cli('reconcile-record',{base:{id:a,state:'completed'},current:{id:a,state:current.state},views:[{id:a,state:unchanged?'completed':'not-started'}]});json(`${temp}/stale-checkin.json`,{unchanged,currentState:current.state,result});console.log(result);
const text=read(plan).split('\n').map(l=>l.includes(`ref: ${a}`)?l.replace('[ ]','[x]'):l).join('\n');commit('view.refreshed',[a],[{path:plan,before:read(plan),after:text}],{renderedState:'not-started'},{renderedState:'completed'});baseline.records[a].views[plan]={fields:{state:'completed'},sha256:hash(read(plan))};json(`${state}/reconciliation.json`,baseline);snapshot('03-stale-checkin-refreshed');
