import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), evidence=path.join(root,'.temp'), vault=path.join(root,'vault');
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration1/codex-home/plugins/cache/daily-tasks-native-eval-iteration1/daily-tasks/0.3.3/bin/daily-tasks.mjs';
let seq=0; const results=[];
function save(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2));}
function call(op,input){const stem=path.join(evidence,`${String(++seq).padStart(4,'0')}-${op}`); const args=[cli,op];if(input!==undefined){save(stem+'.input.json',input);args.push('--input',stem+'.input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(stem+'.result.json',{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const ctx=call('resolve-context',{vaultRoot:vault});
const projects=ctx.projectsRoot, state=ctx.stateRoot;
const scan=()=>call('inspect-records',{projectsRoot:projects});
let records=scan().records;
const P=records.find(r=>r.type==='project').id,M=records.find(r=>r.type==='milestone').id,T=records.find(r=>r.title==='Update LinkedIn').id,R=records.find(r=>r.title==='Update resume').id;
const paths=Object.fromEntries(records.map(r=>[r.id,r.path]));
const hash=s=>s===null?null:crypto.createHash('sha256').update(s).digest('hex');
const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
function field(s,key,value){const line=`${key}: ${JSON.stringify(value)}`;return new RegExp(`^${key}:.*$`,'m').test(s)?s.replace(new RegExp(`^${key}:.*$`,'m'),line):s.replace(/^---\r?\n/,`---\n${line}\n`);}
function removeField(s,key){return s.replace(new RegExp(`^${key}:.*\\r?\\n`,'m'),'');}
function criterion(s,checked){return s.replace(/(- )\[[ x]\](.*<!-- id:)/g,`$1[${checked?'x':' '}]$2`);}
function assert(name,condition,detail){results.push({name,passed:!!condition,detail});save(path.join(evidence,'assertions.json'),results);if(!condition)throw Error(`Assertion failed: ${name}`);}
function closure(id,name,allowed){records=scan().records;const r=call('check-closure',{recordId:id,records});assert(name,r.allowed===allowed,r);return r;}
function transaction(name,edit){const time=call('activity-time',{}),op=call('new-id').id,event=call('new-id').id;const changes=new Map();const get=id=>changes.get(paths[id])??read(paths[id]);const put=(id,s)=>changes.set(paths[id],s);edit({get,put,time,changes});
 // Render existing project and milestone views from canonical states without touching DoD.
 const latest=Object.fromEntries(Object.entries(paths).map(([id,p])=>[id,changes.get(p)??read(p)]));
 for(const parent of [M,P]){let s=latest[parent];if(!s)continue;s=s.split('\n').map(line=>{const match=line.match(/<!-- ref: ([\w-]+) -->/);if(!match||!line.includes('[')||!latest[match[1]])return line;const child=latest[match[1]],st=child.match(/^(?:task|milestone)-state: "?([\w-]+)"?/m)?.[1];if(!st)return line;const mark={completed:'x',cancelled:'-', 'in-progress':'>','not-started':' '}[st];let out=line.replace(/\[[ x>\-]\]/,`[${mark}]`);if(st==='cancelled'&&!out.includes('~~'))out=out.replace(/(\[\[.*?\]\])/,'~~$1~~');if(st!=='cancelled')out=out.replaceAll('~~','');return out;}).join('\n');if(s!==read(paths[parent]))changes.set(paths[parent],s);}
 const effects=[...changes].filter(([p,s])=>s!==read(p)).map(([p,after])=>({path:p,before:read(p),after,beforeHash:hash(read(p)),afterHash:hash(after)}));
 const entry={id:event,operation_id:op,action:'acceptance.closure.'+name,record_ids:Object.keys(paths).filter(id=>effects.some(e=>e.path===paths[id])),actor:{kind:'agent',id:'codex'},...time,original_words:'User authorized scenario5 manual edits and synthetic reviewed evidence on existing records only.',before:effects.map(e=>({path:e.path,sha256:e.beforeHash})),after:{reason:name,files:effects.map(e=>({path:e.path,sha256:e.afterHash}))}};
 const checkpoint={operation_id:op,event:entry,planningBinding:ctx.planningBinding,changes:effects,status:'pending'};const cp=path.join(state,'operations',op+'.json');save(cp,checkpoint);const dir=path.join(evidence,'actions',name);save(path.join(dir,'checkpoint.json'),checkpoint);
 for(let i=0;i<effects.length;i++){const e=effects[i];if(hash(read(e.path))!==e.beforeHash)throw Error('Concurrent edit');save(path.join(dir,`${i}-before.md`),e.before??'ABSENT');save(e.path,e.after);save(path.join(dir,`${i}-after.md`),read(e.path));}
 const actual=scan();const validation=call('validate-records',{records:actual.records});const links=call('check-links',{records:actual.records});save(path.join(dir,'validation.json'),{validation,links});
 call('log-append',{projectsRoot:projects,entry});call('invalidate-project-index',{vaultRoot:vault});const query=call('log-query',{projectsRoot:projects,limit:1000});const logged=query.entries?.find(e=>e.operation_id===op);if(!logged||JSON.stringify(logged)!==JSON.stringify(entry))throw Error('Log payload mismatch');
 const baseline={records:Object.fromEntries(actual.records.map(r=>[r.id,{canonical:r,sha256:hash(read(r.path)),projections:r.projections}]))};save(path.join(state,'reconciliation.json'),baseline);save(path.join(dir,'completed.json'),{...checkpoint,status:'completed'});fs.unlinkSync(cp);
}
function setState(x,id,value){let s=field(x.get(id),`${id===P?'project':id===M?'milestone':id===B?'blocker':'task'}-state`,value);s=field(s,'updated_at',x.time.recorded_at);s=value==='completed'||value==='cancelled'||value==='resolved'?field(s,'resolved_at',x.time.activity_at):removeField(s,'resolved_at');x.put(id,s);}
let B;
function reopen(name,edit,ids){transaction(name,x=>{edit(x);const proposed=scan().records.map(r=>{if(!paths[r.id])return r;const s=x.get(r.id);return call('parse-record',{markdown:s,path:r.path});});const answer=call('reopen-ancestors',{records:proposed,changedIds:ids});save(path.join(evidence,name+'-proposal.json'),answer);for(const r of answer.records){const old=proposed.find(a=>a.id===r.id);if(old&&old.state!==r.state)setState(x,r.id,r.state);}});}
function close(id,name){closure(id,name+'-eligible',true);transaction(name,x=>setState(x,id,id===B?'resolved':'completed'));}
function closeParents(prefix){close(M,prefix+'-milestone');close(P,prefix+'-project');}
save(path.join(evidence,'installed-instructions.json'),{cli,skills:['daily-tasks','daily-tasks-records','daily-tasks-setup'],source:'installed bundle; current case; evals/README.md scenario5',host:'Codex native tool session',model:'not exposed'});
call('log-query',{projectsRoot:projects,limit:1000});
closure(T,'unchecked-task-dod-denies',false);closure(M,'unresolved-children-deny',false);closure(P,'unresolved-milestone-denies',false);
const originalTask=read(paths[T]);
transaction('missing-task-dod',x=>x.put(T,x.get(T).replace(/## Definition of Done[\s\S]*?(?=## Inputs)/,'')));
closure(T,'missing-v2-dod-denies',false);
transaction('empty-task-dod',x=>x.put(T,originalTask.replace(/(- )\[[ x]\].*<!-- id:.*-->\r?\n/,'')));
closure(T,'empty-v2-dod-denies',false);
transaction('restore-original-task-criterion',x=>x.put(T,originalTask));
B=call('new-id').id;paths[B]=path.join(projects,'job-search','blockers','b1-await-approval.md');
transaction('shared-blocker',x=>{x.put(B,`---\nid: "${B}"\ntype: blocker\nrecord_version: 2\ntitle: "Await approval"\nblocker-state: open\nowner: "synthetic@example.test"\nproject_id: "${P}"\ncreated_at: "${x.time.recorded_at}"\nupdated_at: "${x.time.recorded_at}"\n---\n# Await approval\n\nSynthetic reviewer approval of both career artifacts is pending.\n\n## Resolution condition\nBoth artifacts have explicit synthetic reviewer approval.\n\n## Resolution evidence\nAwaiting authorized synthetic review.\n\n## Blocks\n- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: ${T} -->\n- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: ${R} -->\n`);for(const id of [T,R])x.put(id,x.get(id)+`\n## Blocked by\n- [[../blockers/b1-await-approval|Await approval]] <!-- ref: ${B} -->\n`);});
transaction('reviewed-artifacts',x=>{const folder=path.dirname(paths[T]);for(const [id,file,content] of [[T,'reviewed-headline.md','Software engineer building reliable tools and clear workflows.'],[R,'reviewed-summary.md','Software engineer experienced in dependable applications, collaboration, and practical problem solving.']]){x.changes.set(path.join(folder,'outputs',file),`# Synthetic reviewed artifact\n\n${content}\n\nReviewed by Codex under explicit synthetic-test authority: requirement checked, locally saved, wording reviewed.\n`);let s=criterion(x.get(id),true).replace('Work has not started; no artifact has been produced or reviewed.',`Synthetic review completed. Artifact: [Reviewed artifact](outputs/${file}).`);s=s.replace('Link the actual artifact here and from the milestone after review.',`Reviewed artifact: [Local output](outputs/${file}).`);x.put(id,s);}x.put(M,x.get(M)+'\n## Reviewed artifacts\n- [Headline](outputs/reviewed-headline.md)\n- [Summary](outputs/reviewed-summary.md)\n');});
closure(T,'shared-open-blocker-denies-linkedin',false);closure(R,'shared-open-blocker-denies-resume',false);
transaction('resolve-shared-approval',x=>{setState(x,B,'resolved');x.put(B,x.get(B).replace('Awaiting authorized synthetic review.','Both local artifacts reviewed and approved under user-authorized synthetic evidence.'));});
closure(M,'milestone-dod-and-children-still-deny',false);
transaction('cancel-resume-dependency',x=>{setState(x,R,'cancelled');x.put(T,x.get(T)+`\n## Depends on\n- [[t2-update-resume|Update resume]] <!-- ref: ${R} -->\n`);x.put(R,x.get(R)+`\n## Required by\n- [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${T} -->\n`);});
closure(T,'cancelled-dependency-informational',true);close(T,'complete-linkedin');closure(M,'milestone-unchecked-dod-denies-with-terminal-children',false);
transaction('explicitly-reopen-resume',x=>setState(x,R,'not-started'));closure(M,'unresolved-child-denies-after-task-complete',false);close(R,'complete-resume');
transaction('satisfy-milestone-dod',x=>x.put(M,criterion(x.get(M),true)));closeParents('initial-close');
reopen('reopen-shared-blocker',x=>setState(x,B,'open'),[B]);records=scan().records;assert('blocker-reopens-parents-preserves-tasks',records.filter(r=>[T,R].includes(r.id)).every(r=>r.state==='completed')&&records.filter(r=>[M,P].includes(r.id)).every(r=>r.state!=='completed'),records);closure(M,'reopened-blocker-gates-parent',false);
transaction('resolve-reopened-blocker',x=>setState(x,B,'resolved'));closeParents('after-blocker');
reopen('uncheck-milestone-dod',x=>x.put(M,criterion(x.get(M),false)),[M]);records=scan().records;assert('milestone-dod-reopens-parents-preserves-tasks',records.filter(r=>[T,R].includes(r.id)).every(r=>r.state==='completed')&&records.filter(r=>[M,P].includes(r.id)).every(r=>r.state!=='completed'),records);
transaction('restore-milestone-dod',x=>x.put(M,criterion(x.get(M),true)));closeParents('after-milestone-dod');
reopen('uncheck-task-dod',x=>x.put(T,criterion(x.get(T),false)),[T]);records=scan().records;assert('task-dod-reopens-task-and-parents',records.filter(r=>[T,M,P].includes(r.id)).every(r=>r.state!=='completed')&&records.find(r=>r.id===R).state==='completed',records);
transaction('restore-task-dod-and-start',x=>{x.put(T,field(criterion(x.get(T),true),'started_at',x.time.activity_at));setState(x,T,'in-progress');});close(T,'recomplete-linkedin');closeParents('before-explicit-reopen');
reopen('explicit-reopen-not-started',x=>setState(x,T,'not-started'),[T]);records=scan().records;assert('explicit-not-started-overrides-started-at',records.find(r=>r.id===T).state==='not-started'&&!!records.find(r=>r.id===T).started_at&&records.filter(r=>[M,P].includes(r.id)).every(r=>r.state!=='completed'),records);
close(T,'final-complete-linkedin');closeParents('final-close');
records=scan().records;assert('final-exact-record-identities',records.length===5&&records.every(r=>[P,M,T,R,B].includes(r.id)),records);assert('final-all-eligible-records-closed',records.every(r=>r.state===(r.type==='blocker'?'resolved':'completed')),records);
const links=call('check-links',{records});save(path.join(evidence,'final-links.json'),links);call('log-query',{projectsRoot:projects,limit:1000});
save(path.join(evidence,'summary.md'),`# Scenario 5 closure\n\n${results.length} assertions passed. Exact existing project, milestone and two task identities preserved; one shared Await approval blocker added. Original LinkedIn criterion restored. Both tasks and parents completed; blocker resolved.\n\nCLI inputs/results, operation before/after snapshots and queried decision history retained alongside this report. This is the actual installed-skill-authored native session workflow, not regression-test or packaging activation evidence.\n`);
console.log(JSON.stringify({assertions:results.length,passed:results.every(r=>r.passed)}));
