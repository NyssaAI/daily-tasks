# Synthetic reviewed artifact

Software engineer building reliable tools and clear workflows.

Reviewed by Codex under explicit synthetic-test authority: requirement checked, locally saved, wording reviewed.
