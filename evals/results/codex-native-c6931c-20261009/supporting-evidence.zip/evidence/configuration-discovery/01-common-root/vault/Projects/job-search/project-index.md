---
id: "01a12125-7ba5-7700-98fd-8e9d0f32ebe4"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:07.099Z"
updated_at: "2026-10-09T15:35:57.360Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [ ] [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1: update LinkedIn and resume]] <!-- ref: 01a1214e-885f-74e7-9a37-42dfe3e505c3 -->
