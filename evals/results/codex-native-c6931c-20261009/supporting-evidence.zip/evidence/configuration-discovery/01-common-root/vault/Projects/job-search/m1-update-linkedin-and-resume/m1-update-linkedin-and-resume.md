---
id: 01a1214e-885f-74e7-9a37-42dfe3e505c3
type: milestone
record_version: 2
title: "update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-7ba5-7700-98fd-8e9d0f32ebe4"
created_at: "2026-10-09T15:35:57.360Z"
updated_at: "2026-10-09T15:35:57.360Z"
---
# M1 — update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-7ba5-7700-98fd-8e9d0f32ebe4 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] reviewed career materials <!-- id: 01a1214e-8888-791b-aec7-3631f9a01f9d -->
