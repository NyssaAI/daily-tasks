import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const hash=b=>createHash('sha256').update(b).digest('hex');
const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const write=async(p,v)=>fs.writeFile(p,JSON.stringify(v,null,2)+'\n');
const results=await read('.temp/results.json');
for(const result of results){
 const evidence=result.evidence, caseRoot=path.dirname(path.dirname(evidence));
 const files=await fs.readdir(evidence);let records;
 for(const name of files.filter(n=>n.endsWith('.result.json'))){const transcript=await read(path.join(evidence,name));assert.equal(transcript.exitCode,0);const value=JSON.parse(transcript.stdout);if(value.diagnostics)assert.deepEqual(value.diagnostics,[]);if(name.includes('inspect-records'))records=value.records;}
 assert.equal(records.filter(r=>r.type==='milestone').length,1);assert.equal(records.filter(r=>r.type==='task').length,0);
 const statePath=path.join(result.stateRoot,'reconciliation.json');
 await write(path.join(evidence,'baseline-before-refinement.json'),await read(statePath));
 const baselines={schema_version:1,planningBinding:(await read(path.join(evidence,'resolved-context.json'))).planningBinding,records:{}};
 for(const r of records){
   const fields=Object.fromEntries(['title','owner','state','updated_at','project_id','criteria'].filter(k=>k in r).map(k=>[k,r[k]]));
   baselines.records[r.id]={canonical:fields,path:r.path,fingerprint:hash(await fs.readFile(r.path)),views:{}};
 }
 const project=records.find(r=>r.type==='project'), milestone=records.find(r=>r.type==='milestone');
 baselines.records[milestone.id].views[project.path]={rendered:{title:'M1: update LinkedIn and resume',state:'not-started',checked:false},source:{title:milestone.title,state:milestone.state},fingerprint:hash(await fs.readFile(project.path))};
 await write(statePath,baselines);
 const before=await read(path.join(evidence,'before.json'));const after=[];
 async function walk(p){for(const e of await fs.readdir(p,{withFileTypes:true})){if(e.name==='.temp'||e.name==='.daily-tasks')continue;const f=path.join(p,e.name);if(e.isDirectory())await walk(f);else if(e.isFile()){const b=await fs.readFile(f);after.push({path:path.relative(caseRoot,f),sha256:hash(b),bytesBase64:b.toString('base64')});}}}
 await walk(caseRoot);await write(path.join(evidence,'after.json'),after);
 const retained=before.filter(f=>f.path.endsWith('profile.json')).every(f=>after.find(a=>a.path===f.path)?.sha256===f.sha256);assert.ok(retained);
 await write(path.join(evidence,'verification.json'),{recordDiagnostics:[],linkDiagnostics:[],milestones:1,tasks:0,existingProfileBytesRetained:retained,logPayloadVerified:true,pendingOperations:await fs.readdir(path.join(result.stateRoot,'operations')),dailyPlansRoot:result.dailyPlansRoot,baselineRefinement:'Limited to canonical editable field values and project projection snapshot.'});
 console.log(result.case+': verified; one milestone, zero tasks, existing profiles retained');
}
