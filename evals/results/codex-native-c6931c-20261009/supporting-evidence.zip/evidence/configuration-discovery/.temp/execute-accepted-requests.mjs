import fs from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

// Authored for this request from the installed Records, Setup and operation protocol.
const root=process.cwd();
const entry='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration1/codex-home/plugins/cache/daily-tasks-native-eval-iteration1/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const hash=s=>createHash('sha256').update(s).digest('hex');
const json=async(p,v)=>{await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,JSON.stringify(v,null,2)+'\n');};
async function exists(p){try{await fs.access(p);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
async function snapshot(dir){const files=[];async function walk(p){for(const e of await fs.readdir(p,{withFileTypes:true})){if(e.name==='.temp'||e.name==='.daily-tasks')continue;const f=path.join(p,e.name);if(e.isDirectory())await walk(f);else if(e.isFile()){const b=await fs.readFile(f);files.push({path:path.relative(dir,f),sha256:hash(b),bytesBase64:b.toString('base64')});}}}await walk(dir);return files;}
const summary=[];
for(const name of ['01-common-root','02-no-profile','03-explicit-legacy','04-vault-only-legacy']){
 const dir=path.join(root,name), evidence=path.join(dir,'.temp','native-request');await fs.mkdir(evidence,{recursive:true});
 let seq=0;const actions=[];
 async function cli(operation,input){const prefix=String(++seq).padStart(2,'0')+'-'+operation, inputPath=path.join(evidence,prefix+'.input.json');if(input!==undefined)await json(inputPath,input);const args=[entry,operation,...(input===undefined?[]:['--input',inputPath])];const r=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8'});await json(path.join(evidence,prefix+'.result.json'),{command:[process.execPath,...args],cwd:dir,exitCode:r.status,stdout:r.stdout,stderr:r.stderr});actions.push({operation,inputFile:input===undefined?null:inputPath,exitCode:r.status});assert.equal(r.status,0,r.stderr);return JSON.parse(r.stdout);}
 const fixture=JSON.parse(await fs.readFile(path.join(dir,'fixture.json'),'utf8'));
 const before=await snapshot(dir);await json(path.join(evidence,'before.json'),before);
 await cli('--help');
 const vaultRoot=path.join(dir,'vault'), projectsRoot=path.join(vaultRoot,'Projects');
 // No configRoot argument: established common state determines a profile pointer.
 const contextInput={vaultRoot,homeRoot:fixture.home,stateRoot:path.join(vaultRoot,'.nyssaai','daily-tasks')};
 if(name.startsWith('01')||name.startsWith('02'))contextInput.profilePath=path.join(fixture.common,'daily-tasks','profile.json');
 if(name.startsWith('03'))contextInput.profilePath=path.join(vaultRoot,'.nyssa','daily-tasks','profile.json');
 let context=await cli('resolve-context',contextInput);
 const request='Create M1: update LinkedIn and resume in this project; DoD reviewed career materials; no extra tasks.';
 const actor={kind:'person',id:'synthetic@example.test'};
 async function decision(action,record_ids,after,time){return {id:(await cli('new-id')).id,operation_id:(await cli('new-id')).id,action,record_ids,actor,...time,original_words:request,after};}
 async function verifyLog(event){await cli('log-append',{projectsRoot,entry:event});const queried=await cli('log-query',{projectsRoot,action:event.action,limit:1000});await json(path.join(evidence,'verified-'+event.action+'.json'),queried);const entries=Array.isArray(queried)?queried:queried.entries;assert.ok(Array.isArray(entries),'log query entries');assert.deepEqual(entries.find(e=>e.id===event.id),event);}
 if(!context.configured){
   assert.equal(name,'02-no-profile');
   const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
   assert.equal((await cli('validate-profile',profile)).valid,true);
   const time=await cli('activity-time',{}), event=await decision('profile.configured',[],{profile,acceptance_source:'Direct request: accepted common scope; supplied identity and timezone; empty priorities'},time);
   const checkpoint=path.join(contextInput.stateRoot,'operations',event.operation_id+'.json');
   await json(checkpoint,{operation_id:event.operation_id,event,changes:[{path:contextInput.profilePath,before:null,after:profile}],status:'pending'});
   assert.equal(await exists(contextInput.profilePath),false);await json(contextInput.profilePath,profile);
   await verifyLog(event);await fs.unlink(checkpoint);
   context=await cli('resolve-context',contextInput);
 }
 assert.equal(context.profile.user.email,actor.id);assert.equal(context.timezone,'America/Chicago');assert.equal(context.projectsRoot,projectsRoot);
 await cli('validate-profile',context.profile);
 const initial=await cli('inspect-records',{projectsRoot});
 await cli('log-query',{projectsRoot,limit:1000});
 await json(path.join(evidence,'resolved-context.json'),context);
 const projectPath=path.join(projectsRoot,'job-search','project-index.md'), projectBefore=await fs.readFile(projectPath,'utf8');
 const project=await cli('parse-record',{markdown:projectBefore,path:projectPath});
 await json(path.join(evidence,'initial-inspection.json'),initial);
 const milestoneId=(await cli('new-id')).id, criterionId=(await cli('new-id')).id, time=await cli('activity-time',{});
 const projectId=project.id??project.metadata?.id;
 assert.ok(projectId,'Existing project ID');
 const stem='m1-update-linkedin-and-resume', milestonePath=path.join(projectsRoot,'job-search',stem,stem+'.md');
 assert.equal(await exists(path.dirname(milestonePath)),false,'M1 collision');
 const milestone=`---\nid: ${milestoneId}\ntype: milestone\nrecord_version: 2\ntitle: "update LinkedIn and resume"\ndocument-maturity: reviewed\nmilestone-state: not-started\nowner: "synthetic@example.test"\nproject_id: "${projectId}"\ncreated_at: "${time.activity_at}"\nupdated_at: "${time.recorded_at}"\n---\n# M1 — update LinkedIn and resume\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${projectId} -->\n\n## Outcome\n\nUpdate LinkedIn and resume for the job search.\n\n## Definition of Done\n\n- [ ] reviewed career materials <!-- id: ${criterionId} -->\n`;
 const projectAfter=projectBefore.replace(/updated_at: "[^"]+"/,`updated_at: "${time.recorded_at}"`).replace('No milestones yet.',`- [ ] [[${stem}/${stem}|M1: update LinkedIn and resume]] <!-- ref: ${milestoneId} -->`);
 const event=await decision('milestone.accepted',[milestoneId],{title:'update LinkedIn and resume',project_id:projectId,'milestone-state':'not-started',owner:actor.id,definition_of_done:'reviewed career materials',acceptance_source:'Direct named create request',path:milestonePath},time);
 const checkpoint=path.join(context.stateRoot,'operations',event.operation_id+'.json');
 const changes=[{path:milestonePath,before:null,after:hash(milestone)},{path:projectPath,before:hash(projectBefore),after:hash(projectAfter)}];
 await json(checkpoint,{operation_id:event.operation_id,planningBinding:context.planningBinding,event,changes,status:'pending'});
 assert.equal(hash(await fs.readFile(projectPath)),hash(projectBefore));assert.equal(await exists(milestonePath),false);
 await fs.mkdir(path.join(path.dirname(milestonePath),'inputs'),{recursive:true});await fs.mkdir(path.join(path.dirname(milestonePath),'outputs'),{recursive:true});
 await fs.writeFile(milestonePath,milestone);
 const parsedMilestone=await cli('parse-record',{markdown:milestone,path:milestonePath});
 await cli('validate-records',{records:[project,parsedMilestone]});
 await verifyLog(event);
 assert.equal(hash(await fs.readFile(projectPath)),hash(projectBefore));await fs.writeFile(projectPath,projectAfter);
 await cli('invalidate-project-index',{vaultRoot});
 const final=await cli('inspect-records',{projectsRoot});
 await cli('validate-records',{records:final.records});await cli('check-links',{records:final.records});
 await json(path.join(context.stateRoot,'reconciliation.json'),{schema_version:1,records:Object.fromEntries(final.records.map(r=>[r.id,{canonical:r,views:{},fingerprint:changes.find(c=>c.path===r.path)?.after??null}]))});
 assert.equal(hash(await fs.readFile(milestonePath)),hash(milestone));assert.equal(hash(await fs.readFile(projectPath)),hash(projectAfter));
 await fs.unlink(checkpoint);
 const after=await snapshot(dir);await json(path.join(evidence,'after.json'),after);
 for(const old of before.filter(f=>f.path.endsWith('profile.json'))){assert.equal(after.find(f=>f.path===old.path)?.sha256,old.sha256,'Existing profile bytes retained');}
 await json(path.join(evidence,'actions.json'),actions);
 const result={case:name,milestonePath,configRoot:context.configRoot,stateRoot:context.stateRoot,dailyPlansRoot:context.dailyPlansRoot,projectsRoot,profileBytesRetained:true,evidence};summary.push(result);console.log(JSON.stringify(result));
}
await json(path.join(root,'.temp','results.json'),summary);
