---
id: "01a12125-8d9b-7099-8f46-6f2ae4d87f3e"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:11.689Z"
updated_at: "2026-10-09T14:51:11.689Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

No milestones yet.
