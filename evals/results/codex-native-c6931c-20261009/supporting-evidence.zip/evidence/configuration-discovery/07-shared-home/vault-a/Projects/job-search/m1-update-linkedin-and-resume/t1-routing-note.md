---
id: "01a1214e-c9b7-78df-95d3-98aedb469238"
type: task
record_version: 2
title: "Routing note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
milestone_id: "01a1214e-c990-79eb-9b48-e37a8f8ea8d9"
created_at: "2026-10-09T15:36:14.128Z"
updated_at: "2026-10-09T15:36:14.128Z"
---
# M1-T1 — Routing note

**Milestone:** [[m1-update-linkedin-and-resume|update LinkedIn and resume]] <!-- ref: 01a1214e-c990-79eb-9b48-e37a8f8ea8d9 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Requirements

local routing test note

## Definition of Done

- [ ] reviewed routing note <!-- id: 01a1214e-ca09-773c-8c33-a7127033d14a -->
