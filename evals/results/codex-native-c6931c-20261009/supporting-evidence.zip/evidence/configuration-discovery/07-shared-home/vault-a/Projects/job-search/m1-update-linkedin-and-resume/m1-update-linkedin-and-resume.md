---
id: "01a1214e-c990-79eb-9b48-e37a8f8ea8d9"
type: milestone
record_version: 2
title: "update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
created_at: "2026-10-09T15:36:14.128Z"
updated_at: "2026-10-09T15:36:14.128Z"
---
# M1 — update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Outcome

Update LinkedIn and resume for the Job Search project.

## Definition of Done

- [ ] reviewed career materials <!-- id: 01a1214e-c9df-73e5-a830-eb2927e5c389 -->

## Tasks

- [ ] [[t1-routing-note|Routing note]] <!-- ref: 01a1214e-c9b7-78df-95d3-98aedb469238 -->
