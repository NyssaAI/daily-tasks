---
id: "01a12125-8dfc-71fb-9879-f4e9c2effd19"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:11.794Z"
updated_at: "2026-10-09T14:51:11.794Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

No milestones yet.
