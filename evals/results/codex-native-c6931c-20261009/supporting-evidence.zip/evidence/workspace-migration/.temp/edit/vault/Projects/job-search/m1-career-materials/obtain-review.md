---
id: "01a1214f-0d86-75a0-ae8f-536cd47945fc"
type: "task"
title: "Obtain review"
owner: "synthetic@example.test"
created_at: "2026-10-01T12:00:00.000Z"
updated_at: "2026-10-02T12:00:00.000Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
---
# Obtain review

## Requirements
Request feedback; acceptance criteria have not been supplied.

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->
