---
id: "01a1214f-0d5e-77a6-b6b9-35d1c46bb69c"
type: "blocker"
title: "Review pending"
owner: "synthetic@example.test"
created_at: "2026-10-01T12:00:00.000Z"
updated_at: "2026-10-02T12:00:00.000Z"
blocker-state: "open"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
---
# Review pending

## Resolution condition
Reviewer supplies approval.

## Blocks
- [[../m1-career-materials/m1-career-materials|Milestone acceptance]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->
