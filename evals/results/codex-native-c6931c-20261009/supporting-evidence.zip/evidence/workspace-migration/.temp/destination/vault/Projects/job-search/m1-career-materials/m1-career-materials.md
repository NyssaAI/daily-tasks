---
id: "01a1211c-fc13-750e-993c-51e78d20ea25"
type: "milestone"
record_version: 2
title: "Career materials"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
milestone-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
document-maturity: "reviewed"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Outcome

Prepare a reviewed LinkedIn headline and resume summary, saved locally and linked.

## Definition of Done

- [ ] Both reviewed artifacts are linked. <!-- id: 01a1211c-fc9b-7027-a7db-a9c6f17740a9 -->

Evidence: [[outputs/review.txt|Review receipt]]

## Legacy acceptance provenance
Retain this original acceptance provenance.

## Blocked by
- [[../blockers/b1-review|Review pending]] <!-- ref: 01a1214e-dc9e-750f-8647-1adfaab2fd90 -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [ ] [[update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->

## Migration history
Retired standalone acceptance document. <!-- retired-id: 01a1214e-dc74-73a6-871f-ab6dd0af50cb -->

## Pending conversion
- [[obtain-review|Obtain review]] <!-- ref: 01a1214e-dcc6-7a39-b00b-7c9f73532288 -->
- Update resume: task-specific criteria requested; completed history retained.
