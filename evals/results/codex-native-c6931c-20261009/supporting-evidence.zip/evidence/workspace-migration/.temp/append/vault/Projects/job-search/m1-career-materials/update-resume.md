---
id: "01a1211c-fc6d-7e56-b639-7133ec8fe4d6"
type: "task"
title: "Update resume"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
task-state: "completed"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
resolved_at: "2026-10-02T12:00:00.000Z"
document-maturity: "reviewed"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a summary.

## Inputs

No source material has been supplied. Local working inputs belong in inputs/.

## Output and delivery

Save the summary locally in outputs/. Link the actual artifact here and from the milestone after review.

## Verification

Confirm the summary was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Work has not started; no artifact has been produced or reviewed.

## Acceptance reference
[[m1-career-materials#Definition of Done|Milestone acceptance]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->
[[m1-career-materials#Definition of Done|Original criterion]] <!-- ref: 01a1211c-fc9b-7027-a7db-a9c6f17740a9 -->
