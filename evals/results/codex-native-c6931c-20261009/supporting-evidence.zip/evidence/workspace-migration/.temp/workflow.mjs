import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/iteration1/codex-home/plugins/cache/daily-tasks-native-eval-iteration1/daily-tasks/0.3.3';
const [mode,name='destination']=process.argv.slice(2), run=path.join(scratch,name);
fs.mkdirSync(run,{recursive:true});
let seq=fs.readdirSync(run).filter(x=>x.endsWith('-input.json')).length;
const write=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,v);};
const json=(p,v)=>write(p,JSON.stringify(v,null,2));
const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
const hash=v=>v===null?null:crypto.createHash('sha256').update(v).digest('hex');
function cli(op,input){const n=String(++seq).padStart(3,'0'), ip=path.join(run,`${n}-${op}-input.json`);json(ip,input??{});const args=[`${pkg}/bin/daily-tasks.mjs`,op,...(input?['--input',ip]:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});json(path.join(run,`${n}-${op}-result.json`),{command:[process.execPath,...args],status:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const action=(stage,data)=>fs.appendFileSync(path.join(run,'actions.ndjson'),JSON.stringify({at:new Date().toISOString(),stage,...data})+'\n');
const vault=path.join(run,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'job-search'), ws=path.join(project,'m1-career-materials');
const cp=path.join(vault,'.nyssaai/daily-tasks/operations/migration.json');
function snapshot(label){const result={};function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(e.name==='.daily-tasks'||e.name==='.temp')continue;const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(e.name.endsWith('.md'))result[path.relative(vault,p)]=read(p);}}walk(vault);json(path.join(run,label+'.json'),result);return result;}
if(mode==='seed'){
 const source=path.join(root,'vault');
 for(const rel of ['.nyssaai/daily-tasks/profile.json','Projects/job-search/project-index.md','Projects/job-search/m1-career-materials/m1-career-materials.md','Projects/job-search/m1-career-materials/t1-update-linkedin.md','Projects/job-search/m1-career-materials/t2-update-resume.md','Daily/2026-10-09.md'])write(path.join(vault,rel),fs.readFileSync(path.join(source,rel),'utf8'));
 const context=cli('resolve-context',{vaultRoot:vault});json(path.join(run,'context.json'),context);
 const id=()=>cli('new-id').id;
 const mid=/id: "([^"]+)"/.exec(read(path.join(ws,'m1-career-materials.md')))[1], pid=/id: "([^"]+)"/.exec(read(path.join(project,'project-index.md')))[1];
 const did=id(), bid=id(), uid=id();
 const fm=(type,id,title,state)=>`---\nid: "${id}"\ntype: "${type}"\ntitle: "${title}"\nowner: "synthetic@example.test"\ncreated_at: "2026-10-01T12:00:00.000Z"\nupdated_at: "2026-10-02T12:00:00.000Z"\n${type==='blocker'?'blocker-state':type+'-state'}: "${state}"\nproject_id: "${pid}"\n${type==='task'||type==='dod'?`milestone_id: "${mid}"\n`:''}---\n`;
 const old=read(path.join(ws,'m1-career-materials.md')), criteria=old.split('## Definition of Done\n')[1]?.split('## Tasks')[0]??old.split('## Definition of Done\r\n')[1].split('## Tasks')[0];
 let milestone=old.replace(/record_version: 2\r?\n/,'').replace(/## Definition of Done[\s\S]*?(?=## Tasks)/,`## Completion criteria\n\n[[definition-of-done|Legacy DoD]] <!-- ref: ${did} -->\n\n`).replaceAll('t1-update-linkedin','update-linkedin').replaceAll('t2-update-resume','update-resume');
 write(path.join(ws,'milestone.md'),milestone);fs.unlinkSync(path.join(ws,'m1-career-materials.md'));
 const evidence='Review receipt: synthetic legacy evidence.\n';write(path.join(ws,'outputs/review.txt'),evidence);
 const criterion=/id: ([^ ]+)/.exec(criteria)[1];
 const dod=fm('dod',did,'Career materials acceptance','not-started')+`# Legacy Definition of Done\n\n## Definition of Done\n\n${criteria.trim()}\n\nEvidence: [[outputs/review.txt|Review receipt]]\n\n## Notes\n\nRetain this original acceptance provenance.\n\n## Blocked by\n- [[../blockers/b1-review|Review pending]] <!-- ref: ${bid} -->\n`;
 write(path.join(ws,'definition-of-done.md'),dod);
 for(const [number,slug]of [[1,'update-linkedin'],[2,'update-resume']]){const p=path.join(ws,`t${number}-${slug}.md`);let t=read(p).replace(/record_version: 2\r?\n/,'').replaceAll('[[m1-career-materials|','[[milestone|');if(number===2)t=t.replace(/## Definition of Done[\s\S]*?(?=## Inputs)/,'').replace('task-state: "not-started"','task-state: "completed"').replace('document-maturity:', 'resolved_at: "2026-10-02T12:00:00.000Z"\ndocument-maturity:');t+=`\n## Acceptance reference\n[[definition-of-done#Definition of Done|Milestone acceptance]] <!-- ref: ${did} -->\n[[definition-of-done#Definition of Done|Original criterion]] <!-- ref: ${criterion} -->\n`;write(path.join(ws,slug+'.md'),t);fs.unlinkSync(p);}
 write(path.join(ws,'obtain-review.md'),fm('task',uid,'Obtain review','not-started')+`# Obtain review\n\n## Requirements\nRequest feedback; acceptance criteria have not been supplied.\n\n**Milestone:** [[milestone|Career materials]] <!-- ref: ${mid} -->\n`);
 write(path.join(project,'blockers/b1-review.md'),fm('blocker',bid,'Review pending','open')+`# Review pending\n\n## Resolution condition\nReviewer supplies approval.\n\n## Blocks\n- [[../m1-career-materials/definition-of-done|Milestone acceptance]] <!-- ref: ${did} -->\n`);
 write(path.join(project,'project-index.md'),read(path.join(project,'project-index.md')).replaceAll('/m1-career-materials\\|','/milestone\\|').replaceAll('t1-update-linkedin','update-linkedin').replaceAll('t2-update-resume','update-resume'));
 write(path.join(vault,'Daily/2026-10-09.md'),read(path.join(vault,'Daily/2026-10-09.md'))+`\n[[../Projects/job-search/m1-career-materials/definition-of-done#Definition of Done|Acceptance criterion]] <!-- ref: ${criterion} -->\n`);
 const time=cli('activity-time',{}), history={id:id(),operation_id:id(),action:'task.completed',record_ids:[/id: "([^"]+)"/.exec(read(path.join(ws,'update-resume.md')))[1]],actor:{kind:'person',id:'synthetic@example.test'},...time,original_words:'Synthetic legacy completion without recorded task DoD'};cli('log-append',{projectsRoot:projects,entry:history});json(path.join(run,'historical-event.json'),history);cli('log-query',{projectsRoot:projects});
 const before=snapshot('before'), effects=[];
 const effect=(p,after)=>effects.push({path:p,before:read(p),after,beforeHash:hash(read(p)),afterHash:hash(after)});
 let dest=milestone.replace('type: "milestone"','type: "milestone"\nrecord_version: 2').replace(/## Completion criteria[\s\S]*?(?=## Tasks)/,`## Definition of Done\n\n${criteria.trim()}\n\nEvidence: [[outputs/review.txt|Review receipt]]\n\n## Legacy acceptance provenance\nRetain this original acceptance provenance.\n\n## Blocked by\n- [[../blockers/b1-review|Review pending]] <!-- ref: ${bid} -->\n\n`).replaceAll('update-linkedin|','t1-update-linkedin|').replaceAll('update-resume|','update-resume|');dest+=`\n## Migration history\nRetired standalone acceptance document. <!-- retired-id: ${did} -->\n\n## Pending conversion\n- [[obtain-review|Obtain review]] <!-- ref: ${uid} -->\n- Update resume: task-specific criteria requested; completed history retained.\n`;
 effect(path.join(ws,'m1-career-materials.md'),dest);
 let t=read(path.join(ws,'update-linkedin.md')).replace('type: "task"','type: "task"\nrecord_version: 2').replaceAll('[[milestone|','[[m1-career-materials|').replaceAll('definition-of-done#Definition of Done','m1-career-materials#Definition of Done').replaceAll(`ref: ${did}`,`ref: ${mid}`);effect(path.join(ws,'t1-update-linkedin.md'),t);
 for(const rel of ['update-resume.md','obtain-review.md'])effect(path.join(ws,rel),read(path.join(ws,rel)).replaceAll('[[milestone|','[[m1-career-materials|').replaceAll('definition-of-done#Definition of Done','m1-career-materials#Definition of Done').replaceAll(`ref: ${did}`,`ref: ${mid}`));
 effect(path.join(project,'blockers/b1-review.md'),read(path.join(project,'blockers/b1-review.md')).replaceAll('/definition-of-done|','/m1-career-materials|').replaceAll(`ref: ${did}`,`ref: ${mid}`));
 effect(path.join(project,'project-index.md'),read(path.join(project,'project-index.md')).replaceAll('/milestone\\|','/m1-career-materials\\|').replaceAll('/update-linkedin','/t1-update-linkedin'));
 effect(path.join(vault,'Daily/2026-10-09.md'),read(path.join(vault,'Daily/2026-10-09.md')).replaceAll('definition-of-done#Definition of Done','m1-career-materials#Definition of Done'));
 effect(path.join(ws,'milestone.md'),null);effect(path.join(ws,'update-linkedin.md'),null);effect(path.join(ws,'definition-of-done.md'),null);
 const timing=cli('activity-time',{}),event={id:id(),operation_id:id(),action:'workspace.migrated',record_ids:[mid],actor:{kind:'agent',id:'codex'},...timing,original_words:'Conversion explicitly authorized',before:{retiredDoD:did},after:{criterionIds:[criterion],pendingTasks:['Update resume','Obtain review']}};
 const op={status:'pending',planningBinding:context.planningBinding,event,effects,criterion,mid,did,history};json(cp,op);json(path.join(run,'saved-operation.json'),op);action('seed-and-checkpoint',{files:Object.keys(before)});console.log('Seeded '+name);process.exit();
}
const op=JSON.parse(read(cp));
if(mode==='audit'){
 const query=cli('log-query',{projectsRoot:projects}),entries=Array.isArray(query)?query:query.entries;
 const checks={};
 const check=(key,ok)=>checks[key]=Boolean(ok);
 if(['destination','source','append'].includes(name)){
 const before=JSON.parse(read(path.join(run,'before.json'))),after=snapshot('audited-after'),records=validate();
 check('one exact migration event',entries.filter(e=>e.operation_id===op.event.operation_id).length===1&&entries.some(e=>JSON.stringify(e)===JSON.stringify(op.event)));
 check('historical event preserved',entries.some(e=>JSON.stringify(e)===JSON.stringify(op.history)));
 check('no duplicate live records',new Set(records.map(r=>r.id)).size===records.length);
 check('milestone and task identities preserved',[op.mid,...Object.values(before).filter(v=>/type: "task"/.test(v)).map(v=>/id: "([^"]+)"/.exec(v)[1])].every(id=>records.some(r=>r.id===id)));
 const m=records.find(r=>r.id===op.mid),d=before['Projects/job-search/m1-career-materials/definition-of-done.md'];
 check('criterion text state UUID preserved',m.criteria.some(c=>c.id===op.criterion&&c.text==='Both reviewed artifacts are linked.'&&c.checked===false));
 check('standalone retired after incoming-link verification',!fs.existsSync(path.join(ws,'definition-of-done.md'))&&read(path.join(run,'actions.ndjson')).includes('dod-retirement-verification'));
 check('legacy notes and evidence preserved',read(path.join(ws,'m1-career-materials.md')).includes('Retain this original acceptance provenance.')&&read(path.join(ws,'outputs/review.txt'))==='Review receipt: synthetic legacy evidence.\n');
 check('blockers reciprocal milestone',records.some(r=>r.type==='blocker'&&r.blocks.includes(op.mid)&&m.blocked_by.includes(r.id)));
 check('retired identity provenance',read(path.join(ws,'m1-career-materials.md')).includes(`retired-id: ${op.did}`));
 check('inbound task and daily criterion links preserve UUID and new owner',records.filter(r=>r.type==='task'&&r.title!=='Obtain review').every(r=>r.refs.some(x=>x.id===op.criterion&&x.target==='m1-career-materials#Definition of Done'))&&read(path.join(vault,'Daily/2026-10-09.md')).includes(`m1-career-materials#Definition of Done|Acceptance criterion]] <!-- ref: ${op.criterion}`));
 const resume=records.find(r=>r.title==='Update resume'),unresolved=records.find(r=>r.title==='Obtain review');
 check('missing criteria not manufactured or satisfied',resume.state==='completed'&&resume.criteria.length===0&&!resume.record_version);
 check('unresolved legacy remains readable and pending',unresolved.state==='not-started'&&!unresolved.record_version&&read(path.join(ws,'m1-career-materials.md')).includes('## Pending conversion'));
 check('lifecycle timestamps owner preserved',records.filter(r=>r.type==='task'||r.type==='milestone').every(r=>{const old=Object.values(before).find(v=>new RegExp(`^id: "${r.id}"`,'m').test(v));return ['owner','created_at','updated_at','resolved_at','started_at','assignee'].every(k=>{const match=new RegExp(`^${k}: "([^"]+)"`,'m').exec(old);return !match||r[k]===match[1];});}));
 check('actual independent interruption and completed retry',read(path.join(run,'actions.ndjson')).includes(`"stage":"${{destination:'destination persistence',source:'source removal',append:'log append'}[name]}"`)&&read(path.join(run,'actions.ndjson')).split('verified-completion').length>=3&&op.status==='complete');
 let navigation=true;for(const [rel,v]of Object.entries(after)){for(const match of v.matchAll(/\[\[([^\]|]+)(?:\|[^\]]*)?\]\]/g)){const [target,heading]=match[1].replaceAll('\\','').split('#');let p=path.resolve(path.dirname(path.join(vault,rel)),target);if(!path.extname(p))p+='.md';const text=read(p);if(text===null||(heading&&!text.includes('## '+heading)))navigation=false;}}
 check('all affected navigation headings and files resolve',navigation);
 }else if(name==='competing'){
 const closure=JSON.parse(read(path.join(run,'competing-closure.json')));check('closure rejects competing embedded standalone sources',closure.allowed===false&&closure.reasons.some(x=>x.includes('both embedded and standalone')));check('both authorities retained',fs.existsSync(path.join(ws,'definition-of-done.md'))&&read(path.join(ws,'milestone.md')).includes('Embedded competing criterion'));
 }else{
 check('durable pending conflict no false completion',op.status==='pending-conflict');check('no migration event',!entries.some(e=>e.operation_id===op.event.operation_id));
 check('unexpected data preserved',name==='collision'?read(path.join(ws,'M1-CAREER-MATERIALS.MD'))==='Unrelated destination data; preserve exactly.\n':read(path.join(ws,'m1-career-materials.md')).includes('Unexpected user edit: retain.'));
 check('legacy sources and DoD retained',fs.existsSync(path.join(ws,'milestone.md'))&&fs.existsSync(path.join(ws,'definition-of-done.md')));
 }
 json(path.join(run,'assertions.json'),checks);console.log(JSON.stringify({name,checks}));process.exit(Object.values(checks).every(Boolean)?0:1);
}
function conflict(reason){op.status='pending-conflict';op.conflict=reason;json(cp,op);action('conflict',{reason});console.log(reason);}
function validate(){const scan=cli('inspect-records',{projectsRoot:projects});json(path.join(run,'final-inspection.json'),scan);const records=scan.records;cli('validate-records',{records});cli('check-links',{records});return records;}
if(mode==='competing'){const m=read(path.join(ws,'milestone.md'));write(path.join(ws,'milestone.md'),m+`\n## Definition of Done\n- [ ] Embedded competing criterion. <!-- id: ${cli('new-id').id} -->\n`);const scan=cli('inspect-records',{projectsRoot:projects});const closure=cli('check-closure',{recordId:op.mid,records:scan.records});json(path.join(run,'competing-closure.json'),closure);snapshot('competing');console.log(JSON.stringify(closure));process.exit();}
if(mode==='collision'){const p=path.join(ws,'M1-CAREER-MATERIALS.MD');write(p,'Unrelated destination data; preserve exactly.\n');action('collision-injected',{path:p});}
if(mode==='edit'){write(path.join(ws,'m1-career-materials.md'),read(path.join(ws,'m1-career-materials.md'))+'\nUnexpected user edit: retain.\n');action('unexpected-edit',{});}
const actual={};for(const [i,e]of op.effects.entries())actual[String(i)]=read(e.path);
const classification=cli('recover-operation',{operation:{changes:op.effects.map((e,i)=>({key:String(i),before:{present:true,value:e.before},after:{present:true,value:e.after}}))},actual});json(path.join(run,'recovery-classification.json'),classification);
for(const e of op.effects){const v=read(e.path);if(v!==e.before&&v!==e.after){conflict('Unexpected bytes at '+e.path);process.exit();}const other=fs.readdirSync(path.dirname(e.path)).find(x=>x.toLowerCase()===path.basename(e.path).toLowerCase()&&x!==path.basename(e.path));if(other&&e.after!==null){conflict('Case-insensitive unrelated destination: '+other);process.exit();}}
for(const e of op.effects.filter(e=>e.after!==null)){if(read(e.path)===e.after)continue;if(hash(read(e.path))!==e.beforeHash)throw Error('race');write(e.path,e.after);action('destination-persisted',{path:e.path,hash:hash(read(e.path))});}
fs.mkdirSync(path.join(ws,'inputs'),{recursive:true});fs.mkdirSync(path.join(ws,'outputs'),{recursive:true});
cli('invalidate-project-index',{vaultRoot:vault});
if(mode==='destination'){snapshot('interrupted-destination');action('process-interruption',{stage:'destination persistence'});console.log('Interrupted after destination persistence');process.exit();}
for(const e of op.effects.filter(e=>e.after===null)){
 if(read(e.path)===null)continue;
 for(const d of op.effects.filter(e=>e.after!==null))if(hash(read(d.path))!==d.afterHash)throw Error('Destination failed verification');
 if(e.path.endsWith('definition-of-done.md')){const live=snapshot('before-dod-retirement');if(Object.values(live).some(v=>v!==read(e.path)&&/\[\[[^\]]*definition-of-done/.test(v)))throw Error('Live incoming DoD link');if(!read(path.join(ws,'m1-career-materials.md')).includes(op.criterion))throw Error('criterion missing');action('dod-retirement-verification',{incomingLegacyLinks:0,criterionPreserved:true});}
 if(hash(read(e.path))!==e.beforeHash)throw Error('Source changed');fs.unlinkSync(e.path);action('source-removed',{path:e.path});
}
if(mode==='source'){snapshot('interrupted-source');action('process-interruption',{stage:'source removal'});console.log('Interrupted after source removal');process.exit();}
const records=validate();cli('log-append',{projectsRoot:projects,entry:op.event});
if(mode==='append'){action('process-interruption',{stage:'log append'});console.log('Interrupted after log append');process.exit();}
const query=cli('log-query',{projectsRoot:projects});json(path.join(run,'verified-query.json'),query);
const entries=Array.isArray(query)?query:query.entries;
if(!entries)throw Error('Unrecognized log result');const events=entries.filter(e=>e.operation_id===op.event.operation_id);if(events.length!==1||JSON.stringify(events[0])!==JSON.stringify(op.event))throw Error('Event mismatch');if(!entries.some(e=>JSON.stringify(e)===JSON.stringify(op.history)))throw Error('History changed');
json(path.join(vault,'.nyssaai/daily-tasks/reconciliation.json'),{files:Object.fromEntries(op.effects.filter(e=>e.after!==null).map(e=>[e.path,{sha256:hash(read(e.path))}]))});cli('invalidate-project-index',{vaultRoot:vault});op.status='complete';json(cp,op);snapshot('after');action('verified-completion',{exactEvents:events.length,recordCount:records.length});console.log('Completed '+name+' with one exact event');
