# Scenario 8: Workspace migration

Executed the installed skill-authored workflow in six independent synthetic case vaults. Observed assertion checks: 55/55 passed. These counts describe the retained workflow evidence, not an agent score or a claim of plugin activation.

| Branch | Result | Evidence |
| --- | --- | --- |
| destination | Pass | [Assertions](destination/assertions.json), [actions](destination/actions.ndjson) |
| source | Pass | [Assertions](source/assertions.json), [actions](source/actions.ndjson) |
| append | Pass | [Assertions](append/assertions.json), [actions](append/actions.ndjson) |
| edit | Pass | [Assertions](edit/assertions.json), [actions](edit/actions.ndjson) |
| collision | Pass | [Assertions](collision/assertions.json), [actions](collision/actions.ndjson) |
| competing | Pass | [Assertions](competing/assertions.json), [actions](competing/actions.ndjson) |

Each recovery branch used separate process invocations: seed/checkpoint, apply through its interruption boundary and exit, resume the saved operation, retry, then audit. Destination persistence retained temporary duplicate identities while pending; planning was not invoked during that state. Source removal retired the legacy DoD only after all destination bytes, criterion UUID, and remaining incoming legacy links verified. Log append interruption left the saved checkpoint pending; recovery queried and retried the original exact payload.

The unexpected-edit branch changed persisted destination content before recovery. The collision branch created an unrelated uppercase filename on Windows; reading its lowercase destination resolved to the same file, and the before-hash check suspended the operation before writes. Both branches retain pending-conflict checkpoints, old sources/DoD, injected content and zero migration events. The competing-source branch retained both DoD authorities and check-closure explicitly rejected them.

Original milestone/task UUIDs, criterion UUID/text/unchecked state, owner, lifecycle timestamps and history are preserved. Evidence and legacy notes remain linked. Blockers now link reciprocally to the milestone. Task and daily-plan criterion references retain their original criterion UUID and navigate to the milestone's Definition of Done heading. All affected navigation/file/heading targets resolve.

The completed legacy Update resume task has no task DoD: its completion and history remain intact, no criteria were invented, and it remains unversioned/pending conversion. Obtain review remains readable, not-started, unversioned and pending conversion. The host asked for task-specific acceptance criteria; no reply was received during this run. No automatic scheduling or implicit acceptance was introduced.

Evidence includes before/after Markdown snapshots, saved-operation payloads with before/after bytes and hashes, append-only action transcripts, every installed CLI JSON input, stdout/stderr/exit status, log queries, recovery classifications and integrity/link diagnostics. The log itself was only accessed through installed log-append/log-query. Initial case files were used solely as authorized fixture inputs; branch vaults are entirely within this case's .temp. No previous attempts, regression tests, personal directories, or repository implementation were read.

Installed instruction paths/hashes: [manifest](installed-instructions.json). Entry version reported 0.3.3; Node v24.19.0; platform win32/x64. Authenticated-host status, explicit registration evidence and host version/model were not exposed; this run does not assert those release prerequisites or establish host activation from CLI success.
