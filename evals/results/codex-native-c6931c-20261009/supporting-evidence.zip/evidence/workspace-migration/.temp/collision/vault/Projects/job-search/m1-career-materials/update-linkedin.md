---
id: "01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8"
type: "task"
title: "Update LinkedIn"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: "reviewed"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[milestone|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a headline.

## Definition of Done

- [ ] A reviewed headline is saved locally. <!-- id: 01a1211c-fcde-77f4-84d8-63271f429f17 -->

## Inputs

No source material has been supplied. Local working inputs belong in inputs/.

## Output and delivery

Save the headline locally in outputs/. Link the actual artifact here and from the milestone after review.

## Verification

Confirm the headline was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Work has not started; no artifact has been produced or reviewed.

## Acceptance reference
[[definition-of-done#Definition of Done|Milestone acceptance]] <!-- ref: 01a1214f-0f55-7f0b-8532-be2776f28115 -->
[[definition-of-done#Definition of Done|Original criterion]] <!-- ref: 01a1211c-fc9b-7027-a7db-a9c6f17740a9 -->
