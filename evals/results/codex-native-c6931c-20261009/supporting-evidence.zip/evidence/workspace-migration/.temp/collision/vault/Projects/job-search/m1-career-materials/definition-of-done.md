---
id: "01a1214f-0f55-7f0b-8532-be2776f28115"
type: "dod"
title: "Career materials acceptance"
owner: "synthetic@example.test"
created_at: "2026-10-01T12:00:00.000Z"
updated_at: "2026-10-02T12:00:00.000Z"
dod-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
---
# Legacy Definition of Done

## Definition of Done

- [ ] Both reviewed artifacts are linked. <!-- id: 01a1211c-fc9b-7027-a7db-a9c6f17740a9 -->

Evidence: [[outputs/review.txt|Review receipt]]

## Notes

Retain this original acceptance provenance.

## Blocked by
- [[../blockers/b1-review|Review pending]] <!-- ref: 01a1214f-0f7d-7070-a839-66a20d3aeb4a -->
