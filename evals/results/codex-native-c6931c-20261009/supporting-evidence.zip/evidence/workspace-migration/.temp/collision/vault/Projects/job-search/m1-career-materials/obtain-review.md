---
id: "01a1214f-0fa5-7ed0-856b-6d9aee36b9d7"
type: "task"
title: "Obtain review"
owner: "synthetic@example.test"
created_at: "2026-10-01T12:00:00.000Z"
updated_at: "2026-10-02T12:00:00.000Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
---
# Obtain review

## Requirements
Request feedback; acceptance criteria have not been supplied.

**Milestone:** [[milestone|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->
