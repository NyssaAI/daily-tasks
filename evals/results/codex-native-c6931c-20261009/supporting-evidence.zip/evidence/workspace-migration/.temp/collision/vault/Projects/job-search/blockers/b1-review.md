---
id: "01a1214f-0f7d-7070-a839-66a20d3aeb4a"
type: "blocker"
title: "Review pending"
owner: "synthetic@example.test"
created_at: "2026-10-01T12:00:00.000Z"
updated_at: "2026-10-02T12:00:00.000Z"
blocker-state: "open"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
---
# Review pending

## Resolution condition
Reviewer supplies approval.

## Blocks
- [[../m1-career-materials/definition-of-done|Milestone acceptance]] <!-- ref: 01a1214f-0f55-7f0b-8532-be2776f28115 -->
