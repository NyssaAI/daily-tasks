---
id: "01a1214f-11a2-7c8a-88b0-940e8d86fcd3"
type: "blocker"
title: "Review pending"
owner: "synthetic@example.test"
created_at: "2026-10-01T12:00:00.000Z"
updated_at: "2026-10-02T12:00:00.000Z"
blocker-state: "open"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
---
# Review pending

## Resolution condition
Reviewer supplies approval.

## Blocks
- [[../m1-career-materials/definition-of-done|Milestone acceptance]] <!-- ref: 01a1214f-117b-723e-8576-9a5c1e8e6260 -->
