---
id: "01a1211c-fc13-750e-993c-51e78d20ea25"
type: "milestone"
title: "Career materials"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
milestone-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
document-maturity: "reviewed"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Outcome

Prepare a reviewed LinkedIn headline and resume summary, saved locally and linked.

## Completion criteria

[[definition-of-done|Legacy DoD]] <!-- ref: 01a1214f-117b-723e-8576-9a5c1e8e6260 -->

## Tasks

- [ ] [[update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [ ] [[update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->

## Definition of Done
- [ ] Embedded competing criterion. <!-- id: 01a1214f-38e2-78e2-affc-21ac3cce9328 -->
