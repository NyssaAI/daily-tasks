import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3';
const cli=path.join(pkg,'bin/daily-tasks.mjs');
fs.mkdirSync(scratch,{recursive:true});
let seq=fs.readdirSync(scratch).reduce((n,f)=>Math.max(n,Number(f.match(/^(\d+)-/)?.[1]??0)),0);
function save(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
function call(op,input){const tag=String(++seq).padStart(3,'0')+'-'+op;const inp=path.join(scratch,tag+'-input.json');if(input!==undefined)save(inp,input);const args=[cli,op,...(input===undefined?[]:['--input',inp])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(path.join(scratch,tag+'-result.json'),{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const id=()=>{const r=call('new-id');return typeof r==='string'?r:r.id;};
const hash=t=>crypto.createHash('sha256').update(t).digest('hex');
const projects=path.join(vault,'1-projects'), config=path.join(vault,'.nyssaai/daily-tasks');
if(!fs.existsSync(path.join(scratch,'before.json')))save(path.join(scratch,'before.json'),{vault,entries:fs.readdirSync(vault),node:process.version,installedPackage:pkg,loadedSkills:['daily-tasks','daily-tasks-setup','daily-tasks-records'],references:['cli.md','records.md','operations.md','verification.md'],scenarioSource:'D:/repos/NyssaAI/daily-tasks/evals/README.md'});
const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:vault,projectsRoot:projects,dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
const validation=call('validate-profile',profile);if(!validation.valid)throw Error(JSON.stringify(validation));
save(path.join(config,'profile.json'),profile);
fs.mkdirSync(projects,{recursive:true});
const ctx=call('resolve-context',{vaultRoot:vault,configRoot:config});save(path.join(scratch,'context.json'),ctx);
const context={vaultRoot:vault,configRoot:config,stateRoot:ctx.stateRoot};
function event(action,ids,time,before,after,words,actor={kind:'agent',id:'Codex'}){return {id:id(),operation_id:id(),action,record_ids:ids,actor,activity_at:time.activity_at,recorded_at:time.recorded_at,time_defaulted:time.time_defaulted,...(words?{original_words:words}:{}),before,after};}
const setupTime=call('activity-time',{});call('log-append',{projectsRoot:projects,entry:event('profile.configured',[],setupTime,null,profile,'configure this vault only')});
async function commit(ev,changes){const files=changes.map(([p,t])=>({path:p,before:fs.existsSync(p)?hash(fs.readFileSync(p)):null,after:hash(t)}));const checkpoint={schemaVersion:2,operation_id:ev.operation_id,contextBinding:ctx.planningBinding,event:ev,files};const opPath=path.join(ctx.stateRoot,'operations',ev.operation_id+'.json');save(opPath,checkpoint);save(path.join(scratch,ev.operation_id+'-checkpoint.json'),checkpoint);
for(const [p,t] of changes){const f=files.find(x=>x.path===p);const actual=fs.existsSync(p)?hash(fs.readFileSync(p)):null;if(actual!==f.before)throw Error('Concurrent edit');if(actual!==null)save(path.join(scratch,ev.operation_id+'-'+path.basename(p)+'-before.md'),fs.readFileSync(p,'utf8'));save(p,t);save(path.join(scratch,ev.operation_id+'-'+path.basename(p)+'-after.md'),t);}
call('invalidate-project-index',{vaultRoot:vault});
const check=call('inspect-records',{projectsRoot:projects});save(path.join(scratch,ev.operation_id+'-inspection.json'),check);
call('log-append',{projectsRoot:projects,entry:ev});call('log-query',{projectsRoot:projects});
const verified=call('operation-verify',{...context,operationPath:opPath});if(verified.status!=='verified')throw Error(JSON.stringify(verified));const done=call('operation-complete',{...context,operationPath:opPath});save(path.join(scratch,ev.operation_id+'-completion.json'),done);if(fs.existsSync(opPath))throw Error('Checkpoint remains');}
const p=id(),m=id(),d=id(),r=id(),dc=id(),rc=id(),mc=id();save(path.join(scratch,'identities.json'),{p,m,d,r,dc,rc,mc});
const time=call('activity-time',{}), stamp=time.activity_at;
const base=path.join(projects,'demo'), folder=path.join(base,'m1-draft');
fs.mkdirSync(path.join(folder,'inputs'),{recursive:true});fs.mkdirSync(path.join(folder,'outputs'),{recursive:true});
const pp=path.join(base,'project-index.md'),mp=path.join(folder,'m1-draft.md'),dp=path.join(folder,'t1-draft-note.md'),rp=path.join(folder,'t2-review-note.md');
const meta=(uuid,type,title,extra='')=>`---\nid: ${uuid}\ntype: ${type}\n${type==='project'?'':'record_version: 2\n'}title: "${title}"\n${type}-state: not-started\nowner: "synthetic@example.test"\n${extra}created_at: "${stamp}"\nupdated_at: "${stamp}"\n---\n`;
const project=meta(p,'project','Demo')+`# Demo\n\nDraft and review a note.\n\n## Project Summary\n\n- [ ] [[m1-draft/m1-draft|M1 Draft]] <!-- ref: ${m} -->\n- [ ] [[m1-draft/t1-draft-note|Draft note]] <!-- ref: ${d} -->\n- [ ] [[m1-draft/t2-review-note|Review note]] <!-- ref: ${r} -->\n`;
const milestone=meta(m,'milestone','Draft',`project_id: "${p}"\n`)+`# M1 — Draft\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${p} -->\n\n## Outcome\n\nA drafted and reviewed note.\n\n## Definition of Done\n\n- [ ] Both task definitions of done are satisfied. <!-- id: ${mc} -->\n\n## Tasks\n\n- [ ] [[t1-draft-note|Draft note]] <!-- ref: ${d} -->\n- [ ] [[t2-review-note|Review note]] <!-- ref: ${r} -->\n`;
function task(uuid,title,num,requirement,dod,criterion,assignee){return meta(uuid,'task',title,`project_id: "${p}"\nmilestone_id: "${m}"\n${assignee?`assignee: "${assignee}"\n`:''}`)+`# M1-T${num} — ${title}\n\n**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: ${m} -->\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${p} -->\n\n## Requirements\n\n${requirement}\n\n## Definition of Done\n\n- [ ] ${dod} <!-- id: ${criterion} -->\n`;}
await commit(event('records.accepted',[p,m,d,r],time,null,{records:[{id:p,type:'project',path:pp,owner:profile.user.email},{id:m,type:'milestone',path:mp,project_id:p},{id:d,type:'task',path:dp,milestone_id:m,owner:profile.user.email},{id:r,type:'task',path:rp,milestone_id:m,owner:profile.user.email,assignee:'Reviewer','task-state':'not-started'}]},'Explicitly create project Demo, M1 Draft, Draft note and Review note'),[[pp,project],[mp,milestone],[dp,task(d,'Draft note',1,'Write a paragraph.','Reviewed paragraph.',dc)],[rp,task(r,'Review note',2,'Inspect the paragraph.','Recorded review.',rc,'Reviewer')]]);
const started=call('activity-time',{reported:'earlier this morning'});save(path.join(scratch,'exact-start-time.json'),started);
const draftBefore=fs.readFileSync(dp,'utf8');const draftAfter=draftBefore.replace('task-state: not-started','task-state: in-progress').replace(`updated_at: "${stamp}"`,`updated_at: "${started.recorded_at}"\nstarted_at: "${started.activity_at}"`);
await commit(event('task.started',[d],started,{'task-state':'not-started'},{'task-state':'in-progress',started_at:started.activity_at},'earlier this morning',{kind:'person',id:profile.user.email}),[[dp,draftAfter],[mp,milestone.replace('- [ ] [[t1-draft-note','- [>] [[t1-draft-note')],[pp,project.replace('- [ ] [[m1-draft/t1-draft-note','- [>] [[m1-draft/t1-draft-note')]]);
const assigned=call('activity-time',{}),reviewBefore=fs.readFileSync(rp,'utf8');
await commit(event('task.assignee-changed',[r],assigned,{owner:profile.user.email,assignee:'Reviewer','task-state':'not-started'},{owner:profile.user.email,assignee:'Editor','task-state':'not-started'},'Acting as agent reassign Review note to Editor; human ownership cannot change autonomously'),[[rp,reviewBefore.replace('assignee: "Reviewer"','assignee: "Editor"').replace(`updated_at: "${stamp}"`,`updated_at: "${assigned.recorded_at}"`)]]);
const inspected=call('inspect-records',{projectsRoot:projects});textOutput(inspected);
function textOutput(v){save(path.join(scratch,'final-inspection.json'),v);}
const logs=call('log-query',{projectsRoot:projects});save(path.join(scratch,'final-log-query.json'),logs);
const display=call('format-time',{time:started.activity_at,timezone:'America/Chicago'});save(path.join(scratch,'local-start-display.json'),display);
console.log(JSON.stringify({inspected,started,display,logs},null,2));
