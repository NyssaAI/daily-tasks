---
id: 01a121df-5962-7883-908e-acf48f0c5a5b
type: project
title: "Demo"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T18:14:08.290Z"
updated_at: "2026-10-09T18:14:08.290Z"
---
# Demo

Draft and review a note.

## Project Summary

- [ ] [[m1-draft/m1-draft|M1 Draft]] <!-- ref: 01a121df-5990-706e-954c-b76c766cf484 -->
- [>] [[m1-draft/t1-draft-note|Draft note]] <!-- ref: 01a121df-59bd-76e4-bc76-4d25321752e5 -->
- [ ] [[m1-draft/t2-review-note|Review note]] <!-- ref: 01a121df-59ea-72d8-808b-dd02a959c81f -->
