---
id: 01a121df-5990-706e-954c-b76c766cf484
type: milestone
record_version: 2
title: "Draft"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a121df-5962-7883-908e-acf48f0c5a5b"
created_at: "2026-10-09T18:14:08.290Z"
updated_at: "2026-10-09T18:14:08.290Z"
---
# M1 — Draft

**Project:** [[../project-index|Demo]] <!-- ref: 01a121df-5962-7883-908e-acf48f0c5a5b -->

## Outcome

A drafted and reviewed note.

## Definition of Done

- [ ] Both task definitions of done are satisfied. <!-- id: 01a121df-5a71-78e6-96ee-8592fb0f599f -->

## Tasks

- [>] [[t1-draft-note|Draft note]] <!-- ref: 01a121df-59bd-76e4-bc76-4d25321752e5 -->
- [ ] [[t2-review-note|Review note]] <!-- ref: 01a121df-59ea-72d8-808b-dd02a959c81f -->
