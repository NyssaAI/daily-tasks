---
id: 01a121df-59bd-76e4-bc76-4d25321752e5
type: task
record_version: 2
title: "Draft note"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a121df-5962-7883-908e-acf48f0c5a5b"
milestone_id: "01a121df-5990-706e-954c-b76c766cf484"
created_at: "2026-10-09T18:14:08.290Z"
updated_at: "2026-10-09T18:14:08.290Z"
---
# M1-T1 — Draft note

**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: 01a121df-5990-706e-954c-b76c766cf484 -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a121df-5962-7883-908e-acf48f0c5a5b -->

## Requirements

Write a paragraph.

## Definition of Done

- [ ] Reviewed paragraph. <!-- id: 01a121df-5a15-7f1b-ad2b-2bfac32df74f -->
