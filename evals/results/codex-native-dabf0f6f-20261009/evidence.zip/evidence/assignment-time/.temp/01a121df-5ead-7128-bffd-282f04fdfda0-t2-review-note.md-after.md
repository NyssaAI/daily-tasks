---
id: 01a121df-59ea-72d8-808b-dd02a959c81f
type: task
record_version: 2
title: "Review note"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a121df-5962-7883-908e-acf48f0c5a5b"
milestone_id: "01a121df-5990-706e-954c-b76c766cf484"
assignee: "Editor"
created_at: "2026-10-09T18:14:08.290Z"
updated_at: "2026-10-09T18:14:09.239Z"
---
# M1-T2 — Review note

**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: 01a121df-5990-706e-954c-b76c766cf484 -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a121df-5962-7883-908e-acf48f0c5a5b -->

## Requirements

Inspect the paragraph.

## Definition of Done

- [ ] Recorded review. <!-- id: 01a121df-5a43-7abe-ae96-0c29069d1489 -->
