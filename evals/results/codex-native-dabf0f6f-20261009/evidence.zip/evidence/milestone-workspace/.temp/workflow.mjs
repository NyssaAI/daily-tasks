import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3';
const cli=path.join(pkg,'bin/daily-tasks.mjs'), vault=path.join(root,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'job-search'), m=path.join(project,'m1-career-materials');
let seq=0;
function call(op,input){const stem=String(++seq).padStart(3,'0')+'-'+op;const args=[cli,op];if(input!==undefined){const p=path.join(scratch,stem+'.input.json');fs.writeFileSync(p,JSON.stringify(input,null,2));args.push('--input',p);}const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(path.join(scratch,stem+'.result.json'),JSON.stringify({command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status!==0)throw Error(op+': '+r.stderr);return JSON.parse(r.stdout);}
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const read=p=>fs.readFileSync(p,'utf8');
const id=()=>{const r=call('new-id');return typeof r==='string'?r:r.id;};
const context=call('resolve-context',{vaultRoot:vault});fs.writeFileSync(path.join(scratch,'context.json'),JSON.stringify(context,null,2));
const scope={vaultRoot:vault,profilePath:context.profilePath,stateRoot:context.stateRoot,configRoot:context.configRoot};
const files={p:path.join(project,'project-index.md'),m:path.join(m,'m1-career-materials.md'),t1:path.join(m,'t1-update-linkedin.md'),t2:path.join(m,'t2-update-resume.md')};
const ids=Object.fromEntries(Object.entries(files).map(([k,p])=>[k,read(p).match(/^id: "([^"]+)"/m)[1]]));
fs.mkdirSync(path.join(scratch,'before'),{recursive:true});for(const [k,p]of Object.entries(files))fs.copyFileSync(p,path.join(scratch,'before',k+'.md'));
fs.writeFileSync(path.join(scratch,'initial-layout.json'),JSON.stringify({files,inputs:fs.readdirSync(path.join(m,'inputs')),outputs:fs.readdirSync(path.join(m,'outputs'))},null,2));
call('inspect-records',{projectsRoot:projects});call('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:path.join(vault,'Daily')});call('log-query',{projectsRoot:projects,limit:1000});
function transaction(action,changes,recordIds,before,after,words){
 const timing=call('activity-time',{}),operation=id(),event={id:id(),operation_id:operation,action,record_ids:recordIds,actor:{kind:'person',id:context.user?.email??'synthetic@example.test'},...timing,original_words:words,before,after};
 const effects=Object.entries(changes).map(([p,text])=>({path:p,before:fs.existsSync(p)?hash(fs.readFileSync(p)):null,after:text===null?null:hash(text)}));
 const checkpoint={schemaVersion:2,operation_id:operation,contextBinding:context.planningBinding,event,files:effects};
 const opPath=path.join(context.stateRoot,'operations',operation+'.json');fs.mkdirSync(path.dirname(opPath),{recursive:true});fs.writeFileSync(opPath,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(scratch,operation+'.checkpoint.json'),JSON.stringify(checkpoint,null,2));
 for(const effect of effects){if(effect.before!==null){const bytes=fs.readFileSync(effect.path);if(hash(bytes)!==effect.before)throw Error('Changed source');fs.mkdirSync(path.join(project,'.temp'),{recursive:true});fs.writeFileSync(path.join(project,'.temp',operation+'-'+path.basename(effect.path)),bytes);}const text=changes[effect.path];if(text===null)fs.unlinkSync(effect.path);else{fs.mkdirSync(path.dirname(effect.path),{recursive:true});fs.writeFileSync(effect.path,text);}}
 call('invalidate-project-index',{vaultRoot:vault});call('inspect-records',{projectsRoot:projects});call('log-append',{projectsRoot:projects,entry:event});call('log-query',{projectsRoot:projects,limit:1000});const v=call('operation-verify',{...scope,operationPath:opPath});const c=call('operation-complete',{...scope,operationPath:opPath});if(c.status!=='complete'&&c.status!=='completed')throw Error('Completion: '+JSON.stringify(c));
}
const h1=path.join(m,'outputs','linkedin-headline-draft.md'),h2=path.join(m,'outputs','resume-summary-draft.md');
const linked='[[outputs/linkedin-headline-draft.md|Headline draft]]',summary='[[outputs/resume-summary-draft.md|Summary draft]]';
const changes={};for(const [source,name]of [['a/source.txt','linkedin-source.txt'],['b/source.txt','resume-source.txt'],['shared.txt','shared-style-guide.txt']])changes[path.join(m,'inputs',name)]=read(path.join(root,'attachments',source));
changes[path.join(m,'inputs','task-shaped-reference.md')]=read(files.t1);
changes[h1]='# LinkedIn headline draft\n\nCareer materials in progress | Preparing a focused professional profile\n\nDraft for user review. Source supplies no professional background; no credentials or experience are asserted.\n';
changes[h2]='# Resume summary draft\n\nPreparing focused career materials with a clear professional profile and concise resume summary.\n\nDraft for user review. Uses the headline draft in place; supplied sources contain no career facts. Add verified experience before publication.\n';
for(const key of ['t1','t2']){let text=read(files[key]);text=text.replace('No source material has been supplied. Local working inputs belong in inputs/.',`- [[inputs/${key==='t1'?'linkedin':'resume'}-source.txt|Original ${key==='t1'?'LinkedIn':'resume'} source]] — imported unchanged from attachments/${key==='t1'?'a':'b'}/source.txt.\n- [[inputs/shared-style-guide.txt|Shared style guide]] — one working copy from attachments/shared.txt.\n${key==='t1'?'- [[inputs/task-shaped-reference.md|Task-shaped reference attachment]] — copied identity is source content, not accepted work.':`- ${linked} — consume task 1's existing output in place.`}`);const artifact=key==='t1'?linked:summary;text=text.replace('Save the '+(key==='t1'?'headline':'summary')+' locally in outputs/. Link the actual artifact here and from the milestone after review.',`Local draft delivered: ${artifact}. User review remains required.`).replace('Work has not started; no artifact has been produced or reviewed.',`Draft delivered: ${artifact}. Review has not been reported; Definition of Done remains unchecked.`);changes[files[key]]=text;}
transaction('artifacts.delivered',changes,[ids.t1,ids.t2],{inputs:[],outputs:[]},{inputs:Object.keys(changes).filter(p=>p.includes('/inputs/')||p.includes('\\inputs\\')),outputs:[h1,h2]},'Import originals and shared input; authorize two local draft outputs; task2 consumes task1 output in place.');
fs.writeFileSync(path.join(scratch,'stage1.json'),JSON.stringify({ids,h1,h2},null,2));
const inspect=call('inspect-records',{projectsRoot:projects});fs.writeFileSync(path.join(scratch,'inspect-stage1.json'),JSON.stringify(inspect,null,2));
call('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:path.join(vault,'Daily'),timezone:context.timezone,forceRefresh:true});
call('check-closure',{recordId:ids.t1,records:inspect.records});call('check-closure',{recordId:ids.t2,records:inspect.records});
fs.writeFileSync(path.join(scratch,'session.json'),JSON.stringify({root,scratch,pkg,cli,vault,projects,project,m,context,scope,files,ids,h1,h2,seq},null,2));
