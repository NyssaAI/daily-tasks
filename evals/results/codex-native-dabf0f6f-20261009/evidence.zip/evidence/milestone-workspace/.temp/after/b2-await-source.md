---
id: "01a121df-bdb2-77b0-9ddc-6195f2b32383"
type: blocker
record_version: 2
title: "Await source"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:14:33.696Z"
updated_at: "2026-10-09T18:14:33.696Z"
---
# Await source

Waiting for source from the user.

## Resolution condition

The user supplies source.

## Resolution evidence

None reported.

## Blocks

- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->
