---
id: "01a121df-b86f-7220-b83d-eb44bf7bad9f"
type: task
record_version: 2
title: "Polish summary"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:14:32.393Z"
updated_at: "2026-10-09T18:14:32.393Z"
task-state: not-started
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
---
# M1-T3 — Polish summary

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Polish summary.

## Definition of Done

- [ ] User reviewed polished summary. <!-- id: 01a121df-b89b-78d1-bb46-59397b3200c1 -->

## Inputs

- [[outputs/resume-summary-draft.md|Summary draft]] — existing output in place.

## Output and delivery

Save a polished summary locally in outputs/ when executed, and link the actual artifact.

## Verification

Require explicit user review before satisfying the criterion.

## Result

Accepted; work has not started.
