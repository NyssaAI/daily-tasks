---
id: "01a121df-c229-7714-b332-4df9d3ef4ce2"
type: blocker
record_version: 2
title: "Await signoff"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:14:34.839Z"
updated_at: "2026-10-09T18:14:34.839Z"
---
# Await signoff

Waiting for signoff from the user.

## Resolution condition

The user supplies signoff.

## Resolution evidence

None reported.

## Blocks


