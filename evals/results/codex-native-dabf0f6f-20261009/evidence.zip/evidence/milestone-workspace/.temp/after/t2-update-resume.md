---
id: "01a1211c-fc6d-7e56-b639-7133ec8fe4d6"
type: "task"
record_version: 2
title: "Update resume"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: "reviewed"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a summary.

## Definition of Done

- [ ] A reviewed summary is saved locally. <!-- id: 01a1211c-fd0c-7f8e-9ff3-557373a0657f -->

## Inputs

- [[inputs/resume-source.txt|Original resume source]] — imported unchanged from attachments/b/source.txt.
- [[inputs/shared-style-guide.txt|Shared style guide]] — one working copy from attachments/shared.txt.
- [[outputs/linkedin-headline-review-draft.md|Headline draft]] — consume task 1's existing output in place.

## Output and delivery

Local draft delivered: [[outputs/resume-summary-draft.md|Summary draft]]. User review remains required.

## Verification

Confirm the summary was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Draft delivered: [[outputs/resume-summary-draft.md|Summary draft]]. Review has not been reported; Definition of Done remains unchecked.

## Blocked by

- [[../blockers/b2-await-source|Await source]] <!-- ref: 01a121df-bdb2-77b0-9ddc-6195f2b32383 -->
