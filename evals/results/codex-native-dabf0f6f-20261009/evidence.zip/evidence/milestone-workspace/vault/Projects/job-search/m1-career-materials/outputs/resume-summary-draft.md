# Resume summary draft

Preparing focused career materials with a clear professional profile and concise resume summary.

Draft for user review. Uses the headline draft in place; supplied sources contain no career facts. Add verified experience before publication.
