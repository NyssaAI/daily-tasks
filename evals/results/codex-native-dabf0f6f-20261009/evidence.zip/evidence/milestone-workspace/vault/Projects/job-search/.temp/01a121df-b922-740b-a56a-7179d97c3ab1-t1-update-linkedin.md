---
id: "01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8"
type: "task"
record_version: 2
title: "Update LinkedIn"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: "reviewed"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a headline.

## Definition of Done

- [ ] A reviewed headline is saved locally. <!-- id: 01a1211c-fcde-77f4-84d8-63271f429f17 -->

## Inputs

- [[inputs/linkedin-source.txt|Original LinkedIn source]] — imported unchanged from attachments/a/source.txt.
- [[inputs/shared-style-guide.txt|Shared style guide]] — one working copy from attachments/shared.txt.
- [[inputs/task-shaped-reference.md|Task-shaped reference attachment]] — copied identity is source content, not accepted work.

## Output and delivery

Local draft delivered: [[outputs/linkedin-headline-draft.md|Headline draft]]. User review remains required.

## Verification

Confirm the headline was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Draft delivered: [[outputs/linkedin-headline-draft.md|Headline draft]]. Review has not been reported; Definition of Done remains unchecked.
