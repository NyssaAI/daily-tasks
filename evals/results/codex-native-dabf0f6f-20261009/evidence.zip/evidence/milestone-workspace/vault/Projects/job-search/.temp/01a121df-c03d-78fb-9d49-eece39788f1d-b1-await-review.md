---
id: "01a121df-bb45-70d6-a47a-ab0fec44fecb"
type: blocker
record_version: 2
title: "Await review"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:14:33.073Z"
updated_at: "2026-10-09T18:14:33.073Z"
---
# Await review

Waiting for review from the user.

## Resolution condition

The user supplies review.

## Resolution evidence

None reported.

## Blocks


