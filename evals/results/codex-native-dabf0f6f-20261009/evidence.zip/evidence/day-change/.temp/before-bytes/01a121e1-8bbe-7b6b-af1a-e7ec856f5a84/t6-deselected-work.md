---
id: "01a121df-53a0-760b-a55b-29b795dc4654"
type: task
title: "Deselected work"
created_at: "2026-10-05T16:00:00.000Z"
updated_at: "2026-10-05T16:00:00.000Z"
record_version: 2
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
task-state: not-started
---
# M1-T6 — Deselected work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

optional draft

## Definition of Done

- [ ] reviewed draft <!-- id: 01a121df-53ca-7bb0-86df-8f35d7731b13 -->

## Result

Work has not started.
