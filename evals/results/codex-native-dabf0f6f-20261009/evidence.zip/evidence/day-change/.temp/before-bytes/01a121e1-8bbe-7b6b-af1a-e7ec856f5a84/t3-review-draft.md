---
id: "01a121df-51f1-72e0-bb96-d999329f8f67"
type: task
title: "Review draft"
created_at: "2026-10-05T16:00:00.000Z"
updated_at: "2026-10-05T16:00:00.000Z"
record_version: 2
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
task-state: not-started
assignee: "Reviewer"
---
# M1-T3 — Review draft

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

inspect draft

## Definition of Done

- [ ] recorded review <!-- id: 01a121df-521e-7f1d-848d-aed042058b85 -->

## Result

Work has not started.
