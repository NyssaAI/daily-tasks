---
id: "01a121df-5282-7eca-9d4d-fbb26ee3dc7b"
type: task
title: "Past work"
created_at: "2026-10-05T16:00:00.000Z"
updated_at: "2026-10-05T16:00:00.000Z"
record_version: 2
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
task-state: completed
resolved_at: "2026-10-05T16:00:00.000Z"
---
# M1-T4 — Past work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

past result

## Definition of Done

- [x] reviewed result <!-- id: 01a121df-52ac-7c70-84f9-6cd7d4bdcd62 -->

## Result

User explicitly attests the past result was reviewed.
