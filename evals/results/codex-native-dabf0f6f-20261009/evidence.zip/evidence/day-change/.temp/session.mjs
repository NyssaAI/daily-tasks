import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
export const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3/bin/daily-tasks.mjs';
export const monday='2026-10-05T16:00:00Z', tuesday='2026-10-06T16:00:00Z', friday='2026-10-09T16:00:00Z';
export const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
export const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
export function write(p,s){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);}
let seq=fs.existsSync(path.join(scratch,'sequence'))?Number(read(path.join(scratch,'sequence'))):0;
export function call(op,input){const tag=String(++seq).padStart(3,'0')+'-'+op;write(path.join(scratch,'sequence'),String(seq));const args=[cli,op];if(input){const p=path.join(scratch,tag+'-input.json');write(p,JSON.stringify(input,null,2));args.push('--input',p);}const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(path.join(scratch,tag+'-result.json'),JSON.stringify({args,exit:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status!==0)throw Error(tag+': '+r.stderr);return JSON.parse(r.stdout);}
export const id=()=>call('new-id').id;
export function snapshot(name,v=vault){const dest=path.join(scratch,name);function walk(p){for(const e of fs.readdirSync(p,{withFileTypes:true})){if(e.name==='.daily-tasks'||e.name==='.temp')continue;const f=path.join(p,e.name);if(e.isDirectory())walk(f);else write(path.join(dest,path.relative(v,f)),fs.readFileSync(f));}}walk(v);}
if(process.argv[2]==='prepare'){snapshot('initial');const p=call('planning-prepare',{vaultRoot:vault,now:friday});write(path.join(scratch,'initial-packet.json'),JSON.stringify(p,null,2));console.log(JSON.stringify(p,null,2));}
