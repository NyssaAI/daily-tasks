---
id: "01a121df-61b9-77fb-a47d-c99393cff409"
type: "project"
record_version: 2
title: "Job Search"
project-state: "not-started"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:14:48.468Z"
updated_at: "2026-10-09T18:14:48.468Z"
---
# Job Search

Prepare career materials.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a121df-61e5-7174-9a0f-201c6a1b4782 --> | | Career materials | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a121df-620e-78e5-a19b-6b1084bf8d53 --> | Update headline | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a121df-6238-7b55-80ba-a9bb5de4b9fe --> | Update summary | synthetic@example.test | — |
