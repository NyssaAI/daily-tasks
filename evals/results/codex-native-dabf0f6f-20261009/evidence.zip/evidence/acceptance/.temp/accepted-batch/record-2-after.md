---
id: "01a121df-61e5-7174-9a0f-201c6a1b4782"
type: "milestone"
record_version: 2
title: "Career materials"
milestone-state: "not-started"
owner: "synthetic@example.test"
project_id: "01a121df-61b9-77fb-a47d-c99393cff409"
created_at: "2026-10-09T18:14:48.468Z"
updated_at: "2026-10-09T18:14:48.468Z"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a121df-61b9-77fb-a47d-c99393cff409 -->

## Outcome

Prepare the LinkedIn headline and resume summary.

## Definition of Done

- [ ] Both reviewed artifacts linked. <!-- id: 01a121df-62be-7511-8206-987b666b04af -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a121df-620e-78e5-a19b-6b1084bf8d53 -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a121df-6238-7b55-80ba-a9bb5de4b9fe -->
