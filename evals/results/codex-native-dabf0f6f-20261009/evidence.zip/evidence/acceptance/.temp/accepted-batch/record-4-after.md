---
id: "01a121df-6238-7b55-80ba-a9bb5de4b9fe"
type: "task"
record_version: 2
title: "Update resume"
task-state: "not-started"
owner: "synthetic@example.test"
project_id: "01a121df-61b9-77fb-a47d-c99393cff409"
milestone_id: "01a121df-61e5-7174-9a0f-201c6a1b4782"
created_at: "2026-10-09T18:14:48.468Z"
updated_at: "2026-10-09T18:14:48.468Z"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a121df-61e5-7174-9a0f-201c6a1b4782 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a121df-61b9-77fb-a47d-c99393cff409 -->

## Requirements

Update summary.

## Definition of Done

- [ ] Reviewed summary. <!-- id: 01a121df-6294-730b-a80f-269c4dbc0c5d -->

## Inputs

No source artifact supplied yet. Local inputs belong in inputs/.

## Output and delivery

Link the reviewed artifact here and from the milestone when available. Local artifacts belong in outputs/.

## Verification

Verify the stated review criterion and retain its artifact link.

## Result

Pending execution.
