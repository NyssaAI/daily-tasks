import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const cwd=process.cwd(), evidence=path.join(cwd,'.temp'), vault=path.join(cwd,'vault');
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const plan=path.join(vault,'Daily/2026-10-09.md');
const before=fs.readFileSync(plan);
fs.writeFileSync(path.join(evidence,'plan-before.md'),before);
function call(name,input,label=name){const file=path.join(evidence,label+'-input.json');fs.writeFileSync(file,JSON.stringify(input,null,2)); const r=spawnSync(process.execPath,[cli,name,'--input',file],{encoding:'utf8'});fs.writeFileSync(path.join(evidence,label+'-result.json'),r.stdout);fs.writeFileSync(path.join(evidence,label+'-execution.json'),JSON.stringify({command:[process.execPath,cli,name,'--input',file],exitCode:r.status,stderr:r.stderr},null,2));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const context=call('resolve-context',{vaultRoot:vault});
fs.writeFileSync(path.join(evidence,'resolved-context.json'),JSON.stringify(context,null,2));
const projectsRoot=context.projectsRoot;
const records=call('inspect-records',{projectsRoot},'records-before');
call('log-query',{projectsRoot,limit:1000,offset:0},'log-before');
call('parse-checklist',{markdown:before.toString()},'manual-checkbox');
console.log(JSON.stringify({context,records},null,2));
