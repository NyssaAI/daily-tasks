import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
const root=path.resolve('.temp/native-acceptance/runtime-guards-full8-v2/cases/acceptance'),e=path.join(root,'.temp/accepted-batch');
const s=JSON.parse(fs.readFileSync(path.join(e,'session.json'),'utf8')),q=JSON.parse(fs.readFileSync(path.join(e,'proposal.json'),'utf8'));const {c,ctx,planPath,planHash,history}=s;
const cli=path.resolve('.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3/bin/daily-tasks.mjs');let n=40;
function call(op,input){const prefix=path.join(e,`${++n}-${op}`);fs.writeFileSync(prefix+'-input.json',JSON.stringify(input,null,2));const args=[cli,op,'--input',prefix+'-input.json'];const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(prefix+'-result.json',r.stdout);fs.writeFileSync(prefix+'-execution.json',JSON.stringify({command:[process.execPath,...args],exitCode:r.status,stderr:r.stderr},null,2));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const hash=s=>createHash('sha256').update(s).digest('hex');
const words='I explicitly accept this batch: create Job Search project, M1 Career materials milestone, Update LinkedIn task (requirement: update headline; DoD: reviewed headline), and Update resume task (requirement: update summary; DoD: reviewed summary). Milestone DoD: both reviewed artifacts linked. Owner synthetic@example.test; all accepted work not started and unchecked. Accept no other work.';
const event={id:q.eventId,operation_id:q.op,action:'batch.accepted',record_ids:[q.p,q.m,q.t1,q.t2],actor:{kind:'person',id:'synthetic@example.test'},...q.time,original_words:words,before:{records:[]},after:{acceptance_source:'Current explicit user batch acceptance',records:q.records}};
const checkpoint={schemaVersion:2,operation_id:q.op,contextBinding:c.planningBinding,event,files:q.paths.map((p,i)=>({path:p,before:null,after:hash(q.markdown[i])})),protectedFiles:[{path:planPath,sha256:planHash}]};
const operationPath=path.join(c.stateRoot,'operations',q.op+'.json');fs.mkdirSync(path.dirname(operationPath),{recursive:true});fs.writeFileSync(operationPath,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(e,'checkpoint-before.json'),JSON.stringify(checkpoint,null,2));
for(let i=0;i<q.paths.length;i++){if(fs.existsSync(q.paths[i]))throw Error('Destination exists');fs.mkdirSync(path.dirname(q.paths[i]),{recursive:true});fs.writeFileSync(q.paths[i],q.markdown[i]);fs.writeFileSync(path.join(e,`record-${i+1}-after.md`),fs.readFileSync(q.paths[i]));}
for(const d of ['inputs','outputs'])fs.mkdirSync(path.join(q.milestoneDir,d),{recursive:true});
call('invalidate-project-index',{vaultRoot:c.vaultRoot});
const actual=call('inspect-records',{projectsRoot:c.projectsRoot});
for(const op of ['validate-records','check-links']){const r=call(op,{records:actual.records});if(r.diagnostics.length)throw Error(JSON.stringify(r));}
if(actual.records.length!==4)throw Error('Wrong record count');
const clock=JSON.parse(fs.readFileSync(path.join(e,'21-activity-time-result.json'),'utf8'));
if(event.activity_at!==clock.activity_at||event.recorded_at!==clock.recorded_at)throw Error('Timestamp mismatch');
call('log-append',{projectsRoot:c.projectsRoot,entry:event});
const after=call('log-query',{projectsRoot:c.projectsRoot,limit:1000,offset:0});
const queried=after.entries.find(x=>x.id===q.eventId);if(JSON.stringify(queried)!==JSON.stringify(event))throw Error('Exact event differs');
const verify=call('operation-verify',{...ctx,operationPath});console.log(JSON.stringify(verify));
if(verify.status!=='verified')throw Error('Operation not verified');
const complete=call('operation-complete',{...ctx,operationPath});console.log(JSON.stringify(complete));
const candidates=JSON.parse(fs.readFileSync(path.join(c.stateRoot,'candidates.json'),'utf8'));
for(const candidate of candidates.candidates){const id=candidate.title==='Update LinkedIn'?q.t1:candidate.title==='Update resume'?q.t2:null;if(id){candidate.disposition='accepted';candidate.accepted=true;candidate.record_id=id;candidate.project=q.p;candidate.milestone=q.m;candidate.unresolved=[];candidate.acceptance={source:'Current explicit user batch acceptance',event_id:q.eventId,operation_id:q.op,recorded_at:event.recorded_at};}}
fs.writeFileSync(path.join(c.stateRoot,'candidates.json'),JSON.stringify(candidates,null,2)+'\n');fs.writeFileSync(path.join(e,'candidates-after.json'),JSON.stringify(candidates,null,2));
const planAfter=fs.readFileSync(planPath);fs.writeFileSync(path.join(e,'manual-plan-after.md'),planAfter);
for(const id of event.record_ids)call('log-query',{projectsRoot:c.projectsRoot,recordId:id,limit:1000,offset:0});
const proof={acceptedRecordsBefore:0,acceptedRecordsAfter:4,newAcceptanceEvents:after.entries.length-history.entries.length,earlierHistoryUnchanged:history.entries.every(x=>JSON.stringify(x)===JSON.stringify(after.entries.find(y=>y.id===x.id))),manualPlanUnchanged:hash(planAfter)===planHash,metadataAndLinksValid:true,operationVerify:verify,operationComplete:complete,actions:['Resolved original synthetic vault despite changed cwd','Captured zero-record before scan and exact setup-only log query','Generated UUIDv7 record, criterion, operation and event identities','Authored and validated four accepted records','Saved schemaV2 checkpoint before writes with protected manual plan hash','Created project, milestone, two tasks and flat holding directories','Invalidated project inventory','Appended current explicit acceptance through installed CLI','Compared complete queried event payload','Verified and completed operation through installed CLI','Resolved two candidates to their accepted task IDs; preserved source keys']};fs.writeFileSync(path.join(e,'proof.json'),JSON.stringify(proof,null,2));console.log(JSON.stringify(proof,null,2));
