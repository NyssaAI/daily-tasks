---
id: "01a121df-816a-7b25-bb95-9f6be6084484"
type: blocker
record_version: 2
title: "Await approval"
blocker-state: "resolved"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:14:18.264Z"
updated_at: "2026-10-09T18:14:25.998Z"
resolved_at: "2026-10-09T18:14:25.998Z"
---
# Await approval

External approval pending for both career artifacts.

## Resolution condition
Synthetic reviewer explicitly approves both artifacts.

## Resolution evidence
Synthetic reviewer approved both linked artifacts.

## Blocks
- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->
