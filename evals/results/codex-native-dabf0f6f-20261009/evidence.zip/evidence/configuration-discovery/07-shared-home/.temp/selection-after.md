---
id: "01a121df-3e8c-7573-ae6d-1f218b4c3fe1"
type: daily-plan
title: "Daily plan 2026.10.09"
timezone: "America/Chicago"
created_at: "2026-10-09T18:14:01.055Z"
updated_at: "2026-10-09T18:14:29.405Z"
---
# Daily plan — 2026.10.09

Open projects: 1          Open tasks: 1          Late tasks: 0

**Timezone:** America/Chicago

## Selected for today

### My work

#### Job Search / update LinkedIn and resume

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | update LinkedIn and resume | [[../Projects/job-search/m1-update-linkedin-and-resume/t1-routing-note\|Routing note]] <!-- ref: 01a121de-f122-7b96-ab0e-74bd23858b7b --> | — |

### Delegated work

No delegated work selected.

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled
