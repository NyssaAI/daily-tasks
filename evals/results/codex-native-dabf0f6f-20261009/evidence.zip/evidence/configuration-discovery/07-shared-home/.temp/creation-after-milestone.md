---
id: "01a121de-f0f4-7d66-b206-fcd215702d57"
type: milestone
record_version: 2
title: "update LinkedIn and resume"
owner: "synthetic@example.test"
milestone-state: not-started
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
created_at: "2026-10-09T18:13:41.418Z"
updated_at: "2026-10-09T18:13:41.418Z"
---
# M1 — update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Outcome

Update LinkedIn and resume.

## Definition of Done

- [ ] reviewed career materials <!-- id: 01a121de-f150-7122-a6fc-8eaeb095ac84 -->

## Tasks

- [ ] [[t1-routing-note|Routing note]] <!-- ref: 01a121de-f122-7b96-ab0e-74bd23858b7b -->
