import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3';
export const temp=path.join(root,'.temp'), vault=path.join(root,'vault-a');
export function save(name,value){const p=path.join(temp,name);fs.writeFileSync(p,typeof value==='string'?value:JSON.stringify(value,null,2));return p;}
let n=0;
export function cli(op,input){const label=`${Date.now()}-${n++}-${op}`;const args=[path.join(pkg,'bin/daily-tasks.mjs'),op];if(input)args.push('--input',save(label+'-input.json',input));const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(label+'-result.json',{status:r.status,stdout:r.stdout,stderr:r.stderr,args});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const opts={vaultRoot:vault,homeRoot:path.join(root,'synthetic-home'),configRoot:path.join(root,'synthetic-home/.nyssaai/daily-tasks')};
