---
id: "01a121e0-f006-76cf-8581-785081e350b6"
type: milestone
record_version: 2
title: "Update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8f07-738f-bb1a-b031e17a0106"
created_at: "2026-10-09T18:15:52.016Z"
updated_at: "2026-10-09T18:15:52.016Z"
---
# M1 — Update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8f07-738f-bb1a-b031e17a0106 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] Reviewed career materials. <!-- id: 01a121e0-f038-714d-a995-9da58d70a657 -->

## Tasks

No tasks accepted.
