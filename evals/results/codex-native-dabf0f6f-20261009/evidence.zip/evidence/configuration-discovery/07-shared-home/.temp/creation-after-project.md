---
id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:11.958Z"
updated_at: "2026-10-09T18:13:41.418Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — update LinkedIn and resume]] <!-- ref: 01a121de-f0f4-7d66-b206-fcd215702d57 -->

## Tasks

- [ ] [[m1-update-linkedin-and-resume/t1-routing-note|Routing note]] <!-- ref: 01a121de-f122-7b96-ab0e-74bd23858b7b -->
