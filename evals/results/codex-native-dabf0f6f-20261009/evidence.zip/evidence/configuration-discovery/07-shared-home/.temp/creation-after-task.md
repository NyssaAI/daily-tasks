---
id: "01a121de-f122-7b96-ab0e-74bd23858b7b"
type: task
record_version: 2
title: "Routing note"
owner: "synthetic@example.test"
task-state: not-started
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
milestone_id: "01a121de-f0f4-7d66-b206-fcd215702d57"
created_at: "2026-10-09T18:13:41.418Z"
updated_at: "2026-10-09T18:13:41.418Z"
---
# M1-T1 — Routing note

**Milestone:** [[m1-update-linkedin-and-resume|update LinkedIn and resume]] <!-- ref: 01a121de-f0f4-7d66-b206-fcd215702d57 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Requirements

local routing test note

## Definition of Done

- [ ] reviewed routing note <!-- id: 01a121de-f17c-7c0c-bd35-17169a25badf -->
