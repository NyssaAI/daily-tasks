import fs from 'node:fs/promises';import path from 'node:path';import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
const dir=path.resolve('01-common-root'),e=path.join(dir,'.temp'),c=JSON.parse(await fs.readFile(path.join(e,'resolved-context.json'),'utf8')),cp=JSON.parse(await fs.readFile(path.join(e,'checkpoint.saved.json'),'utf8'));
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const hash=s=>createHash('sha256').update(s).digest('hex');const save=(p,x)=>fs.writeFile(p,typeof x==='string'?x:JSON.stringify(x,null,2)+'\n');let seq=20;
const call=async(op,input)=>{const p=path.join(e,`${++seq}-${op}`);await save(p+'.input.json',input);const args=[cli,op,'--input',p+'.input.json'];const r=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8'});await save(p+'.result.json',{command:[process.execPath,...args],cwd:dir,exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);};
const criterion=JSON.parse(JSON.parse(await fs.readFile(path.join(e,'06-new-id.result.json'),'utf8')).stdout).id;
cp.operation_id=cp.operation_id.id;cp.event.id=cp.event.id.id;cp.event.operation_id=cp.operation_id;cp.event.record_ids=cp.event.record_ids.map(x=>x.id);
const oldPath=path.join(c.stateRoot,'operations','[object Object].json'),opPath=path.join(c.stateRoot,'operations',cp.operation_id+'.json');
const texts=[];for(const [i,f] of cp.files.entries()){let text=await fs.readFile(f.path,'utf8');if(i===0)text=text.replace('[object Object]',cp.event.record_ids[0]);else{text=text.replace('[object Object]',cp.event.record_ids[0]).replace('[object Object]',criterion);}f.after=hash(text);texts.push(text);}
await save(opPath,cp);await save(path.join(e,'checkpoint.corrected.json'),cp);
for(let i=0;i<cp.files.length;i++)await save(cp.files[i].path,texts[i]);await fs.unlink(oldPath);
await save(path.join(e,'project.after.md'),texts[0]);await save(path.join(e,'milestone.after.md'),texts[1]);
await call('log-append',{projectsRoot:c.projectsRoot,entry:cp.event});await call('invalidate-project-index',{vaultRoot:c.vaultRoot});
const inspection=await call('inspect-records',{projectsRoot:c.projectsRoot});await call('inspect-navigation',{projectsRoot:c.projectsRoot,dailyPlansRoot:c.dailyPlansRoot});
const input={vaultRoot:c.vaultRoot,homeRoot:c.homeRoot,profilePath:c.profilePath,stateRoot:c.stateRoot,operationPath:opPath};
const verification=await call('operation-verify',input);if(verification.status!=='verified')throw Error(JSON.stringify(verification));const completion=await call('operation-complete',input);const logs=await call('log-query',{projectsRoot:c.projectsRoot,limit:1000});
const before=await fs.readFile(path.join(e,'profile.before.json')),after=await fs.readFile(c.profilePath);if(!before.equals(after))throw Error('Profile changed');await fs.writeFile(path.join(e,'profile.after.json'),after);await save(path.join(e,'summary.json'),{resolved:c,verification,completion,inspection,logs,profilePreserved:true,recovery:'Corrected UUID object extraction; retained original generated IDs and timestamps'});console.log(JSON.stringify({verification,completion}));
