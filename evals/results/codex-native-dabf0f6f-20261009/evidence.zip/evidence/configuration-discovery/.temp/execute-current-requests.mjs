import fs from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=process.cwd();
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const hash=x=>createHash('sha256').update(x).digest('hex');
const save=async(p,x)=>{await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,typeof x==='string'?x:JSON.stringify(x,null,2)+'\n');};
for(const name of ['02-no-profile','03-explicit-legacy','04-vault-only-legacy']){
 const dir=path.join(root,name), evidence=path.join(dir,'.temp'), vault=path.join(dir,'vault'); let seq=0;
 await fs.mkdir(evidence,{recursive:true});
 const call=async(op,input)=>{
  const prefix=path.join(evidence,String(++seq).padStart(2,'0')+'-'+op);
  const args=[cli,op]; if(input!==undefined){await save(prefix+'.input.json',input);args.push('--input',prefix+'.input.json');}
  const r=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8'});
  await save(prefix+'.result.json',{command:[process.execPath,...args],cwd:dir,exitCode:r.status,stdout:r.stdout,stderr:r.stderr});
  if(r.status!==0)throw Error(name+' '+op+' '+r.stderr);
  const value=JSON.parse(r.stdout);return op==='new-id'?value.id:value;
 };
 const commonProfile=path.join(dir,'common','.nyssaai','daily-tasks','profile.json');
 const profilePath=name.startsWith('01')||name.startsWith('02')?commonProfile:path.join(vault,'.nyssa','daily-tasks','profile.json');
 let profileBefore=null; try{profileBefore=await fs.readFile(profilePath);}catch(e){if(e.code!=='ENOENT')throw e;}
 if(profileBefore)await fs.writeFile(path.join(evidence,'profile.before.json'),profileBefore);
 const contextInput={vaultRoot:vault,homeRoot:path.join(dir,'synthetic-home'),stateRoot:path.join(vault,'.nyssaai','daily-tasks')};
 // Ordered skill discovery maps the accepted common root to an exact profile pointer; no configRoot argument.
 if(!name.startsWith('04'))contextInput.profilePath=profilePath;
 let context=await call('resolve-context',contextInput);
 if(!context.configured){
  const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
  const valid=await call('validate-profile',profile); if(!valid.valid)throw Error(JSON.stringify(valid));
  await save(profilePath,profile); context=await call('resolve-context',contextInput);
  const timing=await call('activity-time',{});
  await call('log-append',{projectsRoot:context.projectsRoot,entry:{id:await call('new-id'),operation_id:await call('new-id'),action:'profile.configured',record_ids:[],actor:{kind:'person',id:'synthetic@example.test'},...timing,original_words:'Initialize accepted common scope with Synthetic User synthetic@example.test America/Chicago and empty priorities',before:null,after:profile}});
 }
 await save(path.join(evidence,'resolved-context.json'),context);
 const projectPath=path.join(context.projectsRoot,'job-search','project-index.md');
 const before=await fs.readFile(projectPath,'utf8');await save(path.join(evidence,'project.before.md'),before);
 const inspected=await call('inspect-records',{projectsRoot:context.projectsRoot});
 const project=await call('parse-record',{markdown:before,path:projectPath});
 await save(path.join(evidence,'parsed-project.json'),project);
 const projectId=/^id: "?([^"\r\n]+)"?$/m.exec(before)[1];
 const number=await call('next-record-number',{projectsRoot:context.projectsRoot,type:'milestone',parentId:projectId});
 if(number.number!==1)throw Error('M1 unavailable '+JSON.stringify(number));
 const milestoneId=await call('new-id'),criterionId=await call('new-id'),operationId=await call('new-id'),eventId=await call('new-id'),time=await call('activity-time',{});
 const stem='m1-update-linkedin-and-resume',milestonePath=path.join(path.dirname(projectPath),stem,stem+'.md');
 const milestone=`---\nid: ${milestoneId}\ntype: milestone\nrecord_version: 2\ntitle: "Update LinkedIn and resume"\ndocument-maturity: reviewed\nmilestone-state: not-started\nowner: "synthetic@example.test"\nproject_id: "${projectId}"\ncreated_at: "${time.activity_at}"\nupdated_at: "${time.recorded_at}"\n---\n# M1 — Update LinkedIn and resume\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${projectId} -->\n\n## Outcome\n\nUpdate LinkedIn and resume for the job search.\n\n## Definition of Done\n\n- [ ] Reviewed career materials. <!-- id: ${criterionId} -->\n`;
 const after=before.replace(/^updated_at:.*$/m,`updated_at: "${time.recorded_at}"`).replace('No milestones yet.',`- [ ] [[${stem}/${stem}|M1 — Update LinkedIn and resume]] <!-- ref: ${milestoneId} -->`);
 const event={id:eventId,operation_id:operationId,action:'milestone.accepted',record_ids:[milestoneId],actor:{kind:'person',id:'synthetic@example.test'},...time,original_words:'Create M1: update LinkedIn and resume in this project; DoD reviewed career materials; no extra tasks',before:null,after:{title:'Update LinkedIn and resume',project_id:projectId,'milestone-state':'not-started',owner:'synthetic@example.test',definition_of_done:'Reviewed career materials',acceptance_source:'Direct accepted request in current native host session'}};
 const checkpoint={schemaVersion:2,operation_id:operationId,contextBinding:context.planningBinding,event,files:[{path:projectPath,before:hash(before),after:hash(after)},{path:milestonePath,before:null,after:hash(milestone)}]};
 const operationPath=path.join(context.stateRoot,'operations',operationId+'.json');
 await save(operationPath,checkpoint);await save(path.join(evidence,'checkpoint.saved.json'),checkpoint);
 if(hash(await fs.readFile(projectPath))!==hash(before))throw Error('Project changed');
 await save(milestonePath,milestone);await fs.mkdir(path.join(path.dirname(milestonePath),'inputs'),{recursive:true});await fs.mkdir(path.join(path.dirname(milestonePath),'outputs'),{recursive:true});await save(projectPath,after);
 await save(path.join(evidence,'project.after.md'),after);await save(path.join(evidence,'milestone.after.md'),milestone);
 await call('log-append',{projectsRoot:context.projectsRoot,entry:event});
 await call('invalidate-project-index',{vaultRoot:vault});
 await fs.mkdir(context.dailyPlansRoot,{recursive:true});
 const actual=await call('inspect-records',{projectsRoot:context.projectsRoot}); await call('inspect-navigation',{projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot});
 const verificationInput={...contextInput,operationPath};
 const verified=await call('operation-verify',verificationInput);if(verified.status!=='verified')throw Error(JSON.stringify(verified));
 const completed=await call('operation-complete',verificationInput);
 const logs=await call('log-query',{projectsRoot:context.projectsRoot,limit:1000});
 const profileAfter=await fs.readFile(profilePath);await fs.writeFile(path.join(evidence,'profile.after.json'),profileAfter);
 if(profileBefore&&!profileAfter.equals(profileBefore))throw Error('Profile bytes changed');
 await save(path.join(evidence,'summary.json'),{name,contextInput,resolved:context,milestonePath,profilePreserved:profileBefore?profileAfter.equals(profileBefore):null,verification:verified,completion:completed,recordInspection:actual,logs});
 console.log(JSON.stringify({name,milestonePath,verified,completed}));
}
