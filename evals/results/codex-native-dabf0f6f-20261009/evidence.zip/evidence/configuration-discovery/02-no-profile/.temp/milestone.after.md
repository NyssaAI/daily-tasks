---
id: 01a121df-ae2e-7d4e-9bfb-bf40e438b95a
type: milestone
record_version: 2
title: "Update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-7f6f-70d4-8bdd-d891202c26af"
created_at: "2026-10-09T18:14:29.857Z"
updated_at: "2026-10-09T18:14:29.857Z"
---
# M1 — Update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-7f6f-70d4-8bdd-d891202c26af -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] Reviewed career materials. <!-- id: 01a121df-ae5d-7344-8d5e-ec5fb82a8f9d -->
