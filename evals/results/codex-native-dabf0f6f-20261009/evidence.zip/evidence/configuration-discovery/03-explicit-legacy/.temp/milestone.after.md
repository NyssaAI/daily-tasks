---
id: 01a121df-b169-7b5d-b4f8-cb88d1e7a8da
type: milestone
record_version: 2
title: "Update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-84da-767f-85fe-ac147d7ce5e7"
created_at: "2026-10-09T18:14:30.680Z"
updated_at: "2026-10-09T18:14:30.680Z"
---
# M1 — Update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-84da-767f-85fe-ac147d7ce5e7 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] Reviewed career materials. <!-- id: 01a121df-b194-786a-853b-ab1388d564f7 -->
