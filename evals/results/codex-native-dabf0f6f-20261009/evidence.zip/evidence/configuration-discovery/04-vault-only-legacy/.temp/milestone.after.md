---
id: 01a121df-b4a0-79ee-9dcb-ef230a007495
type: milestone
record_version: 2
title: "Update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8905-73e7-bc52-568640c30a2f"
created_at: "2026-10-09T18:14:31.506Z"
updated_at: "2026-10-09T18:14:31.506Z"
---
# M1 — Update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8905-73e7-bc52-568640c30a2f -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] Reviewed career materials. <!-- id: 01a121df-b4cc-7b30-88f9-b02603bab8e4 -->
