---
id: 01a121de-f662-78b5-b424-d7aff461613c
type: milestone
record_version: 2
title: "Update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-7ba5-7700-98fd-8e9d0f32ebe4"
created_at: "2026-10-09T18:13:42.797Z"
updated_at: "2026-10-09T18:13:42.797Z"
---
# M1 — Update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-7ba5-7700-98fd-8e9d0f32ebe4 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] Reviewed career materials. <!-- id: 01a121de-f68d-7862-89e5-bef810c1c299 -->
