---
id: "01a121e1-2bc3-78df-8ad9-f386529b4161"
type: task
record_version: 2
title: "Independent note"
document-maturity: reviewed
task-state: completed
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
created_at: "2026-10-09T18:16:07.452Z"
updated_at: "2026-10-09T18:16:07.452Z"
resolved_at: "2026-10-09T18:16:07.452Z"
---
# M1-T3 — Independent note

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Create a local note.

## Definition of Done

- [x] Reviewed note. <!-- id: 01a121e1-2bef-7ed9-a94f-7ca4a77a3bac -->

## Inputs

User's explicit acceptance and attestation of reviewed synthetic evidence in this request.

## Output and delivery

Local artifact: [[outputs/independent-note|Independent note]].

## Verification

User attests reviewed synthetic evidence; local artifact exists and is linked.

## Result

[[outputs/independent-note|Reviewed synthetic note]] delivered locally under explicit user acceptance.
