import path from 'node:path';
import {out,vault,ctxInput,ctx,state,projects,m,p1,p2,mp,pp,call,id,time,read,save,hash,row,update,parse,transaction} from './actions.mjs';
const a=parse(p1),b=parse(p2),plan=path.join(ctx.dailyPlansRoot,`${ctx.localDate}-daily-plan.md`);
const baseline=()=>JSON.parse(read(path.join(state,'reconciliation.json')));
const entry=(r,views)=>({canonical:{id:r.id,type:r.type,state:r.state},views:Object.fromEntries(views.map(p=>[p,{hash:hash(read(p)),selected:true,checked:r.state==='completed',state:r.state}]))});
const phase=process.argv[2];
if(phase==='baseline'){
 const tm=time(),planId=id();
 const s=`---\nid: "${planId}"\ntype: daily-plan\ntitle: "Daily plan ${ctx.localDate}"\ntimezone: "${ctx.timezone}"\ncreated_at: "${tm.recorded_at}"\nupdated_at: "${tm.recorded_at}"\n---\n# Daily plan — ${ctx.localDate}\n\n**Timezone:** ${ctx.timezone}\n\n## Selected for today\n\n### My work\n\n${row('../Projects/job-search/m1-career-materials/t1-update-linkedin',a.id,a.title)}\n${row('../Projects/job-search/m1-career-materials/t2-update-resume',b.id,b.title)}\n\n### Delegated work\n\nNo delegated work selected.\n\nLegend: [ ] not started · [>] in progress · [x] completed · [-] cancelled\n\n## Notes and references\n\nPreserved original daily note:\n${read(path.join(vault,'Daily/2026-10-09.md'))}\n`;
 const val={schemaVersion:1,records:{[a.id]:{canonical:{id:a.id,type:a.type,state:a.state},views:{[plan]:{hash:hash(s),selected:true,checked:false},[mp]:{hash:hash(read(mp)),checked:false},[pp]:{hash:hash(read(pp)),checked:false}}},[b.id]:{canonical:{id:b.id,type:b.type,state:b.state},views:{[plan]:{hash:hash(s),selected:true,checked:false},[mp]:{hash:hash(read(mp)),checked:false},[pp]:{hash:hash(read(pp)),checked:false}}}}};
 transaction('synthetic.baseline-established',[[p1,read(p1)],[p2,read(p2)],[mp,read(mp)],[pp,read(pp)],[plan,s]],[a.id,b.id],{acceptance:'User authorizes synthetic plan and baseline; preserve unrelated prose'},val);
 save(path.join(state,'candidates.json'),{candidates:[{source:path.join(vault,'Daily/2026-10-09.md'),text:'Maybe improve my resume',disposition:'pending',reason:'Unidentified manual checkbox; no acceptance'}]});
}
if(phase==='complete'){
 const artifact=path.join(m,'outputs/reviewed-linkedin-headline.md');
 const tm=time();let s=update(read(p1),'task-state','completed');s=update(s,'updated_at',tm.recorded_at);s=s.replace('document-maturity: "reviewed"',`resolved_at: "${tm.activity_at}"\ndocument-maturity: "reviewed"`).replace('- [ ] A reviewed headline','- [x] A reviewed headline').replace('Work has not started; no artifact has been produced or reviewed.','Reviewed synthetic evidence, authorized by the user: [[outputs/reviewed-linkedin-headline|Reviewed headline]].').replace('Link the actual artifact here and from the milestone after review.','Link the actual artifact here and from the milestone after review.\n\nArtifact: [[outputs/reviewed-linkedin-headline|Reviewed headline]].');
 const records=call('inspect-records',{projectsRoot:projects}).records;
 const proposed=call('parse-record',{markdown:s,path:p1});const check=call('check-closure',{recordId:a.id,records:records.map(r=>r.id===a.id?proposed:r)});if(!check.allowed)throw Error(JSON.stringify(check));
 const changeMark=(text,tid,mark)=>text.split('\n').map(line=>line.includes(`ref: ${tid}`)?line.replace('[ ]',`[${mark}]`):line).join('\n');
 const ms=changeMark(read(mp),a.id,'x')+'\nReviewed headline: [[outputs/reviewed-linkedin-headline|Reviewed headline]].\n';const ps=changeMark(read(pp),a.id,'x');
 const val=baseline();val.records[a.id].canonical.state='completed';for(const [p,text] of [[mp,ms],[pp,ps]])val.records[a.id].views[p]={hash:hash(text),checked:true};
 // The daily snapshot deliberately remains unchecked, proving an unchanged stale view.
 transaction('task.completed',[[artifact,'# Reviewed synthetic headline\n\nSoftware professional building thoughtful tools.\n\nReview: user attests reviewed synthetic evidence in this acceptance request.\n'],[p1,s],[mp,ms],[pp,ps]],[a.id],{state:'completed',evidence:artifact,acceptance:'User authorized satisfaction of existing criterion with reviewed synthetic evidence'},val);
 const stale=call('reconcile-record',{base:{id:a.id,type:'task'},current:parse(p1),views:[{id:a.id}]});save(path.join(out,'stale-unchanged-checkin.json'),{planHash:hash(read(plan)),viewSnapshot:val.records[a.id].views[plan],result:stale});if(stale.record.state!=='completed'||stale.conflicts.length||stale.changes.length)throw Error('stale reopened');
 // Refresh only task 1 after the stale read; task 2 remains untouched.
 const fresh=changeMark(read(plan),a.id,'x'),val2=baseline();val2.records[a.id].views[plan]={hash:hash(fresh),selected:true,checked:true};
 transaction('view.refreshed',[[plan,fresh]],[a.id],{state:'completed',reason:'Refresh after unchanged stale view reconciled'},val2);
}
if(phase==='manual'){
 // Authorized deliberate edits: task 1 unchecked; task 2 has incompatible projection edits.
 const before=read(plan),edited=before.split('\n').map(line=>line.includes(`ref: ${a.id}`)?line.replace('[x]','[ ]'):line.includes(`ref: ${b.id}`)?line.replace('[ ]','[x]'):line).join('\n');save(path.join(out,'manual-plan-before.md'),before);save(plan,edited);save(path.join(out,'manual-plan-after.md'),edited);
 const mb=read(mp),me=mb.split('\n').map(line=>line.includes(`ref: ${b.id}`)?line.replace('[ ]','[-]'):line).join('\n');save(path.join(out,'manual-milestone-before.md'),mb);save(mp,me);save(path.join(out,'manual-milestone-after.md'),me);
 const conflict=call('reconcile-record',{base:{id:b.id,type:'task',state:'not-started'},current:parse(p2),views:[{id:b.id,state:'completed'},{id:b.id,state:'cancelled'}]});if(!conflict.conflicts.length)throw Error('missing conflict');save(path.join(state,'conflicts.json'),{schemaVersion:1,conflicts:[{id:'task2-competing-status',recordId:b.id,paths:[plan,mp],sourceHashes:{[plan]:hash(edited),[mp]:hash(me)},...conflict,disposition:'pending'}]});
 const base={id:a.id,type:'task',state:'completed'},result=call('reconcile-record',{base,current:parse(p1),views:[{id:a.id,checked:false}]});if(result.record.state!=='not-started')throw Error('no reopen');
 const records=call('inspect-records',{projectsRoot:projects}).records;call('reopen-ancestors',{records:records.map(r=>r.id===a.id?result.record:r),changedIds:[a.id]});
 const tm=time();let s=update(read(p1),'task-state',result.record.state);s=update(s,'updated_at',tm.recorded_at).replace(/^resolved_at:.*\r?\n/m,'');
 const val=baseline();val.records[a.id].canonical.state='not-started';val.records[a.id].views[plan]={hash:hash(edited),selected:true,checked:false};
 const change=(text)=>text.split('\n').map(line=>line.includes(`ref: ${a.id}`)?line.replace('[x]','[ ]'):line).join('\n');const ms=change(me),ps=change(read(pp));for(const [p,text] of [[mp,ms],[pp,ps]])val.records[a.id].views[p]={hash:hash(text),checked:false};
 transaction('task.reopened',[[p1,s],[mp,ms],[pp,ps],[plan,edited]],[a.id],{state:'not-started',reason:'Deliberate checkbox change after completed view snapshot',priorResolvedAt:a.resolved_at},val);
 save(path.join(state,'checkin.json'),{localDate:ctx.localDate,planningBinding:ctx.planningBinding,pendingOperationIds:[],unresolvedConflictIds:['task2-competing-status'],unresolvedCandidateIds:['manual-resume-note'],nextStep:'Keep task2 pending; process accepted independent task3'});
}
