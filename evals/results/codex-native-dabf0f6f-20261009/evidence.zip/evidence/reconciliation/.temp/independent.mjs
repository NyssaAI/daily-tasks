import path from 'node:path';
import {out,vault,ctxInput,ctx,state,projects,m,p1,p2,mp,pp,call,id,time,read,save,hash,row,parse,transaction} from './actions.mjs';
const phase=process.argv[2];
if(phase==='interrupt'){
 const parent=parse(mp),project=parse(pp),allocation=call('next-record-number',{projectsRoot:projects,type:'task',parentId:parent.id});if(allocation.number!==3)throw Error(JSON.stringify(allocation));
 const tid=id(),criterion=id(),tm=time(),target=path.join(m,'t3-independent-note.md'),artifact=path.join(m,'outputs/independent-note.md');
 const text=`---\nid: "${tid}"\ntype: task\nrecord_version: 2\ntitle: "Independent note"\ndocument-maturity: reviewed\ntask-state: completed\nowner: "${ctx.profile.user.email}"\nproject_id: "${project.id}"\nmilestone_id: "${parent.id}"\ncreated_at: "${tm.recorded_at}"\nupdated_at: "${tm.recorded_at}"\nresolved_at: "${tm.activity_at}"\n---\n# M1-T3 — Independent note\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${parent.id} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${project.id} -->\n\n## Requirements\n\nCreate a local note.\n\n## Definition of Done\n\n- [x] Reviewed note. <!-- id: ${criterion} -->\n\n## Inputs\n\nUser's explicit acceptance and attestation of reviewed synthetic evidence in this request.\n\n## Output and delivery\n\nLocal artifact: [[outputs/independent-note|Independent note]].\n\n## Verification\n\nUser attests reviewed synthetic evidence; local artifact exists and is linked.\n\n## Result\n\n[[outputs/independent-note|Reviewed synthetic note]] delivered locally under explicit user acceptance.\n`;
 const proposed=call('parse-record',{markdown:text,path:target}),records=call('inspect-records',{projectsRoot:projects}).records;const check=call('check-closure',{recordId:tid,records:[...records,proposed]});if(!check.allowed)throw Error(JSON.stringify(check));
 const ms=read(mp).replace('\nReviewed headline:',`\n${row('t3-independent-note',tid,'Independent note','x')}\n\nReviewed headline:`),ps=read(pp)+`\n${row('m1-career-materials/t3-independent-note',tid,'Independent note','x')}\n`;
 const val=JSON.parse(read(path.join(state,'reconciliation.json')));val.records[tid]={canonical:{id:tid,type:'task',state:'completed'},views:{[mp]:{hash:hash(ms),checked:true},[pp]:{hash:hash(ps),checked:true}}};
 const op=transaction('task.accepted-and-completed',[[artifact,'# Independent note\n\nSynthetic local note for the reconciliation acceptance case.\n\nReviewed: user explicitly attests reviewed synthetic evidence.\n'],[target,text],[mp,ms],[pp,ps]],[tid],{acceptance:'Explicitly accept unrelated task3 Independent note; requirement local note; DoD reviewed note; user attests reviewed synthetic evidence',state:'completed',artifact},val,true);
 const input={projectsRoot:projects,entry:op.event};const append=call('log-append',input);save(path.join(out,'interrupted-append-event.json'),{stage:'Decision append persisted; interrupted before operation verification/completion',event:op.event,result:append,operationPath:path.join(state,'operations',op.operation_id+'.json')});
 const progress=JSON.parse(read(path.join(state,'checkin.json')));progress.pendingOperationIds=[op.operation_id];progress.nextStep='Recover independent note exact event and finish verified baseline; task2 remains pending';save(path.join(state,'checkin.json'),progress);save(path.join(out,'interrupted-checkin.json'),progress);
 save(path.join(state,'candidates.json'),{candidates:[{id:'manual-resume-note',source:path.join(vault,'Daily/2026-10-09.md'),text:'Maybe improve my resume',disposition:'pending',reason:'No explicit acceptance of this unidentified checkbox'}]});
 console.log(JSON.stringify({stage:'interrupted',operation:op.operation_id,append}));
}
if(phase==='resume'){
 const saved=JSON.parse(read(path.join(out,'interrupted-append-event.json'))),op=JSON.parse(read(saved.operationPath));
 const actual=call('inspect-records',{projectsRoot:projects}).records.find(r=>r.id===op.event.record_ids[0]);
 call('recover-operation',{operation:{changes:[{key:'task3.state',before:{present:false},after:{present:true,value:'completed'}}]},actual:{'task3.state':actual.state}});
 const before=call('log-query',{projectsRoot:projects,recordId:actual.id,limit:1000});save(path.join(out,'resume-query-before.json'),before);
 const entries=before.entries??before;if(!Array.isArray(entries))throw Error('query shape');const matches=entries.filter(e=>e.operation_id===op.operation_id);if(matches.length!==1||JSON.stringify(matches[0])!==JSON.stringify(op.event))throw Error('event mismatch');
 call('log-append',{projectsRoot:projects,entry:op.event});
 const after=call('log-query',{projectsRoot:projects,recordId:actual.id,limit:1000});save(path.join(out,'resume-query-after.json'),after);
 const verify=call('operation-verify',{...ctxInput,operationPath:saved.operationPath});if(verify.status!=='verified')throw Error(JSON.stringify(verify));const completed=call('operation-complete',{...ctxInput,operationPath:saved.operationPath});if(completed.status!=='completed')throw Error(JSON.stringify(completed));
 const progress=JSON.parse(read(path.join(state,'checkin.json')));progress.pendingOperationIds=[];progress.nextStep='Await explicit resolution of task2 conflict and unidentified candidate';save(path.join(state,'checkin.json'),progress);
 console.log(JSON.stringify({recovery:completed.status,task:actual.id,after}));
}
