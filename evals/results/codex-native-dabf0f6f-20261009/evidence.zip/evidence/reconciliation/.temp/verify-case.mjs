import fs from 'node:fs';
import path from 'node:path';
import {isDeepStrictEqual} from 'node:util';
import {out,vault,ctxInput,ctx,state,projects,m,p1,p2,mp,pp,call,read,save,hash,parse} from './actions.mjs';
const initial=JSON.parse(read(path.join(out,'parsed-initial.json'))),original=JSON.parse(read(path.join(out,'original-records.json'))),stale=JSON.parse(read(path.join(out,'stale-unchanged-checkin.json')));
// Recheck the retained stale source comparison with the full canonical baseline.
const staleResult=call('reconcile-record',{base:initial.a,current:stale.result.record,views:[{id:initial.a.id}]});
const records=call('inspect-records',{projectsRoot:projects});call('validate-records',{records:records.records});call('check-links',{records:records.records});call('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:ctx.dailyPlansRoot});
const history=call('log-query',{projectsRoot:projects,limit:1000}),old=JSON.parse(read(path.join(out,'original-history.json'))),saved=JSON.parse(read(path.join(out,'interrupted-append-event.json')));
const plan=path.join(ctx.dailyPlansRoot,ctx.localDate+'-daily-plan.md'),rows=call('parse-checklist',{markdown:read(plan)}).rows,mrows=call('parse-checklist',{markdown:read(mp)}).rows;
const conflict=JSON.parse(read(path.join(state,'conflicts.json'))),task3=records.records.find(r=>r.title==='Independent note');
const checks={
 'unchanged stale plan did not reopen completed task':staleResult.record.state==='completed'&&staleResult.changes.length===0&&staleResult.conflicts.length===0&&stale.viewSnapshot.checked===false&&stale.planHash===stale.viewSnapshot.hash,
 'deliberate checkbox change reopened task1':parse(p1).state==='not-started'&&rows.find(r=>r.id===initial.a.id).checked===false&&history.entries.some(e=>e.action==='task.reopened'&&e.record_ids.includes(initial.a.id)),
 'task1 existing criterion satisfied with reviewed local evidence':parse(p1).criteria[0].id===initial.a.criteria[0].id&&parse(p1).criteria[0].checked&&read(path.join(m,'outputs/reviewed-linkedin-headline.md')).includes('user attests'),
 'task2 competing completed and cancelled edits remain pending':read(p2)===original[p2]&&rows.find(r=>r.id===initial.b.id).checked===true&&mrows.find(r=>r.id===initial.b.id).state==='cancelled'&&conflict.conflicts[0].disposition==='pending'&&conflict.conflicts[0].conflicts[0].proposals.some(p=>p.value==='completed')&&conflict.conflicts[0].conflicts[0].proposals.some(p=>p.value==='cancelled'),
 'accepted unrelated task3 proceeded':task3?.state==='completed'&&task3.criteria.length===1&&task3.criteria[0].checked&&read(path.join(m,'outputs/independent-note.md')).includes('user explicitly attests'),
 'interrupted append checkpoint retained as evidence':fs.existsSync(path.join(out,saved.event.operation_id+'-checkpoint.json'))&&fs.existsSync(path.join(out,'interrupted-checkin.json')),
 'retry yields exactly one full matching decision':history.entries.filter(e=>e.operation_id===saved.event.operation_id).length===1&&isDeepStrictEqual(history.entries.find(e=>e.operation_id===saved.event.operation_id),saved.event),
 'original history preserved':old.entries.every(e=>history.entries.some(n=>isDeepStrictEqual(e,n))),
 'original unrelated prose and daily note preserved':read(path.join(vault,'Daily/2026-10-09.md'))===original[path.join(vault,'Daily/2026-10-09.md')]&&read(plan).includes(original[path.join(vault,'Daily/2026-10-09.md')])&&read(pp).includes('Prepare career materials for the job search.'),
 'completed independent operation verified and cleared':!fs.existsSync(saved.operationPath)&&JSON.parse(read(path.join(state,'checkin.json'))).pendingOperationIds.length===0,
 'pending conflict not falsely declared reconciled':JSON.parse(read(path.join(state,'checkin.json'))).unresolvedConflictIds.includes('task2-competing-status')
};
const inspection=call('maintenance-inspect',ctxInput),packet=call('planning-prepare',ctxInput);save(path.join(out,'final-preparation.json'),packet);
save(path.join(out,'final-records.json'),records);save(path.join(out,'final-history.json'),history);
const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3/skills';
const loaded=['daily-tasks-checkin/SKILL.md','daily-tasks-records/SKILL.md','daily-tasks-plan/SKILL.md','daily-tasks-setup/SKILL.md','daily-tasks-capture/SKILL.md','daily-tasks/references/operations.md','daily-tasks/references/cli.md','daily-tasks/references/verification.md','daily-tasks/references/records.md','daily-tasks/references/planning-flow.md','daily-tasks/references/response-conventions.md','daily-tasks/assets/task.md','daily-tasks/assets/daily-plan.md'].map(rel=>({path:path.join(bundle,rel),sha256:hash(read(path.join(bundle,rel)))}));
const passed=Object.values(checks).every(Boolean);save(path.join(out,'scenario3-receipt.json'),{scenario:3,id:'reconciliation',passed,checks,loadedSkills:loaded,node:process.version,host:'Current Codex tool session; host version and model not exposed',nativeDiscovery:'Installed skills supplied by host catalog and read from installed paths; packaging and CLI checks are not activation proof',interruption:'After successful append, before verification/completion; exact saved payload retried once',maintenance:inspection,checkin:'Resumable with task2 conflict and unidentified candidate pending'});
save(path.join(out,'scenario3-report.md'),`# Scenario 3 — Reconciliation\n\n${passed?'PASS':'FAIL'}: ${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} assertions.\n\n${Object.entries(checks).map(([k,v])=>`- ${v?'PASS':'FAIL'}: ${k}`).join('\n')}\n\nActions, before/after bytes, installed CLI input/output, source hashes, interruption checkpoint and log-query history are retained in this directory. No raw decision log was read or modified. Task2 conflict and the unidentified original checkbox remain pending. No trusted maintenance worker execution is claimed.\n`);
console.log(JSON.stringify({passed,checks,maintenance:inspection},null,2));if(!passed)process.exitCode=1;
