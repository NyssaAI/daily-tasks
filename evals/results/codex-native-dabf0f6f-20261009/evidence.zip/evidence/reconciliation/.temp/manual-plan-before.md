---
id: "01a121df-f718-760a-9679-caa7347da71f"
type: daily-plan
title: "Daily plan 2026.10.09"
timezone: "America/Chicago"
created_at: "2026-10-09T18:14:48.298Z"
updated_at: "2026-10-09T18:14:48.298Z"
---
# Daily plan — 2026.10.09

**Timezone:** America/Chicago

## Selected for today

### My work

- [x] [[../Projects/job-search/m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [ ] [[../Projects/job-search/m1-career-materials/t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->

### Delegated work

No delegated work selected.

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled

## Notes and references

Preserved original daily note:
# Friday

- [ ] Maybe improve my resume

