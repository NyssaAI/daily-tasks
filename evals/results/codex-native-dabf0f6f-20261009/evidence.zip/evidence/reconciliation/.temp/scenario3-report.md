# Scenario 3 — Reconciliation

PASS: 11/11 assertions.

- PASS: unchanged stale plan did not reopen completed task
- PASS: deliberate checkbox change reopened task1
- PASS: task1 existing criterion satisfied with reviewed local evidence
- PASS: task2 competing completed and cancelled edits remain pending
- PASS: accepted unrelated task3 proceeded
- PASS: interrupted append checkpoint retained as evidence
- PASS: retry yields exactly one full matching decision
- PASS: original history preserved
- PASS: original unrelated prose and daily note preserved
- PASS: completed independent operation verified and cleared
- PASS: pending conflict not falsely declared reconciled

Actions, before/after bytes, installed CLI input/output, source hashes, interruption checkpoint and log-query history are retained in this directory. No raw decision log was read or modified. Task2 conflict and the unidentified original checkbox remain pending. No trusted maintenance worker execution is claimed.
