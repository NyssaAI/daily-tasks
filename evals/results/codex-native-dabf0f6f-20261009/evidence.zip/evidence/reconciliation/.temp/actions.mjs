import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), out=path.join(root,'.temp'), vault=path.join(root,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3';
const cli=path.join(pkg,'bin/daily-tasks.mjs');
fs.mkdirSync(out,{recursive:true});
let seq=fs.existsSync(path.join(out,'sequence.json'))?JSON.parse(fs.readFileSync(path.join(out,'sequence.json'))):0;
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
const save=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
function call(op,input){const n=String(++seq).padStart(3,'0'), f=path.join(out,`${n}-${op}-input.json`); if(input)save(f,input); const args=[cli,op,...(input?['--input',f]:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(path.join(out,`${n}-${op}-result.json`),{command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr});save(path.join(out,'sequence.json'),seq); if(r.status!==0)throw Error(`${op}: ${r.stderr}`);return JSON.parse(r.stdout);}
const ctxInput={vaultRoot:vault,homeRoot:root,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json')};
const packet=call('planning-prepare',ctxInput),ctx=packet.context;
save(path.join(out,'context.json'),ctx);
const state=ctx.stateRoot, projects=ctx.projectsRoot, m=path.join(projects,'job-search/m1-career-materials');
const p1=path.join(m,'t1-update-linkedin.md'),p2=path.join(m,'t2-update-resume.md'),mp=path.join(m,'m1-career-materials.md'),pp=path.join(projects,'job-search/project-index.md');
const parse=p=>call('parse-record',{markdown:read(p),path:p});
const id=()=>{const r=call('new-id');return typeof r==='string'?r:r.id;};
const time=()=>call('activity-time',{});
const row=(p,tid,title,mark=' ')=>`- [${mark}] [[${p}|${title}]] <!-- ref: ${tid} -->`;
const update=(s,key,value)=>s.replace(new RegExp(`^${key}:.*$`,'m'),`${key}: ${JSON.stringify(value)}`);
function transaction(label, edits, recordIds,after,baseline,interrupt=false){
 const tm=time(),operation_id=id(),event={id:id(),operation_id,action:label,record_ids:recordIds,actor:{kind:'person',id:ctx.profile.user.email},...tm,original_words:label,after};
 const files=edits.map(([p,s])=>({path:p,before:read(p)===null?null:hash(read(p)),after:hash(s)}));
 const op={schemaVersion:2,operation_id,contextBinding:ctx.planningBinding,event,files};
 if(baseline){const bp=path.join(state,'reconciliation.json'),text=read(bp);op.baseline={beforeHash:text===null?null:hash(text),...(text===null?{}:{beforeText:text}),value:baseline};}
 const opPath=path.join(state,'operations',operation_id+'.json');save(opPath,op);save(path.join(out,operation_id+'-checkpoint.json'),op);
 for(const [p,s] of edits){const f=files.find(f=>f.path===p);if((read(p)===null?null:hash(read(p)))!==f.before)throw Error('optimistic conflict');save(path.join(out,operation_id+'-'+path.basename(p)+'-before.txt'),read(p)??'<absent>');save(p,s);save(path.join(out,operation_id+'-'+path.basename(p)+'-after.txt'),s);}
 call('invalidate-project-index',{vaultRoot:vault});
 if(interrupt){save(path.join(out,'interrupted.json'),{opPath,event,stage:'Markdown saved; log append pending',logInput:{projectsRoot:projects,entry:event}});return op;}
 call('log-append',{projectsRoot:projects,entry:event});
 const verify=call('operation-verify',{...ctxInput,operationPath:opPath});save(path.join(out,'last-verify.json'),verify);
 const complete=call('operation-complete',{...ctxInput,operationPath:opPath});if(complete.status!=='complete'&&complete.status!=='completed')console.log(JSON.stringify(complete));
 return op;
}
const phase=process.argv[2];
if(phase==='seed'){
 save(path.join(out,'original-records.json'),Object.fromEntries([p1,p2,mp,pp,path.join(vault,'Daily/2026-10-09.md')].map(p=>[p,read(p)])));
 save(path.join(out,'original-history.json'),call('log-query',{projectsRoot:projects,limit:1000}));
 const a=parse(p1),b=parse(p2);save(path.join(out,'parsed-initial.json'),{a,b});console.log(JSON.stringify({a,b,ctx},null,2));
}
export {root,out,vault,ctxInput,ctx,state,projects,m,p1,p2,mp,pp,call,id,time,read,save,hash,row,update,parse,transaction};
