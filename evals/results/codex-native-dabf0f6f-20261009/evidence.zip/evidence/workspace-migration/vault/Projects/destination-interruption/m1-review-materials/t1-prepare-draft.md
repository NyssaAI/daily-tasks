---
id: "01a121df-7fe3-7a63-9ab9-c6c910166be2"
type: "task"
record_version: 2
title: "Prepare draft"
owner: "synthetic@example.test"
created_at: "2026-09-01T15:00:00.000Z"
updated_at: "2026-09-01T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121df-7f55-71d4-9bd6-04aa453a06b3"
milestone_id: "01a121df-7f87-7fec-b08b-0ff27ec0a31a"
---
# Prepare draft

**Milestone:** [[m1-review-materials|Review materials]] <!-- ref: 01a121df-7f87-7fec-b08b-0ff27ec0a31a -->

## Requirements
Write a draft for review.

## Definition of Done
- [ ] Draft linked with source notes. <!-- id: 01a121df-80f5-70f0-a4ae-a005cfd5f627 -->

## Acceptance reference
[[m1-review-materials#Definition of Done|Acceptance]] <!-- ref: 01a121df-7f87-7fec-b08b-0ff27ec0a31a -->
[[m1-review-materials#Definition of Done|Reviewed criterion]] <!-- ref: 01a121df-809d-7666-9ffb-5d6705528342 -->

Unrelated task prose stays.
