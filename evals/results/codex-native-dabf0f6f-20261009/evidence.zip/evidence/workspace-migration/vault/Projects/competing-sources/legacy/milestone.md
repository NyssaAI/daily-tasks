---
id: "01a121df-8c93-7828-a355-e8b768fffb03"
type: "milestone"
title: "Review materials"
owner: "synthetic@example.test"
created_at: "2026-09-01T15:00:00.000Z"
updated_at: "2026-09-01T15:00:00.000Z"
milestone-state: "not-started"
project_id: "01a121df-8c62-7e66-b289-b87127814a1e"
---
# Review materials

**Project:** [[../project-index|competing-sources]] <!-- ref: 01a121df-8c62-7e66-b289-b87127814a1e -->

## Outcome
Deliver reviewed materials.

## Legacy acceptance
[[./definition-of-done#Definition of Done|Acceptance]] <!-- ref: 01a121df-8cc0-7582-b58c-e9e1bb387a23 -->

## Tasks
- [ ] [[prepare|Prepare draft]] <!-- ref: 01a121df-8ced-723b-99c9-639e2f8fdb2c -->
- [x] [[delivered|Previously delivered]] <!-- ref: 01a121df-8d1a-74f0-bd21-e56d782a72d7 -->
- [ ] [[unknown|Unresolved legacy scope]] <!-- ref: 01a121df-8d45-706e-b9b5-81f76f28a2b0 -->

## Definition of Done
- [ ] Separate embedded acceptance. <!-- id: 01a121df-8ea7-786d-9184-1ba92c03821a -->
