---
id: "01a121df-8ced-723b-99c9-639e2f8fdb2c"
type: "task"
title: "Prepare draft"
owner: "synthetic@example.test"
created_at: "2026-09-01T15:00:00.000Z"
updated_at: "2026-09-01T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121df-8c62-7e66-b289-b87127814a1e"
milestone_id: "01a121df-8c93-7828-a355-e8b768fffb03"
---
# Prepare draft

**Milestone:** [[milestone|Review materials]] <!-- ref: 01a121df-8c93-7828-a355-e8b768fffb03 -->

## Requirements
Write a draft for review.

## Definition of Done
- [ ] Draft linked with source notes. <!-- id: 01a121df-8df5-779f-ae98-36038912c541 -->

## Acceptance reference
[[./definition-of-done#Definition of Done|Acceptance]] <!-- ref: 01a121df-8cc0-7582-b58c-e9e1bb387a23 -->
[[./definition-of-done#Definition of Done|Reviewed criterion]] <!-- ref: 01a121df-8d9c-7625-88d2-4de9387559da -->

Unrelated task prose stays.
