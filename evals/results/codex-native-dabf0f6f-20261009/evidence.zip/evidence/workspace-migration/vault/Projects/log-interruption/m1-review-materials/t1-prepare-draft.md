---
id: "01a121df-8506-7d46-9078-c9db6eca03ef"
type: "task"
record_version: 2
title: "Prepare draft"
owner: "synthetic@example.test"
created_at: "2026-09-01T15:00:00.000Z"
updated_at: "2026-09-01T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121df-847c-7fd4-8d31-01f6b180f062"
milestone_id: "01a121df-84a9-7327-987d-0ca4713c947c"
---
# Prepare draft

**Milestone:** [[m1-review-materials|Review materials]] <!-- ref: 01a121df-84a9-7327-987d-0ca4713c947c -->

## Requirements
Write a draft for review.

## Definition of Done
- [ ] Draft linked with source notes. <!-- id: 01a121df-861f-7fd2-a3db-81dd6eb2b674 -->

## Acceptance reference
[[m1-review-materials#Definition of Done|Acceptance]] <!-- ref: 01a121df-84a9-7327-987d-0ca4713c947c -->
[[m1-review-materials#Definition of Done|Reviewed criterion]] <!-- ref: 01a121df-85c0-725f-84e1-5e1490ccbd85 -->

Unrelated task prose stays.
