---
id: "01a121df-8d45-706e-b9b5-81f76f28a2b0"
type: "task"
title: "Unresolved legacy scope"
owner: "synthetic@example.test"
created_at: "2026-09-01T15:00:00.000Z"
updated_at: "2026-09-01T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121df-8c62-7e66-b289-b87127814a1e"
milestone_id: "01a121df-8c93-7828-a355-e8b768fffb03"
---
# Unresolved legacy scope

**Milestone:** [[milestone|Review materials]] <!-- ref: 01a121df-8c93-7828-a355-e8b768fffb03 -->

## Requirements
Await the user's scope and acceptance facts.

## Acceptance reference
[[./definition-of-done#Definition of Done|Acceptance]] <!-- ref: 01a121df-8cc0-7582-b58c-e9e1bb387a23 -->
