---
id: "01a121df-82d3-765f-a2a8-2fd47614626f"
type: "task"
title: "Unresolved legacy scope"
owner: "synthetic@example.test"
created_at: "2026-09-01T15:00:00.000Z"
updated_at: "2026-09-01T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121df-81e9-7102-8694-68c358b7f7c3"
milestone_id: "01a121df-8218-74de-b662-19ef48daaf1f"
---
# Unresolved legacy scope

**Milestone:** [[../m1-review-materials/m1-review-materials|Review materials]] <!-- ref: 01a121df-8218-74de-b662-19ef48daaf1f -->

## Requirements
Await the user's scope and acceptance facts.

## Acceptance reference
[[../m1-review-materials/m1-review-materials#Definition of Done|Acceptance]] <!-- ref: 01a121df-8218-74de-b662-19ef48daaf1f -->
