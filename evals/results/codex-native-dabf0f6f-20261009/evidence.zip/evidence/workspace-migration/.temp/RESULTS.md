# Scenario8 workspace migration

45/45 observed workflow assertions passed. Workflow result: PASS.

Three independent stopped workflows retained checkpoints after destination persistence, source removal and log append. Each was resumed in a separate process invocation and retried with one exact event, preserved identities/history and no duplicate live records. These are native skill-authored workflows in the current conversation, with installed CLI verification, not replayed regression tests.

Unexpected-edit and Windows case-insensitive collision operations remain pending conflicts; their bytes, source DoD and checkpoints are preserved and completion is rejected. Embedded and standalone DoD produce competing-source closure refusal.

Legacy Previously delivered and Unresolved legacy scope tasks remain unversioned and pending conversion. Missing task criteria were requested in the conversation; no criteria or satisfaction were manufactured, and historical completion was preserved.

Evidence: assertions.json (per-condition facts), actions.jsonl (actual writes/interruptions/retirement order), call-*.input.json and call-*.result.json (installed CLI commands, exit codes and stdout/stderr), before*/ and *-verified-final/ (bounded snapshots), final-history-query.json (script-only history access), installed-instructions.json, and project-local .temp recovery copies.

The first destination workflow initially refused retirement because bare DoD wiki links in neighboring synthetic fixtures could be incoming links. Neighboring fixture links were made explicit relative paths, with retained before/after evidence, before retry. An early checkpoint comparison failed on omitted JSON undefined properties before writes; comparison was corrected to the serialized checkpoint representation and the saved operation was reused. Failures/refusals are retained.

Host version/model and independent authentication are not exposed. This receipt records observed current-host workflows and does not independently certify fresh authentication/plugin registration.

| Case | Assertion | Result |
| --- | --- | --- |
| destination-interruption | completed task lacking task DoD is not assigned manufactured criteria or inferred satisfaction | pass |
| destination-interruption | unresolved legacy task remains readable/unversioned and pending conversion | pass |
| destination-interruption | historical event retained byte-equivalent as queried object | pass |
| destination-interruption | milestone/task identities and lifecycle fields survive | pass |
| destination-interruption | criterion IDs, text, checked state and evidence preserved | pass |
| destination-interruption | old DoD retired only after actual pre-removal live-content/reference verification | pass |
| destination-interruption | blocker transferred reciprocally to milestone | pass |
| destination-interruption | inbound task and daily-plan criterion links retain UUID and navigate to new owner | pass |
| destination-interruption | actual stage interruption followed by saved-operation resume and retry leaves one exact event | pass |
| destination-interruption | no duplicate live record or criterion identities after recovery | pass |
| destination-interruption | unrelated prose and DoD provenance preserved | pass |
| source-interruption | completed task lacking task DoD is not assigned manufactured criteria or inferred satisfaction | pass |
| source-interruption | unresolved legacy task remains readable/unversioned and pending conversion | pass |
| source-interruption | historical event retained byte-equivalent as queried object | pass |
| source-interruption | milestone/task identities and lifecycle fields survive | pass |
| source-interruption | criterion IDs, text, checked state and evidence preserved | pass |
| source-interruption | old DoD retired only after actual pre-removal live-content/reference verification | pass |
| source-interruption | blocker transferred reciprocally to milestone | pass |
| source-interruption | inbound task and daily-plan criterion links retain UUID and navigate to new owner | pass |
| source-interruption | actual stage interruption followed by saved-operation resume and retry leaves one exact event | pass |
| source-interruption | no duplicate live record or criterion identities after recovery | pass |
| source-interruption | unrelated prose and DoD provenance preserved | pass |
| log-interruption | completed task lacking task DoD is not assigned manufactured criteria or inferred satisfaction | pass |
| log-interruption | unresolved legacy task remains readable/unversioned and pending conversion | pass |
| log-interruption | historical event retained byte-equivalent as queried object | pass |
| log-interruption | milestone/task identities and lifecycle fields survive | pass |
| log-interruption | criterion IDs, text, checked state and evidence preserved | pass |
| log-interruption | old DoD retired only after actual pre-removal live-content/reference verification | pass |
| log-interruption | blocker transferred reciprocally to milestone | pass |
| log-interruption | inbound task and daily-plan criterion links retain UUID and navigate to new owner | pass |
| log-interruption | actual stage interruption followed by saved-operation resume and retry leaves one exact event | pass |
| log-interruption | no duplicate live record or criterion identities after recovery | pass |
| log-interruption | unrelated prose and DoD provenance preserved | pass |
| unexpected-edit | completed task lacking task DoD is not assigned manufactured criteria or inferred satisfaction | pass |
| unexpected-edit | unresolved legacy task remains readable/unversioned and pending conversion | pass |
| unexpected-edit | historical event retained byte-equivalent as queried object | pass |
| unexpected-edit | pending conflict preserves unexpected/unrelated bytes with no false completion or event | pass |
| windows-collision | completed task lacking task DoD is not assigned manufactured criteria or inferred satisfaction | pass |
| windows-collision | unresolved legacy task remains readable/unversioned and pending conversion | pass |
| windows-collision | historical event retained byte-equivalent as queried object | pass |
| windows-collision | pending conflict preserves unexpected/unrelated bytes with no false completion or event | pass |
| competing-sources | completed task lacking task DoD is not assigned manufactured criteria or inferred satisfaction | pass |
| competing-sources | unresolved legacy task remains readable/unversioned and pending conversion | pass |
| competing-sources | historical event retained byte-equivalent as queried object | pass |
| competing-sources | embedded plus standalone milestone DoD reports competing sources and blocks closure | pass |
