import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=process.cwd(), evidence=path.join(root,'.temp');
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8-v2/codex-home/plugins/cache/daily-tasks-runtime-guards-full8-v2/daily-tasks/0.3.3';
export const vault=path.join(root,'vault');
export const hash=s=>s===null?null:createHash('sha256').update(s).digest('hex');
export async function read(p){try{return await fs.readFile(p,'utf8')}catch(e){if(e.code==='ENOENT')return null;throw e}}
export async function write(p,s){await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,s)}
export async function json(p,v){await write(p,JSON.stringify(v,null,2)+'\n')}
export async function cli(op,input,label=op){await fs.mkdir(evidence,{recursive:true});const seq=(await fs.readdir(evidence)).filter(n=>/^call-/.test(n)).length;const stem=path.join(evidence,`call-${String(seq).padStart(4,'0')}-${label}`);await json(stem+'.input.json',input);const args=[path.join(pkg,'bin/daily-tasks.mjs'),op,'--input',stem+'.input.json'];const r=spawnSync(process.execPath,args,{encoding:'utf8'});await json(stem+'.result.json',{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout)}
export async function id(){const r=spawnSync(process.execPath,[path.join(pkg,'bin/daily-tasks.mjs'),'new-id'],{encoding:'utf8'});await fs.appendFile(path.join(evidence,'new-ids.jsonl'),JSON.stringify({command:'installed CLI new-id',exitCode:r.status,stdout:r.stdout,stderr:r.stderr})+'\n');const v=JSON.parse(r.stdout);return typeof v==='string'?v:v.id}
export function note(meta,body){return '---\n'+Object.entries(meta).map(([k,v])=>`${k}: ${JSON.stringify(v)}`).join('\n')+'\n---\n'+body+'\n'}
export async function action(v){await fs.appendFile(path.join(evidence,'actions.jsonl'),JSON.stringify({observedAt:new Date().toISOString(),...v})+'\n')}
export async function snapshot(name,files){for(const p of files){const s=await read(p);await json(path.join(evidence,name,path.relative(vault,p)+'.snapshot.json'),{path:p,sha256:hash(s),markdown:s})}}
