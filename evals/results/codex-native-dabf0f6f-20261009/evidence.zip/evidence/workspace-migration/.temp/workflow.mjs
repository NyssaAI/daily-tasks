import fs from 'node:fs/promises';
import path from 'node:path';
import {isDeepStrictEqual} from 'node:util';
import {evidence,vault,cli,id,read,write,json,hash,snapshot,action} from './session.mjs';
const context=JSON.parse(await read(path.join(evidence,'context.json'))),cases=JSON.parse(await read(path.join(evidence,'cases.json')));
const [name,phase]=process.argv.slice(2),c=cases.find(c=>c.name===name);if(!c)throw Error('Unknown case');
const ctx={vaultRoot:vault,profilePath:context.profilePath,stateRoot:context.stateRoot};
const manifestPath=path.join(evidence,name+'-operation.json');
const parsed=async(p,s=undefined)=>cli('parse-record',{markdown:s??await read(p),path:p},name+'-parse');
const replace=(s,a,b)=>{if(!s.includes(a))throw Error('Missing expected source: '+a);return s.split(a).join(b)};
async function invalidate(){return cli('invalidate-project-index',{vaultRoot:vault},name+'-invalidate')}
async function compareWrite(file,after){const actual=hash(await read(file.path));if(actual===file.after)return;if(actual!==file.before)throw Error('Unexpected content '+file.path);if(after===null){await fs.unlink(file.path)}else{await write(file.path,after)}await action({case:name,action:after===null?'source-removal':'markdown-write',path:file.path,before:file.before,after:file.after});}
async function prepare(){
 const sources={};for(const [k,p]of Object.entries(c.files))sources[k]=(await read(p))?.replaceAll('[[./definition-of-done#','[[definition-of-done#');
 const records={};for(const k of ['project','milestone','dod','task','completed','unresolved','blocker'])records[k]=await parsed(c.files[k]);
 const m=await cli('next-record-number',{projectsRoot:context.projectsRoot,type:'milestone',parentId:c.ids.project},name+'-milestone-number');
 const t=await cli('next-record-number',{projectsRoot:context.projectsRoot,type:'task',parentId:c.ids.milestone},name+'-task-number');
 if(m.number!==1||t.number!==1)throw Error('Allocation conflict '+JSON.stringify({m,t}));
 const newM=path.join(c.dest,'m1-review-materials.md'),newT=path.join(c.dest,'t1-prepare-draft.md');
 const changes=new Map();
 let milestone=replace(sources.milestone,'type: "milestone"','type: "milestone"\nrecord_version: 2');
 milestone=replace(milestone,'## Legacy acceptance\n[[definition-of-done#Definition of Done|Acceptance]] <!-- ref: '+c.ids.dod+' -->',`## Definition of Done\n${sources.dod.split('## Definition of Done\n')[1].split('\n\n## Provenance')[0]}\n\n## Provenance\nAcceptance supplied by synthetic reviewer; preserve this note.\nRetired standalone acceptance identity retained in migration history.\n\n## Blocked by\n- [[../blockers/b1-approval|Approval]] <!-- ref: ${c.ids.blocker} -->`);
 milestone=replace(milestone,'[[prepare|Prepare draft]]','[[t1-prepare-draft|Prepare draft]]');
 milestone=replace(milestone,'[[delivered|Previously delivered]]','[[../legacy/delivered|Previously delivered]]');
 milestone=replace(milestone,'[[unknown|Unresolved legacy scope]]','[[../legacy/unknown|Unresolved legacy scope]]');
 let task=replace(sources.task,'type: "task"','type: "task"\nrecord_version: 2');
 task=replace(task,'[[milestone|Review materials]]','[[m1-review-materials|Review materials]]');
 task=replace(task,'definition-of-done#Definition of Done','m1-review-materials#Definition of Done');task=replace(task,'<!-- ref: '+c.ids.dod+' -->','<!-- ref: '+c.ids.milestone+' -->');
 const inbound=(s)=>replace(s,'[[milestone|Review materials]]','[[../m1-review-materials/m1-review-materials|Review materials]]');
 let unresolved=inbound(sources.unresolved);unresolved=replace(unresolved,'definition-of-done#Definition of Done','../m1-review-materials/m1-review-materials#Definition of Done');unresolved=replace(unresolved,'<!-- ref: '+c.ids.dod+' -->','<!-- ref: '+c.ids.milestone+' -->');
 let blocker=replace(sources.blocker,'../legacy/definition-of-done|Review acceptance','../m1-review-materials/m1-review-materials|Review materials');blocker=replace(blocker,'<!-- ref: '+c.ids.dod+' -->','<!-- ref: '+c.ids.milestone+' -->');
 const project=replace(sources.project,'legacy/milestone','m1-review-materials/m1-review-materials');
 let plan=replace(sources.plan,`../Projects/${name}/legacy/prepare`,`../Projects/${name}/m1-review-materials/t1-prepare-draft`);
 plan=replace(plan,`../Projects/${name}/legacy/definition-of-done#Definition of Done`,`../Projects/${name}/m1-review-materials/m1-review-materials#Definition of Done`);plan=replace(plan,'<!-- ref: '+c.ids.dod+' -->','<!-- ref: '+c.ids.milestone+' -->');
 changes.set(newM,milestone);changes.set(newT,task);changes.set(c.files.completed,inbound(sources.completed));changes.set(c.files.unresolved,unresolved);changes.set(c.files.blocker,blocker);changes.set(c.files.project,project);changes.set(c.files.plan,plan);changes.set(c.files.milestone,null);changes.set(c.files.task,null);changes.set(c.files.dod,null);
 const operation_id=await id(),eventId=await id(),time=await cli('activity-time',{},name+'-activity');
 const beforeRecords=Object.values(records).map(r=>({id:r.id,type:r.type,path:r.path,project_id:r.project_id??undefined,milestone_id:r.milestone_id??undefined,state:r.state??undefined}));
 const afterRecords=[];for(const [p,s]of changes)if(s!==null){const r=await parsed(p,s);if(r.id&&r.type!=='daily-plan')afterRecords.push({id:r.id,type:r.type,path:p,project_id:r.project_id??undefined,milestone_id:r.milestone_id??undefined,state:r.state??undefined});}
 const event={id:eventId,operation_id,action:'workspace.migrated',record_ids:Object.values(records).map(r=>r.id),actor:{kind:'agent',id:'Codex'},activity_at:time.activity_at,recorded_at:time.recorded_at,time_defaulted:time.time_defaulted,original_words:'User explicitly authorizes synthetic legacy conversion; preserve identities, criteria and history',before:{records:beforeRecords},after:{records:afterRecords,retiredDodId:c.ids.dod,criterionIds:records.dod.criteria.map(x=>x.id),pendingTaskIds:[c.ids.completed,c.ids.unresolved]}};
 const beforeBaseline=await read(path.join(context.stateRoot,'reconciliation.json')),baseline=beforeBaseline?JSON.parse(beforeBaseline):{schemaVersion:1,records:{}};
 for(const [p,s]of changes){if(s===null)continue;const r=await parsed(p,s);if(!['milestone','task','project','blocker'].includes(r.type))continue;baseline.records[r.id]={canonical:{state:r.state},views:{}};}
 const files=[];for(const [p,s]of changes)files.push({path:p,before:hash(await read(p)),after:hash(s)});
 const operation={schemaVersion:2,operation_id,contextBinding:context.planningBinding,event,files,protectedFiles:[{path:c.files.evidence,sha256:hash(sources.evidence)}],baseline:{beforeHash:hash(beforeBaseline),...(beforeBaseline?{beforeText:beforeBaseline}:{}),value:baseline},migration:{retiringPath:c.files.dod,destinationPath:newM,sourceHash:hash(sources.dod),expectedCriteria:records.dod.criteria,preservedFields:{owner:records.dod.owner,created_at:records.dod.created_at}},sourceSnapshot:{retiringMarkdown:sources.dod}};
 const operationPath=path.join(context.stateRoot,'operations',operation_id+'.json');
 const recovery=path.join(c.p,'.temp',operation_id);for(const [p,s]of changes){await json(path.join(recovery,path.basename(p)+'.json'),{path:p,before:await read(p),after:s});}
 const manifest={operationPath,operation,recovery,changes:[...changes],newM,newT};
 await json(operationPath,operation);await json(manifestPath,manifest);await action({case:name,action:'checkpoint-saved-before-writes',operationPath,operationId:operation_id});
 return manifest;
}
async function progress(manifest,stop){
 const {operationPath,operation,changes}=manifest,input={...ctx,operationPath};
 // The persisted checkpoint and project-local recoverable bytes, not a regenerated intent, govern recovery.
 const saved=JSON.parse(await read(operationPath));if(!isDeepStrictEqual(saved,JSON.parse(JSON.stringify(operation))))throw Error('Checkpoint changed');
 const actual={};for(const f of saved.files)actual[f.path]=hash(await read(f.path));
 await cli('recover-operation',{operation:{changes:saved.files.map(f=>({key:f.path,before:{present:true,value:f.before},after:{present:true,value:f.after}}))},actual},name+'-recover-classification');
 const classification=await cli('operation-verify',input,name+'-before-effects');
 if(classification.status==='conflict'){await action({case:name,action:'pending-conflict',result:classification});return classification;}
 for(const [p,s]of changes.filter(([,s])=>s!==null)){await compareWrite(saved.files.find(f=>f.path===p),s);}
 await fs.mkdir(path.join(c.dest,'inputs'),{recursive:true});await fs.mkdir(path.join(c.dest,'outputs'),{recursive:true});await invalidate();
 await snapshot(name+'-destination-persisted',saved.files.map(f=>f.path));
 if(stop==='destination'){await action({case:name,action:'actual-interruption',stage:'destination-persistence',checkpointRetained:true});console.log('INTERRUPTED after destination persistence');return;}
 // Probe while old copies still exist; they must prevent premature retirement.
 if(await read(c.files.milestone)!==null){const pre=await cli('migration-retirement',input,name+'-old-copies-prevent-retirement');if(pre.allowed)throw Error('Premature retirement allowed with old live copies');}
 for(const [p,s]of changes.filter(([p,s])=>s===null&&p!==c.files.dod)){await compareWrite(saved.files.find(f=>f.path===p),null);}
 const retirement=await cli('migration-retirement',input,name+'-immediate-retirement-check');
 if(!retirement.allowed){await action({case:name,action:'retirement-pending',result:retirement});console.log(JSON.stringify(retirement));return retirement;}
 await action({case:name,action:'retirement-authorized-after-live-content-and-links-verification',result:retirement});
 await compareWrite(saved.files.find(f=>f.path===c.files.dod),null);await invalidate();
 await snapshot(name+'-source-removed',saved.files.map(f=>f.path));
 if(stop==='source'){await action({case:name,action:'actual-interruption',stage:'source-removal',checkpointRetained:true});console.log('INTERRUPTED after source removal');return;}
 const q=await cli('log-query',{projectsRoot:context.projectsRoot,limit:1000},name+'-query-before-append');const existing=q.entries.filter(x=>x.operation_id===saved.operation_id);
 if(existing.length&&(!isDeepStrictEqual(existing[0],saved.event)||existing.length!==1))throw Error('Exact event conflict');
 if(!existing.length)await cli('log-append',{projectsRoot:context.projectsRoot,entry:saved.event},name+'-append-migration');
 const logged=await cli('log-query',{projectsRoot:context.projectsRoot,limit:1000},name+'-query-after-append');if(logged.entries.filter(x=>isDeepStrictEqual(x,saved.event)).length!==1)throw Error('Exact event not unique');
 if(stop==='log'){await action({case:name,action:'actual-interruption',stage:'log-append',checkpointRetained:true});console.log('INTERRUPTED after log append');return;}
 const inspect=await cli('inspect-records',{projectsRoot:context.projectsRoot},name+'-final-records');await cli('check-links',{records:inspect.records},name+'-final-links');await cli('inspect-navigation',{projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot},name+'-final-navigation');
 const completion=await cli('migration-complete',input,name+'-complete');await action({case:name,action:'CLI-migration-completion',result:completion});await snapshot(name+'-after',saved.files.map(f=>f.path));console.log(JSON.stringify(completion));return completion;
}
if(phase==='stop-existing-destination'){await progress(JSON.parse(await read(manifestPath)),'destination');}
else if(phase==='prepare-destination'||phase==='prepare-source'||phase==='prepare-log'){const m=await prepare();await progress(m,phase.split('-')[1]);}
else if(phase==='resume'){const m=JSON.parse(await read(manifestPath));if(await read(c.files.dod)===null){
 // Retirement already occurred in a prior observed stage; use the saved retiring snapshot.
 const saved=JSON.parse(await read(m.operationPath));const status=await cli('operation-verify',{...ctx,operationPath:m.operationPath},name+'-resume-after-retirement');if(status.status==='conflict'){console.log(JSON.stringify(status));}else{
 for(const f of saved.files)if(hash(await read(f.path))!==f.after)throw Error('Unexpected missing effect on resume');
 const q=await cli('log-query',{projectsRoot:context.projectsRoot,limit:1000},name+'-resume-query');const matches=q.entries.filter(x=>x.operation_id===saved.operation_id);if(matches.length&&(!isDeepStrictEqual(matches[0],saved.event)||matches.length!==1))throw Error('Event conflict');if(!matches.length)await cli('log-append',{projectsRoot:context.projectsRoot,entry:saved.event},name+'-resume-append');
 await cli('log-query',{projectsRoot:context.projectsRoot,limit:1000},name+'-resume-exact-event');const result=await cli('migration-complete',{...ctx,operationPath:m.operationPath},name+'-resume-complete');await action({case:name,action:'saved-operation-resume',result});await snapshot(name+'-after',saved.files.map(f=>f.path));console.log(JSON.stringify(result));}
 }else{await progress(m);}}
else if(phase==='retry'){const m=JSON.parse(await read(manifestPath));if(await read(m.operationPath)!==null)throw Error('Completion did not clear checkpoint');for(const f of m.operation.files)if(hash(await read(f.path))!==f.after)throw Error('Effect changed');await cli('log-append',{projectsRoot:context.projectsRoot,entry:m.operation.event},name+'-identical-retry');const q=await cli('log-query',{projectsRoot:context.projectsRoot,limit:1000},name+'-retry-query');const events=q.entries.filter(x=>x.operation_id===m.operation.operation_id);if(events.length!==1||!isDeepStrictEqual(events[0],m.operation.event))throw Error('Retry duplicated event');await action({case:name,action:'retry-no-record-writes-one-exact-event',eventCount:events.length});console.log('Retry verified one exact event and unchanged effects');}
else if(phase==='inject-edit'){const m=await prepare();await progress(m,'destination');await fs.appendFile(m.newM,'\nUnexpected synthetic user edit.\n');await action({case:name,action:'independent-unexpected-edit',path:m.newM});}
else if(phase==='inject-collision'){const m=await prepare();const colliding=path.join(c.dest,'M1-REVIEW-MATERIALS.MD');await write(colliding,'Unrelated Windows case-insensitive collision; preserve these bytes.\n');await action({case:name,action:'independent-unrelated-destination-collision',path:colliding});const siblings=await fs.readdir(c.dest);if(!siblings.some(n=>n.toLowerCase()===path.basename(m.newM).toLowerCase()))throw Error('Collision not detected');const result=await cli('operation-verify',{...ctx,operationPath:m.operationPath},name+'-collision-conflict');await action({case:name,action:'pending-conflict-no-write',result});await snapshot(name+'-after',[...m.operation.files.map(f=>f.path),colliding]);console.log(JSON.stringify(result));}
else if(phase==='competing'){const scan=await cli('inspect-records',{projectsRoot:context.projectsRoot},name+'-records');const result=await cli('check-closure',{recordId:c.ids.milestone,records:scan.records},name+'-closure');await action({case:name,action:'competing-sources-closure',result});console.log(JSON.stringify(result));}
else throw Error('Unknown phase');
