---
id: "01a121cd-62a0-7b84-85fc-2348bc33b95a"
type: task
record_version: 2
title: "Past work"
owner: "synthetic@example.test"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
task-state: "completed"
resolved_at: "2026-10-05T16:00:00Z"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: reviewed
---
# M1-T4 — Past work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

past result

## Definition of Done

- [x] reviewed result <!-- id: 01a121cd-62ce-7288-8b85-f039a13bf61e -->

## Inputs

No input supplied.

## Output and delivery

Local results belong in outputs/.

## Verification

User explicitly attested reviewed result in the acceptance request.

## Result

Reviewed result explicitly attested by user.
