---
id: "01a121cd-635b-7b47-93f2-245ef9acff36"
type: task
record_version: 2
title: "Deselected work"
owner: "synthetic@example.test"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: reviewed
---
# M1-T6 — Deselected work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

optional draft

## Definition of Done

- [ ] reviewed draft <!-- id: 01a121cd-638b-7f58-a3a0-c0ea653beb22 -->

## Inputs

No input supplied.

## Output and delivery

Local results belong in outputs/.

## Verification

Record the supplied criterion evidence before completion.

## Result

Work has not started.
