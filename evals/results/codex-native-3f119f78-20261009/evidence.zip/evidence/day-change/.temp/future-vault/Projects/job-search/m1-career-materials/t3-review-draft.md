---
id: "01a121cd-6242-7681-80e4-7d2d8679441b"
type: task
record_version: 2
title: "Review draft"
owner: "synthetic@example.test"
assignee: "Reviewer"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: reviewed
---
# M1-T3 — Review draft

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

inspect draft

## Definition of Done

- [ ] recorded review <!-- id: 01a121cd-6271-755d-a041-0360b9388609 -->

## Inputs

No input supplied.

## Output and delivery

Local results belong in outputs/.

## Verification

Record the supplied criterion evidence before completion.

## Result

Work has not started.
