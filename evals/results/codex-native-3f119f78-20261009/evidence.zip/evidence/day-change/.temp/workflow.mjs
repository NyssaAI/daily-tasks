import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export const root=process.cwd(), temp=path.join(root,'.temp'), pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8/codex-home/plugins/cache/daily-tasks-runtime-guards-full8/daily-tasks/0.3.3';
export const mon='2026-10-05T16:00:00Z',tue='2026-10-06T16:00:00Z',fri='2026-10-09T16:00:00Z';
let seq=fs.existsSync(path.join(temp,'calls.json'))?JSON.parse(fs.readFileSync(path.join(temp,'calls.json'))).length:0;
export function write(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2));}
export const read=p=>fs.readFileSync(p,'utf8');
export const hash=s=>createHash('sha256').update(s).digest('hex');
export function cli(op,input){const n=String(++seq).padStart(3,'0'),ip=path.join(temp,`${n}-${op}-input.json`);if(input)write(ip,input);const args=[path.join(pkg,'bin/daily-tasks.mjs'),op,...(input?['--input',ip]:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(path.join(temp,`${n}-${op}-result.json`),{args,status:r.status,stdout:r.stdout,stderr:r.stderr});const cp=path.join(temp,'calls.json');const calls=fs.existsSync(cp)?JSON.parse(read(cp)):[];calls.push({n,op,inputPath:input?ip:null,status:r.status});write(cp,calls);if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export function ctx(vault,now){return {vaultRoot:vault,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json'),now};}
export function snapshot(vault,label){const dest=path.join(temp,'snapshots',label);fs.cpSync(vault,dest,{recursive:true,filter:p=>!path.relative(vault,p).split(path.sep).includes('.daily-tasks')&&!path.relative(vault,p).split(path.sep).includes('.temp')});}
const vault=path.join(root,'vault');
if(process.argv[2]==='prepare'){snapshot(vault,'original');write(path.join(temp,'initial-packet.json'),cli('planning-prepare',ctx(vault,mon)));console.log(read(path.join(temp,'initial-packet.json')));}

