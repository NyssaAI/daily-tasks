Scenario 4: day-change — PASS

- PASS: Friday only created: no Tuesday/Wednesday/Thursday backfill
- PASS: Unfinished selected own A/delegated C carry once Friday; B and F excluded
- PASS: Completed D and cancelled E remain visible Monday and do not carry
- PASS: Explicitly deselected F remains open/out and no timeframe fitting
- PASS: Precreated Tuesday retained B and identity/created_at; carried A once
- PASS: Remove A and repeat Tuesday keeps B and honors removal
- PASS: Actual interruption pending without false receipt; resume/retry preserves exact IDs/times and one event
- PASS: Explicit future Friday removal persisted Tuesday; Friday receipt retains removal, no recarry/event

Declared GMT simulation clocks: Monday 2026-10-05T16:00:00Z, Tuesday 2026-10-06T16:00:00Z, Friday 2026-10-09T16:00:00Z. Timezone America/Chicago.

Evidence: calls.json indexes installed CLI inputs and raw results (including failures); snapshots/ retains verified views; *checkpoint.json, *interruption.json, *completion.json and *events.json retain checkpoints and exact queried events. Workflow files were authored during this conversation from installed instructions. No previous attempts or regression tests were read.

- Host version/model not exposed. Installed skill loads are observed file reads; packaging alone is not activation evidence.
- Trusted worker adapter unavailable; maintenance results are CLI inspection, not worker success.
- Initial Friday missing-plan packet supplied no selections; documented plan-rollover supplied A/C. Incorrect initial checkpoint and CLI input failures are retained.
- An initial absolute-path copy filter skipped snapshots and independent configuration. Later copies use paths relative to the authorized vault. Original per-write before bytes and initial inventory hashes survive; missing snapshots are not claimed.

The existing noncanonical Friday note has an unrelated ambiguous checkbox. It remains unchanged in the candidate queue; no accepted work was created from it. Check-in progress preserves that decision separately from the completed scenario assertions.
