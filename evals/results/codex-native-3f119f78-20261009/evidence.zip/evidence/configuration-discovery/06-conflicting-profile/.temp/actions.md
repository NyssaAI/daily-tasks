Installed setup discovery selected common/.nyssaai/daily-tasks/profile.json.
Conflict: profile identity conflict@example.test differs from supplied synthetic@example.test; configured vaultRoot points outside this case and differs from authorized case/vault.
No conflicting settings were changed. No configured external vault was accessed. M1 creation paused pending user conflict resolution. Profile and project before/after snapshots retained; CLI validation and authorized-project log query inputs/results retained.
CLI: node installed-package/bin/daily-tasks.mjs --help
CLI: node installed-package/bin/daily-tasks.mjs validate-profile --input case/.temp/validate-profile-input.json
CLI: node installed-package/bin/daily-tasks.mjs log-query --input case/.temp/log-query-input.json
