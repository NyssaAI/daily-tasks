---
id: "01a12125-8905-73e7-bc52-568640c30a2f"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:10.518Z"
updated_at: "2026-10-09T17:54:55.721Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [ ] [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — update LinkedIn and resume]] <!-- ref: 01a121cd-c3bc-7ad6-8491-d6247b4351e9 -->
