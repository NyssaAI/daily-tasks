import fs from 'node:fs';import path from 'node:path';import {cli,scope,write,evidence,hash,text} from './session.mjs';
const c=JSON.parse(text(evidence+'/context.json'));const id=()=>cli('new-id').id;console.log(cli('new-id'));
