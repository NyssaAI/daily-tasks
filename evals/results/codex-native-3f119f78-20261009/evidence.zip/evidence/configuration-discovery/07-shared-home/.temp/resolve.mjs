import {cli,scope,write,evidence} from './session.mjs';
const c=cli('resolve-context',scope);write(evidence+'/context.json',c);console.log(JSON.stringify(c,null,2));cli('inspect-records',{projectsRoot:c.projectsRoot});cli('log-query',{projectsRoot:c.projectsRoot});cli('next-record-number',{projectsRoot:c.projectsRoot,type:'milestone',parentId:'01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4'});
