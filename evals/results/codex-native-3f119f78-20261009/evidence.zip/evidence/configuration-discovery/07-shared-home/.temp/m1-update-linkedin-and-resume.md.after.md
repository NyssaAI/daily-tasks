---
id: "01a121cd-fb3e-7f13-bdfa-a96c19270c0c"
type: milestone
record_version: 2
title: "update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
created_at: "2026-10-09T17:55:09.943Z"
updated_at: "2026-10-09T17:55:09.943Z"
---
# M1 — update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] reviewed career materials <!-- id: 01a121cd-fb94-7377-8757-f66f4aafad5a -->

## Tasks

- [ ] [[t1-routing-note|Routing note]] <!-- ref: 01a121cd-fb68-7981-bb57-1d70ae829ba8 -->
