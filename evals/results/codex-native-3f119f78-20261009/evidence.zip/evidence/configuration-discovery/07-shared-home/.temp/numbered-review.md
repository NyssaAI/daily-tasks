Open projects: 1          Open tasks: 1          Late tasks: 0

Today: 2026.10.09 — America/Chicago

This is your first check-in today. Review available work; status marks show progress, not selection.

## Already selected

None.

## Available tasks

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | update LinkedIn and resume | Routing note | — |

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled · ↺ carried forward

Applied instruction: Select Routing note today.
