---
id: "01a121cd-fb68-7981-bb57-1d70ae829ba8"
type: task
record_version: 2
title: "Routing note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
milestone_id: "01a121cd-fb3e-7f13-bdfa-a96c19270c0c"
created_at: "2026-10-09T17:55:09.943Z"
updated_at: "2026-10-09T17:55:09.943Z"
---
# M1-T1 — Routing note

**Milestone:** [[m1-update-linkedin-and-resume|update LinkedIn and resume]] <!-- ref: 01a121cd-fb3e-7f13-bdfa-a96c19270c0c -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Requirements

local routing test note

## Definition of Done

- [ ] reviewed routing note <!-- id: 01a121cd-fbbe-7e61-bcd7-88083fd80033 -->

## Output and delivery

Local routing test note in [[outputs/routing-note.md|routing-note.md]].

## Verification

Owner review of the routing note establishes the accepted criterion.
