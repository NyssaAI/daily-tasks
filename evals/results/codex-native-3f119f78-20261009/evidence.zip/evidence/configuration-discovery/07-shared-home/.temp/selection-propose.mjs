import path from 'node:path';import {cli,scope,write,evidence,hash,text} from './session.mjs';
const p=cli('planning-prepare',scope),c=p.context,created=JSON.parse(text(evidence+'/created.json'));
const proposal=cli('plan-selection',{vaultRoot:c.vaultRoot,projectsRoot:c.projectsRoot,dailyPlansRoot:c.dailyPlansRoot,contextBinding:c.planningBinding,inventoryBinding:c.planningBinding,inventory:p.inventory,taskIds:[created.tid],action:'add',today:c.localDate,date:c.localDate});console.log(JSON.stringify(proposal));write(evidence+'/selection-proposal.json',proposal);
