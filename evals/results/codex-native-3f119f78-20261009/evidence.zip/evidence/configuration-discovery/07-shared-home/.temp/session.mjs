import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export const root=process.cwd(), evidence=path.join(root,'.temp'), bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8/codex-home/plugins/cache/daily-tasks-runtime-guards-full8/daily-tasks/0.3.3';
export const scope={vaultRoot:path.join(root,'vault-a'),homeRoot:path.join(root,'synthetic-home'),configRoot:path.join(root,'synthetic-home/.nyssaai/daily-tasks'),profilePath:path.join(root,'synthetic-home/.nyssaai/daily-tasks/profile.json')};
let n=fs.readdirSync(evidence).filter(x=>x.endsWith('-result.json')).length;
export function write(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
export function cli(op,input){const stem=path.join(evidence,`${String(++n).padStart(3,'0')}-${op}`); const args=[path.join(bundle,'bin/daily-tasks.mjs'),op];if(input){write(stem+'-input.json',input);args.push('--input',stem+'-input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(stem+'-result.json',r.stdout||r.stderr);write(stem+'-execution.json',{command:process.execPath,args,status:r.status,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const hash=s=>createHash('sha256').update(s).digest('hex');
export function text(p){return fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;}
