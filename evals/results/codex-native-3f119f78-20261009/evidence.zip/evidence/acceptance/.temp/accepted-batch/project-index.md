---
id: 01a121ce-ef2b-76b2-9a1b-783897ff757a
type: project
record_version: 2
title: "Job Search"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T17:56:12.158Z"
updated_at: "2026-10-09T17:56:12.158Z"
---
# Job Search

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a121ce-ef58-79d1-82c3-dfda3fac3021 --> | | Career materials. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a121ce-ef86-7d6c-b244-748b45aad1f4 --> | Update headline. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a121ce-efb2-7c78-9a32-33ff1f8d9d70 --> | Update summary. | synthetic@example.test | — |
