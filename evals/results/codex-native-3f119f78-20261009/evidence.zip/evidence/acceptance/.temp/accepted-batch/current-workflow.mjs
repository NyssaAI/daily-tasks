import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), vault=path.join(root,'vault'), evidence=path.join(root,'.temp','accepted-batch');
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8/codex-home/plugins/cache/daily-tasks-runtime-guards-full8/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const actions=[];
function call(op,input,label=op){const args=[cli,op];if(input){const p=path.join(evidence,label+'.input.json');fs.writeFileSync(p,JSON.stringify(input,null,2));args.push('--input',p);}const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(path.join(evidence,label+'.result.json'),r.stdout);fs.writeFileSync(path.join(evidence,label+'.stderr.txt'),r.stderr);actions.push({operation:op,args,exitCode:r.status});fs.writeFileSync(path.join(evidence,'actions.json'),JSON.stringify(actions,null,2));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const contextInput={vaultRoot:vault,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json')};
const c=call('resolve-context',contextInput);
const query={projectsRoot:c.projectsRoot};
const before=call('inspect-records',query,'records.before');if(before.records.length)throw Error('Unexpected existing records');
call('log-query',query,'log.before');
const manual=path.join(vault,'Daily/2026-10-09.md'), manualBytes=fs.readFileSync(manual);fs.writeFileSync(path.join(evidence,'manual.before.md'),manualBytes);
const candidatesPath=path.join(c.stateRoot,'candidates.json');const candidatesBefore=fs.readFileSync(candidatesPath);fs.writeFileSync(path.join(evidence,'candidates.before.json'),candidatesBefore);
const time=call('activity-time',{},'acceptance.time');
const ids={};for(const name of ['project','milestone','linkedin','resume','milestoneCriterion','linkedinCriterion','resumeCriterion','operation','event']){const r=call('new-id',null,'id.'+name);ids[name]=typeof r==='string'?r:r.id; if(!ids[name])throw Error(JSON.stringify(r));}
fs.writeFileSync(path.join(evidence,'identities.json'),JSON.stringify(ids,null,2));
const p=path.join(c.projectsRoot,'job-search'), m=path.join(p,'m1-career-materials');
const numberM=call('next-record-number',{...query,type:'milestone',parentId:ids.project},'number.milestone');if(numberM.number!==null)throw Error('Unexpected pre-creation allocation');
const numberT=call('next-record-number',{...query,type:'task',parentId:ids.milestone},'number.task');if(numberT.number!==null)throw Error('Unexpected pre-creation allocation');
const owner='synthetic@example.test', stamp=time.recorded_at;
function front(type,id,title,parents=''){return `---\nid: ${id}\ntype: ${type}\nrecord_version: 2\ntitle: "${title}"\n${type}-state: not-started\nowner: "${owner}"\n${parents}created_at: "${stamp}"\nupdated_at: "${stamp}"\n---\n`;}
const project=front('project',ids.project,'Job Search')+`# Job Search\n\n## Project Summary\n\n| Milestone | Task | Description | Owner | Due Date |\n| --- | --- | --- | --- | --- |\n| [ ] [[m1-career-materials/m1-career-materials\\|Career materials]] <!-- ref: ${ids.milestone} --> | | Career materials. | ${owner} | — |\n| | [ ] [[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]] <!-- ref: ${ids.linkedin} --> | Update headline. | ${owner} | — |\n| | [ ] [[m1-career-materials/t2-update-resume\\|Update resume]] <!-- ref: ${ids.resume} --> | Update summary. | ${owner} | — |\n`;
const milestone=front('milestone',ids.milestone,'Career materials',`project_id: "${ids.project}"\n`)+`# M1 — Career materials\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${ids.project} -->\n\n## Outcome\n\nUpdate LinkedIn headline and resume summary.\n\n## Definition of Done\n\n- [ ] Both reviewed artifacts linked. <!-- id: ${ids.milestoneCriterion} -->\n\n## Tasks\n\n- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${ids.linkedin} -->\n- [ ] [[t2-update-resume|Update resume]] <!-- ref: ${ids.resume} -->\n`;
function task(id,title,num,requirement,dod,criterion){return front('task',id,title,`project_id: "${ids.project}"\nmilestone_id: "${ids.milestone}"\n`)+`# M1-T${num} — ${title}\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${ids.milestone} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${ids.project} -->\n\n## Requirements\n\n${requirement}\n\n## Definition of Done\n\n- [ ] ${dod} <!-- id: ${criterion} -->\n\n## Result\n\nNot started; no reviewed artifact supplied.\n`;}
const documents=[{path:path.join(p,'project-index.md'),text:project},{path:path.join(m,'m1-career-materials.md'),text:milestone},{path:path.join(m,'t1-update-linkedin.md'),text:task(ids.linkedin,'Update LinkedIn',1,'Update headline.','Reviewed headline.',ids.linkedinCriterion)},{path:path.join(m,'t2-update-resume.md'),text:task(ids.resume,'Update resume',2,'Update summary.','Reviewed summary.',ids.resumeCriterion)}];
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const parsed=documents.map((d,i)=>call('parse-record',{markdown:d.text,path:d.path},'proposed.'+i));
fs.writeFileSync(path.join(evidence,'proposed.parsed.json'),JSON.stringify(parsed,null,2));
const event={id:ids.event,operation_id:ids.operation,action:'batch.accepted',record_ids:[ids.project,ids.milestone,ids.linkedin,ids.resume],actor:{kind:'person',id:owner},...time,original_words:'I explicitly accept this batch: create Job Search project, M1 Career materials milestone, Update LinkedIn task (requirement: update headline; DoD: reviewed headline), and Update resume task (requirement: update summary; DoD: reviewed summary). Milestone DoD: both reviewed artifacts linked. Owner synthetic@example.test; all accepted work not started and unchecked. Accept no other work.',before:{records:[]},after:{records:parsed.map((r,i)=>({...r,path:documents[i].path})),acceptance_source:'Current explicit user batch acceptance'}};
const checkpoint={schemaVersion:2,operation_id:ids.operation,contextBinding:c.planningBinding,event,files:documents.map(d=>({path:d.path,before:null,after:hash(d.text)})),protectedFiles:[{path:manual,sha256:hash(manualBytes)}]};
const operationPath=path.join(c.stateRoot,'operations',ids.operation+'.json');fs.mkdirSync(path.dirname(operationPath),{recursive:true});fs.writeFileSync(operationPath,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(evidence,'checkpoint.before.json'),JSON.stringify(checkpoint,null,2));
for(const [i,d] of documents.entries()){if(i>0){const n=call('next-record-number',{...query,type:i===1?'milestone':'task',parentId:i===1?ids.project:ids.milestone},'number.live.'+i);if(n.number!==(i===3?2:1))throw Error('Allocation blocked');}if(fs.existsSync(d.path))throw Error('Collision');fs.mkdirSync(path.dirname(d.path),{recursive:true});fs.writeFileSync(d.path,d.text);fs.writeFileSync(path.join(evidence,path.basename(d.path)),d.text);}
for(const dir of ['inputs','outputs'])fs.mkdirSync(path.join(m,dir),{recursive:true});
call('invalidate-project-index',{vaultRoot:vault});
const after=call('inspect-records',query,'records.after');
const valid=call('validate-records',{records:after.records});const links=call('check-links',{records:after.records});
fs.writeFileSync(path.join(evidence,'validation.summary.json'),JSON.stringify({valid,links},null,2));
if(after.records.length!==4||after.diagnostics.length)throw Error('Record validation diagnostics');
if(event.activity_at!==time.activity_at||event.recorded_at!==time.recorded_at)throw Error('Timestamp mismatch');
call('log-append',{projectsRoot:c.projectsRoot,entry:event});
call('log-query',query,'log.after');
for(const [label,id] of Object.entries(ids).filter(([k])=>['project','milestone','linkedin','resume'].includes(k)))call('log-query',{...query,recordId:id},'log.record.'+label);
const operationInput={...contextInput,operationPath};const verification=call('operation-verify',operationInput);if(verification.status!=='verified')throw Error(JSON.stringify(verification));call('operation-complete',operationInput);
const candidates=JSON.parse(candidatesBefore);for(const x of candidates.candidates){if(x.key==='career-materials:update-linkedin'||x.key==='career-materials:improve-resume'){x.disposition='accepted';x.accepted=true;x.recordId=x.key.includes('linkedin')?ids.linkedin:ids.resume;x.acceptanceSource='Current explicit user batch acceptance';x.acceptanceEventId=ids.event; x.unresolved=[];}}
fs.writeFileSync(candidatesPath,JSON.stringify(candidates,null,2)+'\n');fs.writeFileSync(path.join(evidence,'candidates.after.json'),fs.readFileSync(candidatesPath));
const manualAfter=fs.readFileSync(manual);fs.writeFileSync(path.join(evidence,'manual.after.md'),manualAfter);if(!manualBytes.equals(manualAfter))throw Error('Manual note changed');
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({created:documents.map(d=>d.path),ids,manualBeforeHash:hash(manualBytes),manualAfterHash:hash(manualAfter),acceptanceOnlyNow:true,verification},null,2));
console.log(JSON.stringify({created:documents.map(d=>d.path),valid,links,verification}));

