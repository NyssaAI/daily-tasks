---
id: 01a121ce-efb2-7c78-9a32-33ff1f8d9d70
type: task
record_version: 2
title: "Update resume"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a121ce-ef2b-76b2-9a1b-783897ff757a"
milestone_id: "01a121ce-ef58-79d1-82c3-dfda3fac3021"
created_at: "2026-10-09T17:56:12.158Z"
updated_at: "2026-10-09T17:56:12.158Z"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a121ce-ef58-79d1-82c3-dfda3fac3021 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a121ce-ef2b-76b2-9a1b-783897ff757a -->

## Requirements

Update summary.

## Definition of Done

- [ ] Reviewed summary. <!-- id: 01a121ce-f037-769d-ac89-59505885e6e3 -->

## Result

Not started; no reviewed artifact supplied.
