---
id: 01a121ce-ef58-79d1-82c3-dfda3fac3021
type: milestone
record_version: 2
title: "Career materials"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a121ce-ef2b-76b2-9a1b-783897ff757a"
created_at: "2026-10-09T17:56:12.158Z"
updated_at: "2026-10-09T17:56:12.158Z"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a121ce-ef2b-76b2-9a1b-783897ff757a -->

## Outcome

Update LinkedIn headline and resume summary.

## Definition of Done

- [ ] Both reviewed artifacts linked. <!-- id: 01a121ce-efdf-722d-b992-28c6ecbf8538 -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a121ce-ef86-7d6c-b244-748b45aad1f4 -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a121ce-efb2-7c78-9a32-33ff1f8d9d70 -->
