---
id: 01a121cd-2ec9-7570-a58b-96cca0dd65b6
type: project
title: "Demo"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T17:54:17.719Z"
updated_at: "2026-10-09T17:54:17.719Z"
---
# Demo

Create and review a note paragraph.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-draft/m1-draft\|Draft]] <!-- ref: 01a121cd-2ef5-7942-9be0-a7371290dd03 --> | | Both task criteria satisfied. | Synthetic User | — |
| | [ ] [[m1-draft/t1-draft-note\|Draft note]] <!-- ref: 01a121cd-2f22-7a99-9bca-16fb23d481b1 --> | Write a paragraph. | Synthetic User | — |
| | [ ] [[m1-draft/t2-review-note\|Review note]] <!-- ref: 01a121cd-2f4d-7cb4-b88f-e8aeab430fa7 --> | Inspect the paragraph; assigned to Reviewer. | Synthetic User | — |
