---
id: 01a121cd-2f4d-7cb4-b88f-e8aeab430fa7
type: task
record_version: 2
title: "Review note"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a121cd-2ec9-7570-a58b-96cca0dd65b6"
milestone_id: "01a121cd-2ef5-7942-9be0-a7371290dd03"
assignee: "Reviewer"
created_at: "2026-10-09T17:54:17.719Z"
updated_at: "2026-10-09T17:54:17.719Z"
---
# M1-T2 — Review note

**Milestone:** [[m1-draft|Draft]] <!-- ref: 01a121cd-2ef5-7942-9be0-a7371290dd03 -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a121cd-2ec9-7570-a58b-96cca0dd65b6 -->

## Requirements

Inspect the paragraph.

## Definition of Done

- [ ] Recorded review. <!-- id: 01a121cd-2fca-7481-8932-6510da0cdac4 -->
