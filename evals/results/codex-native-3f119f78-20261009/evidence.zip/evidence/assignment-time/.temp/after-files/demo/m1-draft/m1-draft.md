---
id: 01a121cd-2ef5-7942-9be0-a7371290dd03
type: milestone
record_version: 2
title: "Draft"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a121cd-2ec9-7570-a58b-96cca0dd65b6"
created_at: "2026-10-09T17:54:17.719Z"
updated_at: "2026-10-09T17:54:17.719Z"
---
# M1 — Draft

**Project:** [[../project-index|Demo]] <!-- ref: 01a121cd-2ec9-7570-a58b-96cca0dd65b6 -->

## Outcome

Draft and review the note paragraph.

## Definition of Done

- [ ] Both task Definitions of Done are satisfied. <!-- id: 01a121cd-2f77-7f52-aaab-3dce247ce12e -->

## Tasks

- [>] [[t1-draft-note|Draft note]] <!-- ref: 01a121cd-2f22-7a99-9bca-16fb23d481b1 -->
- [ ] [[t2-review-note|Review note]] <!-- ref: 01a121cd-2f4d-7cb4-b88f-e8aeab430fa7 -->
