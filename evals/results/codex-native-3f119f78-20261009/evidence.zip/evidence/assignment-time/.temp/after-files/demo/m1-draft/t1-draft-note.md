---
id: 01a121cd-2f22-7a99-9bca-16fb23d481b1
type: task
record_version: 2
title: "Draft note"
task-state: in-progress
owner: "synthetic@example.test"
project_id: "01a121cd-2ec9-7570-a58b-96cca0dd65b6"
milestone_id: "01a121cd-2ef5-7942-9be0-a7371290dd03"
created_at: "2026-10-09T17:54:17.719Z"
started_at: "2026-10-09T17:54:18.297Z"
updated_at: "2026-10-09T17:54:18.297Z"
---
# M1-T1 — Draft note

**Milestone:** [[m1-draft|Draft]] <!-- ref: 01a121cd-2ef5-7942-9be0-a7371290dd03 -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a121cd-2ec9-7570-a58b-96cca0dd65b6 -->

## Requirements

Write a paragraph.

## Definition of Done

- [ ] Reviewed paragraph. <!-- id: 01a121cd-2fa2-7516-a8e2-ddad11bb043f -->
