import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import crypto from 'node:crypto';
const scratch=path.resolve('.temp'),read=n=>JSON.parse(fs.readFileSync(path.join(scratch,n),'utf8'));
const ctx=read('context.json'), ids=read('identities.json'),start=read('start-checkpoint.json').event;
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8/codex-home/plugins/cache/daily-tasks-runtime-guards-full8/daily-tasks/0.3.3';
let seq=45;
function cli(op,input){const stem=String(seq++).padStart(3,'0')+'-'+op,p=path.join(scratch,stem+'-input.json');fs.writeFileSync(p,JSON.stringify(input,null,2));const args=[path.join(pkg,'bin/daily-tasks.mjs'),op,'--input',p],r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(path.join(scratch,stem+'-execution.json'),JSON.stringify({command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const final=cli('inspect-records',{projectsRoot:ctx.projectsRoot});
const navigation=cli('inspect-navigation',{projectsRoot:ctx.projectsRoot});
const links=cli('check-links',{records:final.records});
const log=cli('log-query',{projectsRoot:ctx.projectsRoot});
const display=cli('format-time',{time:start.activity_at,timezone:ctx.timezone});
fs.writeFileSync(path.join(scratch,'final-log-query.json'),JSON.stringify(log,null,2));fs.writeFileSync(path.join(scratch,'local-start-display.json'),JSON.stringify(display,null,2));
const draft=final.records.find(r=>r.id===ids.draft),review=final.records.find(r=>r.id===ids.review);
const creation=read('creation-inspection.json').records,initialReview=creation.find(r=>r.id===ids.review);
const assigned=log.entries.find(e=>e.action==='task.assignee-changed');
const checks=[
 ['Default owner from setup',final.records.every(r=>r.owner===ctx.profile.user.email)],
 ['Omitted assignee means owner',!Object.hasOwn(draft,'assignee')&&draft.owner===ctx.profile.user.email],
 ['Agent can reassign while human owner stays unchanged',assigned.actor.kind==='agent'&&assigned.before.assignee==='Reviewer'&&assigned.after.assignee==='Editor'&&review.assignee==='Editor'&&creation.every(r=>r.owner===ctx.profile.user.email)&&final.records.every(r=>r.owner===ctx.profile.user.email)],
 ['Assignment never starts work',initialReview.state==='not-started'&&!initialReview.started_at&&review.state==='not-started'&&!review.started_at],
 ['Vague retrospective start uses CLI now and exact original words',start.time_defaulted===true&&start.original_words==='earlier this morning'&&start.activity_at===start.recorded_at&&draft.started_at===start.activity_at&&draft.state==='in-progress'&&JSON.parse(read('025-activity-time-execution.json').stdout).activity_at===start.activity_at&&log.entries.some(e=>JSON.stringify(e)===JSON.stringify(start))],
 ['GMT storage and explicit local timezone display',log.entries.every(e=>/Z$/.test(e.activity_at)&&/Z$/.test(e.recorded_at))&&final.records.every(r=>/Z$/.test(r.created_at)&&/Z$/.test(r.updated_at))&&JSON.stringify(display).includes('America/Chicago')],
 ['No closure or extra work',final.records.length===4&&final.records.every(r=>!['completed','cancelled'].includes(r.state))&&final.records.flatMap(r=>r.criteria).every(c=>!c.checked)],
 ['Integrity checks clean',final.diagnostics.length===0],
 ['All authored operations completed', ['creation','start','reassignment'].every(n=>read(n+'-complete.json').status==='completed')]
];
for(const r of final.records){const dest=path.join(scratch,'after-files',path.relative(ctx.projectsRoot,r.path));fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(r.path,dest);}
const loaded=['daily-tasks/SKILL.md','daily-tasks-setup/SKILL.md','daily-tasks-records/SKILL.md',...['cli','operations','records','verification'].map(n=>'daily-tasks/references/'+n+'.md'),...['project-index','milestone','task'].map(n=>'daily-tasks/assets/'+n+'.md')].map(n=>{const p=path.join(pkg,'skills',n);return {path:p,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')};});
const receipt={scenario:'assignment-time',checks:checks.map(([assertion,passed])=>({assertion,passed})),passed:checks.every(([,v])=>v),startExactGMT:{activity_at:start.activity_at,recorded_at:start.recorded_at,time_defaulted:start.time_defaulted,original_words:start.original_words},display,loadedInstructions:loaded,navigation,links,host:'Current native Codex session; host version/model not exposed; direct installed CLI evidence supports deterministic checks and is not host activation proof.',retainedFailures:['Initial setup log call needed the projects directory; retried before any log entry existed.','Optional navigation call with absent daily plan directory failed; repeated with projectsRoot only.'],ownerAuthority:'No human owner change requested, so no owner mutation performed.'};
fs.writeFileSync(path.join(scratch,'scenario2-assertions.json'),JSON.stringify(receipt,null,2));
fs.writeFileSync(path.join(scratch,'scenario2-result.md'),`Scenario 2: ${receipt.passed?'PASS':'FAIL'}\n\n${checks.map(([a,p])=>`- ${p?'PASS':'FAIL'}: ${a}`).join('\n')}\n\nExact original words: earlier this morning.\n\nGMT activity_at and recorded_at: ${start.activity_at}.\n\nLocal display: ${JSON.stringify(display)}.\n\nAll CLI inputs, raw stdout/stderr, exits, checkpoints and record snapshots are retained beside this report. No task, milestone or project closure performed.\n`);
console.log(JSON.stringify({checks,display,passed:receipt.passed,navigation,links},null,2));
if(!receipt.passed)process.exitCode=1;
