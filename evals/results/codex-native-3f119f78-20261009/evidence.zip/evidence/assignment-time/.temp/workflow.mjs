import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const caseRoot=process.cwd(), scratch=path.join(caseRoot,'.temp'), vault=path.join(caseRoot,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8/codex-home/plugins/cache/daily-tasks-runtime-guards-full8/daily-tasks/0.3.3';
const entry=path.join(pkg,'bin/daily-tasks.mjs');
let seq=0;
const write=(p,s)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);};
const json=(p,v)=>write(p,JSON.stringify(v,null,2)+'\n');
function cli(op,input){const stem=String(++seq).padStart(3,'0')+'-'+op;const args=[entry,op];if(input!==undefined){const p=path.join(scratch,stem+'-input.json');json(p,input);args.push('--input',p);}const r=spawnSync(process.execPath,args,{encoding:'utf8'});json(path.join(scratch,stem+'-execution.json'),{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const id=()=>{const v=cli('new-id');return typeof v==='string'?v:v.id;};
json(path.join(scratch,'before.json'),{vault,files:fs.readdirSync(vault),node:process.version,installedPackage:pkg,authorization:'Current user named creation and updates; vault-only synthetic scope. No owner change authorized.'});
const config=path.join(vault,'.nyssaai/daily-tasks'), projects=path.join(vault,'1-projects');
fs.mkdirSync(projects,{recursive:true});
const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:vault,projectsRoot:projects,dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
const validation=cli('validate-profile',profile);if(!validation.valid)throw Error(JSON.stringify(validation));
json(path.join(config,'profile.json'),profile);
const contextInput={vaultRoot:vault,configRoot:config};
const context=cli('resolve-context',contextInput);json(path.join(scratch,'context.json'),context);
async function event(action,recordIds,actor,before,after,reported){const time=cli('activity-time',reported?{reported}:{});return {id:id(),operation_id:id(),action,record_ids:recordIds,actor,...time,...(reported?{original_words:reported}:{}),before,after};}
const setupEvent=await event('profile.configured',[],{kind:'person',id:profile.user.email},null,profile);
cli('log-append',{projectsRoot:projects,entry:setupEvent});
const ids={project:id(),milestone:id(),draft:id(),review:id(),milestoneCriterion:id(),draftCriterion:id(),reviewCriterion:id()};json(path.join(scratch,'identities.json'),ids);
const pdir=path.join(projects,'demo'),mdir=path.join(pdir,'m1-draft');
const paths={project:path.join(pdir,'project-index.md'),milestone:path.join(mdir,'m1-draft.md'),draft:path.join(mdir,'t1-draft-note.md'),review:path.join(mdir,'t2-review-note.md')};
function metadata(type,title,uuid,time,extras=''){return `---\nid: ${uuid}\ntype: ${type}\n${type==='project'?'':'record_version: 2\n'}title: "${title}"\n${type}-state: not-started\nowner: "${profile.user.email}"\n${extras}created_at: "${time}"\nupdated_at: "${time}"\n---\n`;}
const accepted=await event('records.accepted',Object.values(ids).slice(0,4),{kind:'person',id:profile.user.email},null,{records:Object.entries(paths).map(([k,p])=>({id:ids[k],type:k==='draft'||k==='review'?'task':k,path:p,...(k!=='project'?{project_id:ids.project}:{}),...(k==='draft'||k==='review'?{milestone_id:ids.milestone}:{})})),acceptance:'Explicit user instruction to create Demo, M1 Draft, Draft note and Review note.'});
const t=accepted.activity_at;
let content={
 project:metadata('project','Demo',ids.project,t)+`# Demo\n\nCreate and review a note paragraph.\n\n## Project Summary\n\n| Milestone | Task | Description | Owner | Due Date |\n| --- | --- | --- | --- | --- |\n| [ ] [[m1-draft/m1-draft\\|Draft]] <!-- ref: ${ids.milestone} --> | | Both task criteria satisfied. | Synthetic User | — |\n| | [ ] [[m1-draft/t1-draft-note\\|Draft note]] <!-- ref: ${ids.draft} --> | Write a paragraph. | Synthetic User | — |\n| | [ ] [[m1-draft/t2-review-note\\|Review note]] <!-- ref: ${ids.review} --> | Inspect the paragraph; assigned to Reviewer. | Synthetic User | — |\n`,
 milestone:metadata('milestone','Draft',ids.milestone,t,`project_id: "${ids.project}"\n`)+`# M1 — Draft\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${ids.project} -->\n\n## Outcome\n\nDraft and review the note paragraph.\n\n## Definition of Done\n\n- [ ] Both task Definitions of Done are satisfied. <!-- id: ${ids.milestoneCriterion} -->\n\n## Tasks\n\n- [ ] [[t1-draft-note|Draft note]] <!-- ref: ${ids.draft} -->\n- [ ] [[t2-review-note|Review note]] <!-- ref: ${ids.review} -->\n`,
};
for(const [k,title,req,dod,criterion] of [['draft','Draft note','Write a paragraph.','Reviewed paragraph.',ids.draftCriterion],['review','Review note','Inspect the paragraph.','Recorded review.',ids.reviewCriterion]])content[k]=metadata('task',title,ids[k],t,`project_id: "${ids.project}"\nmilestone_id: "${ids.milestone}"\n${k==='review'?'assignee: "Reviewer"\n':''}`)+`# M1-T${k==='draft'?1:2} — ${title}\n\n**Milestone:** [[m1-draft|Draft]] <!-- ref: ${ids.milestone} -->\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${ids.project} -->\n\n## Requirements\n\n${req}\n\n## Definition of Done\n\n- [ ] ${dod} <!-- id: ${criterion} -->\n`;
async function commit(label,event,next){const files=Object.entries(next).map(([k,s])=>({path:paths[k],before:fs.existsSync(paths[k])?hash(fs.readFileSync(paths[k])):null,after:hash(s)}));const operation={schemaVersion:2,operation_id:event.operation_id,contextBinding:context.planningBinding,event,files};const opPath=path.join(context.stateRoot,'operations',event.operation_id+'.json');json(opPath,operation);json(path.join(scratch,label+'-checkpoint.json'),operation);for(const [k,s] of Object.entries(next)){const p=paths[k],f=files.find(f=>f.path===p);const actual=fs.existsSync(p)?hash(fs.readFileSync(p)):null;if(actual!==f.before)throw Error('Changed before write');if(actual!==null)write(path.join(pdir,'.temp',label+'-'+path.basename(p)),fs.readFileSync(p));write(p,s);}const inspected=cli('inspect-records',{projectsRoot:projects});json(path.join(scratch,label+'-inspection.json'),inspected);if(inspected.diagnostics?.length)throw Error(JSON.stringify(inspected.diagnostics));if(event.activity_at!==event.recorded_at&&event.time_defaulted)throw Error('Invalid fallback');cli('log-append',{projectsRoot:projects,entry:event});cli('invalidate-project-index',{vaultRoot:vault});cli('log-query',{projectsRoot:projects});const verified=cli('operation-verify',{...contextInput,operationPath:opPath});if(verified.status!=='verified')throw Error(JSON.stringify(verified));const completed=cli('operation-complete',{...contextInput,operationPath:opPath});json(path.join(scratch,label+'-complete.json'),completed);}
fs.mkdirSync(path.join(mdir,'inputs'),{recursive:true});fs.mkdirSync(path.join(mdir,'outputs'),{recursive:true});
await commit('creation',accepted,content);
cli('next-record-number',{projectsRoot:projects,type:'milestone',parentId:ids.project});cli('next-record-number',{projectsRoot:projects,type:'task',parentId:ids.milestone});
const start=await event('task.started',[ids.draft],{kind:'person',id:profile.user.email},{'task-state':'not-started'},{'task-state':'in-progress'},'earlier this morning');
json(path.join(scratch,'start-exact-times.json'),{activity_at:start.activity_at,recorded_at:start.recorded_at,time_defaulted:start.time_defaulted,original_words:start.original_words});
const started=content.draft.replace('task-state: not-started','task-state: in-progress').replace(`updated_at: "${t}"`,`started_at: "${start.activity_at}"\nupdated_at: "${start.recorded_at}"`);
const projectStarted=content.project.replace('[ ] [[m1-draft/t1-draft-note','[>] [[m1-draft/t1-draft-note');const milestoneStarted=content.milestone.replace('[ ] [[t1-draft-note','[>] [[t1-draft-note');
await commit('start',start,{draft:started,project:projectStarted,milestone:milestoneStarted});content={...content,draft:started,project:projectStarted,milestone:milestoneStarted};
const reassignment=await event('task.assignee-changed',[ids.review],{kind:'agent',id:'Codex'},{assignee:'Reviewer',owner:profile.user.email,'task-state':'not-started'},{assignee:'Editor',owner:profile.user.email,'task-state':'not-started',reason:'Agent assignment authority; human owner preserved.'});
const reassigned=content.review.replace('assignee: "Reviewer"','assignee: "Editor"').replace(`updated_at: "${t}"`,`updated_at: "${reassignment.recorded_at}"`);
await commit('reassignment',reassignment,{review:reassigned,project:content.project.replace('assigned to Reviewer','assigned to Editor')});
const final=cli('inspect-records',{projectsRoot:projects});json(path.join(scratch,'after.json'),final);cli('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot});const log=cli('log-query',{projectsRoot:projects});json(path.join(scratch,'final-log-query.json'),log);const display=cli('format-time',{time:start.activity_at,timezone:profile.timezone});json(path.join(scratch,'local-start-display.json'),display);
console.log(JSON.stringify({context,ids,paths,start,display,final,log},null,2));
