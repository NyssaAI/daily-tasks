import fs from 'node:fs';
const p='.temp/closure-workflow.mjs';let s=fs.readFileSync(p,'utf8');s=s.replace('let serial=0; const actions=[], assertions=[];',`let serial=200; const actions=JSON.parse(fs.readFileSync('.temp/actions.json','utf8')), assertions=JSON.parse(fs.readFileSync('.temp/assertions.json','utf8'));`);
s=s.replace('for(const[p,s]of map){const r=', 'for(const[p,s]of map){if(!/^type: /m.test(s))continue;const r=');
const head=s.slice(0,s.indexOf("json(path.join(scratch,'installed-instructions.json')"));const tail=s.slice(s.indexOf("gate('shared open blocker gates LinkedIn"));
const recovery=`
const blocker=scan().records.find(r=>r.type==='blocker');
const pendingDir=path.join(ctx.stateRoot,'operations');
for(const name of fs.readdirSync(pendingDir)){
 const operationPath=path.join(pendingDir,name);const checkpoint=JSON.parse(fs.readFileSync(operationPath,'utf8'));
 cli('log-query',{projectsRoot:ctx.projectsRoot,limit:1000});
 checkpoint.event.record_ids=checkpoint.event.record_ids.filter(Boolean);
 json(operationPath,checkpoint);json(path.join(scratch,'actions',checkpoint.event.action,'corrected-checkpoint.json'),checkpoint);
 cli('log-append',{projectsRoot:ctx.projectsRoot,entry:checkpoint.event});cli('log-query',{projectsRoot:ctx.projectsRoot,limit:1000});
 assert('recovered artifact review operation verified',cli('operation-verify',{...scope,operationPath}).status==='verified');
 cli('operation-complete',{...scope,operationPath});assert('recovered artifact review operation completed',!fs.existsSync(operationPath));cli('invalidate-project-index',{vaultRoot:vault});
 actions.push({label:checkpoint.event.action,operation_id:checkpoint.operation_id,files:checkpoint.files});json(path.join(scratch,'actions.json'),actions);
}
let map;
`;
fs.writeFileSync('.temp/closure-continue.mjs',head+recovery+tail);
