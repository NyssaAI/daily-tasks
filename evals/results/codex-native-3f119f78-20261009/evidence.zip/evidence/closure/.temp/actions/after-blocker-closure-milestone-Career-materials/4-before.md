---
id: "01a1211c-fc6d-7e56-b639-7133ec8fe4d6"
type: "task"
record_version: 2
title: "Update resume"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
task-state: "completed"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: "reviewed"
resolved_at: "2026-10-09T17:55:57.852Z"
updated_at: "2026-10-09T17:55:57.901Z"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a summary.

## Definition of Done

- [x] A reviewed summary is saved locally. <!-- id: 01a1211c-fd0c-7f8e-9ff3-557373a0657f -->

## Inputs

No source material has been supplied. Local working inputs belong in inputs/.

## Output and delivery

Save the summary locally in outputs/. [Reviewed artifact](outputs/resume-summary.md). Review evidence is included in the artifact.

## Verification

Confirm the summary was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Synthetic draft produced and reviewed against the existing criterion. [Reviewed artifact](outputs/resume-summary.md).

## Blocked by

- [[../blockers/b1-await-approval|Await approval]] <!-- ref: 01a121ce-0442-75c1-bd51-e47a9247e525 -->

## Required by
- [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
