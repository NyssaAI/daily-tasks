import fs from 'node:fs';
let s=fs.readFileSync('.temp/closure-finalize.mjs','utf8');const tail=s.slice(s.indexOf("const sources="));s=s.slice(0,s.indexOf('const records=scan().records;')).replace('let serial=1500;','let serial=1600;');s+=`
const operationPath=path.join(ctx.stateRoot,'operations',JSON.parse(fs.readFileSync(path.join(scratch,'baseline-checkpoint.json'),'utf8')).operation_id+'.json');
const checkpoint=JSON.parse(fs.readFileSync(operationPath,'utf8'));
checkpoint.files=checkpoint.protectedFiles.map(f=>({path:f.path,before:f.sha256,after:f.sha256}));
for(const r of Object.values(checkpoint.baseline.value.records))r.canonical={fields:r.canonical};
json(operationPath,checkpoint);json(path.join(scratch,'baseline-checkpoint-corrected.json'),checkpoint);
cli('log-query',{projectsRoot:ctx.projectsRoot,limit:1000});const verified=cli('operation-verify',{...scope,operationPath});assert('final baseline verified',verified.status==='verified',verified);cli('operation-complete',{...scope,operationPath});assert('final baseline committed',!fs.existsSync(operationPath));
const records=scan().records;const validation=cli('validate-records',{records}),links=cli('check-links',{records});
`+tail;fs.writeFileSync('.temp/closure-baseline-recovery.mjs',s);
