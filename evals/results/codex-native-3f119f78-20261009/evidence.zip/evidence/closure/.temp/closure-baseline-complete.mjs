import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8/codex-home/plugins/cache/daily-tasks-runtime-guards-full8/daily-tasks/0.3.3';
const cliPath=path.join(pkg,'bin/daily-tasks.mjs');
let serial=1800; const actions=JSON.parse(fs.readFileSync('.temp/actions.json','utf8')), assertions=JSON.parse(fs.readFileSync('.temp/assertions.json','utf8'));
const json=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(v,null,2));};
const hash=s=>s===null?null:crypto.createHash('sha256').update(s).digest('hex');
function cli(op,input){const n=String(++serial).padStart(4,'0'), stem=path.join(scratch,`${n}-${op}`); if(input)json(stem+'-input.json',input);const args=[cliPath,op,...(input?['--input',stem+'-input.json']:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(stem+'-stdout.json',r.stdout);fs.writeFileSync(stem+'-stderr.txt',r.stderr);json(stem+'-execution.json',{command:process.execPath,args,exitCode:r.status});if(r.status!==0)throw Error(`${op}: ${r.stderr}`);return JSON.parse(r.stdout);}
function assert(name,ok,evidence){assertions.push({name,passed:!!ok,evidence});json(path.join(scratch,'assertions.json'),assertions);if(!ok)throw Error(name);}
const ctx=cli('resolve-context',{vaultRoot:vault});
const scope={vaultRoot:vault,profilePath:ctx.profilePath,stateRoot:ctx.stateRoot};
const scan=()=>cli('inspect-records',{projectsRoot:ctx.projectsRoot});
const initial=scan();json(path.join(scratch,'initial-records.json'),initial);
const record=t=>initial.records.find(r=>r.title===t);
const P=record('Job Search'),M=record('Career materials'),A=record('Update LinkedIn'),B=record('Update resume');
const read=r=>fs.readFileSync(r.path,'utf8'); const texts=()=>new Map([P,M,A,B].map(r=>[r.path,read(r)]));
const state=(s,type,value)=>s.replace(new RegExp(`^${type}-state:.*$`,'m'),`${type}-state: "${value}"`);
const setmeta=(s,key,value)=>{const re=new RegExp(`^${key}:.*\\r?\\n`,'m');s=s.replace(re,'');return value===null?s:s.replace(/\r?\n---\r?\n/,`\n${key}: ${JSON.stringify(value)}\n---\n`);};
const criterion=(s,checked)=>s.replace(/- \[[ x]\] (.*<!-- id:)/g,`- [${checked?'x':' '}] $1`);
function views(map,records){for(const [p,s]of map){let next=s;for(const r of records)next=next.split(/\r?\n/).map(line=>line.includes(`<!-- ref: ${r.id} -->`)&&/\[[ x>\-]\]/.test(line)?line.replace(/\[[ x>\-]\]/,r.state==='completed'?'[x]':r.state==='cancelled'?'[-]':r.state==='in-progress'?'[>]':'[ ]'):line).join('\n');map.set(p,next);}}
async function commit(label,map,changedIds=[]){
 const time=cli('activity-time',{});const opid=cli('new-id').id, eid=cli('new-id').id;
 if(!opid||!eid)throw Error('new-id shape');
 let proposed=scan().records; for(const[p,s]of map){if(!/^type: /m.test(s))continue;const r=cli('parse-record',{markdown:s,path:p});const i=proposed.findIndex(x=>x.path===p);if(i<0)proposed.push(r);else proposed[i]=r;}
 if(changedIds.length){const reopen=cli('reopen-ancestors',{records:proposed,changedIds});json(path.join(scratch,`${serial}-reopen-proposal.json`),reopen);for(const r of reopen.records){const old=proposed.find(x=>x.id===r.id);if(old&&r.state!==old.state){let s=map.get(r.path)??fs.readFileSync(r.path,'utf8');s=state(s,r.type,r.state);s=setmeta(s,'resolved_at',null);map.set(r.path,s);}}proposed=reopen.records;}
 views(map,proposed);
 const effects=[];const before=[],after=[];const dir=path.join(scratch,'actions',label);fs.mkdirSync(dir,{recursive:true});
 for(const[p,raw]of map){const prev=fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;let next=raw;if(/^type: /m.test(next))next=setmeta(next,'updated_at',time.recorded_at);if(next===prev)continue;const n=String(effects.length+1);fs.writeFileSync(path.join(dir,n+'-before.md'),prev??'ABSENT');fs.writeFileSync(path.join(dir,n+'-after.md'),next);effects.push({path:p,before:hash(prev),after:hash(next),text:next});before.push({path:p,markdown:prev});after.push({path:p,markdown:next});}
 const event={id:eid,operation_id:opid,action:label,record_ids:proposed.filter(r=>effects.some(f=>f.path===r.path)).map(r=>r.id),actor:{kind:'agent',id:'codex'},...time,original_words:'User-authorized scenario5 closure manual edits and synthetic reviewed evidence.',before,after};
 const checkpoint={schemaVersion:2,operation_id:opid,contextBinding:ctx.planningBinding,event,files:effects.map(({text,...f})=>f)};
 const operationPath=path.join(ctx.stateRoot,'operations',opid+'.json');json(operationPath,checkpoint);json(path.join(dir,'checkpoint.json'),checkpoint);
 for(const f of effects){const actual=fs.existsSync(f.path)?fs.readFileSync(f.path,'utf8'):null;if(hash(actual)!==f.before)throw Error('optimistic conflict');fs.mkdirSync(path.dirname(f.path),{recursive:true});fs.writeFileSync(f.path,f.text);}
 const actual=scan(); const valid=cli('validate-records',{records:actual.records}); const links=cli('check-links',{records:actual.records});json(path.join(dir,'validation.json'),{valid,links});
 cli('log-append',{projectsRoot:ctx.projectsRoot,entry:event});const query=cli('log-query',{projectsRoot:ctx.projectsRoot,limit:1000});const found=query.entries?.find(e=>e.operation_id===opid);if(!found||JSON.stringify(found)!==JSON.stringify(event))throw Error('event differs');
 const verify=cli('operation-verify',{...scope,operationPath});assert(label+' verified',verify.status==='verified',verify);
 const complete=cli('operation-complete',{...scope,operationPath});assert(label+' completed',!fs.existsSync(operationPath),complete);
 cli('invalidate-project-index',{vaultRoot:vault});actions.push({label,operation_id:opid,files:checkpoint.files});json(path.join(scratch,'actions.json'),actions);
}
const closure=(id)=>cli('check-closure',{recordId:id,records:scan().records});
function gate(label,id,allowed){const r=closure(id);assert(label,r.allowed===allowed,r);return r;}
async function lifecycle(label,changes,propagate=[]){const map=texts();const now=cli('activity-time',{});for(const[r,v]of changes){let s=state(map.get(r.path)??read(r),r.type,v);s=setmeta(s,'resolved_at',['completed','cancelled','resolved'].includes(v)?now.activity_at:null);map.set(r.path,s);}await commit(label,map,propagate);}
async function closeAll(label){for(const r of[A,B,M,P]){gate(label+' '+r.title,r.id,true);await lifecycle(label+'-'+r.type+'-'+r.title.replaceAll(' ','-'),[[r,'completed']]);}}



const operationPath=path.join(ctx.stateRoot,'operations',JSON.parse(fs.readFileSync(path.join(scratch,'baseline-checkpoint.json'),'utf8')).operation_id+'.json');
const checkpoint=JSON.parse(fs.readFileSync(operationPath,'utf8'));
checkpoint.files=checkpoint.protectedFiles.map(f=>({path:f.path,before:f.sha256,after:f.sha256}));
for(const r of Object.values(checkpoint.baseline.value.records))for(const v of Object.values(r.views))delete v.state;
json(operationPath,checkpoint);json(path.join(scratch,'baseline-checkpoint-corrected.json'),checkpoint);
cli('log-query',{projectsRoot:ctx.projectsRoot,limit:1000});const verified=cli('operation-verify',{...scope,operationPath});assert('final baseline verified',verified.status==='verified',verified);cli('operation-complete',{...scope,operationPath});assert('final baseline committed',!fs.existsSync(operationPath));
const records=scan().records;const validation=cli('validate-records',{records}),links=cli('check-links',{records});
const sources=['skills/daily-tasks/SKILL.md','skills/daily-tasks-records/SKILL.md','skills/daily-tasks-setup/SKILL.md',...['records','operations','cli','verification'].map(n=>'skills/daily-tasks/references/'+n+'.md'),'skills/daily-tasks/assets/blocker.md'];
json(path.join(scratch,'installed-source-hashes.json'),sources.map(p=>({path:path.join(pkg,p),sha256:hash(fs.readFileSync(path.join(pkg,p)))})));cli('--help');
fs.copyFileSync(path.join(scratch,'0002-inspect-records-stdout.json'),path.join(scratch,'initial-records.json'));
fs.writeFileSync(path.join(scratch,'receipt.md'),'# Scenario 5 closure\n\nPASS: all requested scenario 5 conditions exercised against the original project, milestone and two task IDs.\n\n- Task and milestone DoD gate completion; unresolved children gate parent completion.\n- One reciprocal Await approval blocker gates both tasks and parents; reopening it preserves completed tasks.\n- Cancelled prerequisite remains reciprocal and informational; LinkedIn completed while resume was cancelled.\n- Milestone DoD uncheck reopens parents and preserves completed tasks.\n- Task DoD uncheck reopens the task and parents. Explicit not-started takes precedence with retained started_at.\n- Missing and empty version-2 task DoD rejected completion on the same LinkedIn task; original criterion restored.\n- Final state: both tasks, milestone and project completed; shared blocker resolved; identities and criteria preserved.\n\nActual CLI inputs, outputs, exit codes, log queries, checkpoints and before/after files are retained here. The artifact-record-ID log rejection and corrected pending-operation recovery are retained. No regression tests or previous attempts were read. Final reconciliation baseline verified and committed by installed CLI. This receipt is current native workflow evidence, not packaging-based activation proof.\n');
console.log(JSON.stringify({validation,links,assertions:assertions.length}));
