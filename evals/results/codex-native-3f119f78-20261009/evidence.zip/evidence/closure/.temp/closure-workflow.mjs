import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/runtime-guards-full8/codex-home/plugins/cache/daily-tasks-runtime-guards-full8/daily-tasks/0.3.3';
const cliPath=path.join(pkg,'bin/daily-tasks.mjs');
let serial=0; const actions=[], assertions=[];
const json=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(v,null,2));};
const hash=s=>s===null?null:crypto.createHash('sha256').update(s).digest('hex');
function cli(op,input){const n=String(++serial).padStart(4,'0'), stem=path.join(scratch,`${n}-${op}`); if(input)json(stem+'-input.json',input);const args=[cliPath,op,...(input?['--input',stem+'-input.json']:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(stem+'-stdout.json',r.stdout);fs.writeFileSync(stem+'-stderr.txt',r.stderr);json(stem+'-execution.json',{command:process.execPath,args,exitCode:r.status});if(r.status!==0)throw Error(`${op}: ${r.stderr}`);return JSON.parse(r.stdout);}
function assert(name,ok,evidence){assertions.push({name,passed:!!ok,evidence});json(path.join(scratch,'assertions.json'),assertions);if(!ok)throw Error(name);}
const ctx=cli('resolve-context',{vaultRoot:vault});
const scope={vaultRoot:vault,profilePath:ctx.profilePath,stateRoot:ctx.stateRoot};
const scan=()=>cli('inspect-records',{projectsRoot:ctx.projectsRoot});
const initial=scan();json(path.join(scratch,'initial-records.json'),initial);
const record=t=>initial.records.find(r=>r.title===t);
const P=record('Job Search'),M=record('Career materials'),A=record('Update LinkedIn'),B=record('Update resume');
const read=r=>fs.readFileSync(r.path,'utf8'); const texts=()=>new Map([P,M,A,B].map(r=>[r.path,read(r)]));
const state=(s,type,value)=>s.replace(new RegExp(`^${type}-state:.*$`,'m'),`${type}-state: "${value}"`);
const setmeta=(s,key,value)=>{const re=new RegExp(`^${key}:.*\\r?\\n`,'m');s=s.replace(re,'');return value===null?s:s.replace(/\r?\n---\r?\n/,`\n${key}: ${JSON.stringify(value)}\n---\n`);};
const criterion=(s,checked)=>s.replace(/- \[[ x]\] (.*<!-- id:)/g,`- [${checked?'x':' '}] $1`);
function views(map,records){for(const [p,s]of map){let next=s;for(const r of records)next=next.split(/\r?\n/).map(line=>line.includes(`<!-- ref: ${r.id} -->`)&&/\[[ x>\-]\]/.test(line)?line.replace(/\[[ x>\-]\]/,r.state==='completed'?'[x]':r.state==='cancelled'?'[-]':r.state==='in-progress'?'[>]':'[ ]'):line).join('\n');map.set(p,next);}}
async function commit(label,map,changedIds=[]){
 const time=cli('activity-time',{});const opid=cli('new-id').id, eid=cli('new-id').id;
 if(!opid||!eid)throw Error('new-id shape');
 let proposed=scan().records; for(const[p,s]of map){const r=cli('parse-record',{markdown:s,path:p});const i=proposed.findIndex(x=>x.path===p);if(i<0)proposed.push(r);else proposed[i]=r;}
 if(changedIds.length){const reopen=cli('reopen-ancestors',{records:proposed,changedIds});json(path.join(scratch,`${serial}-reopen-proposal.json`),reopen);for(const r of reopen.records){const old=proposed.find(x=>x.id===r.id);if(old&&r.state!==old.state){let s=map.get(r.path)??fs.readFileSync(r.path,'utf8');s=state(s,r.type,r.state);s=setmeta(s,'resolved_at',null);map.set(r.path,s);}}proposed=reopen.records;}
 views(map,proposed);
 const effects=[];const before=[],after=[];const dir=path.join(scratch,'actions',label);fs.mkdirSync(dir,{recursive:true});
 for(const[p,raw]of map){const prev=fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;let next=raw;if(/^type: /m.test(next))next=setmeta(next,'updated_at',time.recorded_at);if(next===prev)continue;const n=String(effects.length+1);fs.writeFileSync(path.join(dir,n+'-before.md'),prev??'ABSENT');fs.writeFileSync(path.join(dir,n+'-after.md'),next);effects.push({path:p,before:hash(prev),after:hash(next),text:next});before.push({path:p,markdown:prev});after.push({path:p,markdown:next});}
 const event={id:eid,operation_id:opid,action:label,record_ids:proposed.filter(r=>effects.some(f=>f.path===r.path)).map(r=>r.id),actor:{kind:'agent',id:'codex'},...time,original_words:'User-authorized scenario5 closure manual edits and synthetic reviewed evidence.',before,after};
 const checkpoint={schemaVersion:2,operation_id:opid,contextBinding:ctx.planningBinding,event,files:effects.map(({text,...f})=>f)};
 const operationPath=path.join(ctx.stateRoot,'operations',opid+'.json');json(operationPath,checkpoint);json(path.join(dir,'checkpoint.json'),checkpoint);
 for(const f of effects){const actual=fs.existsSync(f.path)?fs.readFileSync(f.path,'utf8'):null;if(hash(actual)!==f.before)throw Error('optimistic conflict');fs.mkdirSync(path.dirname(f.path),{recursive:true});fs.writeFileSync(f.path,f.text);}
 const actual=scan(); const valid=cli('validate-records',{records:actual.records}); const links=cli('check-links',{records:actual.records});json(path.join(dir,'validation.json'),{valid,links});
 cli('log-append',{projectsRoot:ctx.projectsRoot,entry:event});const query=cli('log-query',{projectsRoot:ctx.projectsRoot,limit:1000});const found=query.entries?.find(e=>e.operation_id===opid);if(!found||JSON.stringify(found)!==JSON.stringify(event))throw Error('event differs');
 const verify=cli('operation-verify',{...scope,operationPath});assert(label+' verified',verify.status==='verified',verify);
 const complete=cli('operation-complete',{...scope,operationPath});assert(label+' completed',!fs.existsSync(operationPath),complete);
 cli('invalidate-project-index',{vaultRoot:vault});actions.push({label,operation_id:opid,files:checkpoint.files});json(path.join(scratch,'actions.json'),actions);
}
const closure=(id)=>cli('check-closure',{recordId:id,records:scan().records});
function gate(label,id,allowed){const r=closure(id);assert(label,r.allowed===allowed,r);return r;}
async function lifecycle(label,changes,propagate=[]){const map=texts();const now=cli('activity-time',{});for(const[r,v]of changes){let s=state(map.get(r.path)??read(r),r.type,v);s=setmeta(s,'resolved_at',['completed','cancelled','resolved'].includes(v)?now.activity_at:null);map.set(r.path,s);}await commit(label,map,propagate);}
async function closeAll(label){for(const r of[A,B,M,P]){gate(label+' '+r.title,r.id,true);await lifecycle(label+'-'+r.type+'-'+r.title.replaceAll(' ','-'),[[r,'completed']]);}}
json(path.join(scratch,'installed-instructions.json'),{packageRoot:pkg,skills:['daily-tasks','daily-tasks-records','daily-tasks-setup'],references:['records.md','operations.md','cli.md','verification.md'],authorization:'Current user scenario5; exact existing project/milestone/two tasks; sole new Await approval blocker; synthetic reviews authorized.'});
gate('unchecked task DoD prevents completion',A.id,false);
gate('unchecked milestone DoD and unresolved children',M.id,false);
gate('unresolved milestone prevents project completion',P.id,false);
let map=texts(), original=map.get(A.path);map.set(A.path,original.replace(/## Definition of Done[\s\S]*?(?=## Inputs)/,''));await commit('task-dod-missing',map);gate('missing version2 task DoD prevents completion',A.id,false);
map=texts();map.set(A.path,original.replace(/(## Definition of Done)[\s\S]*?(?=## Inputs)/,'$1\n\n'));await commit('task-dod-empty',map);gate('empty version2 task DoD prevents completion',A.id,false);
map=texts();map.set(A.path,original);await commit('restore-original-task-criterion',map);
const number=cli('next-record-number',{projectsRoot:ctx.projectsRoot,type:'blocker',parentId:P.id});assert('blocker number available',number.number!==null,number);
const blockerId=cli('new-id').id;const blocker={id:blockerId,type:'blocker',path:path.join(path.dirname(P.path),'blockers',`b${number.number}-await-approval.md`)};
const t=cli('activity-time',{});
map=texts();for(const r of[A,B])map.set(r.path,map.get(r.path)+`\n## Blocked by\n\n- [[../blockers/b${number.number}-await-approval|Await approval]] <!-- ref: ${blockerId} -->\n`);
map.set(blocker.path,`---\nid: "${blockerId}"\ntype: blocker\nrecord_version: 2\ntitle: "Await approval"\nblocker-state: open\nowner: "${A.owner}"\nproject_id: "${P.id}"\ncreated_at: "${t.recorded_at}"\nupdated_at: "${t.recorded_at}"\n---\n# Await approval\n\nSynthetic external reviewer approval is pending for both career artifacts.\n\n## Resolution condition\nExplicit synthetic reviewer approval of both linked artifacts.\n\n## Resolution evidence\nPending.\n\n## Blocks\n- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: ${A.id} -->\n- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: ${B.id} -->\n`);await commit('shared-blocker-created',map);
map=texts();for(const[r,file,content]of[[A,'linkedin-headline.md','Software engineer | Building dependable products and clear developer tools'],[B,'resume-summary.md','Software engineer experienced in building dependable products, improving developer workflows, and communicating technical decisions clearly.']]){
 const output=path.join(path.dirname(M.path),'outputs',file);map.set(output,`# ${r.title}: synthetic reviewed artifact\n\n${content}\n\nReview: Codex checked this synthetic draft against the existing requirement under user-authorized acceptance testing. It is saved locally and suitable for this synthetic scenario.\n`);
 let s=criterion(map.get(r.path),true).replace('Work has not started; no artifact has been produced or reviewed.',`Synthetic draft produced and reviewed against the existing criterion. [Reviewed artifact](outputs/${file}).`);s=s.replace('Link the actual artifact here and from the milestone after review.',`[Reviewed artifact](outputs/${file}). Review evidence is included in the artifact.`);map.set(r.path,s);
}map.set(M.path,map.get(M.path)+'\n## Reviewed artifacts\n\n- [Reviewed headline](outputs/linkedin-headline.md)\n- [Reviewed summary](outputs/resume-summary.md)\n');await commit('reviewed-task-evidence',map);
gate('shared open blocker gates LinkedIn despite satisfied DoD',A.id,false);gate('shared open blocker gates resume despite satisfied DoD',B.id,false);
map=texts();map.set(M.path,criterion(map.get(M.path),true));await commit('milestone-evidence-satisfied',map);gate('satisfied milestone DoD still blocked by unresolved children',M.id,false);
await lifecycle('approval-resolved',[[blocker,'resolved']]);
await lifecycle('resume-cancelled-for-informational-dependency',[[B,'cancelled']]);
map=texts();map.set(A.path,map.get(A.path)+`\n## Depends on\n- [[t2-update-resume|Update resume — prerequisite cancelled]] <!-- ref: ${B.id} -->\n`);map.set(B.path,map.get(B.path)+`\n## Required by\n- [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${A.id} -->\n`);await commit('cancelled-dependency-linked',map);
gate('cancelled dependency does not prevent task completion',A.id,true);await lifecycle('linkedin-completed-with-cancelled-dependency',[[A,'completed']]);
await lifecycle('resume-explicitly-reopened-not-started',[[B,'not-started']],[B.id]);
await closeAll('first-eligible-closure');
await lifecycle('shared-blocker-reopened',[[blocker,'open']],[blocker.id]);
let current=scan().records;assert('blocker reopening preserves completed tasks and reopens both parents',[A,B].every(r=>current.find(x=>x.id===r.id).state==='completed')&&[M,P].every(r=>current.find(x=>x.id===r.id).state!=='completed'),current);
gate('open shared blocker gates completed task closure recheck',A.id,false);gate('open shared blocker gates milestone closure',M.id,false);gate('open shared blocker gates project closure',P.id,false);
await lifecycle('shared-blocker-resolved-again',[[blocker,'resolved']]);await closeAll('after-blocker-closure');
map=texts();map.set(M.path,criterion(map.get(M.path),false));await commit('milestone-dod-unchecked',map,[M.id]);current=scan().records;assert('milestone DoD reopening preserves completed tasks',[A,B].every(r=>current.find(x=>x.id===r.id).state==='completed')&&[M,P].every(r=>current.find(x=>x.id===r.id).state!=='completed'),current);gate('milestone DoD gates closure with completed children',M.id,false);
map=texts();map.set(M.path,criterion(map.get(M.path),true));await commit('milestone-dod-restored',map);await closeAll('after-milestone-closure');
map=texts();map.set(A.path,criterion(map.get(A.path),false));await commit('task-dod-unchecked',map,[A.id]);current=scan().records;assert('task DoD uncheck reopens task and parents only',current.find(x=>x.id===A.id).state==='not-started'&&current.find(x=>x.id===B.id).state==='completed'&&[M,P].every(r=>current.find(x=>x.id===r.id).state!=='completed'),current);
map=texts();map.set(A.path,criterion(map.get(A.path),true));await commit('task-dod-restored',map);await closeAll('after-task-dod-closure');
// Retain an old start instant to prove explicit not-started beats the fallback.
map=texts();map.set(A.path,setmeta(map.get(A.path),'started_at',cli('activity-time',{}).activity_at));await commit('synthetic-task-start-history',map);
await lifecycle('linkedin-explicit-reopen-not-started',[[A,'not-started']],[A.id]);current=scan().records;assert('explicit not-started overrides retained started_at',current.find(x=>x.id===A.id).state==='not-started'&&!!current.find(x=>x.id===A.id).started_at&&[M,P].every(r=>current.find(x=>x.id===r.id).state!=='completed'),current);await closeAll('final-eligible-closure');
const final=scan();json(path.join(scratch,'final-records.json'),final);cli('log-query',{projectsRoot:ctx.projectsRoot,limit:1000});assert('exact original work identities plus sole new blocker',final.records.length===5&&[P,M,A,B,blocker].every(r=>final.records.some(x=>x.id===r.id)),final.records.map(r=>({id:r.id,state:r.state})));
fs.writeFileSync(path.join(scratch,'receipt.md'),`# Scenario 5 closure\n\nAll ${assertions.length} observed assertions passed. The installed skills authored the current workflow; all CLI inputs/results, log queries, operation checkpoints and exact before/after Markdown are retained in this directory. This is current native host workflow evidence, not packaging activation proof.\n\nFinal state: both original tasks, milestone and project completed; the sole shared Await approval blocker resolved. Original criterion identities preserved.\n`);
console.log(JSON.stringify({passed:assertions.length,actions:actions.length,receipt:path.join(scratch,'receipt.md')}));
