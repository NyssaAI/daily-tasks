import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const caseRoot=path.resolve('.temp/native-acceptance/release-034-full8/cases/acceptance');
const evidence=path.join(caseRoot,'.temp','accepted-batch');fs.mkdirSync(evidence,{recursive:true});
const cli=path.resolve('.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs');
let n=0;const runTag=String(Date.now());
function save(name,value){fs.writeFileSync(path.join(evidence,name),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');}
function call(op,input){const label=runTag+'-'+String(++n).padStart(2,'0')+'-'+op;const args=[cli,op];if(input!==undefined){save(label+'.input.json',input);args.push('--input',path.join(evidence,label+'.input.json'));}const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(label+'.result.json',r.stdout||r.stderr);fs.appendFileSync(path.join(evidence,'actions.jsonl'),JSON.stringify({args,exit:r.status,stderr:r.stderr})+'\n');if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const hash=x=>createHash('sha256').update(x).digest('hex');
const c=call('resolve-context',{vaultRoot:path.join(caseRoot,'vault')});
const ctx={vaultRoot:c.vaultRoot,profilePath:c.profilePath,stateRoot:c.stateRoot,configRoot:c.configRoot};
const before=call('inspect-records',{projectsRoot:c.projectsRoot});
const logBefore=call('log-query',{projectsRoot:c.projectsRoot,limit:1000});
if(before.records.length!==0||logBefore.nextOffset!==null)throw Error('Unexpected existing work or unqueried history');
const ops=path.join(c.stateRoot,'operations');if(fs.existsSync(ops)&&fs.readdirSync(ops).length)throw Error('Pending operation needs recovery');
const note=path.join(c.dailyPlansRoot,'2026-10-09.md'),noteBefore=fs.readFileSync(note);save('manual-plan.before.md',noteBefore.toString());
const queuePath=path.join(c.stateRoot,'candidates.json'),queueBefore=fs.readFileSync(queuePath,'utf8');save('candidates.before.json',queueBefore);
const time=call('activity-time',{});
const ids=[];for(let i=0;i<9;i++){const r=call('new-id');ids.push(typeof r==='string'?r:r.id);}
if(ids.some(x=>!x))throw Error('Missing generated identity');
const [p,m,t1,t2,d1,d2,dm,operation,eventId]=ids;
const project=path.join(c.projectsRoot,'job-search'),milestone=path.join(project,'m1-career-materials');
const pp=path.join(project,'project-index.md'),mp=path.join(milestone,'m1-career-materials.md'),tp1=path.join(milestone,'t1-update-linkedin.md'),tp2=path.join(milestone,'t2-update-resume.md');
function fm(id,type,title,parent=''){return `---\nid: ${id}\ntype: ${type}\nrecord_version: 2\ntitle: "${title}"\n${type}-state: not-started\nowner: "synthetic@example.test"\n${parent}created_at: "${time.recorded_at}"\nupdated_at: "${time.recorded_at}"\n---\n`;}
const projectText=fm(p,'project','Job Search')+`# Job Search\n\nPrepare career materials.\n\n## Project Summary\n\n| Milestone | Task | Description | Owner | Due Date |\n| --- | --- | --- | --- | --- |\n| [ ] [[m1-career-materials/m1-career-materials\\|Career materials]] <!-- ref: ${m} --> | | Both reviewed artifacts linked. | synthetic@example.test | — |\n| | [ ] [[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]] <!-- ref: ${t1} --> | Update headline. | synthetic@example.test | — |\n| | [ ] [[m1-career-materials/t2-update-resume\\|Update resume]] <!-- ref: ${t2} --> | Update summary. | synthetic@example.test | — |\n`;
const milestoneText=fm(m,'milestone','Career materials',`project_id: "${p}"\n`)+`# M1 — Career materials\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${p} -->\n\n## Outcome\n\nUpdate LinkedIn and resume career materials.\n\n## Definition of Done\n\n- [ ] Both reviewed artifacts linked. <!-- id: ${dm} -->\n\n## Tasks\n\n- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${t1} -->\n- [ ] [[t2-update-resume|Update resume]] <!-- ref: ${t2} -->\n`;
function task(id,title,num,requirement,dod,did){return fm(id,'task',title,`project_id: "${p}"\nmilestone_id: "${m}"\n`)+`# M1-T${num} — ${title}\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${m} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${p} -->\n\n## Requirements\n\n${requirement}\n\n## Definition of Done\n\n- [ ] ${dod} <!-- id: ${did} -->\n\n## Inputs\n\nNo input artifact supplied yet. Local working inputs belong in [inputs](inputs/).\n\n## Output and delivery\n\nLink the reviewed artifact in this task's Result. Local artifacts belong in [outputs](outputs/).\n\n## Verification\n\nRecord explicit review and link its artifact; leave the criterion unchecked until reviewed.\n\n## Result\n\nNot started.\n`;}
const files=[{path:pp,text:projectText},{path:mp,text:milestoneText},{path:tp1,text:task(t1,'Update LinkedIn',1,'Update headline.','Reviewed headline.',d1)},{path:tp2,text:task(t2,'Update resume',2,'Update summary.','Reviewed summary.',d2)}];
const parsed=files.map(f=>call('parse-record',{path:f.path,markdown:f.text}));save('proposed-parsed.json',parsed);
const original_words='I explicitly accept this batch: create Job Search project, M1 Career materials milestone, Update LinkedIn task (requirement: update headline; DoD: reviewed headline), and Update resume task (requirement: update summary; DoD: reviewed summary). Milestone DoD: both reviewed artifacts linked. Owner synthetic@example.test; all accepted work not started and unchecked. Accept no other work.';
const event={id:eventId,operation_id:operation,action:'batch.accepted',record_ids:[p,m,t1,t2],actor:{kind:'person',id:'synthetic@example.test'},...time,original_words,before:{records:[]},after:{acceptance_source:'Current explicit user batch acceptance',records:files.map((f,i)=>({id:[p,m,t1,t2][i],type:['project','milestone','task','task'][i],path:f.path,...(i?{project_id:p}:{}),...(i>1?{milestone_id:m}:{}),state:'not-started'}))}};
const checkpoint={schemaVersion:2,operation_id:operation,contextBinding:c.planningBinding,event,files:files.map(f=>({path:f.path,before:null,after:hash(f.text)})),protectedFiles:[{path:note,sha256:hash(noteBefore)}]};
fs.mkdirSync(ops,{recursive:true});const operationPath=path.join(ops,operation+'.json');fs.writeFileSync(operationPath,JSON.stringify(checkpoint,null,2)+'\n');save('checkpoint.before-write.json',checkpoint);
fs.mkdirSync(path.join(milestone,'inputs'),{recursive:true});fs.mkdirSync(path.join(milestone,'outputs'),{recursive:true});
for(const [i,f] of files.entries()){if(i>0){const allocation=call('next-record-number',{projectsRoot:c.projectsRoot,type:i===1?'milestone':'task',parentId:i===1?p:m});if(allocation.number!==(i===3?2:1))throw Error('Unexpected allocation');}if(fs.existsSync(f.path))throw Error('Destination appeared');fs.writeFileSync(f.path,f.text,{flag:'wx'});save(path.basename(f.path)+'.after.md',f.text);fs.appendFileSync(path.join(evidence,'actions.jsonl'),JSON.stringify({action:'write-accepted-markdown',path:f.path,before:null,after:hash(f.text)})+'\n');call('invalidate-project-index',{vaultRoot:c.vaultRoot});}
call('invalidate-project-index',{vaultRoot:c.vaultRoot});
const after=call('inspect-records',{projectsRoot:c.projectsRoot});
save('actual-records.after.json',after);
call('validate-records',{records:after.records});call('check-links',{records:after.records});call('inspect-navigation',{projectsRoot:c.projectsRoot});
if(event.activity_at!==time.activity_at||event.recorded_at!==time.recorded_at)throw Error('Timestamp mismatch');
call('log-append',{projectsRoot:c.projectsRoot,entry:event});
const logs=call('log-query',{projectsRoot:c.projectsRoot,limit:1000});
const actual=logs.entries.find(e=>e.id===eventId);if(JSON.stringify(actual)!==JSON.stringify(event))throw Error('Exact event mismatch');
for(const id of [p,m,t1,t2])call('log-query',{projectsRoot:c.projectsRoot,recordId:id,limit:1000});
const verified=call('operation-verify',{...ctx,operationPath});if(verified.status!=='verified')throw Error(JSON.stringify(verified));
const complete=call('operation-complete',{...ctx,operationPath});save('completion.json',complete);
const queue=JSON.parse(queueBefore);for(const candidate of queue.candidates){if(candidate.id==='candidate-linkedin'||candidate.id==='candidate-resume'){candidate.accepted=true;candidate.disposition='accepted';candidate.acceptanceSource='Current explicit user batch acceptance';candidate.recordId=candidate.id==='candidate-linkedin'?t1:t2;candidate.operationId=operation;candidate.acceptedAt=time.recorded_at;candidate.parent={projectId:p,milestoneId:m};}}fs.writeFileSync(queuePath,JSON.stringify(queue,null,2)+'\n');save('candidates.after.json',queue);
const checkinPath=path.join(c.stateRoot,'checkin.json');if(fs.existsSync(checkinPath)){const progress=JSON.parse(fs.readFileSync(checkinPath,'utf8'));progress.unresolvedCandidateIds=(progress.unresolvedCandidateIds??[]).filter(id=>!['candidate-linkedin','candidate-resume'].includes(id));progress.nextStep='Accepted batch recorded and verified. Manual daily note preserved; no daily selections requested.';fs.writeFileSync(checkinPath,JSON.stringify(progress,null,2)+'\n');}
save('manual-plan.after.md',fs.readFileSync(note,'utf8'));
save('verification.json',{recordsBefore:before.records.length,recordsAfter:after.records.length,acceptedRecordIds:[p,m,t1,t2],noAcceptanceBefore:!logBefore.entries.some(e=>e.action.includes('accept')),exactEventMatches:true,manualCheckboxPreserved:noteBefore.equals(fs.readFileSync(note)),operationCheckpointCleared:!fs.existsSync(operationPath),logBeforeCount:logBefore.total,logAfterCount:logs.total,acceptanceTime:time.recorded_at});
console.log(JSON.stringify({evidence,verified,complete}));
