---
id: 01a121f1-aced-7b60-b8d6-a9728bfaef2c
type: task
record_version: 2
title: "Update LinkedIn"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a121f1-ac98-7991-933c-384e09256d7e"
milestone_id: "01a121f1-acc2-7bde-8b58-686637bfdc9d"
created_at: "2026-10-09T18:34:08.875Z"
updated_at: "2026-10-09T18:34:08.875Z"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a121f1-acc2-7bde-8b58-686637bfdc9d -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a121f1-ac98-7991-933c-384e09256d7e -->

## Requirements

Update headline.

## Definition of Done

- [ ] Reviewed headline. <!-- id: 01a121f1-ad45-74ee-a47c-36d913f9cab1 -->

## Inputs

No input artifact supplied yet. Local working inputs belong in [inputs](inputs/).

## Output and delivery

Link the reviewed artifact in this task's Result. Local artifacts belong in [outputs](outputs/).

## Verification

Record explicit review and link its artifact; leave the criterion unchecked until reviewed.

## Result

Not started.
