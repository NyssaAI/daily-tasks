---
id: 01a121f1-acc2-7bde-8b58-686637bfdc9d
type: milestone
record_version: 2
title: "Career materials"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a121f1-ac98-7991-933c-384e09256d7e"
created_at: "2026-10-09T18:34:08.875Z"
updated_at: "2026-10-09T18:34:08.875Z"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a121f1-ac98-7991-933c-384e09256d7e -->

## Outcome

Update LinkedIn and resume career materials.

## Definition of Done

- [ ] Both reviewed artifacts linked. <!-- id: 01a121f1-ada7-7625-aeca-11a3927cbfc8 -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a121f1-aced-7b60-b8d6-a9728bfaef2c -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a121f1-ad18-798f-bf59-4d72d7a37b4c -->
