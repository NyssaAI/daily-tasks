---
id: 01a121f1-ac98-7991-933c-384e09256d7e
type: project
record_version: 2
title: "Job Search"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T18:34:08.875Z"
updated_at: "2026-10-09T18:34:08.875Z"
---
# Job Search

Prepare career materials.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a121f1-acc2-7bde-8b58-686637bfdc9d --> | | Both reviewed artifacts linked. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a121f1-aced-7b60-b8d6-a9728bfaef2c --> | Update headline. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a121f1-ad18-798f-bf59-4d72d7a37b4c --> | Update summary. | synthetic@example.test | — |
