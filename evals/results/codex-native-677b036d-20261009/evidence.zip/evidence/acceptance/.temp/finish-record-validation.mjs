import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const base=path.resolve('.temp/native-acceptance/release-034-full8/cases/acceptance');
const out=path.join(base,'.temp','accepted-batch','validation-finish');fs.mkdirSync(out,{recursive:true});
const cli=path.resolve('.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs');let n=0;
const hash=x=>createHash('sha256').update(x).digest('hex');
function save(name,value){fs.writeFileSync(path.join(out,name),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');}
function call(op,input){const key=String(++n).padStart(2,'0')+'-'+op;const args=[cli,op];if(input!==undefined){save(key+'.input.json',input);args.push('--input',path.join(out,key+'.input.json'));}const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(key+'.result.json',r.stdout||r.stderr);fs.appendFileSync(path.join(out,'actions.jsonl'),JSON.stringify({args,status:r.status})+'\n');if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const c=call('resolve-context',{vaultRoot:path.join(base,'vault')});const context={vaultRoot:c.vaultRoot,profilePath:c.profilePath,stateRoot:c.stateRoot};
const before=call('inspect-records',{projectsRoot:c.projectsRoot});
const id=call('new-id').id,eventId=call('new-id').id,time=call('activity-time',{});
const effects=before.records.filter(r=>r.type==='task').map(r=>{const text=fs.readFileSync(r.path,'utf8');save(path.basename(r.path)+'.before.md',text);return {path:r.path,beforeText:text,afterText:text.replace('[inputs](inputs/)','`inputs/`').replace('[outputs](outputs/)','`outputs/`')};});
const finalTexts=new Map(before.records.map(r=>[r.path,effects.find(f=>f.path===r.path)?.afterText??fs.readFileSync(r.path,'utf8')]));
const baseline={schemaVersion:1,records:{}};
for(const r of before.records){const fields={state:r.state,owner:r.owner};baseline.records[r.id]={canonical:fields,views:{}};for(const view of before.records){if(view.projections.some(x=>x.id===r.id)){baseline.records[r.id].views[view.path]={hash:hash(finalTexts.get(view.path)),checked:false,state:'not-started'};}}}
const baselinePath=path.join(c.stateRoot,'reconciliation.json');const beforeText=fs.existsSync(baselinePath)?fs.readFileSync(baselinePath,'utf8'):null;
const event={id:eventId,operation_id:id,action:'records.navigation-corrected',record_ids:effects.map(f=>before.records.find(r=>r.path===f.path).id),actor:{kind:'agent',id:'codex'},...time,before:{directoryLinks:['inputs/','outputs/']},after:{directoryPathsAsText:true,reason:'Navigation validation requires links to regular files; empty holding directories are described as paths.'}};
const note=path.join(c.dailyPlansRoot,'2026-10-09.md');
const op={schemaVersion:2,operation_id:id,contextBinding:c.planningBinding,event,files:effects.map(f=>({path:f.path,before:hash(f.beforeText),after:hash(f.afterText)})),protectedFiles:[{path:note,sha256:hash(fs.readFileSync(note))}],baseline:{beforeHash:beforeText===null?null:hash(beforeText),...(beforeText===null?{}:{beforeText}),value:baseline}};
const operationPath=path.join(c.stateRoot,'operations',id+'.json');fs.writeFileSync(operationPath,JSON.stringify(op,null,2)+'\n');save('checkpoint.json',op);
for(const f of effects){if(hash(fs.readFileSync(f.path))!==hash(f.beforeText))throw Error('Source changed');fs.writeFileSync(f.path,f.afterText);save(path.basename(f.path)+'.after.md',f.afterText);fs.appendFileSync(path.join(out,'actions.jsonl'),JSON.stringify({action:'correct-directory-link',path:f.path})+'\n');}
call('invalidate-project-index',{vaultRoot:c.vaultRoot});
const after=call('inspect-records',{projectsRoot:c.projectsRoot});
for(const operation of ['validate-records','check-links']){const r=call(operation,{records:after.records});if(r.diagnostics.length)throw Error(JSON.stringify(r));}
const nav=call('inspect-navigation',{projectsRoot:c.projectsRoot});if(nav.diagnostics.length)throw Error(JSON.stringify(nav));
call('log-append',{projectsRoot:c.projectsRoot,entry:event});call('log-query',{projectsRoot:c.projectsRoot,limit:1000});
const verified=call('operation-verify',{...context,operationPath});if(verified.status!=='verified')throw Error(JSON.stringify(verified));
const complete=call('operation-complete',{...context,operationPath});if(complete.status!=='completed')throw Error(JSON.stringify(complete));
const logs=call('log-query',{projectsRoot:c.projectsRoot,action:'batch.accepted',limit:1000});
if(logs.total!==1)throw Error('Acceptance event count differs');
save('final-verification.json',{recordCount:after.records.length,allNotStarted:after.records.every(r=>r.state==='not-started'),allOwnedByRequestedOwner:after.records.every(r=>r.owner==='synthetic@example.test'),allCriteriaUnchecked:after.records.every(r=>r.criteria.every(x=>!x.checked)),allProjectionsUnchecked:after.records.every(r=>r.projections.every(x=>!x.checked)),singleAcceptanceEvent:logs.total===1,manualNoteUnchanged:hash(fs.readFileSync(note))===op.protectedFiles[0].sha256,baselineVerified:true,validationDiagnostics:[],navigationDiagnostics:[]});
console.log(JSON.stringify(complete));
