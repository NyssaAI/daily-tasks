import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), out=path.join(root,'.temp');
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs';
function run(label,operation,input){
 const file=path.join(out,label+'.input.json');fs.writeFileSync(file,JSON.stringify(input,null,2));
 const r=spawnSync(process.execPath,[cli,operation,'--input',file],{encoding:'utf8'});
 fs.writeFileSync(path.join(out,label+'.result.json'),r.stdout||r.stderr);
 fs.appendFileSync(path.join(out,'actions.jsonl'),JSON.stringify({operation,inputPath:file,exit:r.status,stderr:r.stderr})+'\n');
 if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);
}
const vault=path.join(root,'vault');
const note=path.join(vault,'Daily','2026-10-09.md');
fs.copyFileSync(note,path.join(out,'plan.before.md'));
const context=run('context','resolve-context',{vaultRoot:vault});
fs.writeFileSync(path.join(out,'context-retained.json'),JSON.stringify(context,null,2));
const records=run('records-before','inspect-records',{projectsRoot:context.projectsRoot});
run('log-before','log-query',{projectsRoot:context.projectsRoot,limit:1000});
run('checkboxes','parse-checklist',{markdown:fs.readFileSync(note,'utf8')});
run('navigation','inspect-navigation',{projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot});
run('prepare','planning-prepare',{vaultRoot:vault});
const state=context.stateRoot;
const candidates={schemaVersion:1,candidates:[
 {id:'candidate-linkedin',title:'Update LinkedIn',kind:'idea',owner:context.user?.email??'synthetic@example.test',parent:null,target_date:null,sourceKeys:['request:acceptance:linkedin'],sources:[{reference:'Current user request',text:'I might want to update LinkedIn and resume sometime.'}],disposition:'unresolved',accepted:false,unresolvedFacts:['Project/milestone and scope are unspecified; no acceptance.']},
 {id:'candidate-resume',title:'Update resume',kind:'idea',owner:context.user?.email??'synthetic@example.test',parent:null,target_date:null,sourceKeys:['request:acceptance:resume','daily:2026-10-09.md:maybe-improve-my-resume'],sources:[{reference:'Current user request',text:'I might want to update LinkedIn and resume sometime.'},{reference:'Daily/2026-10-09.md',text:'- [ ] Maybe improve my resume'}],disposition:'unresolved',accepted:false,unresolvedFacts:['Project/milestone and scope are unspecified; no acceptance.']}
]};
fs.writeFileSync(path.join(state,'candidates.json'),JSON.stringify(candidates,null,2)+'\n');
fs.writeFileSync(path.join(state,'checkin.json'),JSON.stringify({schemaVersion:1,localDay:context.localDate,planningBinding:context.planningBinding,pendingOperationIds:[],unresolvedCandidateIds:candidates.candidates.map(c=>c.id),unresolvedConflictIds:[],processedSources:[{source:'Current user request',version:'current'},{source:'Daily/2026-10-09.md',content:fs.readFileSync(note,'utf8')}],nextStep:'Await explicit candidate acceptance; preserve manual note. No accepted work created.'},null,2)+'\n');
run('records-after','inspect-records',{projectsRoot:context.projectsRoot});
run('log-after','log-query',{projectsRoot:context.projectsRoot,limit:1000});
fs.copyFileSync(note,path.join(out,'plan.after.md'));
fs.copyFileSync(path.join(state,'candidates.json'),path.join(out,'candidates.after.json'));
fs.writeFileSync(path.join(out,'verification.json'),JSON.stringify({manualPlanUnchanged:fs.readFileSync(path.join(out,'plan.before.md')).equals(fs.readFileSync(note)),acceptedWorkCreated:0,candidateCount:2,resumeSourceCount:2,context},null,2));
