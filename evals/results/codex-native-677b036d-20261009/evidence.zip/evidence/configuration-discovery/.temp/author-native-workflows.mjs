import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd();
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs';
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
for(const name of ['01-common-root','02-no-profile','03-explicit-legacy','04-vault-only-legacy']) {
 const dir=path.join(root,name), evidence=path.join(dir,'.temp','native-workflow');fs.mkdirSync(evidence,{recursive:true});let seq=0;
 const call=(op,input)=>{const prefix=path.join(evidence,`${String(++seq).padStart(2,'0')}-${op}`);const args=[cli,op];if(input!==undefined){fs.writeFileSync(prefix+'.input.json',JSON.stringify(input,null,2));args.push('--input',prefix+'.input.json');}const r=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8'});fs.writeFileSync(prefix+'.result.json',r.stdout);fs.writeFileSync(prefix+'.execution.json',JSON.stringify({cwd:dir,args,exitCode:r.status,stderr:r.stderr},null,2));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);};
 const vault=path.join(dir,'vault'),projects=path.join(vault,'Projects');
 let profilePath=name.startsWith('01')||name.startsWith('02')?path.join(dir,'common','.nyssaai','daily-tasks','profile.json'):path.join(vault,'.nyssa','daily-tasks','profile.json');
 const existing=fs.existsSync(profilePath)?fs.readFileSync(profilePath):null;
 if(existing)fs.writeFileSync(path.join(evidence,'profile.before.json'),existing);
 if(!existing){const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};const valid=call('validate-profile',profile);if(!valid.valid)throw Error(JSON.stringify(valid));fs.mkdirSync(path.dirname(profilePath),{recursive:true});fs.writeFileSync(profilePath,JSON.stringify(profile,null,2)+'\n');}
 const discovery={vaultRoot:vault,homeRoot:path.join(dir,'synthetic-home')};if(!name.startsWith('04'))discovery.profilePath=profilePath;
 const context=call('resolve-context',discovery);fs.writeFileSync(path.join(evidence,'resolved-context.json'),JSON.stringify(context,null,2));
 const inventory=call('inspect-records',{projectsRoot:projects});fs.writeFileSync(path.join(evidence,'inventory.before.json'),JSON.stringify(inventory,null,2));
 const projectPath=path.join(projects,'job-search','project-index.md'),before=fs.readFileSync(projectPath,'utf8');fs.writeFileSync(path.join(evidence,'project.before.md'),before);
 const projectId=before.match(/^id: "?([^"\r\n]+)"?/m)[1];const number=call('next-record-number',{projectsRoot:projects,type:'milestone',parentId:projectId});if(number.number!==1)throw Error(JSON.stringify(number));
 const id=call('new-id'),criterion=call('new-id'),operation=call('new-id'),eventId=call('new-id');
 fs.writeFileSync(path.join(evidence,'ids.json'),JSON.stringify({id,criterion,operation,eventId},null,2));
}
