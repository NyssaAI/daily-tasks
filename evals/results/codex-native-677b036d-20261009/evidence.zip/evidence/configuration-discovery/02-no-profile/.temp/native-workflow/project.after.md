---
id: "01a12125-7f6f-70d4-8bdd-d891202c26af"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:08.061Z"
updated_at: "2026-10-09T18:32:41.275Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — update LinkedIn and resume]] <!-- ref: 01a121ef-9b5c-7822-825d-74120dcb7ab7 -->
