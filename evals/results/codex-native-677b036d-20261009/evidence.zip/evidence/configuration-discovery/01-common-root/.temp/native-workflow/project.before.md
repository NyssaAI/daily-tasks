---
id: "01a12125-7ba5-7700-98fd-8e9d0f32ebe4"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:07.099Z"
updated_at: "2026-10-09T14:51:07.099Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

No milestones yet.
