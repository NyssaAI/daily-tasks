---
id: 01a121ef-d3c1-7b44-bd77-1ce5df0f131b
type: task
record_version: 2
title: "Routing note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
milestone_id: "01a121ef-d397-7fef-be21-2a2665aa8be5"
created_at: "2026-10-09T18:32:07.788Z"
updated_at: "2026-10-09T18:32:07.788Z"
---
# M1-T1 — Routing note

**Milestone:** [[m1-update-linkedin-and-resume|update LinkedIn and resume]] <!-- ref: 01a121ef-d397-7fef-be21-2a2665aa8be5 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Requirements

local routing test note

## Definition of Done

- [ ] reviewed routing note <!-- id: 01a121ef-d418-728d-a2d2-484fb29c9241 -->
