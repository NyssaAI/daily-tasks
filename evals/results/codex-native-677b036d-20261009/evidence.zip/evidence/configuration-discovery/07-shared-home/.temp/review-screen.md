Open projects: 1          Open tasks: 1          Late tasks: 0

Today: 2026.10.09 — America/Chicago

Already selected: none.

Available tasks:

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | update LinkedIn and resume | Routing note | — |

Reply by row number and symbol or description:

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled

Decision: select row 1 today, explicitly requested by user.
