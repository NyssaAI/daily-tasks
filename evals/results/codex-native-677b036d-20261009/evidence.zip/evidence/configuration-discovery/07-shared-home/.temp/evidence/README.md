# Selected B operation evidence

Shared personal preferences were resolved from synthetic-home/.nyssaai/daily-tasks/profile.json. Operating state and outputs were resolved independently in vault-b. Configuration was not changed.

The foreign review maps row 1 to vault A's Routing note. Its project identity differs from B's Job Search identity. No completion was applied. Only the explicitly authorized M1 was created, with an unchecked reviewed career materials criterion and zero tasks.

The exact supplied resume and screen were read. Only the referenced operation, review mapping and inventory were read from A for routing validation. No A writes or recovery took place. The saved A operation remains suspended for an A session.

CLI entry: D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs

Actual calls used `node ENTRY OPERATION --input ABSOLUTE_PATH_TO_INPUT` with the input and result files below. Each successful call exited 0. The two foreign routing calls exited 1; their errors and exit results are retained.

| Operation | Input | Result |
| --- | --- | --- |
| resolve-context | context-input.json | context-result.json |
| inspect-records | inspect-input.json | inspect-result.json, inspect-after-result.json |
| next-record-number | number-input.json | number-result.json |
| activity-time | time-input.json | time-result.json |
| log-query | logbefore-input.json | logbefore-result.json, log-after-result.json |
| invalidate-project-index | invalidate-input.json | invalidate-result.json |
| log-append | log-input.json | log-append-result.json |
| operation-verify | verify-input.json | verify-result.json |
| operation-verify | foreign-operation-input.json | foreign-operation-result.json, foreign-operation-exit.txt |
| planning-review | foreign-review-input.json | foreign-review-result.json, foreign-review-exit.txt |
| check-links | links-input.json | links-result.json |
| operation-complete | verify-input.json | complete-result.json |

`node --version` returned v24.19.0. `node ENTRY --help` returned version 0.3.4 and available operations. Four `node ENTRY new-id` calls returned id-1.json through id-4.json.

Exact project before/after and milestone after content are retained in this directory. The milestone did not exist before. operation.json retains the completed checkpoint and exact before/after SHA256 values; the live checkpoint was cleared by operation-complete after verification. The project before bytes are also retained in the project's .temp directory.

The decision was appended and queried using the CLI only; no raw decision log was read, hashed or edited. Foreign routing copies are evidence, not enrolled B state. Record and link diagnostics were empty. Completion returned status completed. No daily plan, review mapping, A checkpoint, or A baseline was imported into B.
