---
id: "01a12125-8905-73e7-bc52-568640c30a2f"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:10.518Z"
updated_at: "2026-10-09T18:32:42.400Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — update LinkedIn and resume]] <!-- ref: 01a121ef-9de8-7894-921b-4544d2cbb8d6 -->
