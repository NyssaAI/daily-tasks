---
id: "01a12125-8905-73e7-bc52-568640c30a2f"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:10.518Z"
updated_at: "2026-10-09T14:51:10.518Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

No milestones yet.
