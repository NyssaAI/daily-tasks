import path from 'node:path';
import fs from 'node:fs';
import {caseRoot,write,read,cli,id,prepare,event,transaction,persist,log,complete,snapshot,clocks} from './host-tools.mjs';
const vault=path.join(caseRoot,'vault');snapshot('initial',vault);
let p=prepare(vault,clocks.mon), pr=p.context.projectsRoot, dir=path.join(pr,'job-search/m1-career-materials'), project=p.inventory.projects[0].id,milestone=p.inventory.milestones[0].id;
const data={A:{...p.inventory.tasks[0]},B:{...p.inventory.tasks[1]}};
let files=[];
for(let [key,title,req,dod,assignee] of [['C','Review draft','inspect draft','recorded review','Reviewer'],['D','Past work','past result','reviewed result'],['E','Abandoned work','draft work','reviewed result'],['F','Deselected work','optional draft','reviewed draft']]){
let num=cli('next-record-number',{projectsRoot:pr,type:'task',parentId:milestone}).number;
// Each accepted task is persisted before the next allocation.
let uuid=id(), criterion=id(), slug=`t${num}-${title.toLowerCase().replaceAll(' ','-')}`, target=path.join(dir,slug+'.md');
let md=`---\nid: "${uuid}"\ntype: task\nrecord_version: 2\ntitle: "${title}"\nowner: "synthetic@example.test"\n${assignee?`assignee: "${assignee}"\n`:''}project_id: "${project}"\nmilestone_id: "${milestone}"\ncreated_at: "2026-10-05T16:00:00.000Z"\nupdated_at: "2026-10-05T16:00:00.000Z"\ntask-state: not-started\ndocument-maturity: reviewed\n---\n# M1-T${num} — ${title}\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${milestone} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${project} -->\n\n## Requirements\n\n${req}\n\n## Definition of Done\n\n- [ ] ${dod} <!-- id: ${criterion} -->\n\n## Inputs\n\nNo supplied files.\n\n## Output and delivery\n\nLocal results belong in outputs/.\n\n## Verification\n\nRecord explicit review before satisfying the criterion.\n\n## Result\n\nNot started.\n`;
let mf=path.join(dir,'m1-career-materials.md'),pf=path.join(pr,'job-search/project-index.md');
let changes=[{path:target,before:null,after:md},{path:mf,before:read(mf),after:read(mf)+`\n- [ ] [[${slug}|${title}]] <!-- ref: ${uuid} -->\n`},{path:pf,before:read(pf),after:read(pf)+`\n| | [ ] [[m1-career-materials/${slug}\\|${title}]] <!-- ref: ${uuid} --> | ${req} | Synthetic User | — |\n`}];
let ev=event(id(),'task.accepted',[uuid],clocks.mon,null,{id:uuid,type:'task',path:target,milestone_id:milestone,project_id:project},`User explicitly accepted ${key} ${title}, requirement ${req}, DoD ${dod}.`);
let t=transaction(p,changes,ev);persist(t,p);log(t,p);complete(t,p);data[key]={id:uuid,title,path:path.relative(pr,target).replaceAll('\\','/'),state:'not-started',assignee:assignee??null};p=prepare(vault,clocks.mon);
}
fs.mkdirSync(path.join(dir,'inputs'),{recursive:true});fs.mkdirSync(path.join(dir,'outputs'),{recursive:true});
// Authorized synthetic terminal state edits: canonical first, then both project views.
for(let key of ['D','E']){let task=data[key],f=path.join(pr,task.path),before=read(f),state=key==='D'?'completed':'cancelled',after=before.replace('task-state: not-started',`task-state: ${state}\nresolved_at: "2026-10-05T16:00:00.000Z"`);if(key==='D')after=after.replace('- [ ] reviewed result','- [x] reviewed result').replace('Not started.','User explicitly attests that the past result was reviewed.');
let parsed=cli('inspect-records',{projectsRoot:pr});write(path.join(caseRoot,'.temp',`closure-${key}-inventory.json`),parsed);
if(key==='D'){let rr=cli('parse-record',{markdown:after,path:f});let records=parsed.records.map(r=>r.id===task.id?rr:r);console.log('closure',cli('check-closure',{recordId:task.id,records}));}
let changes=[{path:f,before,after}];for(let v of [path.join(dir,'m1-career-materials.md'),path.join(pr,'job-search/project-index.md')]){let b=read(v);let a=b.split('\n').map(line=>line.includes(`ref: ${task.id}`)?line.replace('[ ]',key==='D'?'[x]':'[-]').replace(task.title,key==='E'?`~~${task.title}~~ Cancelled`:task.title):line).join('\n');changes.push({path:v,before:b,after:a});}
let ev=event(id(),`task.${state}`,[task.id],clocks.mon,{id:task.id,type:'task',path:f,milestone_id:milestone,project_id:project,state:'not-started'},{id:task.id,type:'task',path:f,milestone_id:milestone,project_id:project,state},key==='D'?'Past result reviewed, explicitly attested.':'Abandoned work explicitly cancelled.');let t=transaction(p,changes,ev);persist(t,p);log(t,p);complete(t,p);task.state=state;p=prepare(vault,clocks.mon);}
write(path.join(caseRoot,'.temp','tasks.json'),data);snapshot('accepted-terminal',vault);
