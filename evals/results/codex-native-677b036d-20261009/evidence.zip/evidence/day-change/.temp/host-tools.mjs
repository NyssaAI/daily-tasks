import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const caseRoot=process.cwd(), evidence=path.join(caseRoot,'.temp');
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4';
let seq=fs.existsSync(path.join(evidence,'calls.jsonl'))?fs.readFileSync(path.join(evidence,'calls.jsonl'),'utf8').trim().split('\n').length:0;
export function write(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
export function read(p){return fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;}
export function hash(v){return v===null?null:crypto.createHash('sha256').update(v).digest('hex');}
export function cli(op,input){let n=String(++seq).padStart(4,'0'), f=path.join(evidence,`${n}-${op}-input.json`);write(f,input??{});let r=spawnSync(process.execPath,[path.join(pkg,'bin/daily-tasks.mjs'),op,...(op==='new-id'?[]:['--input',f])],{encoding:'utf8'});write(path.join(evidence,`${n}-${op}-result.json`),{status:r.status,stdout:r.stdout,stderr:r.stderr});fs.appendFileSync(path.join(evidence,'calls.jsonl'),JSON.stringify({n,op,input:f,status:r.status})+'\n');if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export function id(){let r=cli('new-id');return typeof r==='string'?r:r.id;}
export function snapshot(label,root){let dest=path.join(evidence,'snapshots',label);function walk(p){for(let e of fs.readdirSync(p,{withFileTypes:true})){if(e.name==='.daily-tasks'||e.name==='.temp')continue;let q=path.join(p,e.name);if(e.isDirectory())walk(q);else write(path.join(dest,path.relative(root,q)),read(q));}}walk(root);}
export const clocks={mon:'2026-10-05T16:00:00Z',tue:'2026-10-06T16:00:00Z',fri:'2026-10-09T16:00:00Z'};
export function inputs(vault,now){return {vaultRoot:vault,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json'),homeRoot:caseRoot,now};}
export function prepare(vault,now){return cli('planning-prepare',inputs(vault,now));}
export function event(operation_id,action,ids,now,before,after,words){return {id:id(),operation_id,action,record_ids:ids,actor:{kind:'person',id:'synthetic@example.test'},...cli('activity-time',{now}),before,after,original_words:words};}
export function transaction(packet,files,ev,extra={}){let op={schemaVersion:2,operation_id:ev.operation_id,contextBinding:packet.context.planningBinding,event:ev,files:files.map(f=>({path:f.path,before:hash(f.before),after:hash(f.after)})),...extra};let p=path.join(packet.context.stateRoot,'operations',ev.operation_id+'.json');write(p,op);write(path.join(evidence,'checkpoints',ev.operation_id+'.json'),op);for(let f of files){write(path.join(evidence,'before-after',ev.operation_id,path.basename(f.path)+'.before'),f.before??'ABSENT');write(path.join(evidence,'before-after',ev.operation_id,path.basename(f.path)+'.after'),f.after??'ABSENT');}return {op,p,files};}
export function persist(t,packet){for(let f of t.files){if(hash(read(f.path))!==hash(f.before))throw Error('optimistic mismatch '+f.path);if(f.after===null)fs.unlinkSync(f.path);else write(f.path,f.after);cli('invalidate-project-index',{vaultRoot:packet.context.vaultRoot});}}
export function log(t,packet){return cli('log-append',{projectsRoot:packet.context.projectsRoot,entry:t.op.event});}
export function complete(t,packet,kind='operation-complete'){let inp={...inputs(packet.context.vaultRoot,packet.context.now),operationPath:t.p};let v=cli('operation-verify',inp);write(path.join(evidence,'verification',t.op.operation_id+'.json'),v);let r=cli(kind,inp);if(r.status!=='complete'&&r.status!=='completed')console.log(JSON.stringify(r));return r;}
