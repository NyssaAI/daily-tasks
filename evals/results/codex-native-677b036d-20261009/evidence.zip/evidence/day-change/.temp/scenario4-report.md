# Scenario 4 — Day change

Executed in the current native Codex tool session using installed Daily Tasks 0.3.4 instructions. Fourteen final-state checks passed; this is a workflow result, not a claim that packaging or CLI execution establishes host activation. Host version/model/authentication were not exposed, so those acceptance prerequisites remain unverified.

## Actual results

- Monday selected A/C/D/E; D is completed with explicitly attested reviewed-result DoD; E is explicitly cancelled. F was selected then explicitly deselected, retaining its open canonical record and durable removal ID.
- Friday created only `2026.10.09-daily-plan.md`. It carried personal A and delegated C (Reviewer), with no skipped Tuesday–Thursday plans. D/E remain visible Monday; F remains out.
- Independent precreated Tuesday retained B, its UUID, original Monday creation timestamp and fixture prose. A carried once, was removed, and remained removed on repeated Tuesday preparation.
- An actual interruption occurred after Friday destination persistence in a separate vault. Completion returned pending/event-missing and wrote no receipt. Recovery appended the original event, completed the receipt, and retried append/preparation without duplicate rows or events. Original event IDs and GMT strings match exactly.
- A separate future allocation transferred A to Tuesday, then removed it while the simulated clock was Monday. Its pending Tuesday removal state survived rollover and retry; A stayed absent.
- No execution timeframe, scheduling or time fitting was requested or authored. All clocks were the user's full GMT simulation instants in America/Chicago.

## Retained evidence

`receipt.json` contains individual checks, installed skill paths/hashes, declared clocks and limitations. `calls.jsonl` indexes every retained CLI input/result pair. `checkpoints/`, `before-after/` and `snapshots/` retain actual effects and pending-operation evidence. Final events are retained only through `*-final-log-query.json`; raw log files were never read, copied or hashed. Baselines were enrolled through verified operation completion; Friday review and check-in state were saved.

## Failures and corrections

The first missing-plan preparation was mistakenly treated as an empty carry proposal. Specialized completion rejected it without a receipt. That failed attempt and its logged event remain retained; its pending operation was explicitly superseded by the correct carry operation. A second attempt omitted terminal D/E sources because the planning inventory contains open tasks; adding the actual unchanged terminal source evidence allowed specialized verification to succeed.

The first Tuesday authoring attempt rewrote creation time/prose. Completion rejected it. The pending operation was repaired to restore the observed original creation time and prose before completion. This is a recovered authoring error, not a clean first-attempt pass.

An initial future fixture had simultaneous Monday and Tuesday active allocations. `plan-selection` refused removal with empty effects and a conflict; no removal was written from that proposal. A separate valid move followed by future removal supplied the final future-removal evidence.

Maintenance used actual CLI inspection. No worker-success timestamp or trusted worker execution is claimed. A full clean native acceptance designation is withheld because host prerequisites are unverified and the run includes the retained authoring errors above.
