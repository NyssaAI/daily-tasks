import path from 'node:path';
import {caseRoot,read,write,hash,prepare,inputs,cli,clocks} from './host-tools.mjs';
let v=path.join(caseRoot,'.temp/tuesday-vault'),p=prepare(v,clocks.tue),f=path.join(p.context.stateRoot,'operations',p.pendingOperations[0]),op=JSON.parse(read(f)),target=op.files[0].path,original=op.rollover.sourceSnapshot.currentMarkdown,current=read(target);
let fixed=current.replace(/created_at: "[^"]+"/,original.match(/created_at: "[^"]+"/)[0])+'\nRetain this precreated Tuesday prose.\n';write(target,fixed);op.files[0].after=hash(fixed);write(f,op);write(path.join(caseRoot,'.temp/checkpoints',op.operation_id+'-identity-prose-repair.json'),op);console.log(cli('rollover-complete',{...inputs(v,clocks.tue),operationPath:f}));
