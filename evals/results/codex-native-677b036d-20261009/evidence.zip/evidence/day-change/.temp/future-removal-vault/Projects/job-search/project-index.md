---
id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
type: "project"
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
project-state: "not-started"
---
# Job Search

Prepare career materials for the job search.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 --> | | Both reviewed artifacts linked. | Synthetic User | — |
| | [ ] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 --> | Draft a headline. | Synthetic User | — |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 --> | Draft a summary. | Synthetic User | — |

| | [ ] [[m1-career-materials/t3-review-draft\|Review draft]] <!-- ref: 01a121f0-05c1-75a0-b68f-b122daf76b75 --> | inspect draft | Synthetic User | — |

| | [x] [[m1-career-materials/t4-past-work\|Past work]] <!-- ref: 01a121f0-0857-776f-9cf9-0d3d88efca5e --> | past result | Synthetic User | — |

| | [-] [[m1-career-materials/t5-abandoned-work\|~~Abandoned work~~ Cancelled]] <!-- ref: 01a121f0-0aef-7852-b99b-1923914d0fdd --> | draft work | Synthetic User | — |

| | [ ] [[m1-career-materials/t6-deselected-work\|Deselected work]] <!-- ref: 01a121f0-0d9a-70bf-8211-44be02783018 --> | optional draft | Synthetic User | — |
