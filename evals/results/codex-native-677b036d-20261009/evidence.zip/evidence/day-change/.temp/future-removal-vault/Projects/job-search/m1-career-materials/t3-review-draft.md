---
id: "01a121f0-05c1-75a0-b68f-b122daf76b75"
type: task
record_version: 2
title: "Review draft"
owner: "synthetic@example.test"
assignee: "Reviewer"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
created_at: "2026-10-05T16:00:00.000Z"
updated_at: "2026-10-05T16:00:00.000Z"
task-state: not-started
document-maturity: reviewed
---
# M1-T3 — Review draft

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

inspect draft

## Definition of Done

- [ ] recorded review <!-- id: 01a121f0-05ef-79d3-b13c-8d47834b4ac3 -->

## Inputs

No supplied files.

## Output and delivery

Local results belong in outputs/.

## Verification

Record explicit review before satisfying the criterion.

## Result

Not started.
