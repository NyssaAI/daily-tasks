---
id: "01a121f0-0857-776f-9cf9-0d3d88efca5e"
type: task
record_version: 2
title: "Past work"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
created_at: "2026-10-05T16:00:00.000Z"
updated_at: "2026-10-05T16:00:00.000Z"
task-state: completed
resolved_at: "2026-10-05T16:00:00.000Z"
document-maturity: reviewed
---
# M1-T4 — Past work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

past result

## Definition of Done

- [x] reviewed result <!-- id: 01a121f0-0882-703f-a1cb-0a80f599a27f -->

## Inputs

No supplied files.

## Output and delivery

Local results belong in outputs/.

## Verification

Record explicit review before satisfying the criterion.

## Result

User explicitly attests that the past result was reviewed.
