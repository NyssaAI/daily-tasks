import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs';
const finish=process.argv.includes('--finish');
const resume=process.argv.includes('--resume')||finish;
let n=resume?Math.max(...fs.readdirSync(scratch).map(f=>Number(f.match(/^(\d+)-/)?.[1]??0))):0;
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
function call(op,input={}) { const prefix=path.join(scratch,`${String(++n).padStart(3,'0')}-${op}`); fs.writeFileSync(prefix+'.input.json',JSON.stringify(input,null,2)); const r=spawnSync(process.execPath,[cli,op,'--input',prefix+'.input.json'],{encoding:'utf8'}); fs.writeFileSync(prefix+'.result.json',JSON.stringify({command:[process.execPath,cli,op,'--input',prefix+'.input.json'],status:r.status,stdout:r.stdout,stderr:r.stderr},null,2)); if(r.status!==0) throw Error(r.stderr); return JSON.parse(r.stdout); }
const ctx=call('resolve-context',{vaultRoot:vault});
const context={vaultRoot:vault,profilePath:ctx.profilePath,stateRoot:ctx.stateRoot};
const project=path.join(ctx.projectsRoot,'job-search'), folder=path.join(project,'m1-career-materials');
const P=path.join(project,'project-index.md'), M=path.join(folder,'m1-career-materials.md'), T1=path.join(folder,'t1-update-linkedin.md'), T2=path.join(folder,'t2-update-resume.md');
const originals=resume?JSON.parse(fs.readFileSync(path.join(scratch,'original-records.json'),'utf8')):Object.fromEntries([P,M,T1,T2].map(p=>[p,fs.readFileSync(p,'utf8')]));
if(!resume) fs.writeFileSync(path.join(scratch,'original-records.json'),JSON.stringify(originals,null,2));
const scan=()=>call('inspect-records',{projectsRoot:ctx.projectsRoot});
let records=scan().records;
const id=p=>records.find(r=>r.path===p).id;
const ids={p:id(P),m:id(M),t1:id(T1),t2:id(T2)};
const outcomes=resume?JSON.parse(fs.readFileSync(path.join(scratch,'assertions.json'),'utf8')):[];
function expect(label,condition,observed) { outcomes.push({label,pass:!!condition,observed}); fs.writeFileSync(path.join(scratch,'assertions.json'),JSON.stringify(outcomes,null,2)); if(!condition) throw Error(label+' failed'); }
function gate(label,p,allowed) { records=scan().records; const result=call('check-closure',{recordId:id(p),records}); expect(label,result.allowed===allowed,result); return result; }
function state(s,type,value,time) {s=s.replace(new RegExp(`${type}-state: .*`),`${type}-state: "${value}"`).replace(/updated_at: .*/,`updated_at: "${time}"`); s=s.replace(/^resolved_at: .*\r?\n/gm,''); if(['completed','cancelled','resolved'].includes(value)) s=s.replace(/\r?\n---\r?\n/,`\nresolved_at: "${time}"\n---\n`); return s; }
function checked(s,value) {return s.replace(/(- \[)[ x](\] .*<!-- id:)/g,`$1${value?'x':' '}$2`);}
async function commit(label,author) {
 const time=call('activity-time',{}), operation_id=call('new-id').id, eventId=call('new-id').id;
 const proposed=await author(time.activity_at);
 // Refresh only existing managed projections, preserving all prose and links.
 const combined=new Map([P,M,T1,T2].map(p=>[p,proposed[p]??fs.readFileSync(p,'utf8')]));
 const planned=[]; for(const [p,markdown] of combined) planned.push(call('parse-record',{markdown,path:p}));
 const parsed=planned.map(r=>r.record??r); const states=new Map(parsed.map(r=>[r.id,r.state]));
 for(const p of [M,P]) {const s=combined.get(p); const refreshed=s.split('\n').map(line=>{const ref=line.match(/<!-- ref: ([\w-]+) -->/); if(!ref||!line.includes('[')||!states.has(ref[1])) return line; const st=states.get(ref[1]); return line.replace(/\[[ x>\-]\]/,st==='completed'?'[x]':st==='cancelled'?'[-]':st==='in-progress'?'[>]':'[ ]');}).join('\n'); if(refreshed!==fs.readFileSync(p,'utf8')||proposed[p]) proposed[p]=refreshed; }
 for(const old of records) proposed[old.path]??=fs.readFileSync(old.path,'utf8');
 const changes=Object.entries(proposed).map(([p,after])=>({path:p,before:fs.existsSync(p)?fs.readFileSync(p,'utf8'):null,after}));
 const event={id:eventId,operation_id,action:'closure.'+label,record_ids:[...Object.values(ids)],actor:{kind:'agent',id:'codex'},...time,original_words:'User authorized scenario 5 synthetic closure, manual edits and review evidence.',before:{records:records.map(r=>({id:r.id,type:r.type,path:r.path,state:r.state,project_id:r.project_id,milestone_id:r.milestone_id}))},after:{reason:label,files:changes.map(c=>({path:c.path,sha256:sha(c.after)}))}};
 const op={schemaVersion:2,operation_id,contextBinding:ctx.planningBinding,event,files:changes.map(c=>({path:c.path,before:c.before===null?null:sha(c.before),after:sha(c.after)}))};
 const baselinePath=path.join(ctx.stateRoot,'reconciliation.json');
 const baselineText=fs.existsSync(baselinePath)?fs.readFileSync(baselinePath,'utf8'):null;
 const baselineValue=baselineText?JSON.parse(baselineText):{schemaVersion:1,records:{}};
 const afterRecords=[];for(const old of records) {const parsedAfter=call('parse-record',{markdown:proposed[old.path]??fs.readFileSync(old.path,'utf8'),path:old.path});afterRecords.push(parsedAfter.record??parsedAfter);}
 for(const r of afterRecords) {const views={};for(const view of afterRecords) if(view.projections.some(row=>row.id===r.id)) {const row=view.projections.find(row=>row.id===r.id);views[view.path]={hash:sha(proposed[view.path]??fs.readFileSync(view.path,'utf8')),checked:row.checked};} baselineValue.records[r.id]={canonical:{state:r.state},views};}
 op.baseline={beforeHash:baselineText===null?null:sha(baselineText),...(baselineText===null?{}:{beforeText:baselineText}),value:baselineValue};
 const dir=path.join(scratch,label+'-'+operation_id);fs.mkdirSync(dir,{recursive:true}); fs.writeFileSync(path.join(dir,'before-after.json'),JSON.stringify(changes,null,2));
 const opPath=path.join(ctx.stateRoot,'operations',operation_id+'.json');fs.mkdirSync(path.dirname(opPath),{recursive:true});fs.writeFileSync(opPath,JSON.stringify(op,null,2));fs.writeFileSync(path.join(dir,'checkpoint.json'),JSON.stringify(op,null,2));
 for(const c of changes) {const actual=fs.existsSync(c.path)?fs.readFileSync(c.path,'utf8'):null;if(actual!==c.before) throw Error('Concurrent change');fs.mkdirSync(path.dirname(c.path),{recursive:true});fs.writeFileSync(c.path,c.after);}
 call('log-append',{projectsRoot:ctx.projectsRoot,entry:event});
 call('invalidate-project-index',{vaultRoot:vault});
 const found=call('log-query',{projectsRoot:ctx.projectsRoot,action:event.action}); expect(label+' exact log payload',found.entries?.some(e=>JSON.stringify(e)===JSON.stringify(event))??false,found);
 const verify=call('operation-verify',{...context,operationPath:opPath}); expect(label+' verification',verify.status==='verified',verify);
 const completion=call('operation-complete',{...context,operationPath:opPath}); expect(label+' completion',completion.status==='completed'||completion.status==='verified',completion);
 records=scan().records;call('validate-records',{records});call('check-links',{records}); console.log(label+' committed');
}
async function closeParents(label) {gate(label+' milestone eligible',M,true);await commit(label+'-milestone',time=>({[M]:state(fs.readFileSync(M,'utf8'),'milestone','completed',time)}));gate(label+' project eligible',P,true);await commit(label+'-project',time=>({[P]:state(fs.readFileSync(P,'utf8'),'project','completed',time)}));}
async function propagate(label,p,edit) {await commit(label,time=>{const proposedText=edit(fs.readFileSync(p,'utf8'),time);const proposedRecord=call('parse-record',{markdown:proposedText,path:p});const r=proposedRecord.record??proposedRecord;const proposedRecords=records.map(old=>old.id===r.id?r:old);const result=call('reopen-ancestors',{records:proposedRecords,changedIds:[r.id]}); fs.writeFileSync(path.join(scratch,label+'-'+n+'-proposal.json'),JSON.stringify(result,null,2)); const changes={[p]:proposedText};for(const next of result.records) {const prev=records.find(old=>old.id===next.id);if(next.state!==prev.state) changes[next.path]=state(changes[next.path]??fs.readFileSync(next.path,'utf8'),next.type,next.state,time);} return changes;});}
function checkStates(label,wanted) {records=scan().records;expect(label,Object.entries(wanted).every(([key,value])=>records.find(r=>r.id===ids[key]).state===value),records.map(r=>({id:r.id,state:r.state})));}
let B,blockerId,number;
if(!resume) {
gate('unchecked task criterion prevents completion',T1,false);
gate('unresolved children prevent milestone closure',M,false);
gate('unresolved milestone prevents project closure',P,false);
number=call('next-record-number',{projectsRoot:ctx.projectsRoot,type:'blocker',parentId:ids.p});
fs.writeFileSync(path.join(scratch,'blocker-allocation.json'),JSON.stringify(number));
blockerId=call('new-id').id; B=path.join(project,'blockers',`b${number.number}-await-approval.md`);ids.b=blockerId;
await commit('shared-blocker',time=>({
 [B]:`---\nid: "${blockerId}"\ntype: blocker\nrecord_version: 2\ntitle: "Await approval"\nblocker-state: open\nowner: "synthetic@example.test"\nproject_id: "${ids.p}"\ncreated_at: "${time}"\nupdated_at: "${time}"\n---\n# Await approval\n\nExternal approval of both career artifacts is pending.\n\n## Resolution condition\nSynthetic reviewer explicitly approves both artifacts.\n\n## Resolution evidence\nApproval pending.\n\n## Blocks\n- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: ${ids.t1} -->\n- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: ${ids.t2} -->\n`,
 [T1]:originals[T1]+`\n## Blocked by\n- [[../blockers/b${number.number}-await-approval|Await approval]] <!-- ref: ${blockerId} -->\n`,
 [T2]:originals[T2]+`\n## Blocked by\n- [[../blockers/b${number.number}-await-approval|Await approval]] <!-- ref: ${blockerId} -->\n`
}));
await commit('reviewed-evidence',time=>{
 const result={}; for(const [p,name,text] of [[T1,'reviewed-headline.md','Software engineer building reliable tools for everyday work.'],[T2,'reviewed-summary.md','Software engineer experienced in delivering maintainable tools, collaborating with users, and verifying practical results.']]) {result[path.join(folder,'outputs',name)]=`# Synthetic reviewed artifact\n\n${text}\n\nReviewed at ${time}: checked clarity, relevance and local persistence for this authorized synthetic acceptance scenario. Approved as review evidence; external approval remains pending.\n`;let s=checked(fs.readFileSync(p,'utf8'),true);s=s.replace('Work has not started; no artifact has been produced or reviewed.',`Synthetic review completed at ${time}. Artifact: [Reviewed material](outputs/${name}). Existing criterion verified against the saved local artifact.`);s=s.replace('Link the actual artifact here and from the milestone after review.',`[Reviewed artifact](outputs/${name}).`);result[p]=s;} result[M]=fs.readFileSync(M,'utf8')+'\n## Reviewed artifacts\n- [Reviewed headline](outputs/reviewed-headline.md)\n- [Reviewed summary](outputs/reviewed-summary.md)\n'; return result;
});
gate('shared approval blocker prevents LinkedIn completion',T1,false);
gate('shared approval blocker prevents resume completion',T2,false);
await commit('resolve-approval',time=>({[B]:state(fs.readFileSync(B,'utf8'),'blocker','resolved',time).replace('Approval pending.',`Synthetic reviewer approved both linked artifacts at ${time}.`)}));
gate('reviewed LinkedIn eligible',T1,true);
await commit('cancel-prerequisite',time=>({[T2]:state(fs.readFileSync(T2,'utf8'),'task','cancelled',time)+`\n## Required by\n- [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${ids.t1} -->\n`,[T1]:fs.readFileSync(T1,'utf8')+`\n## Depends on\n- [[t2-update-resume|Update resume]] <!-- ref: ${ids.t2} -->\n` }));
gate('cancelled dependency informational permits LinkedIn closure',T1,true);
await commit('complete-linkedin',time=>({[T1]:state(fs.readFileSync(T1,'utf8'),'task','completed',time)}));
gate('milestone criterion prevents closure despite terminal children',M,false);
await commit('restore-resume-open',time=>({[T2]:state(fs.readFileSync(T2,'utf8'),'task','not-started',time),[M]:checked(fs.readFileSync(M,'utf8'),true)}));
gate('unresolved child prevents closure despite checked milestone criterion',M,false);
gate('resume eligible after explicit reopening',T2,true);
await commit('complete-resume',time=>({[T2]:state(fs.readFileSync(T2,'utf8'),'task','completed',time)}));
await closeParents('initial-close');
await propagate('reopen-shared-blocker',B,(s,time)=>state(s,'blocker','open',time));
checkStates('blocker reopens parents preserving completed tasks',{p:'in-progress',m:'in-progress',t1:'completed',t2:'completed',b:'open'});
gate('reopened shared blocker gates parent closure',M,false);
await commit('resolve-reopened-blocker',time=>({[B]:state(fs.readFileSync(B,'utf8'),'blocker','resolved',time)}));await closeParents('after-blocker');
await propagate('uncheck-milestone-dod',M,s=>checked(s,false));
} else {const blocker=records.find(r=>r.type==='blocker');B=blocker.path;blockerId=blocker.id;ids.b=blockerId;if(!finish) await propagate('repair-milestone-reopening',M,s=>s);}
if(finish) {
 await propagate('repeat-milestone-dod-reopening',M,s=>checked(s,false));
 checkStates('repeated milestone DoD change reopens both parents in same operation',{p:'in-progress',m:'in-progress',t1:'completed',t2:'completed'});
 await commit('repeat-restore-milestone-criterion',()=>({[M]:checked(fs.readFileSync(M,'utf8'),true)}));await closeParents('repeat-milestone-close');
 await propagate('repeat-explicit-task-reopen',T1,(s,time)=>state(s,'task','not-started',time));
 checkStates('explicit not-started reopens closed parents with historical start preserved',{p:'in-progress',m:'in-progress',t1:'not-started',t2:'completed'});
 gate('explicitly reopened task eligible',T1,true);await commit('repeat-complete-linkedin',time=>({[T1]:state(fs.readFileSync(T1,'utf8'),'task','completed',time)}));await closeParents('repeat-final');
} else {
checkStates('milestone DoD reopens parents preserving completed tasks',{p:'in-progress',m:'in-progress',t1:'completed',t2:'completed'});
await commit('restore-milestone-dod',()=>({[M]:checked(fs.readFileSync(M,'utf8'),true)}));await closeParents('after-milestone');
await propagate('uncheck-task-dod',T1,s=>checked(s,false));
checkStates('task DoD reopens task and parents',{p:'in-progress',m:'in-progress',t1:'not-started',t2:'completed'});
// Add an explicit historical start to prove the requested reopening state overrides fallback.
await commit('explicit-start',time=>({[T1]:state(fs.readFileSync(T1,'utf8'),'task','in-progress',time).replace(/\n---\n/,`\nstarted_at: "${time}"\n---\n`)}));
await propagate('explicit-reopen-not-started',T1,(s,time)=>state(s,'task','not-started',time));
checkStates('explicit not-started preserved despite started_at',{p:'in-progress',m:'in-progress',t1:'not-started',t2:'completed'});
const retained=fs.readFileSync(T1,'utf8');
await commit('temporary-missing-dod',()=>({[T1]:retained.replace(/## Definition of Done\r?\n[\s\S]*?(?=## Inputs)/,'')}));gate('new version 2 task missing DoD cannot complete',T1,false);
await commit('temporary-empty-dod',()=>({[T1]:retained.replace(/(## Definition of Done\r?\n)[\s\S]*?(?=## Inputs)/,'$1\n')}));gate('new version 2 task empty DoD cannot complete',T1,false);
await commit('restore-original-task-criterion',()=>({[T1]:checked(retained,true)}));gate('restored original task criterion eligible',T1,true);
await commit('final-complete-linkedin',time=>({[T1]:state(fs.readFileSync(T1,'utf8'),'task','completed',time)}));await closeParents('final');
}
checkStates('final eligible records closed',{p:'completed',m:'completed',t1:'completed',t2:'completed',b:'resolved'});
const final=scan();expect('exact original project milestone and tasks plus sole blocker',final.records.length===5&&final.records.every(r=>Object.values(ids).includes(r.id)),final.records.map(r=>({id:r.id,path:r.path})));
call('inspect-navigation',{projectsRoot:ctx.projectsRoot,dailyPlansRoot:ctx.dailyPlansRoot});call('log-query',{projectsRoot:ctx.projectsRoot,limit:1000});
fs.writeFileSync(path.join(scratch,'final-records.json'),JSON.stringify(Object.fromEntries([P,M,T1,T2,B].map(p=>[p,fs.readFileSync(p,'utf8')])),null,2));
console.log(`${outcomes.filter(o=>o.pass).length} passed, ${outcomes.filter(o=>!o.pass).length} retained failures; evidence in ${scratch}`);
