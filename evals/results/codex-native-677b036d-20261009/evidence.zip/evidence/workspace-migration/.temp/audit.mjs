import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {isDeepStrictEqual as equal} from 'node:util';
const base=process.cwd(), scratch=path.join(base,'.temp'), pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4';
const read=async p=>fs.readFile(p,'utf8').catch(e=>{if(e.code==='ENOENT')return null;throw e;});
const assertions=[];const check=(name,passed,detail)=>assertions.push({name,passed,detail});
async function cli(label,op,input){const p=path.join(scratch,label+'.input.json');await fs.writeFile(p,JSON.stringify(input,null,2));const r=spawnSync(process.execPath,[path.join(pkg,'bin/daily-tasks.mjs'),op,'--input',p],{encoding:'utf8'});await fs.writeFile(path.join(scratch,label+'.result.json'),JSON.stringify({status:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const actions=(await read(path.join(scratch,'actions.jsonl'))).trim().split('\n').map(JSON.parse);
const processes=(await read(path.join(scratch,'isolated-processes.jsonl'))).trim().split('\n').map(JSON.parse);
for(const stage of ['destination','source','log']){
 const name=stage+'-isolated', m=JSON.parse(await read(path.join(scratch,name+'.manifest.json'))), final=JSON.parse(await read(path.join(scratch,name+'.final.json'))), records=final.scan.records;
 const milestone=records.find(r=>r.id===m.ids.milestone), task=records.find(r=>r.id===m.ids.task), completed=records.find(r=>r.id===m.ids.completed), unresolved=records.find(r=>r.id===m.ids.unresolved), blocker=records.find(r=>r.id===m.ids.blocker);
 const history=await cli(name+'-history','log-query',{projectsRoot:path.dirname(m.p),recordId:m.ids.completed,limit:1000});
 const links=await cli(name+'-links','check-links',{records});const validity=await cli(name+'-validation','validate-records',{records});
 check(name+': stable live identities',Object.values(m.ids).filter(id=>![m.ids.dod,m.ids.criterion,m.ids.taskCriterion,m.ids.plan].includes(id)).every(id=>records.filter(r=>r.id===id).length===1)&&!records.some(r=>r.id===m.ids.dod));
 check(name+': criteria text, state, UUID and evidence preserved',equal(milestone.criteria,m.operation.migration.expectedCriteria)&&task.criteria[0].id===m.ids.taskCriterion&&await read(path.join(m.p,'evidence.md'))===m.sources[path.join(m.p,'evidence.md')]);
 check(name+': lifecycle and historical event preserved',completed.state==='completed'&&completed.resolved_at===m.history.activity_at&&history.entries.some(e=>equal(e,m.history))&&task.state==='in-progress');
 const pre=actions.find(a=>a.name===name&&a.phase==='pre-retirement-check'), removal=actions.findIndex(a=>a.name===name&&a.phase==='source-removal'&&a.path===m.operation.migration.retiringPath), preIndex=actions.indexOf(pre);
 check(name+': retirement verified before removal',pre?.result.allowed===true&&preIndex<removal&&final.actual.every(f=>f.actual===f.after));
 check(name+': reciprocal blocker transferred',milestone.blocked_by.includes(blocker.id)&&blocker.blocks.includes(milestone.id)&&!blocker.blocks.includes(m.ids.dod));
 const taskMarkdown=await read(task.path), planMarkdown=await read(path.join(m.ctx.vaultRoot,'Daily','migration-'+name+'.md'));
 check(name+': inbound task and plan criterion links keep UUID and new owner',taskMarkdown.includes(`[[m1-migration#Definition of Done|Acceptance criterion]] <!-- ref: ${m.ids.criterion} -->`)&&planMarkdown.includes(`/m1-migration/m1-migration#Definition of Done|Criterion]] <!-- ref: ${m.ids.criterion} -->`)&&final.nav.diagnostics.length===0);
 check(name+': missing task DoD remains unversioned and unsatisfied',!completed.record_version&&!completed.criteria.length&&!unresolved.record_version&&!unresolved.criteria.length&&unresolved.state==='not-started'&&m.operation.event.after.pendingCriteria.includes(unresolved.id));
 check(name+': independent interruption, saved resume, exact event, retry',processes.some(p=>p.args[0]==='run'&&p.args[1]===name&&p.status===({destination:23,source:24,log:25}[stage]))&&final.events.length===1&&equal(final.events[0],m.operation.event)&&final.checkpoint===null);
 check(name+': unchanged unrelated prose', (await read(path.join(m.p,'project-index.md'))).includes('Unrelated prose must survive.')&&planMarkdown.includes('Unrelated daily note.'));
 await fs.writeFile(path.join(scratch,name+'.link-validation.json'),JSON.stringify({links,validity},null,2));
}
for(const kind of ['edit','collision']){
 const name=kind+'-isolated',m=JSON.parse(await read(path.join(scratch,name+'.manifest.json'))),result=await cli(name+'-final-conflict','operation-verify',{...m.ctx,operationPath:m.operationPath}),query=await cli(name+'-events','log-query',{projectsRoot:path.dirname(m.p),recordId:m.ids.milestone,limit:1000}),text=await read(m.operation.migration.destinationPath);
 check(name+': pending conflict, no overwrite or completion',result.status==='conflict'&&await read(m.operationPath)!==null&&(kind==='edit'?text.endsWith('Unexpected human edit.\n'):text==='Unrelated Windows collision content.\n')&&!query.entries.some(e=>e.operation_id===m.operation.operation_id)&&await read(m.operation.migration.retiringPath)!==null);
}
const closure=JSON.parse(await read(path.join(scratch,'competing-isolated.closure.json')));check('embedded and standalone sources prevent closure',closure.allowed===false&&closure.reasons.some(r=>r.includes('both embedded and standalone')));
const loaded=['skills/daily-tasks/SKILL.md','skills/daily-tasks-records/SKILL.md','skills/daily-tasks-setup/SKILL.md',...['operations','cli','workspace-migration','verification','records'].map(n=>'skills/daily-tasks/references/'+n+'.md')];
const instructionEvidence=[];for(const relative of loaded){const p=path.join(pkg,relative);instructionEvidence.push({path:p,sha256:createHash('sha256').update(await fs.readFile(p)).digest('hex')});}
const report={scenario:'workspace-migration',assertions,passed:assertions.filter(a=>a.passed).length,total:assertions.length,loadedInstructions:instructionEvidence,node:process.version,host:'Current Codex session; version/model/authentication not exposed as verifiable runtime evidence',scope:'Skill-authored workflows invoking installed CLI, not packaging activation evidence',missingCriteria:'Asked in current chat; no criteria manufactured; unresolved tasks remain pending',retainedFailures:'Initial shared-vault attempts source/log hit conservative basename incoming-link diagnostics. Premature retry probes appended migration events while still pending; these attempts are not passing receipts. All original attempts retained. Isolated independent cases are reported separately.'};
await fs.writeFile(path.join(scratch,'scenario8-report.json'),JSON.stringify(report,null,2));
await fs.writeFile(path.join(scratch,'scenario8-report.md'),`# Scenario 8 workspace migration\n\n${report.passed}/${report.total} isolated workflow assertions passed.\n\n${assertions.map(a=>`- ${a.passed?'PASS':'FAIL'}: ${a.name}`).join('\n')}\n\nMissing task criteria were requested and remain pending; completed legacy history was preserved.\n\n${report.retainedFailures}\n\n${report.scope}. ${report.host}. No independent authenticated host activation claim is made.\n\nEvidence: scenario8-report.json, actions.jsonl, isolated-processes.jsonl, manifests, final snapshots, and individual installed CLI input/result files. No raw log files were read, copied or hashed.\n`);
console.log(JSON.stringify({passed:report.passed,total:report.total,failures:assertions.filter(a=>!a.passed)}));
