import {spawnSync} from 'node:child_process';
import fs from 'node:fs/promises';
const steps=[['run','source','source'],['resume','source'],['retry','source'],['run','log','log'],['resume','log'],['retry','log'],['run','edit','destination'],['edit','edit'],['collision','collision'],['competing','competing']];
for(const args of steps){const r=spawnSync(process.execPath,['.temp/scenario8.mjs',...args],{encoding:'utf8'});const observation={args,status:r.status,stdout:r.stdout,stderr:r.stderr};await fs.appendFile('.temp/processes.jsonl',JSON.stringify(observation)+'\n');console.log(JSON.stringify(observation));}
