import {spawnSync} from 'node:child_process';
import fs from 'node:fs/promises';
const steps=[];
for(const stage of ['destination','source','log']){const n=stage+'-isolated';steps.push(['seed',n],['run',n,stage],['resume',n],['retry',n]);}
for(const kind of ['edit','collision','competing']){const n=kind+'-isolated';steps.push(['seed',n]);if(kind==='edit')steps.push(['run',n,'destination']);steps.push([kind,n]);if(kind!=='competing')steps.push(['resume',n]);}
for(const args of steps){const r=spawnSync(process.execPath,['.temp/scenario8.mjs',...args],{encoding:'utf8'});const observation={args,status:r.status,stdout:r.stdout,stderr:r.stderr};await fs.appendFile('.temp/isolated-processes.jsonl',JSON.stringify(observation)+'\n');console.log(JSON.stringify({args,status:r.status,stdout:r.stdout.slice(0,160),stderr:r.stderr.slice(0,160)}));}
