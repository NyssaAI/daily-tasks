import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), [mode,name,stage]=process.argv.slice(2), vault=name.endsWith('-isolated')?path.join(root,'.temp','fixtures',name,'vault'):path.join(root,'vault'), evidence=path.join(root,'.temp');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4';
const cli=path.join(pkg,'bin/daily-tasks.mjs');
await fs.mkdir(evidence,{recursive:true});
const hash=s=>s===null?null:createHash('sha256').update(s).digest('hex');
const read=async p=>fs.readFile(p,'utf8').catch(e=>{if(e.code==='ENOENT')return null;throw e;});
const save=async(p,s)=>{await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,s);};
async function call(op,input){const stamp=`${Date.now()}-${process.pid}-${op}-${Math.random().toString(16).slice(2)}`;const inputPath=path.join(evidence,stamp+'.input.json');if(input)await save(inputPath,JSON.stringify(input,null,2));const args=[cli,op,...(input?['--input',inputPath]:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});await save(path.join(evidence,stamp+'.result.json'),JSON.stringify({args,status:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
async function id(){const r=await call('new-id');return typeof r==='string'?r:r.id;}
const action=async(data)=>fs.appendFile(path.join(evidence,'actions.jsonl'),JSON.stringify({at:new Date().toISOString(),...data})+'\n');
if(mode==='seed'&&name.endsWith('-isolated'))await save(path.join(vault,'.nyssaai/daily-tasks/profile.json'),await read(path.join(root,'vault/.nyssaai/daily-tasks/profile.json')));
const context=await call('resolve-context',{vaultRoot:vault});
const ctx={vaultRoot:vault,profilePath:context.profilePath,stateRoot:context.stateRoot};
const manifestPath=path.join(evidence,name+'.manifest.json');
if(mode==='seed'){
 const ids={};for(const key of ['project','milestone','dod','task','completed','unresolved','criterion','taskCriterion','blocker','plan'])ids[key]=await id();
 const time=await call('activity-time',{}), p=path.join(context.projectsRoot,'migration-'+name), old=path.join(p,'legacy'), dest=path.join(p,'m1-migration');
 const meta=(type,key,title,state,extra='')=>`---\nid: ${ids[key]}\ntype: ${type}\ntitle: "${title}"\nowner: synthetic@example.test\ncreated_at: ${time.activity_at}\nupdated_at: ${time.activity_at}\n${type==='dod'?'dod-state':type+'-state'}: ${state}\n${extra}---\n# ${title}\n\n`;
 const parent=`project_id: ${ids.project}\n`, taskParent=parent+`milestone_id: ${ids.milestone}\n`;
 const criterion=`- [x] Review accepted with [evidence](../evidence.md). <!-- id: ${ids.criterion} -->\n`;
 const block=`## Blocked by\n- [[../blockers/b1-review|Review approval]] <!-- ref: ${ids.blocker} -->\n`;
 const dod=meta('dod','dod','Legacy acceptance','completed',parent+`milestone_id: ${ids.milestone}\n`)+`## Definition of Done\n${criterion}\nProvenance: synthetic review retained verbatim.\n\n${block}`;
 const milestone=meta('milestone','milestone','Migration','in-progress',parent)+`## Definition of Done\n- [[definition-of-done|Acceptance]] <!-- ref: ${ids.dod} -->\n\n## Tasks\n- [ ] [[draft|Draft]] <!-- ref: ${ids.task} -->\n- [x] [[completed|Completed legacy]] <!-- ref: ${ids.completed} -->\n- [ ] [[unresolved|Unresolved legacy]] <!-- ref: ${ids.unresolved} -->\n`;
 const task=meta('task','task','Draft','in-progress',taskParent+`started_at: ${time.activity_at}\n`)+`## Requirements\nDraft the synthetic artifact.\n\n## Definition of Done\n- [ ] Draft verified. <!-- id: ${ids.taskCriterion} -->\n\n## Reference\n- [[definition-of-done#Definition of Done|Acceptance criterion]] <!-- ref: ${ids.criterion} -->\n`;
 const completed=meta('task','completed','Completed legacy','completed',taskParent+`resolved_at: ${time.activity_at}\n`)+`## Requirements\nPreviously completed legacy work. No accepted task DoD supplied.\n`;
 const unresolved=meta('task','unresolved','Unresolved legacy','not-started',taskParent)+`## Requirements\nAcceptance details remain unresolved.\n`;
 const index=meta('project','project','Migration '+name,'in-progress')+`## Milestones\n- [[legacy/milestone|Migration]] <!-- ref: ${ids.milestone} -->\n\nUnrelated prose must survive.\n`;
 const blocker=meta('blocker','blocker','Review approval','open',parent)+`## Resolution\nSynthetic external approval is required.\n\n## Blocks\n- [[../legacy/definition-of-done|Acceptance]] <!-- ref: ${ids.dod} -->\n`;
 const plan=meta('daily-plan','plan','Migration view','not-started')+`- [ ] [[../Projects/migration-${name}/legacy/draft|Draft]] <!-- ref: ${ids.task} -->\n- [[../Projects/migration-${name}/legacy/definition-of-done#Definition of Done|Criterion]] <!-- ref: ${ids.criterion} -->\n\nUnrelated daily note.\n`;
 const sources={[path.join(p,'project-index.md')]:index,[path.join(old,'milestone.md')]:milestone,[path.join(old,'definition-of-done.md')]:dod,[path.join(old,'draft.md')]:task,[path.join(old,'completed.md')]:completed,[path.join(old,'unresolved.md')]:unresolved,[path.join(p,'blockers/b1-review.md')]:blocker,[path.join(context.dailyPlansRoot,'migration-'+name+'.md')]:plan,[path.join(p,'evidence.md')]:'Synthetic review evidence.\n'};
 for(const [f,s]of Object.entries(sources)){await save(f,s);await save(path.join(p,'.temp','before',path.relative(p,f).replaceAll('..','outside')),s);}
 const history={id:await id(),operation_id:await id(),action:'task.completed',record_ids:[ids.completed],actor:{kind:'person',id:'synthetic@example.test'},...time,original_words:'Synthetic historical completion',after:{'task-state':'completed'}};delete history.activity;await call('log-append',{projectsRoot:context.projectsRoot,entry:history});
 const opId=await id(), eventId=await id(), opTime=await call('activity-time',{});
 const destination=path.join(dest,'m1-migration.md'), retiring=path.join(old,'definition-of-done.md');
 const newMilestone=milestone.replace('type: milestone\n','type: milestone\nrecord_version: 2\n').replace(/## Definition of Done[\s\S]*?## Tasks/,`## Definition of Done\n${criterion}\nProvenance: synthetic review retained verbatim.\n\n${block}\n## Tasks`).replace('[[draft|','[[t1-draft|').replace('[[completed|','[[t2-completed|').replace('[[unresolved|','[[t3-unresolved|');
 const replacements={};replacements[destination]=newMilestone;replacements[path.join(dest,'t1-draft.md')]=task.replace('type: task\n','type: task\nrecord_version: 2\n').replace('[[definition-of-done#','[[m1-migration#');replacements[path.join(dest,'t2-completed.md')]=completed;replacements[path.join(dest,'t3-unresolved.md')]=unresolved;
 replacements[path.join(p,'project-index.md')]=index.replace('legacy/milestone','m1-migration/m1-migration');replacements[path.join(p,'blockers/b1-review.md')]=blocker.replace('../legacy/definition-of-done','../m1-migration/m1-migration').replace(ids.dod,ids.milestone);replacements[path.join(context.dailyPlansRoot,'migration-'+name+'.md')]=plan.replace('/legacy/draft','/m1-migration/t1-draft').replace('/legacy/definition-of-done','/m1-migration/m1-migration');
 for(const f of ['milestone.md','draft.md','completed.md','unresolved.md','definition-of-done.md'])replacements[path.join(old,f)]=null;
 const files=[];for(const [f,s]of Object.entries(replacements))files.push({path:f,before:hash(await read(f)),after:hash(s)});
 const parsed=await call('parse-record',{markdown:dod,path:retiring});
 const snapshots=(after)=>['project','milestone','task','completed','unresolved','dod','blocker'].map(key=>({id:ids[key],type:key==='completed'||key==='unresolved'?'task':key==='dod'?'dod':key==='task'?'task':key,path:key==='milestone'?(after?destination:path.join(old,'milestone.md')):key==='task'?(after?path.join(dest,'t1-draft.md'):path.join(old,'draft.md')):key==='completed'?(after?path.join(dest,'t2-completed.md'):path.join(old,'completed.md')):key==='unresolved'?(after?path.join(dest,'t3-unresolved.md'):path.join(old,'unresolved.md')):key==='dod'?retiring:key==='project'?path.join(p,'project-index.md'):path.join(p,'blockers/b1-review.md'),...(key!=='project'?{project_id:ids.project}:{}),...(['task','completed','unresolved'].includes(key)?{milestone_id:ids.milestone}:{})}));
 const event={id:eventId,operation_id:opId,action:'workspace.migration',record_ids:Object.values(ids).filter(x=>x!==ids.plan&&x!==ids.criterion&&x!==ids.taskCriterion),actor:{kind:'agent',id:'Codex'},...opTime,original_words:'User explicitly authorized scenario8 legacy conversion',before:{records:snapshots(false)},after:{records:snapshots(true).filter(x=>x.type!=='dod'),retired_dod_id:ids.dod,pendingCriteria:[ids.completed,ids.unresolved]}};
 const operation={schemaVersion:2,operation_id:opId,contextBinding:context.planningBinding,event,files,migration:{retiringPath:retiring,destinationPath:destination,sourceHash:hash(dod),expectedCriteria:parsed.criteria,preservedFields:{owner:parsed.owner}},sourceSnapshot:{retiringMarkdown:dod}};
 const operationPath=path.join(context.stateRoot,'operations',opId+'.json');await save(operationPath,JSON.stringify(operation,null,2));
 await save(manifestPath,JSON.stringify({ids,p,old,dest,operationPath,operation,replacements,sources,history,ctx},null,2));await action({name,phase:'seed-and-checkpoint',operationPath});console.log(JSON.stringify({name,operationPath}));
}else{
 const m=JSON.parse(await read(manifestPath)), input={...m.ctx,operationPath:m.operationPath};
 const apply=async(f,s)=>{const current=await read(f),effect=m.operation.files.find(x=>x.path===f);if(hash(current)===effect.after)return;if(hash(current)!==effect.before){await action({name,phase:'conflict',path:f});throw Error('Unexpected edit: '+f);}if(s===null)await fs.unlink(f);else await save(f,s);await action({name,phase:s===null?'source-removal':'destination-persistence',path:f,before:hash(current),after:hash(s)});};
 if(mode==='run'||mode==='resume'){
  await call('operation-verify',input);
  for(const [f,s]of Object.entries(m.replacements))if(s!==null)await apply(f,s);
  await fs.mkdir(path.join(m.dest,'inputs'),{recursive:true});await fs.mkdir(path.join(m.dest,'outputs'),{recursive:true});await call('invalidate-project-index',{vaultRoot:vault});
  if(stage==='destination'){await action({name,phase:'actual-process-interruption',stage});process.exit(23);}
  for(const [f,s]of Object.entries(m.replacements))if(s===null&&f!==m.operation.migration.retiringPath)await apply(f,null);
  if(await read(m.operation.migration.retiringPath)!==null){const permission=await call('migration-retirement',input);await action({name,phase:'pre-retirement-check',result:permission});if(!permission.allowed)throw Error('Retirement prohibited');await apply(m.operation.migration.retiringPath,null);}
  if(stage==='source'){await action({name,phase:'actual-process-interruption',stage});process.exit(24);}
  await call('log-append',{projectsRoot:context.projectsRoot,entry:m.operation.event});
  if(stage==='log'){await action({name,phase:'actual-process-interruption',stage});process.exit(25);}
  const result=await call('migration-complete',input);await action({name,phase:'completion',result});console.log(JSON.stringify(result));
 }else if(mode==='retry'){
  await call('log-append',{projectsRoot:context.projectsRoot,entry:m.operation.event});const query=await call('log-query',{projectsRoot:context.projectsRoot,recordId:m.ids.milestone,limit:1000});const events=query.entries.filter(x=>x.operation_id===m.operation.operation_id);const scan=await call('inspect-records',{projectsRoot:context.projectsRoot});const nav=await call('inspect-navigation',{projectsRoot:context.projectsRoot,dailyPlansRoot:context.dailyPlansRoot});await save(path.join(evidence,name+'.final.json'),JSON.stringify({events,scan,nav,checkpoint:await read(m.operationPath),actual:await Promise.all(m.operation.files.map(async f=>({...f,actual:hash(await read(f.path))})))},null,2));console.log(JSON.stringify({events:events.length,checkpointPresent:await read(m.operationPath)!==null}));
 }else if(mode==='edit'){
  const f=m.operation.migration.destinationPath;await save(f,(await read(f))+'\nUnexpected human edit.\n');console.log(JSON.stringify(await call('operation-verify',input)));console.log(JSON.stringify(await call('migration-complete',input)));
 }else if(mode==='collision'){
  const f=m.operation.migration.destinationPath.toUpperCase();await save(f,'Unrelated Windows collision content.\n');const listing=await fs.readdir(m.dest);await action({name,phase:'case-insensitive-collision',listing,content:await read(f)});console.log(JSON.stringify(await call('operation-verify',input)));console.log(JSON.stringify(await call('migration-complete',input)));
 }else if(mode==='competing'){
  const f=path.join(m.old,'milestone.md');await save(f,(await read(f)).replace('## Definition of Done\n','## Definition of Done\n- [ ] Embedded competing criterion. <!-- id: '+await id()+' -->\n'));const scan=await call('inspect-records',{projectsRoot:context.projectsRoot});await save(path.join(evidence,name+'.closure-scan.json'),JSON.stringify(scan,null,2));const result=await call('check-closure',{recordId:m.ids.milestone,records:scan.records});await save(path.join(evidence,name+'.closure.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 }
}
