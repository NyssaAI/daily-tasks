---
id: 01a121f1-9685-728b-ae54-63d5a71e9898
type: daily-plan
title: "Migration view"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:03.312Z
updated_at: 2026-10-09T18:34:03.312Z
daily-plan-state: not-started
---
# Migration view

- [ ] [[../Projects/migration-destination-isolated/legacy/draft|Draft]] <!-- ref: 01a121f1-957a-71e9-a1d2-04fdaab8fb14 -->
- [[../Projects/migration-destination-isolated/legacy/definition-of-done#Definition of Done|Criterion]] <!-- ref: 01a121f1-95ff-78cd-a9c1-cf41e2fb65ba -->

Unrelated daily note.
