---
id: 01a121f1-9659-7937-a8d3-383a63ca000e
type: blocker
title: "Review approval"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:03.312Z
updated_at: 2026-10-09T18:34:03.312Z
blocker-state: open
project_id: 01a121f1-94f8-7616-bcd1-d49da7205ffc
---
# Review approval

## Resolution
Synthetic external approval is required.

## Blocks
- [[../legacy/definition-of-done|Acceptance]] <!-- ref: 01a121f1-9550-7a80-a09f-0e8c7aae66cf -->
