---
id: 01a121f1-b10a-713f-af8b-bfc7347ee830
type: project
title: "Migration collision-isolated"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:10.608Z
updated_at: 2026-10-09T18:34:10.608Z
project-state: in-progress
---
# Migration collision-isolated

## Milestones
- [[legacy/milestone|Migration]] <!-- ref: 01a121f1-b137-730f-8756-817368957882 -->

Unrelated prose must survive.
