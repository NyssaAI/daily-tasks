---
id: 01a121f1-b278-7604-b985-db8f9a77d59b
type: blocker
title: "Review approval"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:10.608Z
updated_at: 2026-10-09T18:34:10.608Z
blocker-state: open
project_id: 01a121f1-b10a-713f-af8b-bfc7347ee830
---
# Review approval

## Resolution
Synthetic external approval is required.

## Blocks
- [[../legacy/definition-of-done|Acceptance]] <!-- ref: 01a121f1-b16a-7625-86af-57b0753b5a79 -->
