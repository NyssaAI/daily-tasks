---
id: 01a121f1-b7f9-7b18-9074-8dcb4c9f4410
type: blocker
title: "Review approval"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:11.924Z
updated_at: 2026-10-09T18:34:11.924Z
blocker-state: open
project_id: 01a121f1-b687-71f5-9365-b7d4ba548fa6
---
# Review approval

## Resolution
Synthetic external approval is required.

## Blocks
- [[../legacy/definition-of-done|Acceptance]] <!-- ref: 01a121f1-b6e7-78c2-8647-110ad84343a5 -->
