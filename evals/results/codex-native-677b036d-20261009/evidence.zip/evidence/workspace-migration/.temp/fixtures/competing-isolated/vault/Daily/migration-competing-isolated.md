---
id: 01a121f1-b825-7d33-bda8-3859d4c27075
type: daily-plan
title: "Migration view"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:11.924Z
updated_at: 2026-10-09T18:34:11.924Z
daily-plan-state: not-started
---
# Migration view

- [ ] [[../Projects/migration-competing-isolated/legacy/draft|Draft]] <!-- ref: 01a121f1-b715-7745-a368-a5c653538e22 -->
- [[../Projects/migration-competing-isolated/legacy/definition-of-done#Definition of Done|Criterion]] <!-- ref: 01a121f1-b7a0-75db-a24d-c1125bed233a -->

Unrelated daily note.
