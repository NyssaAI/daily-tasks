---
id: 01a121f1-b6b6-7ea6-a050-462230e8ada0
type: milestone
title: "Migration"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:11.924Z
updated_at: 2026-10-09T18:34:11.924Z
milestone-state: in-progress
project_id: 01a121f1-b687-71f5-9365-b7d4ba548fa6
---
# Migration

## Definition of Done
- [[definition-of-done|Acceptance]] <!-- ref: 01a121f1-b6e7-78c2-8647-110ad84343a5 -->

## Tasks
- [ ] [[draft|Draft]] <!-- ref: 01a121f1-b715-7745-a368-a5c653538e22 -->
- [x] [[completed|Completed legacy]] <!-- ref: 01a121f1-b743-72a2-9b57-651da7baf4c3 -->
- [ ] [[unresolved|Unresolved legacy]] <!-- ref: 01a121f1-b772-7a98-abb7-7e3d07825266 -->
