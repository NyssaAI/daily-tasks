---
id: 01a121f1-94f8-7616-bcd1-d49da7205ffc
type: project
title: "Migration destination-isolated"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:03.312Z
updated_at: 2026-10-09T18:34:03.312Z
project-state: in-progress
---
# Migration destination-isolated

## Milestones
- [[legacy/milestone|Migration]] <!-- ref: 01a121f1-9522-7ed9-9eb6-f5269427c802 -->

Unrelated prose must survive.
