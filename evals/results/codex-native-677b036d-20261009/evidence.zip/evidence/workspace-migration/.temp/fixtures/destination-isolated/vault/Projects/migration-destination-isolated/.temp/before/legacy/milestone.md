---
id: 01a121f1-9522-7ed9-9eb6-f5269427c802
type: milestone
title: "Migration"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:03.312Z
updated_at: 2026-10-09T18:34:03.312Z
milestone-state: in-progress
project_id: 01a121f1-94f8-7616-bcd1-d49da7205ffc
---
# Migration

## Definition of Done
- [[definition-of-done|Acceptance]] <!-- ref: 01a121f1-9550-7a80-a09f-0e8c7aae66cf -->

## Tasks
- [ ] [[draft|Draft]] <!-- ref: 01a121f1-957a-71e9-a1d2-04fdaab8fb14 -->
- [x] [[completed|Completed legacy]] <!-- ref: 01a121f1-95a6-723f-93a9-4a7de07c295b -->
- [ ] [[unresolved|Unresolved legacy]] <!-- ref: 01a121f1-95d3-7fd3-8403-c13c5486f528 -->
