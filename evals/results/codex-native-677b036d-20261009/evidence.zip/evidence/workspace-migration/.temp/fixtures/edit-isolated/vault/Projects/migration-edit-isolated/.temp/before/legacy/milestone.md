---
id: 01a121f1-ab4a-7cf4-ae5c-06a5faa66354
type: milestone
title: "Migration"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:09.000Z
updated_at: 2026-10-09T18:34:09.000Z
milestone-state: in-progress
project_id: 01a121f1-ab1e-7a9a-a072-b038d7c9c658
---
# Migration

## Definition of Done
- [[definition-of-done|Acceptance]] <!-- ref: 01a121f1-ab7a-77d6-8597-0f737ca740ac -->

## Tasks
- [ ] [[draft|Draft]] <!-- ref: 01a121f1-aba8-7bbd-b314-843a78715d4f -->
- [x] [[completed|Completed legacy]] <!-- ref: 01a121f1-abd6-730c-81ad-7208b796f477 -->
- [ ] [[unresolved|Unresolved legacy]] <!-- ref: 01a121f1-ac02-780d-8a0e-ee320149cfb9 -->
