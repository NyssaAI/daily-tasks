---
id: 01a121f1-957a-71e9-a1d2-04fdaab8fb14
type: task
record_version: 2
title: "Draft"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:03.312Z
updated_at: 2026-10-09T18:34:03.312Z
task-state: in-progress
project_id: 01a121f1-94f8-7616-bcd1-d49da7205ffc
milestone_id: 01a121f1-9522-7ed9-9eb6-f5269427c802
started_at: 2026-10-09T18:34:03.312Z
---
# Draft

## Requirements
Draft the synthetic artifact.

## Definition of Done
- [ ] Draft verified. <!-- id: 01a121f1-962b-7c02-a6ac-a3c401b1ea60 -->

## Reference
- [[m1-migration#Definition of Done|Acceptance criterion]] <!-- ref: 01a121f1-95ff-78cd-a9c1-cf41e2fb65ba -->
