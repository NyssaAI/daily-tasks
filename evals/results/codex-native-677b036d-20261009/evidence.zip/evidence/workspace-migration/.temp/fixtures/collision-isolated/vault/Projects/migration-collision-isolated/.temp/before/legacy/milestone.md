---
id: 01a121f1-b137-730f-8756-817368957882
type: milestone
title: "Migration"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:10.608Z
updated_at: 2026-10-09T18:34:10.608Z
milestone-state: in-progress
project_id: 01a121f1-b10a-713f-af8b-bfc7347ee830
---
# Migration

## Definition of Done
- [[definition-of-done|Acceptance]] <!-- ref: 01a121f1-b16a-7625-86af-57b0753b5a79 -->

## Tasks
- [ ] [[draft|Draft]] <!-- ref: 01a121f1-b196-7ce1-8030-264cd7daadba -->
- [x] [[completed|Completed legacy]] <!-- ref: 01a121f1-b1c2-7588-860c-f413393a856a -->
- [ ] [[unresolved|Unresolved legacy]] <!-- ref: 01a121f1-b1ef-79da-8d7e-8fcaafc25321 -->
