---
id: 01a121f1-acba-7f74-8d5c-a539111c1a4c
type: daily-plan
title: "Migration view"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:09.000Z
updated_at: 2026-10-09T18:34:09.000Z
daily-plan-state: not-started
---
# Migration view

- [ ] [[../Projects/migration-edit-isolated/m1-migration/t1-draft|Draft]] <!-- ref: 01a121f1-aba8-7bbd-b314-843a78715d4f -->
- [[../Projects/migration-edit-isolated/m1-migration/m1-migration#Definition of Done|Criterion]] <!-- ref: 01a121f1-ac33-7c8a-b18d-d153256cdc0e -->

Unrelated daily note.
