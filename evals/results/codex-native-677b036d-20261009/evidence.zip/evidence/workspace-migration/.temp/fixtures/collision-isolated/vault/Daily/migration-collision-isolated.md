---
id: 01a121f1-b301-7f02-be5b-0c7321909c82
type: daily-plan
title: "Migration view"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:10.608Z
updated_at: 2026-10-09T18:34:10.608Z
daily-plan-state: not-started
---
# Migration view

- [ ] [[../Projects/migration-collision-isolated/legacy/draft|Draft]] <!-- ref: 01a121f1-b196-7ce1-8030-264cd7daadba -->
- [[../Projects/migration-collision-isolated/legacy/definition-of-done#Definition of Done|Criterion]] <!-- ref: 01a121f1-b21a-78cc-a867-435beea0be34 -->

Unrelated daily note.
