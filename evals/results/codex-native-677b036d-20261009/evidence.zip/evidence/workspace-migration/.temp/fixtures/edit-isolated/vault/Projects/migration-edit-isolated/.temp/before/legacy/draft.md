---
id: 01a121f1-aba8-7bbd-b314-843a78715d4f
type: task
title: "Draft"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:09.000Z
updated_at: 2026-10-09T18:34:09.000Z
task-state: in-progress
project_id: 01a121f1-ab1e-7a9a-a072-b038d7c9c658
milestone_id: 01a121f1-ab4a-7cf4-ae5c-06a5faa66354
started_at: 2026-10-09T18:34:09.000Z
---
# Draft

## Requirements
Draft the synthetic artifact.

## Definition of Done
- [ ] Draft verified. <!-- id: 01a121f1-ac60-7299-8add-8f9a8b474dd8 -->

## Reference
- [[definition-of-done#Definition of Done|Acceptance criterion]] <!-- ref: 01a121f1-ac33-7c8a-b18d-d153256cdc0e -->
