---
id: 01a121f1-b715-7745-a368-a5c653538e22
type: task
title: "Draft"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:11.924Z
updated_at: 2026-10-09T18:34:11.924Z
task-state: in-progress
project_id: 01a121f1-b687-71f5-9365-b7d4ba548fa6
milestone_id: 01a121f1-b6b6-7ea6-a050-462230e8ada0
started_at: 2026-10-09T18:34:11.924Z
---
# Draft

## Requirements
Draft the synthetic artifact.

## Definition of Done
- [ ] Draft verified. <!-- id: 01a121f1-b7cc-7f19-bed0-fc76667aa9fb -->

## Reference
- [[definition-of-done#Definition of Done|Acceptance criterion]] <!-- ref: 01a121f1-b7a0-75db-a24d-c1125bed233a -->
