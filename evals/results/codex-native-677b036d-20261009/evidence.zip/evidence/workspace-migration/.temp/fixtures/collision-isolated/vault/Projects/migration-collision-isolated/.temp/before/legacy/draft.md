---
id: 01a121f1-b196-7ce1-8030-264cd7daadba
type: task
title: "Draft"
owner: synthetic@example.test
created_at: 2026-10-09T18:34:10.608Z
updated_at: 2026-10-09T18:34:10.608Z
task-state: in-progress
project_id: 01a121f1-b10a-713f-af8b-bfc7347ee830
milestone_id: 01a121f1-b137-730f-8756-817368957882
started_at: 2026-10-09T18:34:10.608Z
---
# Draft

## Requirements
Draft the synthetic artifact.

## Definition of Done
- [ ] Draft verified. <!-- id: 01a121f1-b24b-7026-b7d5-02ef5e036784 -->

## Reference
- [[definition-of-done#Definition of Done|Acceptance criterion]] <!-- ref: 01a121f1-b21a-78cc-a867-435beea0be34 -->
