# Scenario 8 workspace migration

30/30 isolated workflow assertions passed.

- PASS: destination-isolated: stable live identities
- PASS: destination-isolated: criteria text, state, UUID and evidence preserved
- PASS: destination-isolated: lifecycle and historical event preserved
- PASS: destination-isolated: retirement verified before removal
- PASS: destination-isolated: reciprocal blocker transferred
- PASS: destination-isolated: inbound task and plan criterion links keep UUID and new owner
- PASS: destination-isolated: missing task DoD remains unversioned and unsatisfied
- PASS: destination-isolated: independent interruption, saved resume, exact event, retry
- PASS: destination-isolated: unchanged unrelated prose
- PASS: source-isolated: stable live identities
- PASS: source-isolated: criteria text, state, UUID and evidence preserved
- PASS: source-isolated: lifecycle and historical event preserved
- PASS: source-isolated: retirement verified before removal
- PASS: source-isolated: reciprocal blocker transferred
- PASS: source-isolated: inbound task and plan criterion links keep UUID and new owner
- PASS: source-isolated: missing task DoD remains unversioned and unsatisfied
- PASS: source-isolated: independent interruption, saved resume, exact event, retry
- PASS: source-isolated: unchanged unrelated prose
- PASS: log-isolated: stable live identities
- PASS: log-isolated: criteria text, state, UUID and evidence preserved
- PASS: log-isolated: lifecycle and historical event preserved
- PASS: log-isolated: retirement verified before removal
- PASS: log-isolated: reciprocal blocker transferred
- PASS: log-isolated: inbound task and plan criterion links keep UUID and new owner
- PASS: log-isolated: missing task DoD remains unversioned and unsatisfied
- PASS: log-isolated: independent interruption, saved resume, exact event, retry
- PASS: log-isolated: unchanged unrelated prose
- PASS: edit-isolated: pending conflict, no overwrite or completion
- PASS: collision-isolated: pending conflict, no overwrite or completion
- PASS: embedded and standalone sources prevent closure

Missing task criteria were requested and remain pending; completed legacy history was preserved.

Initial shared-vault attempts source/log hit conservative basename incoming-link diagnostics. Premature retry probes appended migration events while still pending; these attempts are not passing receipts. All original attempts retained. Isolated independent cases are reported separately.

Skill-authored workflows invoking installed CLI, not packaging activation evidence. Current Codex session; version/model/authentication not exposed as verifiable runtime evidence. No independent authenticated host activation claim is made.

Evidence: scenario8-report.json, actions.jsonl, isolated-processes.jsonl, manifests, final snapshots, and individual installed CLI input/result files. No raw log files were read, copied or hashed.

Overall: all requested assertions executed; isolated workflows pass, but retained initial failures prevent an unqualified acceptance pass.
