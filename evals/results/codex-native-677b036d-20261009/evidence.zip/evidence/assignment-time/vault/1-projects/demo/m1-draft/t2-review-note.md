---
id: 01a121f0-8711-791f-b8fc-ff7b6bcc175a
type: task
record_version: 2
title: "Review note"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a121f0-8688-7864-8a47-60f9c583a4d7"
milestone_id: "01a121f0-86b7-74cd-8ca2-da24d4ac0d0f"
assignee: "Editor"
created_at: "2026-10-09T18:32:54.048Z"
updated_at: "2026-10-09T18:32:54.976Z"
---
# M1-T2 — Review note

**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: 01a121f0-86b7-74cd-8ca2-da24d4ac0d0f -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a121f0-8688-7864-8a47-60f9c583a4d7 -->

## Requirements

Inspect the paragraph.

## Definition of Done

- [ ] Recorded review. <!-- id: 01a121f0-8792-78da-8423-def71303f639 -->
