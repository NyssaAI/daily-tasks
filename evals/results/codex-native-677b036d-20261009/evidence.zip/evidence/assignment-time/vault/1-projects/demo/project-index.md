---
id: 01a121f0-8688-7864-8a47-60f9c583a4d7
type: project
title: "Demo"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T18:32:54.048Z"
updated_at: "2026-10-09T18:32:54.048Z"
---
# Demo

Synthetic paragraph drafting and review project.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-draft/m1-draft\|M1 Draft]] <!-- ref: 01a121f0-86b7-74cd-8ca2-da24d4ac0d0f --> | | Draft and review a paragraph. | Synthetic User | — |
| | [>] [[m1-draft/t1-draft-note\|Draft note]] <!-- ref: 01a121f0-86e5-7003-ae29-281d77eeae3a --> | Draft paragraph. | Synthetic User | — |
| | [ ] [[m1-draft/t2-review-note\|Review note]] <!-- ref: 01a121f0-8711-791f-b8fc-ff7b6bcc175a --> | Inspect paragraph; assigned to Editor. | Synthetic User | — |
