---
id: 01a121f0-86b7-74cd-8ca2-da24d4ac0d0f
type: milestone
record_version: 2
title: "Draft"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a121f0-8688-7864-8a47-60f9c583a4d7"
created_at: "2026-10-09T18:32:54.048Z"
updated_at: "2026-10-09T18:32:54.048Z"
---
# M1 — Draft

**Project:** [[../project-index|Demo]] <!-- ref: 01a121f0-8688-7864-8a47-60f9c583a4d7 -->

## Outcome

Draft and review the paragraph.

## Definition of Done

- [ ] Both task Definitions of Done are satisfied. <!-- id: 01a121f0-873b-7aa8-b1a9-7b2990633410 -->

## Tasks

- [>] [[t1-draft-note|Draft note]] <!-- ref: 01a121f0-86e5-7003-ae29-281d77eeae3a -->
- [ ] [[t2-review-note|Review note]] <!-- ref: 01a121f0-8711-791f-b8fc-ff7b6bcc175a -->
