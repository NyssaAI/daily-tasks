---
id: 01a121f0-86e5-7003-ae29-281d77eeae3a
type: task
record_version: 2
title: "Draft note"
task-state: in-progress
owner: "synthetic@example.test"
project_id: "01a121f0-8688-7864-8a47-60f9c583a4d7"
milestone_id: "01a121f0-86b7-74cd-8ca2-da24d4ac0d0f"
created_at: "2026-10-09T18:32:54.048Z"
updated_at: "2026-10-09T18:32:54.507Z"
started_at: "2026-10-09T18:32:54.507Z"
---
# M1-T1 — Draft note

**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: 01a121f0-86b7-74cd-8ca2-da24d4ac0d0f -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a121f0-8688-7864-8a47-60f9c583a4d7 -->

## Requirements

Write a paragraph.

## Definition of Done

- [ ] Reviewed paragraph. <!-- id: 01a121f0-8768-7bf2-a361-b8ea0312cc03 -->
