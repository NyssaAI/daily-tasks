import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const cwd=process.cwd(), evidence=path.join(cwd,'.temp'), vault=path.join(cwd,'vault');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4';
const cli=path.join(pkg,'bin/daily-tasks.mjs'); let n=0;
const write=(p,t)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,t)};
function call(op,input){const stem=String(++n).padStart(3,'0')+'-'+op;let args=[cli,op];if(input!==undefined){const p=path.join(evidence,stem+'.input.json');write(p,JSON.stringify(input,null,2));args.push('--input',p)}const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(path.join(evidence,stem+'.result.json'),JSON.stringify({command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout)}
const id=()=>call('new-id').id;
const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:vault,projectsRoot:path.join(vault,'1-projects'),dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
write(path.join(evidence,'before.json'),JSON.stringify({vaultEntries:fs.readdirSync(vault),profile:null,records:[]},null,2));
const valid=call('validate-profile',profile);if(!valid.valid)throw Error(JSON.stringify(valid));
const profilePath=path.join(vault,'.nyssaai/daily-tasks/profile.json');write(profilePath,JSON.stringify(profile,null,2));
const context=call('resolve-context',{vaultRoot:vault,profilePath});
write(path.join(evidence,'context.json'),JSON.stringify(context,null,2));
write(path.join(evidence,'session.json'),JSON.stringify({pkg,profile,profilePath,context,n},null,2));
console.log(JSON.stringify({valid,context,exampleId:call('new-id'),time:call('activity-time',{reported:'earlier this morning'})},null,2));
write(path.join(evidence,'session.json'),JSON.stringify({pkg,profile,profilePath,context,n},null,2));
