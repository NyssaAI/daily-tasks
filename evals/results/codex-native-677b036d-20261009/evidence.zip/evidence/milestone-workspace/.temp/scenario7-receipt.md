# Scenario 7 — pass

- PASS: Initial numbered milestone, sibling T1/T2, empty flat holding areas
- PASS: Both different same-basename originals preserved under meaningful names
- PASS: Shared input has one working copy and both consumer links
- PASS: Two local drafts, T2 consumes T1 output in place
- PASS: Distinct requirements and task/milestone DoD; output alone does not satisfy DoD
- PASS: Copied-ID task-shaped attachment excluded from inspection and planning inventory
- PASS: Reorder preserves labels; T1 cancelled and T3 accepted without number reuse
- PASS: B1/B2 then B1 resolved and B3 accepted with stable labels
- PASS: One B2 record reciprocally links both original tasks
- PASS: Output rename repairs affected links and preserves unrelated prose
- PASS: Project → milestone → task → files navigation and integrity
- PASS: Project-local work, flat inputs/outputs and scratch in case .temp

Ten operations independently verified and completed by installed CLI. Actual CLI inputs/results and log queries retained alongside this receipt. Native host/model details beyond current session are not exposed; packaging is not used as activation evidence.
