---
id: "01a1211c-fc6d-7e56-b639-7133ec8fe4d6"
type: "task"
record_version: 2
title: "Update resume"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T14:41:50.392Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: "reviewed"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a summary.

## Definition of Done

- [ ] A reviewed summary is saved locally. <!-- id: 01a1211c-fd0c-7f8e-9ff3-557373a0657f -->

## Inputs

- [Resume source](inputs/resume-source.txt) — original attachments/b/source.txt.
- [Shared style guide](inputs/shared-style-guide.txt) — original attachments/shared.txt.
- [Headline draft](outputs/linkedin-headline-review-draft.md) — task 1 output consumed in place.

## Output and delivery

Draft: [Summary](outputs/resume-summary-draft.md). Save the summary locally in outputs/. Link the actual artifact here and from the milestone after review.

## Verification

Confirm the summary was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Local draft delivered: [Summary](outputs/resume-summary-draft.md), using the headline draft in its existing location. Review remains pending.

## Blocked by

- [[../blockers/b2-await-source|Await source]] <!-- ref: 01a121f0-9d76-7162-a904-0115d49cd4eb -->
