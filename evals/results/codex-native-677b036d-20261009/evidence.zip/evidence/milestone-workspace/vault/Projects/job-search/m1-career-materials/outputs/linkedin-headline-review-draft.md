# LinkedIn headline draft

Career professional preparing for the next opportunity

Draft for review; source supplied no experience or role facts. Shared style source retained.
