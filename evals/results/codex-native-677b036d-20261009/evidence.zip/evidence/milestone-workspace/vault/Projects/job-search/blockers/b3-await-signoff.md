---
id: "01a121f0-a1bc-76db-bf2f-6256be6edc54"
type: blocker
record_version: 2
title: "Await signoff"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:33:00.650Z"
updated_at: "2026-10-09T18:33:00.650Z"
---
# Await signoff

Waiting for external signoff.

## Resolution condition

The approver supplies signoff.

## Resolution evidence

Pending.

## Blocks
