---
id: "01a121f0-9d76-7162-a904-0115d49cd4eb"
type: blocker
record_version: 2
title: "Await source"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:32:59.555Z"
updated_at: "2026-10-09T18:32:59.555Z"
---
# Await source

Waiting for external source.

## Resolution condition

The source provider supplies the required source.

## Resolution evidence

Pending.

## Blocks

- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->
