import * as a from './host-actions.mjs';
import fs from 'node:fs';import path from 'node:path';import {spawn} from 'node:child_process';
const parent=a.parsed(a.milestone),project=a.parsed(a.project);
const allocation=a.call('next-record-number',{projectsRoot:a.pr,type:'task',parentId:parent.id});
if(allocation.number!==3)throw Error(JSON.stringify(allocation));
const tid=a.id(),criterion=a.id(),time=a.call('activity-time',{}),t3=path.join(a.m,'t3-independent-note.md'),output=path.join(a.m,'outputs/independent-note.md');
const text=`---\nid: "${tid}"\ntype: task\nrecord_version: 2\ntitle: "Independent note"\nowner: "${a.ctx.profile.user.email}"\ncreated_at: "${time.recorded_at}"\nupdated_at: "${time.recorded_at}"\ntask-state: "completed"\nresolved_at: "${time.activity_at}"\nproject_id: "${project.id}"\nmilestone_id: "${parent.id}"\ndocument-maturity: "reviewed"\n---\n# M1-T3 — Independent note\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${parent.id} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${project.id} -->\n\n## Requirements\n\nCreate a local note. Explicitly accepted by the user in this synthetic native acceptance request.\n\n## Definition of Done\n\n- [x] Reviewed note. <!-- id: ${criterion} -->\n\n## Inputs\n\nUser-supplied synthetic acceptance and review attestation.\n\n## Output and delivery\n\nLocal [Independent note](outputs/independent-note.md).\n\n## Verification\n\nThe user attests reviewed synthetic evidence. The local note exists and was inspected.\n\n## Result\n\nDelivered [reviewed synthetic note](outputs/independent-note.md). Independent of the unresolved task 2 status conflict.\n`;
const proposed=a.parsed(t3,text),records=a.call('inspect-records',{projectsRoot:a.pr}).records;
if(!a.call('check-closure',{recordId:tid,records:[...records,proposed]}).allowed)throw Error('Task3 closure rejected');
const effects=[{path:output,text:'# Independent note\n\nSynthetic local note for reconciliation acceptance.\n\nReviewed: user explicitly attests reviewed synthetic evidence.\n'},{path:t3,text},{path:a.milestone,text:a.read(a.milestone)+`\n- [x] [[t3-independent-note|Independent note]] <!-- ref: ${tid} -->\n`},{path:a.project,text:a.read(a.project)+`\n- [x] [[m1-career-materials/t3-independent-note|Independent note]] <!-- ref: ${tid} -->\n`}];
const b=JSON.parse(a.read(path.join(a.state,'reconciliation.json')));
// Existing task 2 baseline is intentionally preserved, including its divergent project hash.
// Enroll only task 3; no baseline advancement for the pending conflicting item.
b.records[tid]={canonical:{state:'completed'},views:{[a.project]:{hash:a.hash(effects.find(e=>e.path===a.project).text),checked:true},[a.milestone]:{hash:a.hash(effects.find(e=>e.path===a.milestone).text),checked:true}}};
const o=a.operation('task3-accept-complete',[tid],effects,b,{protectedFiles:[{path:a.plan,sha256:a.hash(a.read(a.plan))},{path:a.t2,sha256:a.hash(a.read(a.t2))}]});
a.json(path.join(a.temp,'interrupted-operation-pointer.json'),{operationPath:o.opPath,taskId:tid,taskPath:t3});
const cp=JSON.parse(a.read(path.join(a.state,'checkin.json')));cp.pendingOperationIds=[o.op.operation_id];cp.nextStep='Recover interrupted task3 log append using exact saved event.';a.json(path.join(a.state,'checkin.json'),cp);
const input=path.join(a.temp,'interrupted-log-append-input.json');a.json(input,{projectsRoot:a.pr,entry:o.op.event});
const directory=path.join(a.pr,'.daily-tasks');fs.mkdirSync(directory,{recursive:true});
let child,killed=false;
const watcher=fs.watch(directory,(event,name)=>{if(String(name)==='.decision-log.lock'&&!killed){killed=true;child.kill();}});
child=spawn(process.execPath,[path.join(a.pkg,'bin/daily-tasks.mjs'),'log-append','--input',input],{stdio:['ignore','pipe','pipe']});
let stdout='',stderr='';child.stdout.on('data',d=>stdout+=d);child.stderr.on('data',d=>stderr+=d);
const result=await new Promise(resolve=>child.on('exit',(code,signal)=>resolve({pid:child.pid,code,signal,killed,stdout,stderr})));watcher.close();
a.json(path.join(a.temp,'actual-interrupted-log-append-result.json'),{command:[process.execPath,path.join(a.pkg,'bin/daily-tasks.mjs'),'log-append','--input',input],...result});
a.json(path.join(a.temp,'interrupted-checkpoint.json'),JSON.parse(a.read(o.opPath)));
console.log(JSON.stringify(result));
