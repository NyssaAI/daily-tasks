import * as a from './host-actions.mjs';
import path from 'node:path';
const r1=a.parsed(a.t1),r2=a.parsed(a.t2);
function mark(text,id,mark){return text.split('\n').map(l=>l.includes(`ref: ${id}`)?l.replace(/\[[ x>\-]\]/,`[${mark}]`):l).join('\n');}
function baseline(effects,states={}){const b=JSON.parse(a.read(path.join(a.state,'reconciliation.json')));for(const [id,state]of Object.entries(states))b.records[id].canonical.state=state;for(const e of effects){const rows=a.call('parse-checklist',{markdown:e.text}).rows;for(const [id,r] of Object.entries(b.records))if(r.views[e.path]){r.views[e.path].hash=a.hash(e.text);const row=rows.find(r=>r.id===id);if(row)r.views[e.path].checked=row.checked;}}return b;}
const headline=path.join(a.m,'outputs/linkedin-headline.md');
const evidence='# Reviewed synthetic headline\n\nSoftware engineer building reliable, thoughtful tools.\n\nReview evidence: user explicitly attests reviewed synthetic evidence in this native acceptance request. Local synthetic artifact only.\n';
const time=a.call('activity-time',{});
let text=a.read(a.t1).replace('- [ ] A reviewed headline','- [x] A reviewed headline').replace('Work has not started; no artifact has been produced or reviewed.','Reviewed synthetic headline: [local artifact](outputs/linkedin-headline.md). User attests review; existing criterion is satisfied.').replace('Save the headline locally in outputs/. Link the actual artifact here and from the milestone after review.','Saved [reviewed synthetic headline](outputs/linkedin-headline.md) locally.').replace('task-state: "not-started"','task-state: "completed"').replace(/updated_at: .*/,`updated_at: "${time.recorded_at}"\nresolved_at: "${time.activity_at}"`);
const proposed=a.parsed(a.t1,text),records=a.call('inspect-records',{projectsRoot:a.pr}).records;
const closure=a.call('check-closure',{recordId:r1.id,records:records.map(r=>r.id===r1.id?proposed:r)});if(!closure.allowed)throw Error(JSON.stringify(closure));
let effects=[{path:headline,text:evidence},{path:a.t1,text},{path:a.project,text:mark(a.read(a.project),r1.id,'x')},{path:a.milestone,text:mark(a.read(a.milestone),r1.id,'x')+'\nReviewed task 1 artifact: [headline](outputs/linkedin-headline.md).\n'}];
const staleHash=a.hash(a.read(a.plan));
a.finish(a.operation('task1-complete-stale-plan',[r1.id],effects,baseline(effects,{[r1.id]:'completed'}),{protectedFiles:[{path:a.plan,sha256:staleHash}]}));
let current=a.parsed(a.t1);
const unchanged=a.call('reconcile-record',{base:{id:r1.id,type:'task',state:'completed'},current,views:[{id:r1.id}]});
if(unchanged.record.state!=='completed'||a.hash(a.read(a.plan))!==staleHash)throw Error('Stale view reopened');
a.json(path.join(a.temp,'stale-unchanged-check.json'),{planHash:staleHash,unchanged,normalization:'Row equals its own rendered unchecked baseline; contributes no edit.'});
// Synchronize the known stale projection only after testing it, then make a deliberate uncheck.
effects=[{path:a.plan,text:mark(a.read(a.plan),r1.id,'x')}];
a.finish(a.operation('task1-refresh-view',[r1.id],effects,baseline(effects)));
a.snapshot('before-manual-uncheck',[a.plan]);a.write(a.plan,mark(a.read(a.plan),r1.id,' '));a.snapshot('after-manual-uncheck',[a.plan]);
const reopened=a.call('reconcile-record',{base:{id:r1.id,type:'task',state:'completed'},current:a.parsed(a.t1),views:[{id:r1.id,checked:false}]});
if(reopened.record.state!=='not-started')throw Error('Changed checkbox failed');
a.call('reopen-ancestors',{records:records.map(r=>r.id===r1.id?reopened.record:r),changedIds:[r1.id]});
text=a.read(a.t1).replace('task-state: "completed"','task-state: "not-started"').replace(/^resolved_at:.*\r?\n/m,'');
effects=[{path:a.t1,text},{path:a.project,text:mark(a.read(a.project),r1.id,' ')},{path:a.milestone,text:mark(a.read(a.milestone),r1.id,' ')},{path:a.plan,text:a.read(a.plan)}];
a.finish(a.operation('task1-reopen-checkbox',[r1.id],effects,baseline(effects,{[r1.id]:'not-started'})));
// Competing edits to two existing projections are retained without selecting a winner.
a.snapshot('before-competing-edits',[a.project,a.plan]);
a.write(a.project,mark(a.read(a.project),r2.id,'x'));
a.write(a.plan,mark(a.read(a.plan),r2.id,'-'));
a.snapshot('after-competing-edits',[a.project,a.plan]);
const conflict=a.call('reconcile-record',{base:{id:r2.id,type:'task',state:'not-started'},current:a.parsed(a.t2),views:[{id:r2.id,state:'completed'},{id:r2.id,state:'cancelled'}]});
if(!conflict.conflicts.length)throw Error('Missing conflict');
a.json(path.join(a.state,'checkin.json'),{schemaVersion:1,planningBinding:a.ctx.planningBinding,localDate:a.ctx.localDate,pendingOperationIds:[],unresolvedConflictIds:[r2.id],conflicts:[{recordId:r2.id,...conflict,sourcePaths:[a.project,a.plan],sourceHashes:[a.hash(a.read(a.project)),a.hash(a.read(a.plan))]}],unresolvedCandidateIds:['friday-maybe-improve-resume'],nextStep:'Continue accepted independent task3; do not resolve task2 without a supplied decision.'});
a.json(path.join(a.temp,'pending-task2-conflict.json'),conflict);
