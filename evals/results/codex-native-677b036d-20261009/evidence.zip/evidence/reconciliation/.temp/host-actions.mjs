import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=process.cwd(), temp=path.join(root,'.temp'), vault=path.join(root,'vault');
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-full8/codex-home/plugins/cache/daily-tasks-release-034-full8/daily-tasks/0.3.4';
let seq=fs.existsSync(path.join(temp,'sequence.json'))?JSON.parse(fs.readFileSync(path.join(temp,'sequence.json'))):0;
export const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
export const hash=t=>t===null?null:crypto.createHash('sha256').update(t).digest('hex');
export function write(p,t){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,t);}
export function json(p,v){write(p,JSON.stringify(v,null,2)+'\n');}
export function cli(op,input={},opts={}){const n=String(++seq).padStart(3,'0'), p=path.join(temp,`${n}-${op}-input.json`);json(p,input);json(path.join(temp,'sequence.json'),seq);const args=[path.join(pkg,'bin/daily-tasks.mjs'),op,...(op==='new-id'?[]:['--input',p])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});json(path.join(temp,`${n}-${op}-result.json`),{command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0&&!opts.allowFailure)throw Error(r.stderr);return {result:r.status===0?JSON.parse(r.stdout):null,...r};}
export function call(op,input){return cli(op,input).result;}
export const ctx=call('planning-prepare',{vaultRoot:vault}).context;
export const scope={vaultRoot:vault,profilePath:ctx.profilePath,stateRoot:ctx.stateRoot};
export const pr=ctx.projectsRoot, state=ctx.stateRoot, m=path.join(pr,'job-search/m1-career-materials'), project=path.join(pr,'job-search/project-index.md'), milestone=path.join(m,'m1-career-materials.md'), t1=path.join(m,'t1-update-linkedin.md'), t2=path.join(m,'t2-update-resume.md'), plan=path.join(ctx.dailyPlansRoot,`${ctx.localDate}-daily-plan.md`);
export function id(){const r=call('new-id');return typeof r==='string'?r:r.id;}
export function parsed(p,t=read(p)){return call('parse-record',{markdown:t,path:p});}
export function snapshot(label,paths){for(const p of paths){const t=read(p);if(t!==null)write(path.join(temp,label,path.relative(vault,p)),t);}}
export function operation(action,ids,effects,baseline,extra={}){const time=call('activity-time',{}), operation_id=id(), event={id:id(),operation_id,action,record_ids:ids,actor:{kind:'person',id:ctx.profile.user.email},...time,original_words:'User authorized scenario3 synthetic evidence, manual edits, and independent task acceptance.',before:effects.map(e=>({path:e.path,sha256:hash(read(e.path))})),after:{paths:effects.map(e=>e.path),reason:action}};const op={schemaVersion:2,operation_id,contextBinding:ctx.planningBinding,event,files:effects.map(e=>({path:e.path,before:hash(read(e.path)),after:hash(e.text)})),...extra};if(baseline){const beforeText=read(path.join(state,'reconciliation.json'));op.baseline={beforeHash:hash(beforeText),...(beforeText===null?{}:{beforeText}),value:baseline};}const opPath=path.join(state,'operations',`${operation_id}.json`);json(opPath,op);json(path.join(temp,`checkpoint-${action}.json`),op);snapshot(`before-${action}`,effects.map(e=>e.path));for(const e of effects){if(hash(read(e.path))!==op.files.find(f=>f.path===e.path).before)throw Error('Unexpected before');write(e.path,e.text);}snapshot(`after-${action}`,effects.map(e=>e.path));call('invalidate-project-index',{vaultRoot:vault});return {op,opPath};}
export function finish(o){call('log-append',{projectsRoot:pr,entry:o.op.event});const v=call('operation-verify',{...scope,operationPath:o.opPath});if(v.status!=='verified')throw Error(JSON.stringify(v));const c=call('operation-complete',{...scope,operationPath:o.opPath});console.log(JSON.stringify(c));return c;}
