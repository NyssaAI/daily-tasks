import * as a from './host-actions.mjs';
import fs from 'node:fs';import path from 'node:path';import {isDeepStrictEqual} from 'node:util';
const interrupted=JSON.parse(a.read(path.join(a.temp,'actual-interrupted-log-append-result.json')));
if(!interrupted.killed||interrupted.code!==null)throw Error('No real interruption');
let stopped=false;try{process.kill(interrupted.pid,0);}catch(e){if(e.code==='ESRCH')stopped=true;else throw e;}if(!stopped)throw Error('Interrupted owner still active');
const lock=path.resolve(a.pr,'.daily-tasks/.decision-log.lock');
if(!lock.startsWith(path.resolve(a.vault)+path.sep))throw Error('Lock outside case vault');
if(fs.existsSync(lock)){if(fs.lstatSync(lock).isSymbolicLink())throw Error('Unsafe lock');const names=fs.readdirSync(lock);if(names.some(n=>n!=='owner.json'))throw Error('Unexpected lock content');if(names.includes('owner.json'))fs.unlinkSync(path.join(lock,'owner.json'));fs.rmdirSync(lock);}
a.json(path.join(a.temp,'lock-recovery-evidence.json'),{pid:interrupted.pid,stopped,lock,removedOnlyKnownLock:true});
const pointer=JSON.parse(a.read(path.join(a.temp,'interrupted-operation-pointer.json'))),op=JSON.parse(a.read(pointer.operationPath));
const before=a.call('log-query',{projectsRoot:a.pr,limit:1000});a.json(path.join(a.temp,'history-before-resume.json'),before);
const actual={};const changes=[];for(const f of op.files){const key=f.path;actual[key]=a.hash(a.read(key));changes.push({key,before:{present:true,value:f.before},after:{present:true,value:f.after}});}
const recovery=a.call('recover-operation',{operation:{changes},actual});a.json(path.join(a.temp,'recovery-classification.json'),recovery);
const first=a.call('log-append',{projectsRoot:a.pr,entry:op.event});
const query=a.call('log-query',{projectsRoot:a.pr,recordId:pointer.taskId,limit:1000});
const entries=query.entries??query;
if(!Array.isArray(entries))throw Error(JSON.stringify(query));
const matching=entries.filter(e=>e.operation_id===op.operation_id);
if(matching.length!==1||!isDeepStrictEqual(matching[0],op.event))throw Error('Full matching event not found');
const verified=a.call('operation-verify',{...a.scope,operationPath:pointer.operationPath});if(verified.status!=='verified')throw Error(JSON.stringify(verified));
const completed=a.call('operation-complete',{...a.scope,operationPath:pointer.operationPath});if(completed.status!=='completed')throw Error(JSON.stringify(completed));
const retry=a.call('log-append',{projectsRoot:a.pr,entry:op.event});
const after=a.call('log-query',{projectsRoot:a.pr,limit:1000});a.json(path.join(a.temp,'history-after-retry.json'),after);
const all=after.entries??after,prior=before.entries??before;
if(!prior.every(e=>all.some(x=>isDeepStrictEqual(e,x))))throw Error('History changed');
if(all.filter(e=>e.operation_id===op.operation_id).length!==1)throw Error('Duplicate decision');
const cp=JSON.parse(a.read(path.join(a.state,'checkin.json')));cp.pendingOperationIds=[];cp.nextStep='Task2 remains pending completed/cancelled choice; Friday checkbox remains a candidate.';a.json(path.join(a.state,'checkin.json'),cp);
a.call('invalidate-project-index',{vaultRoot:a.vault});
let packet=a.call('planning-prepare',a.scope);
const shared=p=>({...a.scope,now:p.context.now,expectedPlanHash:p.current.sha256,expectedPreviousHash:p.previous?.sha256??null,expectedInventoryHash:p.inventoryHash});
if(packet.rollover.status!=='complete'){const r=a.cli('planning-state',{...shared(packet),action:'complete-rollover',expectedStateHash:packet.state.rollover.sha256},{allowFailure:true});a.json(path.join(a.temp,'rollover-result.json'),r.result??{stderr:r.stderr});}
packet=a.call('planning-prepare',a.scope);
a.cli('planning-state',{...shared(packet),action:'save-review',expectedStateHash:packet.state.review.sha256,expectedReviewHash:packet.reviewHash},{allowFailure:true});
const records=a.call('inspect-records',{projectsRoot:a.pr});a.call('validate-records',{records:records.records});a.call('check-links',{records:records.records});a.call('inspect-navigation',{projectsRoot:a.pr,dailyPlansRoot:a.ctx.dailyPlansRoot});a.call('maintenance-inspect',a.scope);
a.snapshot('final',[a.t1,a.t2,pointer.taskPath,a.project,a.milestone,a.plan,path.join(a.ctx.dailyPlansRoot,'2026-10-09.md'),path.join(a.state,'reconciliation.json'),path.join(a.state,'checkin.json')]);
const conflict=JSON.parse(a.read(path.join(a.temp,'pending-task2-conflict.json')));
const report={scenario:'workflow-v3/reconciliation',assertions:{staleUnchangedPlanDoesNotReopen:JSON.parse(a.read(path.join(a.temp,'stale-unchanged-check.json'))).unchanged.record.state==='completed',deliberateCheckboxChangeReopens:a.parsed(a.t1).state==='not-started',competingEditsPending:conflict.conflicts.length>0&&a.parsed(a.t2).state==='not-started'&&a.read(a.project).split('\n').some(l=>l.includes(a.parsed(a.t2).id)&&l.includes('[x]'))&&a.read(a.plan).split('\n').some(l=>l.includes(a.parsed(a.t2).id)&&l.includes('[-]')),unrelatedAcceptedTaskProceeds:a.parsed(pointer.taskPath).state==='completed',actualLogAppendInterrupted:interrupted.killed,oneFullMatchingDecisionAfterResumeAndRetry:all.filter(e=>e.operation_id===op.operation_id).length===1&&isDeepStrictEqual(all.find(e=>e.operation_id===op.operation_id),op.event),originalHistoryPreserved:prior.every(e=>all.some(x=>isDeepStrictEqual(e,x))),unrelatedProsePreserved:a.read(a.plan).includes('Synthetic unrelated prose: preserve this sentence through reconciliation.')&&a.read(path.join(a.ctx.dailyPlansRoot,'2026-10-09.md'))===a.read(path.join(a.temp,'original/Daily/2026-10-09.md')),pendingConflictPreserved:cp.unresolvedConflictIds.length===1},interruptedOperationId:op.operation_id,eventId:op.event.id,firstAppend:first,retry,completion:completed,host:{node:process.version,model:'not exposed by host tools',authentication:'not exposed by host tools'},limitations:['Native current-host skill execution; authentication and model are not independently exposed.','Trusted maintenance worker evidence unavailable; no worker success claimed.'],installedSkills:['daily-tasks-checkin','daily-tasks-records','daily-tasks-plan','daily-tasks-setup'].map(s=>path.join(a.pkg,'skills',s,'SKILL.md'))};
report.allScenarioAssertionsPassed=Object.values(report.assertions).every(Boolean);a.json(path.join(a.temp,'scenario3-result.json'),report);console.log(JSON.stringify(report,null,2));
