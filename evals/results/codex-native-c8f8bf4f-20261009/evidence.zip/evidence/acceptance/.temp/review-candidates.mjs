import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const cwd=process.cwd(), evidence=path.join(cwd,'.temp'), vault=path.join(cwd,'vault');
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-rollover-full8/codex-home/plugins/cache/daily-tasks-release-034-rollover-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs';
const save=(name,value)=>fs.writeFileSync(path.join(evidence,name),JSON.stringify(value,null,2)+'\n');
function call(label,op,input){const file=path.join(evidence,label+'.input.json');save(label+'.input.json',input);const r=spawnSync(process.execPath,[cli,op,'--input',file],{encoding:'utf8'});save(label+'.execution.json',{command:[process.execPath,cli,op,'--input',file],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);const result=JSON.parse(r.stdout);save(label+'.result.json',result);return result;}
const plan=path.join(vault,'Daily','2026-10-09.md');
const before=fs.readFileSync(plan);fs.writeFileSync(path.join(evidence,'manual-plan.before.md'),before);
const context=call('context','resolve-context',{vaultRoot:vault});
save('resolved-context.json',context);
console.log(JSON.stringify(context));
const records=call('records-before','inspect-records',{projectsRoot:context.projectsRoot});
call('log-before','log-query',{projectsRoot:context.projectsRoot,limit:1000,offset:0});
call('checkbox-source','parse-checklist',{markdown:before.toString('utf8')});
console.log(JSON.stringify(records));
const queuePath=path.join(context.stateRoot,'candidates.json');
save('candidates.before.json',{exists:fs.existsSync(queuePath),content:fs.existsSync(queuePath)?JSON.parse(fs.readFileSync(queuePath,'utf8')):null});
const owner=context.profile.user.email;
const candidates=[
 {id:'candidate-resume',title:'Update resume',type:'task-candidate',disposition:'unresolved',accepted:false,owner,assignee:null,project_id:null,milestone_id:null,target_date:null,source_keys:['current-request:resume','Daily/2026-10-09.md:checkbox:Maybe improve my resume'],sources:[{key:'current-request:resume',kind:'idea',text:'I might want to update LinkedIn and resume sometime.'},{key:'Daily/2026-10-09.md:checkbox:Maybe improve my resume',path:'Daily/2026-10-09.md',line:3,kind:'manual-checkbox',text:'Maybe improve my resume'}],unresolved_facts:['Explicit acceptance','Parent project and accepted milestone','Scope and definition of done']},
 {id:'candidate-linkedin',title:'Update LinkedIn',type:'task-candidate',disposition:'unresolved',accepted:false,owner,assignee:null,project_id:null,milestone_id:null,target_date:null,source_keys:['current-request:linkedin'],sources:[{key:'current-request:linkedin',kind:'idea',text:'I might want to update LinkedIn and resume sometime.'}],unresolved_facts:['Explicit acceptance','Parent project and accepted milestone','Scope and definition of done']}
];
const queue={schema_version:1,local_date:context.localDate,candidates,next_step:'Await explicit acceptance; preserve manual plan. No accepted records created.'};
fs.writeFileSync(queuePath,JSON.stringify(queue,null,2)+'\n');save('candidates.after.json',JSON.parse(fs.readFileSync(queuePath,'utf8')));
const after=fs.readFileSync(plan);fs.writeFileSync(path.join(evidence,'manual-plan.after.md'),after);
const recordsAfter=call('records-after','inspect-records',{projectsRoot:context.projectsRoot});
const logAfter=call('log-after','log-query',{projectsRoot:context.projectsRoot,limit:1000,offset:0});
save('actions-and-verification.json',{actions:['Resolved existing vault-only profile','Inspected accepted records','Queried decision log before and after','Parsed manual checkbox','Deduplicated resume mentions into one candidate','Persisted two unresolved candidates'],acceptedRecordsCreated:0,recordsBefore:records.records.length,recordsAfter:recordsAfter.records.length,manualPlanByteIdentical:before.equals(after),logBefore:JSON.parse(fs.readFileSync(path.join(evidence,'log-before.result.json'),'utf8')),logAfter,unresolvedCandidateCount:candidates.length,personalDirectoriesRead:false});
console.log(JSON.stringify({manualPlanByteIdentical:before.equals(after),recordsAfter:recordsAfter.records.length,logAfter,unresolvedCandidates:candidates.length}));
