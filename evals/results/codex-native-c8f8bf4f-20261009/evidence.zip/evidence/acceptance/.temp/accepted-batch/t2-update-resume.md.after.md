---
id: 01a12209-83af-7719-a19d-39236436388e
type: task
record_version: 2
title: "Update resume"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12209-8328-7035-8d00-409faa8fc947"
milestone_id: "01a12209-8355-7615-ba5f-48109a7cd585"
created_at: "2026-10-09T19:00:11.680Z"
updated_at: "2026-10-09T19:00:11.680Z"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a12209-8355-7615-ba5f-48109a7cd585 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12209-8328-7035-8d00-409faa8fc947 -->

## Requirements

Update summary.

## Definition of Done

- [ ] Reviewed summary. <!-- id: 01a12209-8406-709b-8c78-f19a7d3518bd -->

## Inputs

Source materials not supplied yet. Store supplied working files in inputs/.

## Output and delivery

Link the reviewed artifact here and from the milestone; local artifacts belong in outputs/.

## Verification

Owner reviews the summary and records evidence.

## Result

Awaiting execution.
