---
id: 01a12209-8382-75e5-ace9-19bf58900921
type: task
record_version: 2
title: "Update LinkedIn"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12209-8328-7035-8d00-409faa8fc947"
milestone_id: "01a12209-8355-7615-ba5f-48109a7cd585"
created_at: "2026-10-09T19:00:11.680Z"
updated_at: "2026-10-09T19:00:11.680Z"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a12209-8355-7615-ba5f-48109a7cd585 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12209-8328-7035-8d00-409faa8fc947 -->

## Requirements

Update headline.

## Definition of Done

- [ ] Reviewed headline. <!-- id: 01a12209-83d9-7110-9212-994d86802525 -->

## Inputs

Source materials not supplied yet. Store supplied working files in inputs/.

## Output and delivery

Link the reviewed artifact here and from the milestone; local artifacts belong in outputs/.

## Verification

Owner reviews the headline and records evidence.

## Result

Awaiting execution.
