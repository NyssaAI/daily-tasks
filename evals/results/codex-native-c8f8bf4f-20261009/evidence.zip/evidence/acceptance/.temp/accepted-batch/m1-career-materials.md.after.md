---
id: 01a12209-8355-7615-ba5f-48109a7cd585
type: milestone
record_version: 2
title: "Career materials"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12209-8328-7035-8d00-409faa8fc947"
created_at: "2026-10-09T19:00:11.680Z"
updated_at: "2026-10-09T19:00:11.680Z"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12209-8328-7035-8d00-409faa8fc947 -->

## Outcome

Update LinkedIn headline and resume summary.

## Definition of Done

- [ ] Both reviewed artifacts linked. <!-- id: 01a12209-8433-7bd3-8372-056352fa02e8 -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a12209-8382-75e5-ace9-19bf58900921 -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a12209-83af-7719-a19d-39236436388e -->
