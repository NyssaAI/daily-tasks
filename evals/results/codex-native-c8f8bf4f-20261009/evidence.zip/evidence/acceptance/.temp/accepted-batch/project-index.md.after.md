---
id: 01a12209-8328-7035-8d00-409faa8fc947
type: project
record_version: 2
title: "Job Search"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:11.680Z"
updated_at: "2026-10-09T19:00:11.680Z"
---
# Job Search

Prepare career materials.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a12209-8355-7615-ba5f-48109a7cd585 --> | | Career materials | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a12209-8382-75e5-ace9-19bf58900921 --> | Update headline | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a12209-83af-7719-a19d-39236436388e --> | Update summary | synthetic@example.test | — |
