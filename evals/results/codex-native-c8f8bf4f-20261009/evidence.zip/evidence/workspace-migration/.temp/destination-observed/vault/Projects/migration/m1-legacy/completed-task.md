---
id: "01a12209-ba0b-7c1c-9e45-01daf7af8a1c"
type: "task"
title: "Completed legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:25.497Z"
updated_at: "2026-10-09T19:00:25.497Z"
task-state: "completed"
resolved_at: "2026-10-09T19:00:25.497Z"
project_id: "01a12209-b956-74f9-821a-ca9cdaa54248"
milestone_id: "01a12209-b985-701c-91eb-05e850bd7529"
---
# Completed legacy task

**Milestone:** [[m1-legacy|Legacy milestone]] <!-- ref: 01a12209-b985-701c-91eb-05e850bd7529 -->

## Requirements
Retain legacy requirements; completion criteria have not been accepted.

## References
[[m1-legacy#Definition of Done|Milestone criterion]] <!-- ref: 01a12209-ba8f-737c-8d19-1ac2b2561458 -->

Unrelated task prose remains.
