---
id: "01a12209-b956-74f9-821a-ca9cdaa54248"
type: "project"
title: "Synthetic migration"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:25.497Z"
updated_at: "2026-10-09T19:00:25.497Z"
project-state: "in-progress"
---
# Synthetic migration

## Milestones
- [ ] [[m1-legacy/m1-legacy|Legacy milestone]] <!-- ref: 01a12209-b985-701c-91eb-05e850bd7529 -->

Unrelated project prose remains.
