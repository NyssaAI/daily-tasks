---
id: "01a12209-53ec-7a16-b661-a2d55160aa2b"
type: "project"
title: "Synthetic migration"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:59:59.539Z"
updated_at: "2026-10-09T18:59:59.539Z"
project-state: "in-progress"
---
# Synthetic migration

## Milestones
- [ ] [[m1-legacy/m1-legacy|Legacy milestone]] <!-- ref: 01a12209-5418-7e15-8fc0-8d8c6f8384c3 -->

Unrelated project prose remains.
