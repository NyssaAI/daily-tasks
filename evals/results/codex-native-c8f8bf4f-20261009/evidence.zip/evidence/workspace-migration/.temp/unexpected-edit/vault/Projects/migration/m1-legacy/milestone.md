---
id: "01a12209-5418-7e15-8fc0-8d8c6f8384c3"
type: "milestone"
title: "Legacy milestone"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:59:59.539Z"
updated_at: "2026-10-09T18:59:59.539Z"
milestone-state: "in-progress"
project_id: "01a12209-53ec-7a16-b661-a2d55160aa2b"
---
# Legacy milestone

## Outcome
Retain accepted legacy work.

## Definition
[[definition-of-done|Legacy definition]] <!-- ref: 01a12209-5443-7849-ac3c-b917f1a6d377 -->

## Tasks
- [ ] [[ready-task|Ready task]] <!-- ref: 01a12209-546f-740e-aa02-533baf6286f3 -->
- [x] [[completed-task|Completed legacy task]] <!-- ref: 01a12209-549b-7aca-ab67-a54d011dda67 -->
- [ ] [[unresolved-task|Unresolved legacy task]] <!-- ref: 01a12209-54c7-7b01-9427-ad03991be9ab -->
