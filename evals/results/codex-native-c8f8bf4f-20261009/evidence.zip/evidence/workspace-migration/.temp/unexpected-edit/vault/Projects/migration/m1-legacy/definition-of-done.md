---
id: "01a12209-5443-7849-ac3c-b917f1a6d377"
type: "dod"
title: "Legacy definition"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:59:59.539Z"
updated_at: "2026-10-09T18:59:59.539Z"

milestone_id: "01a12209-5418-7e15-8fc0-8d8c6f8384c3"
---
# Legacy definition

## Criteria
- [x] Reviewed artifact available: [[outputs/review-evidence.txt|Review evidence]]. <!-- id: 01a12209-5522-7756-b3ef-e639b69e708e -->

## Provenance
Accepted legacy review evidence; preserve this narrative.

## Blocked by
- [[../blockers/b1-review|Review pending]] <!-- ref: 01a12209-54f2-77fd-8f04-0b8930a2db40 -->
