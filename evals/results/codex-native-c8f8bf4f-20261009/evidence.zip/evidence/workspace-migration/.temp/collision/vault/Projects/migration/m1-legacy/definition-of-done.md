---
id: "01a12209-5c1b-7acd-9495-c430ea4fe5fc"
type: "dod"
title: "Legacy definition"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:01.557Z"
updated_at: "2026-10-09T19:00:01.557Z"

milestone_id: "01a12209-5bec-7b64-b44b-b5e330997f55"
---
# Legacy definition

## Criteria
- [x] Reviewed artifact available: [[outputs/review-evidence.txt|Review evidence]]. <!-- id: 01a12209-5d06-7687-a230-9a600b36f014 -->

## Provenance
Accepted legacy review evidence; preserve this narrative.

## Blocked by
- [[../blockers/b1-review|Review pending]] <!-- ref: 01a12209-5cd6-768b-a73f-d16ed26e7be4 -->
