---
id: "01a12209-5cd6-768b-a73f-d16ed26e7be4"
type: "blocker"
title: "Review pending"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:01.557Z"
updated_at: "2026-10-09T19:00:01.557Z"
blocker-state: "open"
project_id: "01a12209-5bbc-74d8-81b3-15153d97f613"
---
# Review pending

## Impediment
Await external review.

## Resolves when
Reviewer confirms acceptance.

## Blocks
- [[../m1-legacy/definition-of-done|Legacy definition]] <!-- ref: 01a12209-5c1b-7acd-9495-c430ea4fe5fc -->
