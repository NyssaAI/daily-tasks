---
id: "01a12209-5caa-73d8-8d87-5468a27ba156"
type: "task"
title: "Unresolved legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:01.557Z"
updated_at: "2026-10-09T19:00:01.557Z"
task-state: "not-started"
project_id: "01a12209-5bbc-74d8-81b3-15153d97f613"
milestone_id: "01a12209-5bec-7b64-b44b-b5e330997f55"
---
# Unresolved legacy task

**Milestone:** [[milestone|Legacy milestone]] <!-- ref: 01a12209-5bec-7b64-b44b-b5e330997f55 -->

## Requirements
Retain legacy requirements; completion criteria have not been accepted.

## References
[[definition-of-done#Criteria|Milestone criterion]] <!-- ref: 01a12209-5d06-7687-a230-9a600b36f014 -->

Unrelated task prose remains.
