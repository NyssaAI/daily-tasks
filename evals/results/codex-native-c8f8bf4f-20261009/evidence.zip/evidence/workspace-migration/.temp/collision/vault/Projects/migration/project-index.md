---
id: "01a12209-5bbc-74d8-81b3-15153d97f613"
type: "project"
title: "Synthetic migration"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:01.557Z"
updated_at: "2026-10-09T19:00:01.557Z"
project-state: "in-progress"
---
# Synthetic migration

## Milestones
- [ ] [[m1-legacy/milestone|Legacy milestone]] <!-- ref: 01a12209-5bec-7b64-b44b-b5e330997f55 -->

Unrelated project prose remains.
