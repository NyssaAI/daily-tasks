---
id: "01a12209-5bec-7b64-b44b-b5e330997f55"
type: "milestone"
title: "Legacy milestone"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:01.557Z"
updated_at: "2026-10-09T19:00:01.557Z"
milestone-state: "in-progress"
project_id: "01a12209-5bbc-74d8-81b3-15153d97f613"
---
# Legacy milestone

## Outcome
Retain accepted legacy work.

## Definition
[[definition-of-done|Legacy definition]] <!-- ref: 01a12209-5c1b-7acd-9495-c430ea4fe5fc -->

## Tasks
- [ ] [[ready-task|Ready task]] <!-- ref: 01a12209-5c4a-74d2-ae17-cd205835c3fd -->
- [x] [[completed-task|Completed legacy task]] <!-- ref: 01a12209-5c7b-73f6-ab8b-349bebdcb0d3 -->
- [ ] [[unresolved-task|Unresolved legacy task]] <!-- ref: 01a12209-5caa-73d8-8d87-5468a27ba156 -->
