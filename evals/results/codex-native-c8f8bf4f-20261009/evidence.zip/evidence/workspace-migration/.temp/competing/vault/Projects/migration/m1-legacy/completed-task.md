---
id: "01a12209-6327-7172-ac91-b82251f67c93"
type: "task"
title: "Completed legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:03.260Z"
updated_at: "2026-10-09T19:00:03.260Z"
task-state: "completed"
resolved_at: "2026-10-09T19:00:03.260Z"
project_id: "01a12209-626b-77f7-8966-269f39fbcced"
milestone_id: "01a12209-629d-7c07-a20c-2bb12a7e2ca2"
---
# Completed legacy task

**Milestone:** [[milestone|Legacy milestone]] <!-- ref: 01a12209-629d-7c07-a20c-2bb12a7e2ca2 -->

## Requirements
Retain legacy requirements; completion criteria have not been accepted.

## References
[[definition-of-done#Criteria|Milestone criterion]] <!-- ref: 01a12209-63b1-79fb-8fa3-21ced64afa2b -->

Unrelated task prose remains.
