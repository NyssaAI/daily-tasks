---
id: "01a12209-62ca-78a0-a23e-d059c3ba5e5f"
type: "dod"
title: "Legacy definition"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:03.260Z"
updated_at: "2026-10-09T19:00:03.260Z"

milestone_id: "01a12209-629d-7c07-a20c-2bb12a7e2ca2"
---
# Legacy definition

## Criteria
- [x] Reviewed artifact available: [[outputs/review-evidence.txt|Review evidence]]. <!-- id: 01a12209-63b1-79fb-8fa3-21ced64afa2b -->

## Provenance
Accepted legacy review evidence; preserve this narrative.

## Blocked by
- [[../blockers/b1-review|Review pending]] <!-- ref: 01a12209-6383-7f1b-a1a6-729c0f28b4cb -->
