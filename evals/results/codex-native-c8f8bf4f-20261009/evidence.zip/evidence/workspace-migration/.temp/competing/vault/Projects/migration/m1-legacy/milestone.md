---
id: "01a12209-629d-7c07-a20c-2bb12a7e2ca2"
type: "milestone"
title: "Legacy milestone"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:03.260Z"
updated_at: "2026-10-09T19:00:03.260Z"
milestone-state: "in-progress"
project_id: "01a12209-626b-77f7-8966-269f39fbcced"
---
# Legacy milestone

## Outcome
Retain accepted legacy work.

## Definition
[[definition-of-done|Legacy definition]] <!-- ref: 01a12209-62ca-78a0-a23e-d059c3ba5e5f -->

## Tasks
- [ ] [[ready-task|Ready task]] <!-- ref: 01a12209-62f6-7819-8045-901a12571ae4 -->
- [x] [[completed-task|Completed legacy task]] <!-- ref: 01a12209-6327-7172-ac91-b82251f67c93 -->
- [ ] [[unresolved-task|Unresolved legacy task]] <!-- ref: 01a12209-6355-7cf7-b6db-7531352722b7 -->

## Definition of Done
- [ ] Embedded competing review. <!-- id: 01a12209-670c-77e9-a166-25c0538e7d67 -->
