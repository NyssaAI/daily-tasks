---
id: "01a12209-6383-7f1b-a1a6-729c0f28b4cb"
type: "blocker"
title: "Review pending"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:03.260Z"
updated_at: "2026-10-09T19:00:03.260Z"
blocker-state: "open"
project_id: "01a12209-626b-77f7-8966-269f39fbcced"
---
# Review pending

## Impediment
Await external review.

## Resolves when
Reviewer confirms acceptance.

## Blocks
- [[../m1-legacy/definition-of-done|Legacy definition]] <!-- ref: 01a12209-62ca-78a0-a23e-d059c3ba5e5f -->
