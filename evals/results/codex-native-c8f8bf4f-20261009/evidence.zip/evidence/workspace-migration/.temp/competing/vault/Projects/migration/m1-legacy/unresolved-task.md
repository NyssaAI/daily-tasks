---
id: "01a12209-6355-7cf7-b6db-7531352722b7"
type: "task"
title: "Unresolved legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:03.260Z"
updated_at: "2026-10-09T19:00:03.260Z"
task-state: "not-started"
project_id: "01a12209-626b-77f7-8966-269f39fbcced"
milestone_id: "01a12209-629d-7c07-a20c-2bb12a7e2ca2"
---
# Unresolved legacy task

**Milestone:** [[milestone|Legacy milestone]] <!-- ref: 01a12209-629d-7c07-a20c-2bb12a7e2ca2 -->

## Requirements
Retain legacy requirements; completion criteria have not been accepted.

## References
[[definition-of-done#Criteria|Milestone criterion]] <!-- ref: 01a12209-63b1-79fb-8fa3-21ced64afa2b -->

Unrelated task prose remains.
