---
id: "01a12209-626b-77f7-8966-269f39fbcced"
type: "project"
title: "Synthetic migration"
owner: "synthetic@example.test"
created_at: "2026-10-09T19:00:03.260Z"
updated_at: "2026-10-09T19:00:03.260Z"
project-state: "in-progress"
---
# Synthetic migration

## Milestones
- [ ] [[m1-legacy/milestone|Legacy milestone]] <!-- ref: 01a12209-629d-7c07-a20c-2bb12a7e2ca2 -->

Unrelated project prose remains.
