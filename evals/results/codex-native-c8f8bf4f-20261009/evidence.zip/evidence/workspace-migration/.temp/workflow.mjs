import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=path.resolve('.temp');
const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-rollover-full8/codex-home/plugins/cache/daily-tasks-release-034-rollover-full8/daily-tasks/0.3.4';
const cli=path.join(pkg,'bin/daily-tasks.mjs');
const [mode,name,stop]=process.argv.slice(2);
const dir=path.join(root,name); await fs.mkdir(dir,{recursive:true});
let seq=(await fs.readdir(dir)).filter(x=>/^cli-/.test(x)).length;
const hash=s=>s===null?null:crypto.createHash('sha256').update(s).digest('hex');
const read=async p=>fs.readFile(p,'utf8').catch(e=>{if(e.code==='ENOENT')return null;throw e});
async function put(p,s){await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,s);}
async function call(op,input){const base=path.join(dir,`cli-${String(++seq).padStart(3,'0')}-${op}`);if(input)await put(base+'-input.json',JSON.stringify(input,null,2));const r=spawnSync(process.execPath,[cli,op,...(input?['--input',base+'-input.json']:[])],{encoding:'utf8'});await put(base+'-result.json',JSON.stringify({command:[process.execPath,cli,op,...(input?['--input',base+'-input.json']:[])],exit:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
async function action(text){await fs.appendFile(path.join(dir,'actions.ndjson'),JSON.stringify({at:new Date().toISOString(),text})+'\n');}
const vault=path.join(dir,'vault'), projects=path.join(vault,'Projects'), project=path.join(projects,'migration'), work=path.join(project,'m1-legacy');
const profile=path.join(vault,'.nyssaai/daily-tasks/profile.json');
const scope={vaultRoot:vault,profilePath:profile};
const manifestPath=path.join(dir,'manifest.json');
if(mode==='seed'){
 const ids={};for(const k of ['project','milestone','dod','ready','completed','unresolved','blocker','criterion','taskCriterion','plan'])ids[k]=(await call('new-id')).id;
 const time=await call('activity-time',{});const stamp=time.recorded_at;
 await put(profile,JSON.stringify({schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'Daily',projectIndex:{ttlSeconds:14400}},null,2));
 const context=await call('resolve-context',scope);
 const meta=(key,type,title,state,extra='')=>`---\nid: "${ids[key]}"\ntype: "${type}"\ntitle: "${title}"\nowner: "synthetic@example.test"\ncreated_at: "${stamp}"\nupdated_at: "${stamp}"\n${state}\n${extra}---\n# ${title}\n\n`;
 const rel=(target,label,id)=>`[[${target}|${label}]] <!-- ref: ${id} -->`;
 const oldM=path.join(work,'milestone.md'),newM=path.join(work,'m1-legacy.md'),dod=path.join(work,'definition-of-done.md');
 const criterion=`- [x] Reviewed artifact available: [[outputs/review-evidence.txt|Review evidence]]. <!-- id: ${ids.criterion} -->`;
 const block=`- ${rel('../blockers/b1-review','Review pending',ids.blocker)}`;
 const files={};
 files[path.join(project,'project-index.md')]=meta('project','project','Synthetic migration','project-state: "in-progress"')+`## Milestones\n- [ ] ${rel('m1-legacy/milestone','Legacy milestone',ids.milestone)}\n\nUnrelated project prose remains.\n`;
 files[oldM]=meta('milestone','milestone','Legacy milestone','milestone-state: "in-progress"',`project_id: "${ids.project}"\n`)+`## Outcome\nRetain accepted legacy work.\n\n## Definition\n${rel('definition-of-done','Legacy definition',ids.dod)}\n\n## Tasks\n- [ ] ${rel('ready-task','Ready task',ids.ready)}\n- [x] ${rel('completed-task','Completed legacy task',ids.completed)}\n- [ ] ${rel('unresolved-task','Unresolved legacy task',ids.unresolved)}\n`;
 files[dod]=meta('dod','dod','Legacy definition','',`milestone_id: "${ids.milestone}"\n`)+`## Criteria\n${criterion}\n\n## Provenance\nAccepted legacy review evidence; preserve this narrative.\n\n## Blocked by\n${block}\n`;
 for(const [key,title,state,file] of [['ready','Ready task','in-progress','ready-task.md'],['completed','Completed legacy task','completed','completed-task.md'],['unresolved','Unresolved legacy task','not-started','unresolved-task.md']]){
 files[path.join(work,file)]=meta(key,'task',title,`task-state: "${state}"`,`${key==='completed'?`resolved_at: "${stamp}"\n`:''}project_id: "${ids.project}"\nmilestone_id: "${ids.milestone}"\n`)+`**Milestone:** ${rel('milestone','Legacy milestone',ids.milestone)}\n\n## Requirements\n${key==='ready'?'Produce a distinct task artifact.':'Retain legacy requirements; completion criteria have not been accepted.'}\n\n${key==='ready'?`## Definition of Done\n- [ ] Task artifact independently reviewed. <!-- id: ${ids.taskCriterion} -->\n\n`:''}## References\n${rel('definition-of-done#Criteria','Milestone criterion',ids.criterion)}\n\nUnrelated task prose remains.\n`;
 }
 const blocker=path.join(project,'blockers/b1-review.md');files[blocker]=meta('blocker','blocker','Review pending','blocker-state: "open"',`project_id: "${ids.project}"\n`)+`## Impediment\nAwait external review.\n\n## Resolves when\nReviewer confirms acceptance.\n\n## Blocks\n- ${rel('../m1-legacy/definition-of-done','Legacy definition',ids.dod)}\n`;
 const daily=path.join(vault,'Daily/2026-10-09.md'); files[daily]=meta('plan','daily-plan','Migration review','')+`- [x] ${rel('../Projects/migration/m1-legacy/definition-of-done#Criteria','Review criterion',ids.criterion)}\n\nUnrelated daily prose remains.\n`;
 files[path.join(work,'outputs/review-evidence.txt')]='Synthetic accepted review evidence.\n';
 for(const [p,s] of Object.entries(files))await put(p,s);
 await fs.mkdir(path.join(work,'inputs'),{recursive:true});
 const history={id:(await call('new-id')).id,operation_id:(await call('new-id')).id,action:'task.completed',record_ids:[ids.completed],actor:{kind:'person',id:'synthetic@example.test'},...time,original_words:'Synthetic historical completion without task criteria',before:{id:ids.completed,type:'task',path:path.join(work,'completed-task.md'),project_id:ids.project,milestone_id:ids.milestone,'task-state':'in-progress'},after:{id:ids.completed,type:'task',path:path.join(work,'completed-task.md'),project_id:ids.project,milestone_id:ids.milestone,'task-state':'completed'}};
 delete history.reported;await call('log-append',{projectsRoot:projects,entry:history});const historyQuery=await call('log-query',{projectsRoot:projects});
 const after={};
 for(const [p,s] of Object.entries(files)){
 if(p===dod)continue;
 let out=s.replaceAll('m1-legacy/milestone','m1-legacy/m1-legacy').replaceAll('[[milestone|','[[m1-legacy|').replaceAll('definition-of-done#Criteria','m1-legacy#Definition of Done');
 if(p===oldM){out=out.replace('type: "milestone"','type: "milestone"\nrecord_version: 2').replace(/## Definition\n[^\n]+\n/,`## Definition of Done\n${criterion}\n\n## Provenance\nAccepted legacy review evidence; preserve this narrative.\n\n## Blocked by\n${block}\n`);out=out.replaceAll('[[ready-task|','[[t1-ready-task|');after[newM]=out;after[oldM]=null;}
 else if(p.endsWith('ready-task.md')){after[path.join(work,'t1-ready-task.md')]=out.replace('type: "task"','type: "task"\nrecord_version: 2');after[p]=null;}
 else if(p===blocker)after[p]=out.replaceAll('../m1-legacy/definition-of-done','../m1-legacy/m1-legacy').replaceAll(ids.dod,ids.milestone);
 else after[p]=out;
 }
 after[dod]=null;
 const parsed=await call('parse-record',{markdown:files[dod],path:dod});
 const opid=(await call('new-id')).id;const timing=await call('activity-time',{});
 const facts=(p,s)=>({id:/id: "([^"]+)"/.exec(s)?.[1],type:/type: "([^"]+)"/.exec(s)?.[1],path:p,...(s.includes('project_id:')?{project_id:ids.project}:{}),...(s.includes('milestone_id:')?{milestone_id:ids.milestone}:{})});
 const beforeFacts=Object.entries(files).filter(([p])=>p.endsWith('.md')&&!p.includes('/Daily')&&!p.includes('\\Daily')).map(([p,s])=>facts(p,s));
 const event={id:(await call('new-id')).id,operation_id:opid,action:'workspace.migration',record_ids:[ids.milestone,ids.dod,ids.ready],actor:{kind:'agent',id:'codex'},activity_at:timing.activity_at,recorded_at:timing.recorded_at,time_defaulted:timing.time_defaulted,original_words:'User explicitly authorized synthetic legacy conversion',before:{records:beforeFacts},after:{records:Object.entries(after).filter(([p,s])=>s&&p.endsWith('.md')&&!p.includes(`${path.sep}Daily`)).map(([p,s])=>facts(p,s)),retired_dod_id:ids.dod,pending_conversion:[ids.completed,ids.unresolved]}};
 const operationPath=path.join(context.stateRoot,'operations',opid+'.json');
 const operation={schemaVersion:2,operation_id:opid,contextBinding:context.planningBinding,event,files:Object.entries(after).map(([p,s])=>({path:p,before:hash(files[p]??null),after:hash(s)})),migration:{retiringPath:dod,destinationPath:newM,sourceHash:hash(files[dod]),expectedCriteria:parsed.criteria,preservedFields:{owner:parsed.owner}},sourceSnapshot:{retiringMarkdown:files[dod]}};
 await put(operationPath,JSON.stringify(operation,null,2));
 const m={ids,context,scope,files,after,operationPath,operation,historyQuery,oldM,newM,dod,work,projects};await put(manifestPath,JSON.stringify(m,null,2));
 await put(path.join(project,'.temp/migration-before.json'),JSON.stringify(files,null,2));
 await action('Seeded authorized legacy fixture and saved exact schemaV2 operation before migration writes. Missing criteria requested; completed and unresolved tasks remain unversioned.');
 console.log(JSON.stringify({name,stage:'seeded',operationPath}));
}else{
 const m=JSON.parse(await read(manifestPath));const bound={...scope,operationPath:m.operationPath};
 if(mode==='audit'){
 const query=await call('log-query',{projectsRoot:projects});
 const bytes=Object.fromEntries(await Promise.all(m.operation.files.map(async e=>[e.path,{sha256:hash(await read(e.path)),content:await read(e.path)}])));
 await put(path.join(dir,`audit-${stop}.json`),JSON.stringify({query,checkpointPresent:await read(m.operationPath)!==null,bytes},null,2));console.log(`saved ${stop} actual state`);
 }else if(mode==='competing'){
 await put(m.oldM,m.files[m.oldM]+`\n## Definition of Done\n- [ ] Embedded competing review. <!-- id: ${(await call('new-id')).id} -->\n`);
 const inspected=await call('inspect-records',{projectsRoot:projects}); const records=inspected.records;
 const closure=await call('check-closure',{recordId:m.ids.milestone,records}); await put(path.join(dir,'closure.json'),JSON.stringify(closure,null,2));console.log(JSON.stringify(closure));
 }else if(mode==='inject'){
 if(stop==='edit')await fs.appendFile(m.newM,'\nUnexpected human edit: preserve me.\n');
 else await put(path.join(work,'M1-LEGACY.MD'),'UNRELATED Windows case-insensitive destination; never overwrite.\n');
 await action(`Injected ${stop}; operation stays pending.`);
 }else{
 await call('recover-operation',{operation:{changes:m.operation.files.map(e=>({key:e.path,before:{present:true,value:e.before},after:{present:true,value:e.after}}))},actual:Object.fromEntries(await Promise.all(m.operation.files.map(async e=>[e.path,hash(await read(e.path))])))});
 let conflict=false;
 for(const e of m.operation.files){const actual=await read(e.path);const h=hash(actual);if(h!==e.before&&h!==e.after){conflict=true;await action(`Conflict: ${e.path}; observed hash ${h}; no overwrite.`);}}
 if(conflict){await call('operation-verify',bound);await put(path.join(dir,'pending-conflict.json'),JSON.stringify({status:'pending-conflict',checkpointRetained:await read(m.operationPath)!==null},null,2));console.log('pending conflict; no writes or completion');process.exit(0);}
 // First persist all destination and incoming-link bytes. Removal is separately interruptible.
 for(const [p,s] of Object.entries(m.after)){if(s===null)continue;const actual=await read(p);if(hash(actual)===hash(s))continue;if(hash(actual)!==hash(m.files[p]??null))throw Error('write conflict');await put(p,s);await action(`Persisted destination ${p}; hash ${hash(await read(p))}`);}
 await call('invalidate-project-index',{vaultRoot:vault});
 if(stop==='destination'){await action('ACTUAL INTERRUPTION after destination persistence; source records and pending checkpoint retained.');console.log('interrupted after destination persistence');process.exit(0);}
 for(const [p,s] of Object.entries(m.after)){if(s!==null||p===m.dod)continue;const actual=await read(p);if(actual===null)continue;const destination=p===m.oldM?m.newM:path.join(work,'t1-ready-task.md');if(hash(await read(destination))!==hash(m.after[destination]))throw Error('destination verification failed');if(hash(actual)!==hash(m.files[p]))throw Error('source edit');await fs.unlink(p);await action(`Removed verified working source ${p}`);}
 if(await read(m.dod)!==null){const retirement=await call('migration-retirement',bound);if(!retirement.allowed)throw Error(JSON.stringify(retirement));await action('migration-retirement allowed immediately before DoD removal; all incoming sources were checked by installed CLI.');await fs.unlink(m.dod);await action('Retired old DoD after pre-removal verification.');}
 if(stop==='source'){await action('ACTUAL INTERRUPTION after source removal; checkpoint retained and migration event absent.');console.log('interrupted after source removal');process.exit(0);}
 await call('log-append',{...bound,projectsRoot:projects,entry:m.operation.event});
 const query=await call('log-query',{projectsRoot:projects,action:'workspace.migration'});await put(path.join(dir,'migration-query.json'),JSON.stringify(query,null,2));
 if(stop==='log'){await action('ACTUAL INTERRUPTION after log append; checkpoint retained.');console.log('interrupted after log append');process.exit(0);}
 if(await read(m.operationPath)!==null){const completed=await call('migration-complete',bound);await put(path.join(dir,'completion.json'),JSON.stringify(completed,null,2));if(completed.status!=='completed')throw Error(JSON.stringify(completed));}
 const inventory=await call('inspect-records',{projectsRoot:projects});await call('check-links',{records:inventory.records});await call('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:path.join(vault,'Daily')});
 await put(path.join(dir,'after.json'),JSON.stringify(Object.fromEntries(await Promise.all(Object.keys(m.after).map(async p=>[p,await read(p)]))),null,2));
 await action('Resume/retry verified final effects and queried exact migration event; unchanged historical event retained.');console.log(JSON.stringify({name,status:'completed',query}));
 }
}
