---
id: "01a12209-240a-7f78-ac3b-caeb1725951f"
type: "project"
title: "Synthetic migration"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:59:47.283Z"
updated_at: "2026-10-09T18:59:47.283Z"
project-state: "in-progress"
---
# Synthetic migration

## Milestones
- [ ] [[m1-legacy/m1-legacy|Legacy milestone]] <!-- ref: 01a12209-2437-7ac5-ac26-eea7eb466438 -->

Unrelated project prose remains.
