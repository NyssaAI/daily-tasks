---
id: "01a12208-f0a7-7bef-a442-195e26ca7137"
type: "task"
record_version: 2
title: "Ready task"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:59:34.003Z"
updated_at: "2026-10-09T18:59:34.003Z"
task-state: "in-progress"
project_id: "01a12208-f01b-7f38-b9ac-f05fee3d0980"
milestone_id: "01a12208-f04c-7f29-b5a1-4aed095a6ea8"
---
# Ready task

**Milestone:** [[m1-legacy|Legacy milestone]] <!-- ref: 01a12208-f04c-7f29-b5a1-4aed095a6ea8 -->

## Requirements
Produce a distinct task artifact.

## Definition of Done
- [ ] Task artifact independently reviewed. <!-- id: 01a12208-f195-7aba-98a6-d1c5d5f5d232 -->

## References
[[m1-legacy#Definition of Done|Milestone criterion]] <!-- ref: 01a12208-f166-7ea2-b2aa-b0794910e2ca -->

Unrelated task prose remains.
