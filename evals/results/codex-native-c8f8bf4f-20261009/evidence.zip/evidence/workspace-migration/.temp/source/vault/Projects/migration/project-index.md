---
id: "01a12208-f01b-7f38-b9ac-f05fee3d0980"
type: "project"
title: "Synthetic migration"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:59:34.003Z"
updated_at: "2026-10-09T18:59:34.003Z"
project-state: "in-progress"
---
# Synthetic migration

## Milestones
- [ ] [[m1-legacy/m1-legacy|Legacy milestone]] <!-- ref: 01a12208-f04c-7f29-b5a1-4aed095a6ea8 -->

Unrelated project prose remains.
