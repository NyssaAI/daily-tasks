import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {isDeepStrictEqual as same} from 'node:util';
const base=path.resolve('.temp'),checks=[];
const json=async p=>JSON.parse(await fs.readFile(p,'utf8'));
function check(name,ok,evidence){checks.push({name,passed:!!ok,evidence});}
for(const name of ['destination','destination-observed','source','log']){
 const d=path.join(base,name),m=await json(path.join(d,'manifest.json')),a=await json(path.join(d,'audit-final.json'));
 const entries=a.query.entries,events=entries.filter(e=>e.action==='workspace.migration');
 check(`${name}: retry has one exact event`,events.length===1&&same(events[0],m.operation.event),`${name}/audit-final.json`);
 check(`${name}: historical lifecycle event unchanged`,m.historyQuery.entries.every(e=>entries.some(x=>same(x,e))),`${name}/audit-final.json`);
 check(`${name}: all declared bytes and absences match`,m.operation.files.every(e=>a.bytes[e.path].sha256===e.after),`${name}/audit-final.json`);
 check(`${name}: verified checkpoint cleared`,!a.checkpointPresent&& (await json(path.join(d,'completion.json'))).status==='completed',`${name}/completion.json`);
 const milestone=a.bytes[m.newM].content;
 check(`${name}: criterion identity, text, satisfaction, evidence and provenance preserved`,milestone.includes(m.ids.criterion)&&milestone.includes('- [x] Reviewed artifact available: [[outputs/review-evidence.txt|Review evidence]].')&&milestone.includes('Accepted legacy review evidence; preserve this narrative.'),`${name}/after.json`);
 const live=Object.values(a.bytes).filter(x=>x.content).map(x=>x.content);
 for(const id of [m.ids.milestone,m.ids.ready,m.ids.completed,m.ids.unresolved])check(`${name}: single live identity ${id}`,live.filter(s=>s.split('\n').includes(`id: "${id}"`)).length===1,`${name}/after.json`);
 for(const [key,file,state] of [['completed','completed-task.md','completed'],['unresolved','unresolved-task.md','not-started']]){
 const content=a.bytes[path.join(m.work,file)].content;
 check(`${name}: ${key} remains readable, unversioned and pending criteria`,content.includes(`task-state: "${state}"`)&&!content.includes('record_version:')&&!content.includes('## Definition of Done')&&content.includes(m.ids[key])&&m.operation.event.after.pending_conversion.includes(m.ids[key]),`${name}/after.json`);
 }
 const blocker=a.bytes[path.join(m.work,'../blockers/b1-review.md')].content;
 check(`${name}: reciprocal milestone blocker`,milestone.includes(`ref: ${m.ids.blocker}`)&&blocker.includes(`ref: ${m.ids.milestone}`)&&!blocker.includes(m.ids.dod),`${name}/after.json`);
 check(`${name}: task and daily criterion refs retain UUID and navigate owner`,Object.entries(a.bytes).filter(([p,v])=>v.content&&(p.endsWith('completed-task.md')||p.includes(`${path.sep}Daily${path.sep}`))).every(([p,v])=>v.content.includes('m1-legacy#Definition of Done')&&v.content.includes(`ref: ${m.ids.criterion}`)),`${name}/after.json`);
 const actions=(await fs.readFile(path.join(d,'actions.ndjson'),'utf8')).trim().split('\n').map(JSON.parse);
 check(`${name}: retirement gate precedes removal`,actions.findIndex(a=>a.text.startsWith('migration-retirement allowed'))>=0&&actions.findIndex(a=>a.text.startsWith('migration-retirement allowed'))<actions.findIndex(a=>a.text.startsWith('Retired old DoD')),`${name}/actions.ndjson`);
}
for(const [name,stage,count,removed] of [['destination-observed','destination',0,false],['source','source',0,true],['log','log',1,true]]){
 const d=path.join(base,name),m=await json(path.join(d,'manifest.json')),a=await json(path.join(d,`audit-interrupted-${stage}.json`));
 check(`Independent interruption after ${stage}: persisted stage and checkpoint`,a.checkpointPresent&&a.bytes[m.newM].sha256===m.operation.files.find(e=>e.path===m.newM).after&&(removed?a.bytes[m.dod].content===null:a.bytes[m.dod].content!==null)&&a.query.entries.filter(e=>e.action==='workspace.migration').length===count,`${name}/audit-interrupted-${stage}.json`);
}
for(const name of ['unexpected-edit','collision']){
 const d=path.join(base,name),m=await json(path.join(d,'manifest.json')),a=await json(path.join(d,'audit-conflict.json'));
 check(`${name}: pending conflict without event or false completion`,a.checkpointPresent&&a.query.entries.every(e=>e.action!=='workspace.migration')&&(await json(path.join(d,'pending-conflict.json'))).status==='pending-conflict',`${name}/audit-conflict.json`);
 check(`${name}: injected content and all sources retained`,a.bytes[m.newM].content.includes(name==='collision'?'UNRELATED Windows':'Unexpected human edit')&&a.bytes[m.dod].content===m.files[m.dod]&&a.bytes[m.oldM].content===m.files[m.oldM],`${name}/audit-conflict.json`);
}
const closure=await json(path.join(base,'competing/closure.json'));
check('Embedded plus standalone closure reports competing sources',!closure.allowed&&closure.reasons.some(x=>x.includes('both embedded and standalone Definition of Done sources')),'competing/closure.json');
const installed='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-rollover-full8/codex-home/plugins/cache/daily-tasks-release-034-rollover-full8/daily-tasks/0.3.4';
const loaded=['skills/daily-tasks/SKILL.md','skills/daily-tasks-records/SKILL.md','skills/daily-tasks-setup/SKILL.md','skills/daily-tasks/references/records.md','skills/daily-tasks/references/operations.md','skills/daily-tasks/references/cli.md','skills/daily-tasks/references/workspace-migration.md','skills/daily-tasks/references/verification.md'];
const sources=await Promise.all(loaded.map(async p=>({path:path.join(installed,p),sha256:crypto.createHash('sha256').update(await fs.readFile(path.join(installed,p))).digest('hex')})));
const report={scenario:'workspace-migration',at:new Date().toISOString(),node:process.version,platform:process.platform,hostVersion:'Not exposed',model:'Not exposed',evidenceType:'Current host skill-instruction-authored file workflows plus installed CLI; not proof of native activation or authenticated plugin registration',sources,missingCriteriaRequest:'Sent in current host via request_user_input_async; no supplied answer; both legacy tasks pending conversion',checks,passed:checks.filter(c=>c.passed).length,total:checks.length};
await fs.writeFile(path.join(base,'scenario8-evidence.json'),JSON.stringify(report,null,2));
const failed=checks.filter(c=>!c.passed);
await fs.writeFile(path.join(base,'scenario8-report.md'),`# Scenario 8 observed workflow evidence\n\n${report.passed}/${report.total} evidence checks passed. ${failed.length?'Failures are retained in scenario8-evidence.json.':'All required migration behaviors were observed.'}\n\nEvidence: skill-authored file workflows and installed CLI in this host. Host version/model and authenticated plugin registration were not exposed; this does not attest native activation. No prior attempts or regression tests were read or run.\n\nEach fixture directory retains before/after bytes, saved operation, actions, installed CLI inputs/results and query-only log evidence. Interruptions were separate process exits, followed by saved-operation resume and a second retry.\n\nMissing task criteria were requested in the host. Completed legacy task retains completion and timestamp; Unresolved legacy task remains readable and open. Both remain unversioned and pending conversion.\n\nUnexpected edit and unrelated uppercase Windows collision remain pending without overwrite or completion. Competing DoD closure is denied.\n\n${checks.map(c=>`- ${c.passed?'PASS':'FAIL'}: ${c.name} — ${c.evidence}`).join('\n')}\n`);
console.log(JSON.stringify({passed:report.passed,total:report.total,failed}));
