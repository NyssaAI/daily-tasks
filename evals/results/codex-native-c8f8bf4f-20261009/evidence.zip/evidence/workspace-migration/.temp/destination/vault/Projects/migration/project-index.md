---
id: "01a12208-9fa9-7088-9963-feec6742e150"
type: "project"
title: "Synthetic migration"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:59:13.386Z"
updated_at: "2026-10-09T18:59:13.386Z"
project-state: "in-progress"
---
# Synthetic migration

## Milestones
- [ ] [[m1-legacy/m1-legacy|Legacy milestone]] <!-- ref: 01a12208-9fd5-71ed-ab52-a105fd948efa -->

Unrelated project prose remains.
