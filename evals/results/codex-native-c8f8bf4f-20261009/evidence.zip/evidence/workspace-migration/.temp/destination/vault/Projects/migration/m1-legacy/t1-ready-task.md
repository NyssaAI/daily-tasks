---
id: "01a12208-a032-7eee-a7a1-1e1c254614e0"
type: "task"
record_version: 2
title: "Ready task"
owner: "synthetic@example.test"
created_at: "2026-10-09T18:59:13.386Z"
updated_at: "2026-10-09T18:59:13.386Z"
task-state: "in-progress"
project_id: "01a12208-9fa9-7088-9963-feec6742e150"
milestone_id: "01a12208-9fd5-71ed-ab52-a105fd948efa"
---
# Ready task

**Milestone:** [[m1-legacy|Legacy milestone]] <!-- ref: 01a12208-9fd5-71ed-ab52-a105fd948efa -->

## Requirements
Produce a distinct task artifact.

## Definition of Done
- [ ] Task artifact independently reviewed. <!-- id: 01a12208-a10e-7d48-80e4-f785e381f12c -->

## References
[[m1-legacy#Definition of Done|Milestone criterion]] <!-- ref: 01a12208-a0e2-7e78-b1df-f7fdc08633af -->

Unrelated task prose remains.
