import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {cli,context,scope,projects,hash,read,inspect,temp,pkg} from './workflow.mjs';
const initial=inspect().records;
const P=initial.find(r=>r.type==='project'), M=initial.find(r=>r.type==='milestone');
const T1=initial.find(r=>r.title==='Update LinkedIn'), T2=initial.find(r=>r.title==='Update resume');
const resume=process.argv.includes('--resume');
const assertions=resume?JSON.parse(read(path.join(temp,'assertions.json'))):[];
function pass(name,data){assertions.push({name,passed:true,data});fs.writeFileSync(path.join(temp,'assertions.json'),JSON.stringify(assertions,null,2));console.log(name);}
function field(text,key,value){const re=new RegExp('^'+key+':.*$','m');return re.test(text)?text.replace(re,key+': '+JSON.stringify(value)):text.replace(/^---\r?\n/,'---\n'+key+': '+JSON.stringify(value)+'\n');}
function state(text,type,value){text=field(text,type+'-state',value);if(value!=='completed'&&value!=='resolved')text=text.replace(/^resolved_at:.*\r?\n/gm,'');return text;}
function criterion(text,checked){return text.replace(/(- )\[[ x]\]( .*<!-- id:)/g,'$1['+(checked?'x':' ')+']$2');}
function records(){return inspect().records;}
function closure(r,allowed,label){const out=cli('check-closure',{recordId:r.id,records:records()});assert.equal(out.allowed,allowed,JSON.stringify(out));pass(label,out);return out;}
let n=resume?Math.max(0,...fs.readdirSync(temp).filter(s=>/^\d\d-/.test(s)).map(s=>Number(s.slice(0,2)))):0;
function commit(label,changes){
 const stamp=cli('activity-time',{}), oid=cli('new-id').id,eid=cli('new-id').id;
 const dir=path.join(temp,String(++n).padStart(2,'0')+'-'+label);fs.mkdirSync(dir,{recursive:true});
 const files=[];const before={},after={};
 for(const [p,content] of changes){const old=fs.existsSync(p)?read(p):null;files.push({path:p,before:old===null?null:hash(old),after:hash(content)});before[p]=old;after[p]=content;fs.writeFileSync(path.join(dir,path.basename(p)+'.before.txt'),old??'<absent>');fs.writeFileSync(path.join(dir,path.basename(p)+'.after.txt'),content);}
 const ids=initial.filter(r=>changes.has(r.path)).map(r=>r.id);if(B&&changes.has(B.path)&&!ids.includes(B.id))ids.push(B.id);
 const event={id:eid,operation_id:oid,action:'acceptance.closure.'+label,record_ids:ids,actor:{kind:'agent',id:'codex'},...stamp,original_words:'User-authorized scenario5 manual edits and synthetic reviewed evidence',before,after};
 const checkpoint={schemaVersion:2,operation_id:oid,contextBinding:context.planningBinding,event,files};
 const operationPath=path.join(context.stateRoot,'operations',oid+'.json');fs.mkdirSync(path.dirname(operationPath),{recursive:true});fs.writeFileSync(operationPath,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(dir,'checkpoint.json'),JSON.stringify(checkpoint,null,2));
 for(const f of files){assert.equal(fs.existsSync(f.path)?hash(read(f.path)):null,f.before);fs.mkdirSync(path.dirname(f.path),{recursive:true});fs.writeFileSync(f.path,changes.get(f.path));}
 cli('invalidate-project-index',{vaultRoot:context.vaultRoot});
 const inspected=inspect();fs.writeFileSync(path.join(dir,'inspection.json'),JSON.stringify(inspected,null,2));
 cli('log-append',{projectsRoot:projects,entry:event});
 const query=cli('log-query',{projectsRoot:projects,action:event.action});fs.writeFileSync(path.join(dir,'log-query.json'),JSON.stringify(query,null,2));
 const verified=cli('operation-verify',{...scope,operationPath});assert.equal(verified.status,'verified',JSON.stringify(verified));
 const completed=cli('operation-complete',{...scope,operationPath});assert.equal(completed.status,'completed',JSON.stringify(completed));
}
let B=initial.find(r=>r.type==='blocker');
function withViews(changes){const proposed=records().map(r=>changes.has(r.path)?cli('parse-record',{markdown:changes.get(r.path),path:r.path}):r);const byId=new Map(proposed.map(r=>[r.id,r]));for(const parent of [M,P]){let text=changes.get(parent.path)??read(parent.path);text=text.split('\n').map(line=>{const ref=line.match(/<!-- ref: ([\w-]+) -->/);const r=ref&&byId.get(ref[1]);if(r&&['task','milestone'].includes(r.type)&&/\[[ x>\-]\]/.test(line)){const box={completed:'x',cancelled:'-', 'in-progress':'>','not-started':' '}[r.state];line=line.replace(/\[[ x>\-]\]/,'['+box+']');if(r.state==='cancelled'&&!line.includes('~~'))line=line.replace(/(\[\[.*?\]\])/,'~~$1~~');if(r.state!=='cancelled')line=line.replaceAll('~~','');}return line;}).join('\n');if(text!==read(parent.path))changes.set(parent.path,text);}return changes;}
function transition(r,value,label){if(value==='completed')closure(r,true,label+'-eligible');const stamp=cli('activity-time',{});let text=state(read(r.path),r.type,value);text=field(text,'updated_at',stamp.recorded_at);if(value==='completed'||value==='resolved'||value==='cancelled')text=field(text,'resolved_at',stamp.activity_at);commit(label,withViews(new Map([[r.path,text]])));}
function reopen(label,changes,changedIds){const proposed=records().map(r=>changes.has(r.path)?cli('parse-record',{markdown:changes.get(r.path),path:r.path}):r);const out=cli('reopen-ancestors',{records:proposed,changedIds});fs.writeFileSync(path.join(temp,label+'-proposal.json'),JSON.stringify(out,null,2));for(const r of out.records){const old=proposed.find(x=>x.id===r.id);if(old&&r.state!==old.state)changes.set(r.path,state(changes.get(r.path)??read(r.path),r.type,r.state));}commit(label,withViews(changes));return out;}
function states(label,expected){const rs=records();for(const [r,s]of expected)assert.equal(rs.find(x=>x.id===r.id).state,s);pass(label,expected.map(([r,s])=>({title:r.title,state:s})));}
fs.writeFileSync(path.join(temp,'loaded-skills.json'),JSON.stringify({package:pkg,skills:['daily-tasks','daily-tasks-records','daily-tasks-setup'],references:['records.md','operations.md','cli.md','verification.md'],host:'Codex native tool session; model/version not exposed',authority:'Current user scenario5 request; existing records only; one new shared blocker'},null,2));
if(!resume){
closure(T1,false,'unchecked-task-DoD-gates-closure');
closure(M,false,'unchecked-milestone-DoD-and-unresolved-children-gate-closure');
closure(P,false,'unresolved-milestone-gates-project');
const originalCriterion=read(T1.path).match(/- \[ \] A reviewed headline.*<!-- id:.* -->/)[0];
commit('missing-task-DoD',new Map([[T1.path,read(T1.path).replace(/## Definition of Done\r?\n[\s\S]*?(?=## Inputs)/,'')]]));
closure(T1,false,'version2-task-missing-DoD-cannot-complete');
commit('empty-task-DoD',new Map([[T1.path,read(T1.path).replace('## Inputs','## Definition of Done\n\n## Inputs')]]));
closure(T1,false,'version2-task-empty-DoD-cannot-complete');
commit('restore-original-task-criterion',new Map([[T1.path,read(T1.path).replace('## Definition of Done\n\n','## Definition of Done\n\n'+originalCriterion+'\n\n')]]));
pass('original-task-criterion-restored',originalCriterion);
const number=cli('next-record-number',{projectsRoot:projects,type:'blocker',parentId:P.id});assert.equal(number.number,1);
B={id:cli('new-id').id,type:'blocker',path:path.join(path.dirname(P.path),'blockers','b1-await-approval.md'),title:'Await approval'};
const time=cli('activity-time',{});
const blocker=`---\nid: "${B.id}"\ntype: blocker\nrecord_version: 2\ntitle: "Await approval"\nblocker-state: open\nowner: "${P.owner}"\nproject_id: "${P.id}"\ncreated_at: "${time.activity_at}"\nupdated_at: "${time.recorded_at}"\n---\n# Await approval\n\nExternal synthetic reviewer approval is pending for both career materials.\n\n## Resolution condition\nThe synthetic reviewer approves both local artifacts.\n\n## Resolution evidence\nAwaiting approval.\n\n## Blocks\n- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: ${T1.id} -->\n- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: ${T2.id} -->\n`;
const changes=new Map([[B.path,blocker]]);for(const t of [T1,T2])changes.set(t.path,read(t.path)+`\n## Blocked by\n- [[../blockers/b1-await-approval|Await approval]] <!-- ref: ${B.id} -->\n`);commit('shared-blocker-created',changes);
const links=cli('check-links',{records:records()});fs.writeFileSync(path.join(temp,'shared-links.json'),JSON.stringify(links,null,2));pass('one-shared-blocker-reciprocal-to-both-tasks',links);
const outputs=path.join(path.dirname(M.path),'outputs');const headline=path.join(outputs,'reviewed-linkedin-headline.md'),summary=path.join(outputs,'reviewed-resume-summary.md');
const evidence=new Map([[headline,'# Reviewed LinkedIn headline\n\nSoftware engineer | Reliable products and clear technical communication\n\nSynthetic acceptance artifact. Reviewed by the authorized synthetic reviewer; meets the existing headline criterion.\n'],[summary,'# Reviewed resume summary\n\nSoftware engineer who builds reliable products, investigates problems carefully, and communicates clearly with collaborators.\n\nSynthetic acceptance artifact. Reviewed by the authorized synthetic reviewer; meets the existing summary criterion.\n']]);
for(const [t,file]of [[T1,headline],[T2,summary]]){let text=criterion(read(t.path),true).replace('Work has not started; no artifact has been produced or reviewed.',`Synthetic reviewer confirmed the local artifact meets the existing criterion: [Reviewed artifact](outputs/${path.basename(file)}).`);evidence.set(t.path,text);}
evidence.set(M.path,read(M.path)+'\n## Reviewed artifacts\n- [Reviewed headline](outputs/reviewed-linkedin-headline.md)\n- [Reviewed summary](outputs/reviewed-resume-summary.md)\n\nSynthetic reviewer verified both artifacts and links; milestone criterion remains unchecked for gate verification.\n');commit('reviewed-task-evidence',evidence);
closure(T1,false,'shared-open-blocker-gates-LinkedIn');closure(T2,false,'shared-open-blocker-gates-resume');
commit('satisfy-milestone-criterion',new Map([[M.path,criterion(read(M.path),true)]]));closure(M,false,'satisfied-milestone-DoD-does-not-close-unresolved-children');
transition(B,'resolved','resolve-shared-blocker');
transition(T2,'cancelled','cancel-resume-prerequisite');
commit('cancelled-dependency-linked',new Map([[T1.path,read(T1.path)+`\n## Depends on\n- [[t2-update-resume|Update resume]] <!-- ref: ${T2.id} -->\n\nPrerequisite cancelled; dependency is informational.\n`],[T2.path,read(T2.path)+`\n## Required by\n- [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${T1.id} -->\n`]]));
}else{
// Correct the authored blocker transition: the initial descriptor omitted its type.
const corrected=read(B.path).replace(/^undefined-state:.*\r?\n/gm,'');
commit('correct-blocker-transition',new Map([[B.path,state(corrected,'blocker','resolved')]]));
}
closure(T1,true,'cancelled-dependency-is-informational');transition(T1,'completed','complete-LinkedIn-with-cancelled-dependency');
closure(M,true,'cancelled-child-is-explicit-disposition');
reopen('explicitly-reopen-resume',new Map([[T2.path,state(read(T2.path),'task','not-started')]]),[T2.id]);transition(T2,'completed','complete-resume');
commit('milestone-criterion-unchecked-gate',new Map([[M.path,criterion(read(M.path),false)]]));closure(M,false,'completed-children-do-not-satisfy-milestone-DoD');
commit('milestone-criterion-confirmed',new Map([[M.path,criterion(read(M.path),true)]]));transition(M,'completed','close-milestone');transition(P,'completed','close-project');
states('eligible-tasks-and-parents-closed',[[T1,'completed'],[T2,'completed'],[M,'completed'],[P,'completed']]);
reopen('reopen-shared-blocker',new Map([[B.path,state(read(B.path),'blocker','open')]]),[B.id]);states('blocker-reopens-parents-preserves-tasks',[[T1,'completed'],[T2,'completed'],[M,'in-progress'],[P,'in-progress']]);closure(M,false,'reopened-shared-blocker-gates-parent');
transition(B,'resolved','resolve-reopened-blocker');transition(M,'completed','reclose-milestone-after-blocker');transition(P,'completed','reclose-project-after-blocker');
reopen('uncheck-milestone-DoD',new Map([[M.path,criterion(read(M.path),false)]]),[M.id]);states('milestone-DoD-reopens-parents-preserves-tasks',[[T1,'completed'],[T2,'completed'],[M,'in-progress'],[P,'in-progress']]);
commit('restore-milestone-DoD',new Map([[M.path,criterion(read(M.path),true)]]));transition(M,'completed','reclose-milestone-after-DoD');transition(P,'completed','reclose-project-after-DoD');
reopen('uncheck-task-DoD',new Map([[T1.path,criterion(read(T1.path),false)]]),[T1.id]);states('task-DoD-reopens-task-and-parents',[[T1,'not-started'],[T2,'completed'],[M,'in-progress'],[P,'in-progress']]);
commit('restore-task-reviewed-criterion',new Map([[T1.path,criterion(read(T1.path),true)]]));transition(T1,'completed','reclose-LinkedIn');transition(M,'completed','reclose-milestone-after-task');transition(P,'completed','reclose-project-after-task');
// Retain a real prior start to demonstrate the explicit state takes precedence over fallback.
commit('retain-explicit-synthetic-prior-start',new Map([[T1.path,field(read(T1.path),'started_at',cli('activity-time',{}).activity_at)]]));
reopen('explicit-reopen-LinkedIn-not-started',new Map([[T1.path,state(read(T1.path),'task','not-started')]]),[T1.id]);states('explicit-not-started-overrides-prior-start',[[T1,'not-started'],[T2,'completed'],[M,'in-progress'],[P,'in-progress']]);
const final=inspect();cli('validate-records',{records:final.records});cli('check-links',{records:final.records});cli('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot});cli('log-query',{projectsRoot:projects,limit:1000});
assert.equal(final.records.filter(r=>r.type==='task').length,2);assert.equal(final.records.filter(r=>r.type==='blocker').length,1);
fs.writeFileSync(path.join(temp,'final-records.json'),JSON.stringify(final,null,2));
fs.writeFileSync(path.join(temp,'report.md'),`# Scenario5 closure\n\nExecuted against the original Job Search project, Career materials milestone and two tasks through the installed 0.3.4 instructions and CLI in this native tool session. No previous attempt, regression test or personal directory was read.\n\n${assertions.map(a=>'- PASS: '+a.name).join('\n')}\n\nFinal state: LinkedIn explicitly reopened as not-started; resume completed; milestone/project in-progress; shared blocker resolved. Original task criterion and its identity restored. Before/after bytes, checkpoints, CLI input/result envelopes and log queries are retained beside this report.\n\nThis records actual skill-authored native session actions; it does not infer host activation from packaging or direct CLI tests. Host model/version and independent plugin-registration evidence were not exposed.\n`);
