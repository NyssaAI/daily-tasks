import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {cli,context,scope,projects,hash,read,inspect,temp} from './workflow.mjs';
const rs=inspect().records, time=cli('activity-time',{}), id=cli('new-id').id;
const changes=new Map();
for(const r of rs){let text=read(r.path);if(r.type==='blocker')text=text.replace('External synthetic reviewer approval is pending for both career materials.','Synthetic reviewer approval for both career materials has been received.').replace('Awaiting approval.','User-authorized synthetic reviewer approved both reviewed local artifacts; approval was reopened and resolved during scenario5.');if(r.type==='milestone')text=text.replace('milestone criterion remains unchecked for gate verification.','milestone criterion was independently confirmed after gate verification.');if(r.title==='Update LinkedIn')text=text.replace('Prerequisite cancelled; dependency is informational.','The prerequisite was cancelled during gate verification and explicitly reopened/completed afterward; dependency remains informational.');if(text!==read(r.path))changes.set(r.path,text);}
const dir=path.join(temp,'final-evidence-prose');fs.mkdirSync(dir,{recursive:true});
const files=[...changes].map(([p,t])=>{fs.writeFileSync(path.join(dir,path.basename(p)+'.before.txt'),read(p));fs.writeFileSync(path.join(dir,path.basename(p)+'.after.txt'),t);return {path:p,before:hash(read(p)),after:hash(t)};});
const event={id:cli('new-id').id,operation_id:id,action:'acceptance.closure.final-evidence-prose',record_ids:rs.filter(r=>changes.has(r.path)).map(r=>r.id),actor:{kind:'agent',id:'codex'},...time,after:{reason:'Align current narrative with observed synthetic approval and criteria history.'}};
const checkpoint={schemaVersion:2,operation_id:id,contextBinding:context.planningBinding,event,files};
const operationPath=path.join(context.stateRoot,'operations',id+'.json');fs.writeFileSync(operationPath,JSON.stringify(checkpoint,null,2));fs.writeFileSync(path.join(dir,'checkpoint.json'),JSON.stringify(checkpoint,null,2));
for(const f of files){assert.equal(hash(read(f.path)),f.before);fs.writeFileSync(f.path,changes.get(f.path));}
cli('invalidate-project-index',{vaultRoot:context.vaultRoot});cli('log-append',{projectsRoot:projects,entry:event});
assert.equal(cli('operation-verify',{...scope,operationPath}).status,'verified');assert.equal(cli('operation-complete',{...scope,operationPath}).status,'completed');
const final=inspect();assert.deepEqual(final.diagnostics,[]);assert.deepEqual(cli('validate-records',{records:final.records}).diagnostics,[]);assert.deepEqual(cli('check-links',{records:final.records}).diagnostics,[]);assert.deepEqual(cli('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot}).diagnostics,[]);
const queried=cli('log-query',{projectsRoot:projects,limit:1000});
let matched=0;for(const d of fs.readdirSync(temp,{withFileTypes:true}).filter(d=>d.isDirectory())){const p=path.join(temp,d.name,'checkpoint.json');if(!fs.existsSync(p))continue;const saved=JSON.parse(read(p));const found=queried.entries.filter(e=>e.operation_id===saved.operation_id);assert.equal(found.length,1);assert.deepEqual(found[0],saved.event);matched++;}
assert.equal(fs.readdirSync(path.join(context.stateRoot,'operations')).length,0);
fs.writeFileSync(path.join(temp,'final-records.json'),JSON.stringify(final,null,2));fs.writeFileSync(path.join(temp,'final-log-query.json'),JSON.stringify(queried,null,2));
const audit={matchedExactEvents:matched,metadataDiagnostics:[],linkDiagnostics:[],navigationDiagnostics:[],pendingOperations:0,authoredWorkflowError:'Initial blocker descriptor omitted type, producing undefined-state while leaving blocker open. Its unexpected denial was retained; corrected through a new verified operation, then resumed without replaying earlier steps.',initialCliError:'Relative --input rejected; subsequent CLI inputs are absolute.',originalCriterionPreserved:true};fs.writeFileSync(path.join(temp,'final-audit.json'),JSON.stringify(audit,null,2));
fs.appendFileSync(path.join(temp,'report.md'),`\nFinal audit: ${matched} exact checkpoint events each queried once; no pending operations; no metadata, relationship or navigation diagnostics. One authored blocker-edit error and the initial relative-input rejection are retained in the evidence, with correction details in final-audit.json.\n`);
console.log(JSON.stringify(audit,null,2));
