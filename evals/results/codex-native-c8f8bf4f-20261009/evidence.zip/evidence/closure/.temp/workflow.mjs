import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export const root=process.cwd(), temp=path.join(root,'.temp'), vault=path.join(root,'vault');
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-rollover-full8/codex-home/plugins/cache/daily-tasks-release-034-rollover-full8/daily-tasks/0.3.4';
let count=fs.existsSync(path.join(temp,'sequence.txt'))?Number(fs.readFileSync(path.join(temp,'sequence.txt'),'utf8')):0;
export function cli(op,input){const stem=String(++count).padStart(3,'0')+'-'+op;fs.writeFileSync(path.join(temp,'sequence.txt'),String(count));const p=path.join(temp,stem+'.input.json');if(input)fs.writeFileSync(p,JSON.stringify(input,null,2));const args=[path.join(pkg,'bin/daily-tasks.mjs'),op,...(input?['--input',p]:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(path.join(temp,stem+'.result.json'),JSON.stringify({command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const context=cli('resolve-context',{vaultRoot:vault});
export const scope={vaultRoot:vault,profilePath:context.profilePath,stateRoot:context.stateRoot};
export const projects=context.projectsRoot;
export const hash=s=>createHash('sha256').update(s).digest('hex');
export const read=p=>fs.readFileSync(p,'utf8');
export function inspect(){return cli('inspect-records',{projectsRoot:projects});}
if(process.argv[1]===path.join(temp,'workflow.mjs'))console.log(JSON.stringify({context,inspection:inspect()},null,2));
