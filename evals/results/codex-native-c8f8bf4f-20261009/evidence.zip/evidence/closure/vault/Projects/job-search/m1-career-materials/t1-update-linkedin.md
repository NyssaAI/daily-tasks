---
started_at: "2026-10-09T19:00:24.648Z"
id: "01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8"
type: "task"
record_version: 2
title: "Update LinkedIn"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T19:00:22.565Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: "reviewed"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a headline.

## Definition of Done

- [x] A reviewed headline is saved locally. <!-- id: 01a1211c-fcde-77f4-84d8-63271f429f17 -->

## Inputs

No source material has been supplied. Local working inputs belong in inputs/.

## Output and delivery

Save the headline locally in outputs/. Link the actual artifact here and from the milestone after review.

## Verification

Confirm the headline was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Synthetic reviewer confirmed the local artifact meets the existing criterion: [Reviewed artifact](outputs/reviewed-linkedin-headline.md).

## Blocked by
- [[../blockers/b1-await-approval|Await approval]] <!-- ref: 01a12209-1aa5-7fb3-9d45-da3cd9f32a4e -->

## Depends on
- [[t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->

The prerequisite was cancelled during gate verification and explicitly reopened/completed afterward; dependency remains informational.
