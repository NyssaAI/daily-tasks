---
id: "01a12208-d26e-7876-b539-58b5ca7e81d0"
type: blocker
record_version: 2
title: "Await signoff"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:59:25.982Z"
updated_at: "2026-10-09T18:59:25.982Z"
---
# Await signoff

Waiting for signoff from the user.

## Resolution condition

User supplies signoff.

## Resolution evidence

None supplied.

## Blocks
