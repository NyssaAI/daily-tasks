---
id: "01a12208-cb97-72c5-ac3f-746f6d92e11b"
type: blocker
record_version: 2
title: "Await review"
blocker-state: resolved
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:59:24.228Z"
updated_at: "2026-10-09T18:59:25.360Z"
resolved_at: "2026-10-09T18:59:25.360Z"
---
# Await review

Waiting for review from the user.

## Resolution condition

User supplies review.

## Resolution evidence

Resolved by explicit user instruction in this scenario.

## Blocks
