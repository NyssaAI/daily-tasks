# Resume summary draft

Career professional preparing for the next opportunity, with career materials being developed for a focused job search.

Uses the headline wording from [T1 headline draft](career-headline-draft.md) in place. Sources contain synthetic labels only; qualifications and achievements require user input and review.
