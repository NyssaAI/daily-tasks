---
id: "01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8"
type: "task"
record_version: 2
title: "Update LinkedIn"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T18:59:23.549Z"
task-state: "cancelled"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: "reviewed"
resolved_at: "2026-10-09T18:59:23.549Z"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a headline.

## Definition of Done

- [ ] A reviewed headline is saved locally. <!-- id: 01a1211c-fcde-77f4-84d8-63271f429f17 -->

## Inputs

- [LinkedIn source](inputs/linkedin-source.txt), imported from attachments/a/source.txt.
- [Shared style guide](inputs/style-guide.txt), imported once from attachments/shared.txt.

## Output and delivery

Local draft: [Headline draft](outputs/career-headline-draft.md). User review remains required.

## Verification

Confirm the headline was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Produced [Headline draft](outputs/career-headline-draft.md). Draft only; no review evidence supplied.

## Blocked by

- [[../blockers/b2-await-source|Await source]] <!-- ref: 01a12208-ce01-7b9b-a971-454df8f70896 -->
