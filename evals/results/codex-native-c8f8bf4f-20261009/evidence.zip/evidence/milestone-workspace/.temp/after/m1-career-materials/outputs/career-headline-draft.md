# LinkedIn headline draft

Career professional preparing for the next opportunity

Synthetic draft based on the LinkedIn source label and shared style guide label. No professional history was supplied; user review required.
