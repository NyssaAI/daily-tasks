# Scenario 7 — Milestone workspace

PASS — 12/12 assertion groups.

- PASS: Initial numbered milestone and sibling tasks with empty flat holding folders
- PASS: Both same-basename originals preserved under meaningful distinct names
- PASS: One shared copy linked from both consumers; inputs and outputs remain flat
- PASS: Two outputs delivered and T2 consumes T1 output in place
- PASS: Requirements and criterion identity/text preserved and distinct; drafts do not satisfy review
- PASS: Copied-ID task-shaped attachment excluded from records and planning inventory
- PASS: Reordered tasks retain T1/T2 labels; T1 cancelled and accepted T3 owns its criteria; next is T4
- PASS: B1 resolved; B2 and B3 open; stable labels and one reciprocal shared B2
- PASS: Project to milestone to tasks to files navigation valid
- PASS: Rename repairs all affected live links and preserves unrelated prose
- PASS: All operations verified and completed with retained CLI log-query evidence
- PASS: All local work effects remain inside the project and disposable scratch is in case .temp

Actual actions, before/after copies, installed CLI structured inputs/results, operation checkpoints/completions and log-query evidence are retained beside this report. No prior attempts, regression tests or personal records were read. Host version/model were not exposed; this receipt does not infer activation from packaging.
