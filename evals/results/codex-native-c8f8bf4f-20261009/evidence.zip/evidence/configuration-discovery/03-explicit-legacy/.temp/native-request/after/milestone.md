---
id: 01a12208-b553-767e-826b-b6d61fcc2db4
type: milestone
record_version: 2
title: "Update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-84da-767f-85fe-ac147d7ce5e7"
created_at: "2026-10-09T18:59:18.684Z"
updated_at: "2026-10-09T18:59:18.684Z"
---
# M1 — Update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-84da-767f-85fe-ac147d7ce5e7 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] Reviewed career materials. <!-- id: 01a12208-b587-7fa2-a5d8-ef3b219e1a3c -->

## Tasks

No tasks accepted.
