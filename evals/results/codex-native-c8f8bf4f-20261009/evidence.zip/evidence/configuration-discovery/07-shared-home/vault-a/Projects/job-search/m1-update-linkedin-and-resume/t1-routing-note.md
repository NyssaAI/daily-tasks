---
id: 01a12207-bd5c-76a6-a091-9a23bfaaabbe
type: task
record_version: 2
title: "Routing note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
milestone_id: "01a12207-bd2a-7a32-bb69-9cea566af994"
created_at: "2026-10-09T18:58:15.234Z"
updated_at: "2026-10-09T18:58:15.234Z"
---
# M1-T1 — Routing note

**Milestone:** [[m1-update-linkedin-and-resume|update LinkedIn and resume]] <!-- ref: 01a12207-bd2a-7a32-bb69-9cea566af994 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Requirements

local routing test note

## Definition of Done

- [ ] reviewed routing note <!-- id: 01a12207-bdb7-765c-88e7-c00d6a7dcd7b -->

## Output and delivery

Local note in the milestone's flat outputs/ folder.

## Verification

Review the routing note against the requirement and explicitly record criterion satisfaction.
