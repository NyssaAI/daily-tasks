---
id: 01a12207-bd2a-7a32-bb69-9cea566af994
type: milestone
record_version: 2
title: "update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
created_at: "2026-10-09T18:58:15.234Z"
updated_at: "2026-10-09T18:58:15.234Z"
---
# M1 — update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] reviewed career materials <!-- id: 01a12207-bd8b-74d6-8789-9f88df69217d -->

## Tasks

- [ ] [[t1-routing-note|Routing note]] <!-- ref: 01a12207-bd5c-76a6-a091-9a23bfaaabbe -->
