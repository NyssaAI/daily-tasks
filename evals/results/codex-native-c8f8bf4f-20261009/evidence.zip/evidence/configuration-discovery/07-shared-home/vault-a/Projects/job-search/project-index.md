---
id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:11.958Z"
updated_at: "2026-10-09T18:58:15.234Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [ ] [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — update LinkedIn and resume]] <!-- ref: 01a12207-bd2a-7a32-bb69-9cea566af994 -->

## Tasks

| Status | Task | Owner |
| --- | --- | --- |
| [ ] | [[m1-update-linkedin-and-resume/t1-routing-note\|Routing note]] <!-- ref: 01a12207-bd5c-76a6-a091-9a23bfaaabbe --> | synthetic@example.test |
