import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export const root=process.cwd();
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-rollover-full8/codex-home/plugins/cache/daily-tasks-release-034-rollover-full8/daily-tasks/0.3.4';
export const context={vaultRoot:path.join(root,'vault-a'),profilePath:path.join(root,'synthetic-home/.nyssaai/daily-tasks/profile.json'),homeRoot:path.join(root,'synthetic-home')};
export const save=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
export const hash=s=>createHash('sha256').update(s).digest('hex');
let n=fs.existsSync('.temp/counter')?Number(fs.readFileSync('.temp/counter','utf8')):0;
export function cli(op,input){const label=String(++n).padStart(3,'0')+'-'+op;save('.temp/counter',String(n));const ip=path.join(root,'.temp',label+'.input.json');if(input)save(ip,input);const args=[pkg+'/bin/daily-tasks.mjs',op,...(input?['--input',ip]:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});save('.temp/'+label+'.result.json',r.stdout||r.stderr);save('.temp/'+label+'.execution.json',{args,exitCode:r.status,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
export const id=()=>cli('new-id').id;
