import fs from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';

const root=process.cwd();
const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-rollover-full8/codex-home/plugins/cache/daily-tasks-release-034-rollover-full8/daily-tasks/0.3.4';
const cli=path.join(bundle,'bin/daily-tasks.mjs');
const sha=x=>createHash('sha256').update(x).digest('hex');
const write=async(p,x)=>{await fs.mkdir(path.dirname(p),{recursive:true}); await fs.writeFile(p,x);};
const json=async(p,x)=>write(p,JSON.stringify(x,null,2)+'\n');
const request='Create M1: update LinkedIn and resume in this project; DoD reviewed career materials; no extra tasks.';
for(const name of ['02-no-profile','03-explicit-legacy','04-vault-only-legacy']){
 const cwd=path.join(root,name), temp=path.join(cwd,'.temp/native-request');
 await fs.mkdir(temp,{recursive:true}); let seq=0;
 const call=async(op,input)=>{
  const prefix=path.join(temp,String(++seq).padStart(2,'0')+'-'+op);
  const args=[cli,op];
  if(input!==undefined){await json(prefix+'.input.json',input);args.push('--input',prefix+'.input.json');}
  const r=spawnSync(process.execPath,args,{cwd,encoding:'utf8'});
  await json(prefix+'.execution.json',{cwd,command:process.execPath,args,status:r.status,stdout:r.stdout,stderr:r.stderr});
  if(r.status!==0)throw Error(name+' '+op+': '+r.stderr);
  const value=JSON.parse(r.stdout); await json(prefix+'.result.json',value);return op==='new-id'?value.id:value;
 };
 const f=JSON.parse(await fs.readFile(path.join(cwd,'fixture.json'),'utf8'));
 const vaultRoot=f.vaults[0], projectsRoot=path.join(vaultRoot,'Projects');
 const indexPath=path.join(projectsRoot,'job-search/project-index.md');
 const indexBefore=await fs.readFile(indexPath,'utf8');
 await write(path.join(temp,'before/project-index.md'),indexBefore);
 const input={vaultRoot,homeRoot:f.home,stateRoot:path.join(vaultRoot,'.nyssaai/daily-tasks')};
 if(name.startsWith('01')||name.startsWith('02'))input.profilePath=path.join(f.common,'daily-tasks/profile.json');
 if(name.startsWith('03'))input.profilePath=path.join(vaultRoot,'.nyssa/daily-tasks/profile.json');
 let context=await call('resolve-context',input);
 let profileBefore=null;
 if(context.configured){profileBefore=await fs.readFile(context.profilePath);await write(path.join(temp,'before/profile.json'),profileBefore);}
 else{
  if(name!=='02-no-profile')throw Error('Unexpected missing profile');
  const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
  const valid=await call('validate-profile',profile);if(!valid.valid)throw Error(JSON.stringify(valid));
  await json(input.profilePath,profile);
  context=await call('resolve-context',input);
  const time=await call('activity-time',{});
  const id=await call('new-id'),opid=await call('new-id');
  await call('log-append',{projectsRoot,entry:{id,operation_id:opid,action:'profile.configured',record_ids:[],actor:{kind:'person',id:'synthetic@example.test'},...time,original_words:'Initialize accepted common scope for Synthetic User synthetic@example.test America/Chicago; no priorities supplied.',before:null,after:profile}});
  await call('log-query',{projectsRoot,action:'profile.configured'});
 }
 await call('--help');
 await json(path.join(temp,'request.json'),{request,user:'Synthetic User',email:'synthetic@example.test',timezone:'America/Chicago',acceptedScope:f.acceptedScope,context,node:process.version});
 const recordsBefore=await call('inspect-records',{projectsRoot});
 const parsed=await call('parse-record',{markdown:indexBefore,path:indexPath});
 await json(path.join(temp,'parsed-project.json'),parsed);
 const projectId=/^id:\s*"?([^"\r\n]+)"?$/m.exec(indexBefore)[1];
 const number=await call('next-record-number',{projectsRoot,type:'milestone',parentId:projectId});
 if(number.number!==1)throw Error('M1 number conflict '+JSON.stringify(number));
 const milestoneId=await call('new-id'),criterionId=await call('new-id'),operationId=await call('new-id'),eventId=await call('new-id');
 const timing=await call('activity-time',{});
 const slug='m1-update-linkedin-and-resume';
 const dir=path.join(projectsRoot,'job-search',slug), milestonePath=path.join(dir,slug+'.md');
 const milestone=`---\nid: ${milestoneId}\ntype: milestone\nrecord_version: 2\ntitle: "Update LinkedIn and resume"\ndocument-maturity: reviewed\nmilestone-state: not-started\nowner: "synthetic@example.test"\nproject_id: "${projectId}"\ncreated_at: "${timing.activity_at}"\nupdated_at: "${timing.recorded_at}"\n---\n# M1 — Update LinkedIn and resume\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${projectId} -->\n\n## Outcome\n\nUpdate LinkedIn and resume for the job search.\n\n## Definition of Done\n\n- [ ] Reviewed career materials. <!-- id: ${criterionId} -->\n\n## Tasks\n\nNo tasks accepted.\n`;
 const indexAfter=indexBefore.replace(/^updated_at:.*$/m,`updated_at: "${timing.recorded_at}"`).replace('No milestones yet.',`- [ ] [[${slug}/${slug}|M1 — Update LinkedIn and resume]] <!-- ref: ${milestoneId} -->`);
 const event={id:eventId,operation_id:operationId,action:'milestone.accepted',record_ids:[milestoneId],actor:{kind:'person',id:'synthetic@example.test'},...timing,original_words:request,before:null,after:{title:'Update LinkedIn and resume',project_id:projectId,'milestone-state':'not-started',owner:'synthetic@example.test',definition_of_done:'Reviewed career materials',acceptance_source:'Direct named user create instruction',tasks:[]}};
 const checkpoint={schemaVersion:2,operation_id:operationId,contextBinding:context.planningBinding,event,files:[{path:milestonePath,before:null,after:sha(milestone)},{path:indexPath,before:sha(indexBefore),after:sha(indexAfter)}]};
 const operationPath=path.join(context.stateRoot,'operations',operationId+'.json');
 await json(operationPath,checkpoint); await json(path.join(temp,'checkpoint.json'),checkpoint);
 if(sha(await fs.readFile(indexPath))!==sha(indexBefore))throw Error('Project changed');
 try{await fs.access(milestonePath);throw Error('Milestone exists');}catch(e){if(e.code!=='ENOENT')throw e;}
 await write(path.join(projectsRoot,'job-search/.temp',operationId+'-project-before.md'),indexBefore);
 await fs.mkdir(path.join(dir,'inputs'),{recursive:true});await fs.mkdir(path.join(dir,'outputs'),{recursive:true});
 await write(milestonePath,milestone); await write(indexPath,indexAfter);
 const inspected=await call('inspect-records',{projectsRoot});
 const validation=await call('validate-records',{records:inspected.records});if(validation.diagnostics.length)throw Error(JSON.stringify(validation));
 await call('check-links',{records:inspected.records});
 await call('inspect-navigation',{projectsRoot});
 const savedTiming=timing;
 if(event.activity_at!==savedTiming.activity_at||event.recorded_at!==savedTiming.recorded_at)throw Error('Timestamp mismatch');
 await call('log-append',{projectsRoot,entry:event});
 await call('invalidate-project-index',{vaultRoot});
 const query=await call('log-query',{projectsRoot,recordId:milestoneId});
 const verificationInput={...input,operationPath};
 const verification=await call('operation-verify',verificationInput);
 if(verification.status!=='verified')throw Error('Verification '+JSON.stringify(verification));
 const completion=await call('operation-complete',verificationInput);
 await write(path.join(temp,'after/project-index.md'),await fs.readFile(indexPath));
 await write(path.join(temp,'after/milestone.md'),await fs.readFile(milestonePath));
 const profileAfter=await fs.readFile(context.profilePath);await write(path.join(temp,'after/profile.json'),profileAfter);
 if(profileBefore&&!profileBefore.equals(profileAfter))throw Error('Existing profile bytes changed');
 await json(path.join(temp,'summary.json'),{name,milestonePath,configRoot:context.configRoot,stateRoot:context.stateRoot,projectsRoot,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,existingProfileUnchanged:profileBefore?profileBefore.equals(profileAfter):null,profileBeforeHash:profileBefore?sha(profileBefore):null,profileAfterHash:sha(profileAfter),verification,completion,query,recordsBefore});
 console.log(JSON.stringify({name,milestonePath,completion,dailyPlansRoot:context.dailyPlansRoot}));
}
