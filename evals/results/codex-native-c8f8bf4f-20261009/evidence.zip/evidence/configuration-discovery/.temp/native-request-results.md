# Configuration discovery: actual native request results

Executed four independent accepted milestone requests using installed Daily Tasks 0.3.4 skills and CLI, Node v24.19.0, with each CLI subprocess running from its individual case root. No previous attempts or regression tests were read. No personal directories were accessed.

All four created exactly one M1, Update LinkedIn and resume, with embedded unchecked DoD “Reviewed career materials”, owner synthetic@example.test, not-started state, project navigation, and flat inputs/outputs. No tasks were created.

| Case | Configuration directory, relative to case | Daily output directory | Projects directory | Completion |
| --- | --- | --- | --- | --- |
| 01-common-root | common/.nyssaai/daily-tasks | vault/Daily | vault/Projects | verified, completed |
| 02-no-profile | common/.nyssaai/daily-tasks | vault/2-areas/daily-plans | vault/Projects | verified, completed |
| 03-explicit-legacy | vault/.nyssa/daily-tasks | vault/Daily | vault/Projects | verified, completed |
| 04-vault-only-legacy | vault/.nyssa/daily-tasks | vault/Daily | vault/Projects | verified, completed |

Timezone is America/Chicago in every case. Existing profiles in 01, 03 and 04 retained exact bytes. Case 02 initialized the accepted conventional common configuration scope with the supplied identity/timezone and empty priorities. The legacy profiles were reused in place; new operating state was explicitly bound to vault/.nyssaai/daily-tasks as requested. No legacy state existed to migrate. Daily output locations were resolved; no daily-plan creation was requested.

For common scope, the installed CLI has no common-state-root input; the skill translated the accepted root to its exact conventional profilePath. Neither common case passed a configRoot argument. Case 03 used the explicit legacy pointer. Case 04 passed no profilePath or configRoot and the CLI discovered the existing vault legacy profile.

Each case retains CLI input JSON, command/cwd/exit/stdout/stderr, parsed results, log-append/log-query evidence, before/after documents and profile bytes, checkpoint evidence and a summary in its `.temp/native-request/`. The root `.temp/` retains the newly authored execution and recovery scripts.

Case 01 retained two failed intermediate calls: navigation inspection included an absent daily directory, and log append rejected object-valued IDs. The workflow corrected UUID result extraction, validated the corrected records, and resumed the original event IDs/timestamps. No failed event was logged. Its original and corrected checkpoints and all failure results remain in evidence. CLI completion verified the actual files and exact logged event, then cleared the pending checkpoint.

All final record, link and project-navigation diagnostics are empty. All four operation completions returned completed without pending effects or conflicts. These results demonstrate the actual skill-authored workflows and CLI execution, not an independent claim of automatic host activation.
