import path from 'node:path';
import {cli,scope,save,read,hash,scratch,m,t1,milestone,project,event,checkpoint,finish,changeState,mark,snapshot} from './session.mjs';
const {ctx,plan,a,b}=JSON.parse(read(scratch+'/scenario-context.json'));
const basePath=path.join(ctx.stateRoot,'reconciliation.json');
function baseline(edits,state,checked){const beforeText=read(basePath),value=JSON.parse(beforeText);value.records[a.id].canonical.state=state;for(const [p,text] of edits)if(value.records[a.id].views[p])value.records[a.id].views[p]={...value.records[a.id].views[p],hash:hash(text),checked};return {beforeHash:hash(beforeText),beforeText,value};}
const ev=event('task.complete',[a.id],{state:a.state},{state:'completed',reason:'User authorizes reviewed synthetic headline evidence.'});
const output=path.join(m,'outputs/reviewed-linkedin-headline.md');
const evidence='# Reviewed synthetic LinkedIn headline\n\nSoftware engineer | Reliable tools and clear collaboration\n\nSynthetic evidence reviewed for this acceptance case under explicit user authorization.\n';
let text=changeState(read(t1),'completed',ev.recorded_at).replace('- [ ] A reviewed headline','- [x] A reviewed headline').replace('Work has not started; no artifact has been produced or reviewed.','Reviewed synthetic headline saved in [[outputs/reviewed-linkedin-headline|local evidence]]. User authorized satisfaction of the existing criterion.').replace('Save the headline locally in outputs/. Link the actual artifact here and from the milestone after review.','Delivered [[outputs/reviewed-linkedin-headline|reviewed headline]].');
const proposed=cli('parse-record',{markdown:text,path:t1});
const all=cli('inspect-records',{projectsRoot:ctx.projectsRoot}).records.map(r=>r.id===a.id?proposed:r);
const close=cli('check-closure',{recordId:a.id,records:all});if(!close.allowed)throw Error(JSON.stringify(close));
let ms=mark(read(milestone),a.id,'x')+'\nReviewed artifact: [[outputs/reviewed-linkedin-headline|LinkedIn headline]].\n';
const edits=[[t1,text],[output,evidence],[milestone,ms],[project,mark(read(project),a.id,'x')]];
const op=checkpoint(ctx,ev,edits,baseline(edits,'completed',true));finish(op,ev);
const stale=cli('reconcile-record',{base:{state:'not-started'},current:{state:'completed'},views:[{}]});
if(stale.record?.state && stale.record.state!=='completed')throw Error('Stale row reopened');
if(!read(t1).includes('task-state: "completed"')||!read(plan).includes('| 1 | [ ]'))throw Error('Stale case incorrect');
save(scratch+'/stale-checkin.json',{result:stale,canonicalCompleted:true,unchangedPlanStillOpen:true,normalization:'Plan row matches its stored checked:false snapshot; no edit contributed.'});
snapshot('stale-checkin',[t1,plan,milestone,project]);
// Refresh after comparison, then save the rendered checkbox through verification.
const refresh=event('view.refresh',[a.id],{planChecked:false},{planChecked:true,reason:'Refresh only after stale comparison.'});
const refreshed=mark(read(plan),a.id,'x');const rop=checkpoint(ctx,refresh,[[plan,refreshed]],baseline([[plan,refreshed]],'completed',true));finish(rop,refresh);
// Actual user-authorized manual checkbox edit, captured separately from reconciliation.
snapshot('before-manual-uncheck',[plan]);save(plan,mark(read(plan),a.id,' '));snapshot('after-manual-uncheck',[plan]);
const delta=cli('reconcile-record',{base:{state:'completed'},current:{state:'completed'},views:[{checked:false}]});save(scratch+'/checkbox-reconciliation.json',delta);
const rev=event('task.reopen',[a.id],{state:'completed',resolved_at:ev.recorded_at},{state:'not-started',reason:'Deliberate changed plan checkbox; original completion remains in history.'});
const reopened=changeState(read(t1),'not-started',rev.recorded_at);
const parsed=cli('parse-record',{markdown:reopened,path:t1});cli('reopen-ancestors',{records:cli('inspect-records',{projectsRoot:ctx.projectsRoot}).records.map(r=>r.id===a.id?parsed:r),changedIds:[a.id]});
const redit=[[t1,reopened],[milestone,mark(read(milestone),a.id,' ')],[project,mark(read(project),a.id,' ')],[plan,read(plan)]];
finish(checkpoint(ctx,rev,redit,baseline(redit,'not-started',false)),rev);
save(scratch+'/linkedin-events.json',{complete:ev,reopen:rev});
console.log('Stale plan preserved completion; deliberate uncheck reopened task.');
