import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=process.cwd(), scratch=path.join(root,'.temp'), vault=path.join(root,'vault');
export const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-rollover-full8/codex-home/plugins/cache/daily-tasks-release-034-rollover-full8/daily-tasks/0.3.4';
let seq=fs.existsSync(path.join(scratch,'counter'))?Number(fs.readFileSync(path.join(scratch,'counter'),'utf8')):0;
export function save(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
export function cli(op,input){const n=String(++seq).padStart(3,'0'), stem=path.join(scratch,n+'-'+op);save(path.join(scratch,'counter'),String(seq));if(input!==undefined)save(stem+'.input.json',input);const args=[bundle+'/bin/daily-tasks.mjs',op,...(input===undefined?[]:['--input',stem+'.input.json'])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(stem+'.result.json',{command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(op+': '+r.stderr);return JSON.parse(r.stdout);}
export const read=p=>fs.readFileSync(p,'utf8');
export const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
export const scope={vaultRoot:vault};
export const m=path.join(vault,'Projects/job-search/m1-career-materials'), t1=path.join(m,'t1-update-linkedin.md'),t2=path.join(m,'t2-update-resume.md'), milestone=path.join(m,'m1-career-materials.md'),project=path.join(vault,'Projects/job-search/project-index.md');
export function snapshot(label,paths){for(const p of paths)if(fs.existsSync(p))save(path.join(scratch,label,path.relative(vault,p)),read(p));}
export function changeState(text,state,time){return text.replace(/task-state: .*/,`task-state: "${state}"`).replace(/updated_at: .*/,`updated_at: "${time}"`).replace(/^resolved_at: .*\r?\n/m,'').replace(/\r?\n---\r?\n#/,`${state==='completed'?`\nresolved_at: "${time}"`:''}\n---\n#`);}
export function mark(text,id,mark){return text.split('\n').map(l=>l.includes('ref: '+id)?l.replace(/\[[ x>\-]\]/,`[${mark}]`):l).join('\n');}
export function event(action,ids,before,after){const time=cli('activity-time',{});return {id:cli('new-id').id,operation_id:cli('new-id').id,action,record_ids:ids,actor:{kind:'person',id:'synthetic@example.test'},...time,before,after};}
export function checkpoint(ctx,ev,edits,baseline){const op={schemaVersion:2,operation_id:ev.operation_id,contextBinding:ctx.planningBinding,event:ev,files:edits.map(([p,after])=>({path:p,before:fs.existsSync(p)?hash(read(p)):null,after:after===null?null:hash(after)})),...(baseline?{baseline}:{})};const p=path.join(ctx.stateRoot,'operations',ev.operation_id+'.json');save(p,op);save(path.join(scratch,'checkpoints',ev.operation_id+'.json'),op);snapshot('before-'+ev.operation_id,edits.map(e=>e[0]));for(const [file,after] of edits){const expected=op.files.find(f=>f.path===file).before;if((fs.existsSync(file)?hash(read(file)):null)!==expected)throw Error('Concurrent edit');save(file,after);}cli('invalidate-project-index',{vaultRoot:vault});return p;}
export function finish(p,ev){cli('log-append',{projectsRoot:path.join(vault,'Projects'),entry:ev});const v=cli('operation-verify',{...scope,operationPath:p});if(v.status!=='verified')throw Error(JSON.stringify(v));const r=cli('operation-complete',{...scope,operationPath:p});return r;}
