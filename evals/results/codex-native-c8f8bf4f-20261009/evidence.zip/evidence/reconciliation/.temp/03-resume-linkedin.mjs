import path from 'node:path';
import {cli,scope,save,read,hash,scratch,t1,milestone,project,event,checkpoint,finish,changeState,mark,snapshot} from './session.mjs';
const {ctx,plan,a}=JSON.parse(read(scratch+'/scenario-context.json'));
const basePath=path.join(ctx.stateRoot,'reconciliation.json');
function baseline(edits,state,checked){const beforeText=read(basePath),value=JSON.parse(beforeText);value.records[a.id].canonical.state=state;for(const [p,text] of edits)if(value.records[a.id].views[p])value.records[a.id].views[p]={...value.records[a.id].views[p],hash:hash(text),checked};return {beforeHash:hash(beforeText),beforeText,value};}
const stale=cli('reconcile-record',{base:{id:a.id,type:'task',state:'not-started'},current:{id:a.id,type:'task',state:'completed'},views:[{id:a.id}]});
if(stale.record.state!=='completed'||!read(plan).includes('| 1 | [ ]'))throw Error('Stale assertion failed');
save(scratch+'/stale-checkin.json',{result:stale,canonicalCompleted:true,unchangedPlanStillOpen:true,normalization:'Plan row matches its stored checked:false snapshot; no edit contributed.'});snapshot('stale-checkin',[t1,plan,milestone,project]);
const refresh=event('view.refresh',[a.id],{planChecked:false},{planChecked:true,reason:'Refresh after comparison.'});
const refreshed=mark(read(plan),a.id,'x');finish(checkpoint(ctx,refresh,[[plan,refreshed]],baseline([[plan,refreshed]],'completed',true)),refresh);
snapshot('before-manual-uncheck',[plan]);save(plan,mark(read(plan),a.id,' '));snapshot('after-manual-uncheck',[plan]);
const delta=cli('reconcile-record',{base:{id:a.id,type:'task',state:'completed'},current:{id:a.id,type:'task',state:'completed'},views:[{id:a.id,checked:false}]});if(delta.record.state!=='not-started')throw Error('Reopen proposal failed');save(scratch+'/checkbox-reconciliation.json',delta);
const rev=event('task.reopen',[a.id],{state:'completed'},{state:'not-started',reason:'Deliberate changed plan checkbox; original completion remains in history.'});
const reopened=changeState(read(t1),'not-started',rev.recorded_at);
const parsed=cli('parse-record',{markdown:reopened,path:t1});cli('reopen-ancestors',{records:cli('inspect-records',{projectsRoot:ctx.projectsRoot}).records.map(r=>r.id===a.id?parsed:r),changedIds:[a.id]});
const edits=[[t1,reopened],[milestone,mark(read(milestone),a.id,' ')],[project,mark(read(project),a.id,' ')],[plan,read(plan)]];
finish(checkpoint(ctx,rev,edits,baseline(edits,'not-started',false)),rev);
console.log('Stale plan preserved completion; deliberate uncheck reopened task.');
