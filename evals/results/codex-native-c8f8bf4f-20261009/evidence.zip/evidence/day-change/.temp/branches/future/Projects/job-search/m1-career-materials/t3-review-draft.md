---
id: "01a12208-177c-7dfd-b2fb-b4abd2045bc4"
type: task
record_version: 2
title: "Review draft"
owner: "synthetic@example.test"
assignee: "Reviewer"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
task-state: "not-started"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: reviewed
---
# M1-T3 — Review draft

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

inspect draft

## Definition of Done

- [ ] recorded review <!-- id: 01a12208-17a9-7e04-953d-1343fae20609 -->

## Inputs

No supplied files.

## Output and delivery

Local result in outputs/ when available.

## Verification

Record review before completing.

## Result

No execution reported.
