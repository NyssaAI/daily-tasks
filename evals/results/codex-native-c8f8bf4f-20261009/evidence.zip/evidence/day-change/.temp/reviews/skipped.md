Open projects: 1          Open tasks: 4          Late tasks: 0

**Timezone:** America/Chicago

This is your first check-in today. Review carried work and choose any additions explicitly.

## Already selected

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | Career materials | [[../Projects/job-search/m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 --> | — |
| 2 | [ ] | Job Search | Career materials | [[../Projects/job-search/m1-career-materials/t3-review-draft\|Review draft]] <!-- ref: 01a12208-177c-7dfd-b2fb-b4abd2045bc4 --> | — |

## Available tasks

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 3 | [ ] | Job Search | Career materials | [[../Projects/job-search/m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 --> | — |
| 4 | [ ] | Job Search | Career materials | [[../Projects/job-search/m1-career-materials/t6-deselected-work\|Deselected work]] <!-- ref: 01a12208-18f4-7ebd-86fa-d8de32825bb1 --> | — |

Reply by row number and symbol or description:

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled · ↺ carried forward

## Update your plan

add / remove / keep selections / show details / show more
