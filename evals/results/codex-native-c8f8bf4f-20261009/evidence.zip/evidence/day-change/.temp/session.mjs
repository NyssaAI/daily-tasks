import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=process.cwd();
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-rollover-full8/codex-home/plugins/cache/daily-tasks-release-034-rollover-full8/daily-tasks/0.3.4';
export const mon='2026-10-05T16:00:00Z',tue='2026-10-06T16:00:00Z',fri='2026-10-09T16:00:00Z';
export const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
export const read=p=>fs.readFileSync(p,'utf8');
export function write(p,s){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);}
export function json(p,v){write(p,JSON.stringify(v,null,2));}
let seq=fs.existsSync(path.join(root,'.temp/sequence.json'))?JSON.parse(read(path.join(root,'.temp/sequence.json'))):0;
export function cli(op,input){const n=++seq;json(path.join(root,'.temp/sequence.json'),seq);const base=path.join(root,'.temp/cli',String(n).padStart(3,'0')+'-'+op);if(input)json(base+'.input.json',input);const args=[path.join(pkg,'bin/daily-tasks.mjs'),op,...(input?['--input',base+'.input.json']:[])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});json(base+'.execution.json',{command:process.execPath,args,status:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(op+': '+r.stderr);return JSON.parse(r.stdout);}
export function ctx(vault,now){return {vaultRoot:vault,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json'),now};}
export function prepare(vault,now){return cli('planning-prepare',ctx(vault,now));}
export function snap(label,files){for(const p of files){json(path.join(root,'.temp/snapshots',label,hash(p)+'.json'),{path:p,content:fs.existsSync(p)?read(p):null});}}
export function clone(src,dst){fs.cpSync(src,dst,{recursive:true,filter:p=>!['.daily-tasks','.temp'].includes(path.basename(p))});}
export const id=()=>{const v=cli('new-id');return typeof v==='string'?v:v.id;};
