import fs from 'node:fs';import path from 'node:path';import {root,read,write,json,id,prepare,cli,mon,tue,fri,ctx,hash,snap} from './session.mjs';import {tasks,document,begin,resume,routing,stateInput} from './rollover.mjs';
const A=tasks.find(t=>t.key==='A'),B=tasks.find(t=>t.key==='B');
for(const name of ['precreated','interrupted','future']){
 const vault=path.join(root,'.temp/branches',name),monday=path.join(vault,'Daily/2026.10.05-daily-plan.md');const existing=cli('parse-record',{markdown:read(monday)});write(monday,document('2026.10.05',existing.id,[A],mon));
 if(name!=='interrupted'){const dest=path.join(vault,'Daily/2026.10.06-daily-plan.md');write(dest,document('2026.10.06',id(),name==='future'?[A,B]:[B],mon));snap(name+'-precreated',[monday,dest]);}
}
const pre=path.join(root,'.temp/branches/precreated');const r=begin(pre,tue);json(path.join(root,'.temp/precreated-run.json'),r);resume(r,tue);json(path.join(root,'.temp/precreated-repeat.json'),begin(pre,tue));
const interrupt=path.join(root,'.temp/branches/interrupted');const ir=begin(interrupt,tue);json(path.join(root,'.temp/interrupted-run.json'),ir);const checkpoint=read(ir.operationPath);const p=prepare(interrupt,tue);json(path.join(root,'.temp/interruption-observation.json'),{checkpoint:JSON.parse(checkpoint),destination:read(p.current.path),receipt:p.state.rollover.value,pending:p.pendingOperations,log:cli('log-query',{projectsRoot:p.context.projectsRoot})});
console.log('Stopped after destination persistence: receipt '+JSON.stringify(p.state.rollover.value));
const verify=cli('rollover-complete',{...ctx(interrupt,tue),operationPath:ir.operationPath});json(path.join(root,'.temp/interrupted-premature-completion.json'),verify);console.log('Premature completion '+JSON.stringify(verify));
resume(ir,fri);cli('log-append',{projectsRoot:ir.p.context.projectsRoot,entry:ir.checkpoint.event});json(path.join(root,'.temp/interrupted-retry.json'),{rollover:begin(interrupt,tue),log:cli('log-query',{projectsRoot:ir.p.context.projectsRoot})});
// Prepared proposal for explicit Tuesday removal, while still Monday in the future branch.
for(const [name,now] of [['precreated',tue],['future',mon]]){const vault=path.join(root,'.temp/branches',name),p=prepare(vault,now);const proposal=cli('plan-selection',{...routing(p),inventory:p.inventory,taskIds:[A.id],action:'remove',today:p.context.localDate,date:'2026.10.06'});json(path.join(root,'.temp',name+'-removal-proposal.json'),{p,proposal});console.log(name+' removal '+JSON.stringify(proposal));}
