---
id: 01a12207-b613-77de-8850-25da07c4983c
type: milestone
record_version: 2
title: "Draft"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12207-b5e3-79e3-b6c9-7f057427cd65"
created_at: "2026-10-09T18:58:50.140Z"
updated_at: "2026-10-09T18:59:32.036Z"
---
# M1 — Draft

**Project:** [[../project-index|Demo]] <!-- ref: 01a12207-b5e3-79e3-b6c9-7f057427cd65 -->

## Outcome

Draft and review a paragraph.

## Definition of Done

- [ ] Both task Definitions of Done are satisfied. <!-- id: 01a12207-b69e-7826-8b14-9f3f2ad1ccb8 -->

## Tasks

- [>] [[t1-draft-note|Draft note]] <!-- ref: 01a12207-b642-7d58-ab9c-c22ab9995dce -->

- [ ] [[t2-review-note|Review note]] <!-- ref: 01a12207-b66f-7cb0-994d-5e8c5476555d -->

## Decisions

Accepted by Synthetic User.
