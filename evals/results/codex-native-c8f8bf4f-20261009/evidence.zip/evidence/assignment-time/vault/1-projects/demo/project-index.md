---
id: 01a12207-b5e3-79e3-b6c9-7f057427cd65
type: project
title: "Demo"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T18:58:37.582Z"
updated_at: "2026-10-09T18:59:32.593Z"
---
# Demo

Create and review a paragraph through M1 Draft.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |

| [ ] [[m1-draft/m1-draft\|M1 Draft]] <!-- ref: 01a12207-b613-77de-8850-25da07c4983c --> | | Draft and review a paragraph. | Synthetic User | — |

| | [>] [[m1-draft/t1-draft-note\|Draft note]] <!-- ref: 01a12207-b642-7d58-ab9c-c22ab9995dce --> | Write a paragraph. | Synthetic User | — |

| | [ ] [[m1-draft/t2-review-note\|Review note]] <!-- ref: 01a12207-b66f-7cb0-994d-5e8c5476555d --> | Inspect the paragraph. | Synthetic User (assigned to Editor) | — |

## Decisions

Accepted by Synthetic User. Times display in America/Chicago.
