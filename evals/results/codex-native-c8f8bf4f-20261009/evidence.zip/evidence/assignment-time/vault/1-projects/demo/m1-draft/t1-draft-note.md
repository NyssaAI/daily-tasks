---
id: 01a12207-b642-7d58-ab9c-c22ab9995dce
type: task
record_version: 2
title: "Draft note"
document-maturity: reviewed
task-state: in-progress
owner: "synthetic@example.test"
project_id: "01a12207-b5e3-79e3-b6c9-7f057427cd65"
milestone_id: "01a12207-b613-77de-8850-25da07c4983c"
created_at: "2026-10-09T18:59:09.887Z"
updated_at: "2026-10-09T18:59:32.036Z"
started_at: "2026-10-09T18:59:32.036Z"
---
# M1-T1 — Draft note

**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: 01a12207-b613-77de-8850-25da07c4983c -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a12207-b5e3-79e3-b6c9-7f057427cd65 -->

## Requirements

Write a paragraph.

## Definition of Done

- [ ] Reviewed paragraph. <!-- id: 01a12207-b6cb-7355-b930-50d48785e069 -->

## Inputs

Local inputs belong in inputs/.

## Output and delivery

Local deliverables belong in outputs/.

## Verification

Synthetic User must explicitly confirm the task criterion is satisfied.

## Activity

Reported start: "earlier this morning". The recording-time fallback is Oct 9, 2026, 1:59:32 PM CDT (America/Chicago).
