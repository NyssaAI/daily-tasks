---
id: 01a12207-b66f-7cb0-994d-5e8c5476555d
type: task
record_version: 2
title: "Review note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
assignee: "Editor"
project_id: "01a12207-b5e3-79e3-b6c9-7f057427cd65"
milestone_id: "01a12207-b613-77de-8850-25da07c4983c"
created_at: "2026-10-09T18:59:10.413Z"
updated_at: "2026-10-09T18:59:32.593Z"
---
# M1-T2 — Review note

**Milestone:** [[m1-draft|M1 Draft]] <!-- ref: 01a12207-b613-77de-8850-25da07c4983c -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a12207-b5e3-79e3-b6c9-7f057427cd65 -->

## Requirements

Inspect the paragraph.

## Definition of Done

- [ ] Recorded review. <!-- id: 01a12207-b6fa-78bf-b42f-6f76a36f76fc -->

## Inputs

Local inputs belong in inputs/.

## Output and delivery

Local deliverables belong in outputs/.

## Verification

Synthetic User must explicitly confirm the task criterion is satisfied.
