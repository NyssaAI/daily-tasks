# Scenario 2: Assignment and time

PASS — 5/5 assertions.

- PASS: Default human owner comes from setup
- PASS: Omitted assignee means owner performs Draft note
- PASS: Agent assigns/reassigns without changing human owner or starting Review note
- PASS: Vague retrospective start uses now plus exact original words
- PASS: GMT storage and local display with explicit timezone

Draft note start wording: "earlier this morning".
Exact activity_at and recorded_at: 2026-10-09T18:59:32.036Z.
CLI local display: Oct 9, 2026, 1:59:32 PM CDT (America/Chicago).

Owner remains Synthetic User for all four records. Review note: Reviewer → Editor by Codex agent; not started. Definitions of Done remain unchecked. No work closure performed.

Raw CLI inputs/results, checkpoints and before/after content are retained beside this receipt. Initial setup log append failed because the new projects directory did not yet exist; creating that directory and retrying the exact saved event succeeded once. Initial number request before project creation returned null; allocation was repeated after project creation and returned 1. No guessed allocation was used.

Installed skill provenance and assertions: scenario2-receipt.json. CLI calls: calls.json. Final inspection, snapshots and queried log: after.json. Host version/model were not exposed. CLI verification is integrity evidence, not proof of native plugin discovery.
