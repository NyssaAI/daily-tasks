---
id: "01a121fa-a60a-7a4d-b74c-0c23be084d50"
type: task
record_version: 2
title: "Past work"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
task-state: completed
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
resolved_at: "2026-10-05T16:00:00Z"
document-maturity: reviewed
---
# M1-T4 — Past work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements
past result

## Definition of Done
- [x] reviewed result <!-- id: 01a121fa-a636-797a-b7b3-afb4d5f16559 -->

## Result
User explicitly attested reviewed result.
