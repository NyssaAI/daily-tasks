---
id: "01a121fa-a43e-7b2a-8386-7461628a0b25"
type: task
record_version: 2
title: "Review draft"
owner: "synthetic@example.test"
assignee: "Reviewer"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
task-state: not-started
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
document-maturity: reviewed
---
# M1-T3 — Review draft

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements
inspect draft

## Definition of Done
- [ ] recorded review <!-- id: 01a121fa-a46d-7b99-8993-e4e1e34d366b -->

## Result
Work not started.
