---
id: "01a121fa-aa07-7c4e-b347-a87c5819eec9"
type: task
record_version: 2
title: "Deselected work"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
task-state: not-started
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
document-maturity: reviewed
---
# M1-T6 — Deselected work

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements
optional draft

## Definition of Done
- [ ] reviewed draft <!-- id: 01a121fa-aa36-7a50-960a-6cabe24244dc -->

## Result
Work not started.
