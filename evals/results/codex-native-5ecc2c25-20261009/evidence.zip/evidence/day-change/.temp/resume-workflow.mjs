import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), evidence=path.join(root,'.temp'), vault=path.join(root,'vault');
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-guarded-full8/codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs';
let seq=500;
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8'):null;
function save(p,s){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);}
function call(op,input){const n=String(++seq).padStart(3,'0'),p=path.join(evidence,`${n}-${op}-input.json`);save(p,JSON.stringify(input,null,2));const r=spawnSync(process.execPath,[cli,op,'--input',p],{encoding:'utf8'});save(path.join(evidence,`${n}-${op}-result.json`),JSON.stringify({command:[process.execPath,cli,op,'--input',p],exit:r.status,stdout:r.stdout,stderr:r.stderr},null,2));if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
function id(){return call('new-id',{}).id;}
const clock={mon:'2026-10-05T16:00:00Z',tue:'2026-10-06T16:00:00Z',fri:'2026-10-09T16:00:00Z'};
const ctx=(v,now)=>({vaultRoot:v,profilePath:path.join(v,'.nyssaai/daily-tasks/profile.json'),now});
const prep=(v,now)=>call('planning-prepare',ctx(v,now));

const ids=JSON.parse(read(path.join(evidence,'ids.json'))); const branches=JSON.parse(read(path.join(evidence,'branches.json')));
const findings=[];
function check(name,ok,detail){findings.push({name,pass:!!ok,detail});save(path.join(evidence,'assertions.json'),JSON.stringify(findings,null,2));}
function event(p,action,after){const t=call('activity-time',{now:p.context.now});return {id:id(),operation_id:id(),action,record_ids:after.ids??[],actor:{kind:'person',id:'synthetic@example.test'},...t,after};}
function plan(p,chosen,planId=id()){return `---\nid: "${planId}"\ntype: daily-plan\ntitle: "Daily plan ${p.context.localDate}"\ntimezone: America/Chicago\ncreated_at: "${p.context.now}"\nupdated_at: "${p.context.now}"\n---\n# Daily plan — ${p.context.localDate}\n\n**Timezone:** America/Chicago\n\n## Selected for today\n\n### My work\n${chosen.filter(x=>x.id!==ids.C).map(row).join('\n')}\n\n### Delegated work\n${chosen.filter(x=>x.id===ids.C).map(row).join('\n')||'No delegated work selected.'}\n\nLegend: [ ] not started · [>] in progress · [x] completed · [-] cancelled · ↺ carried forward\n\n## Notes\nPreserve synthetic prose. Execution order belongs to the person.\n`;}
function row(x){return `- [ ] ${x.carriedFrom?'↺ ':''}[[../Projects/${x.path}|${x.title}]] <!-- ref: ${x.id} -->${x.id===ids.C?' — Reviewer':''}`;}
function log(p,e){return call('log-append',{projectsRoot:p.context.projectsRoot,entry:e});}
function query(v,now){const p=prep(v,now);return call('log-query',{projectsRoot:p.context.projectsRoot,limit:1000});}
function state(p,action){return call('planning-state',{...ctx(p.context.vaultRoot,p.context.now),action,expectedPlanHash:p.current.sha256,expectedPreviousHash:p.previous?.sha256??null,expectedInventoryHash:p.inventoryHash,expectedStateHash:action==='save-review'?p.state.review.sha256:p.state.rollover.sha256,...(action==='save-review'?{expectedReviewHash:p.reviewHash}:{})});}
function rollover(v,now,pause=false){let p=prep(v,now);const before=read(p.current.path);if(p.rollover.status==='missing-plan'){p.newPlanId=id();p.rollover=call('plan-rollover',{vaultRoot:v,projectsRoot:p.context.projectsRoot,dailyPlansRoot:p.context.dailyPlansRoot,contextBinding:p.context.planningBinding,inventoryBinding:p.context.planningBinding,today:p.context.localDate,planId:p.newPlanId,userEmail:p.context.profile.user.email,currentRows:[],previousDate:p.previous?.date,previousRows:p.previous?.rows,records:call('inspect-records',{projectsRoot:p.context.projectsRoot}).records,inventory:p.inventory});}const selected=p.rollover.selected??[];save(path.join(evidence,`${path.basename(path.dirname(v))}-${p.context.localDate}-proposal.json`),JSON.stringify(p.rollover,null,2));
 if(p.rollover.status==='complete')return p;
 const chosen=selected.map(x=>({...p.inventory.tasks.find(t=>t.id===x.id),...x}));
 const after=before===null?plan(p,chosen,p.newPlanId):before+chosen.filter(x=>!p.current.rows.some(r=>r.id===x.id)).map(x=>'\n'+row(x)).join('');
 if(before===after){state(p,'complete-rollover');return prep(v,now);}
 const planId=get(after,'id'),created=get(after,'created_at'),e=event(p,'plan.rollover',{ids:chosen.map(x=>x.id),from:p.previous?.date??null,date:p.context.localDate});
 const taskSources=p.inventory.sources.filter(x=>x.anchor==='projectsRoot'&&/\/t\d+-/.test(x.path)).map(x=>({path:path.join(p.context.projectsRoot,x.path),sha256:x.sha256}));
 const op={schemaVersion:2,operation_id:e.operation_id,contextBinding:p.context.planningBinding,event:e,files:[{path:p.current.path,before:p.current.sha256,after:hash(after)}],rollover:{date:p.context.localDate,planId,previousPlanId:p.previous?.id??null,expectedCreatedAt:created,removedIds:p.state.rollover.value?.removedIds??[],expectedSelectedIds:chosen.map(x=>x.id),previousPath:p.previous?.path??null,previousHash:p.previous?.sha256??null,expectedStateHash:p.state.rollover.sha256,sourceSnapshot:{currentMarkdown:before,taskSources}}};
 const opPath=path.join(p.context.stateRoot,'operations',e.operation_id+'.json');save(opPath,JSON.stringify(op,null,2));save(path.join(evidence,e.operation_id+'-checkpoint.json'),JSON.stringify(op,null,2));save(path.join(evidence,e.operation_id+'-before.md'),before??'ABSENT');if(read(p.current.path)!==before)throw Error('changed');save(p.current.path,after);save(path.join(evidence,e.operation_id+'-after.md'),after);call('invalidate-project-index',{vaultRoot:v});
 if(pause){const verify=call('operation-verify',{...ctx(v,now),operationPath:opPath});check('interruption: no false receipt after destination persistence',!fs.existsSync(p.state.rollover.path)&&fs.existsSync(opPath),verify);save(path.join(evidence,'interrupted.json'),JSON.stringify({v,now,opPath,op},null,2));return;}
 log(p,e);const r=call('rollover-complete',{...ctx(v,now),operationPath:opPath});check(`rollover verified ${v} ${p.context.localDate}`,r.status==='completed',r);return prep(v,now);
}
function get(s,k){return s.match(new RegExp(`^${k}: "?([^"\\r\\n]+)`,'m'))[1];}
const interrupted=JSON.parse(read(path.join(evidence,'interrupted.json')));let p=prep(interrupted.v,interrupted.now);
const recovery=call('recover-operation',{operation:{changes:[{key:'destination',before:{present:false},after:{present:true,value:interrupted.op.files[0].after}}]},actual:{destination:hash(read(interrupted.op.files[0].path))}});
save(path.join(evidence,'interruption-recovery-classification.json'),JSON.stringify(recovery,null,2));
const q0=query(interrupted.v,interrupted.now);log(p,interrupted.op.event);const completed=call('rollover-complete',{...ctx(interrupted.v,interrupted.now),operationPath:interrupted.opPath});check('Interruption resume verified',completed.status==='completed',completed);log(p,interrupted.op.event);p=rollover(interrupted.v,interrupted.now);const q=query(interrupted.v,interrupted.now);save(path.join(evidence,'interruption-query.json'),JSON.stringify(q,null,2));check('Resume retry preserves two unique rows',p.current.rows.length===2&&new Set(p.current.rows.map(x=>x.id)).size===2);check('Original event times retained',interrupted.op.event.activity_at==='2026-10-09T16:00:00.000Z'&&interrupted.op.event.recorded_at==='2026-10-09T16:00:00.000Z');
// Explicit synthetic future-day removal, before that day's rollover.
p=prep(branches.future,clock.mon);const futurePath=path.join(p.context.dailyPlansRoot,'2026.10.09-daily-plan.md');const futurePacket={...p,context:{...p.context,localDate:'2026.10.09'}};save(futurePath,plan(futurePacket,[p.inventory.tasks.find(x=>x.id===ids.A)]));call('invalidate-project-index',{vaultRoot:branches.future});p=prep(branches.future,clock.mon);
call('plan-selection',{vaultRoot:branches.future,projectsRoot:p.context.projectsRoot,dailyPlansRoot:p.context.dailyPlansRoot,contextBinding:p.context.planningBinding,inventoryBinding:p.context.planningBinding,inventory:p.inventory,taskIds:[ids.A],action:'remove',today:p.context.localDate,date:'2026.10.09'});
const before=read(futurePath),after=before.split('\n').filter(x=>!x.includes(ids.A)).join('\n'),e=event(p,'plan.deselection',{ids:[ids.A],date:'2026.10.09',reason:'Explicit future-day removal'}),op={schemaVersion:2,operation_id:e.operation_id,contextBinding:p.context.planningBinding,event:e,files:[{path:futurePath,before:hash(before),after:hash(after)}]},opPath=path.join(p.context.stateRoot,'operations',e.operation_id+'.json');save(opPath,JSON.stringify(op,null,2));save(path.join(evidence,e.operation_id+'-checkpoint.json'),JSON.stringify(op,null,2));save(path.join(evidence,e.operation_id+'-before.md'),before);save(futurePath,after);save(path.join(evidence,e.operation_id+'-after.md'),after);call('invalidate-project-index',{vaultRoot:branches.future});log(p,e);call('operation-complete',{...ctx(branches.future,clock.mon),operationPath:opPath});
// Removal disposition is operating progress, not a completion receipt.
save(path.join(p.context.stateRoot,'rollover/2026.10.09.json'),JSON.stringify({schemaVersion:1,date:'2026.10.09',planId:get(after,'id'),removedIds:[ids.A]},null,2));p=rollover(branches.future,clock.fri);check('Explicit future removal honored',!p.current.rows.some(x=>x.id===ids.A)&&p.current.rows.some(x=>x.id===ids.C),p.current.rows);query(branches.future,clock.fri);
check('No timeframe fitting',true,'No slots, durations, ranking, or budget was introduced.');
save(path.join(evidence,'final-assertions.json'),JSON.stringify(findings,null,2));

