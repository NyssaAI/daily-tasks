import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), evidence=path.join(root,'.temp','accepted-batch');
fs.mkdirSync(evidence,{recursive:true});
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-guarded-full8/codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs';
let seq=0; const actions=[];
function call(op,input){const stem=String(++seq).padStart(2,'0')+'-'+op; const args=[cli,op];if(input!==undefined){const file=path.join(evidence,stem+'-input.json');fs.writeFileSync(file,JSON.stringify(input,null,2)+'\n');args.push('--input',file);}const r=spawnSync(process.execPath,args,{encoding:'utf8'});fs.writeFileSync(path.join(evidence,stem+'-result.json'),r.stdout);fs.writeFileSync(path.join(evidence,stem+'-execution.json'),JSON.stringify({args,exitCode:r.status,stderr:r.stderr},null,2));actions.push({op,exitCode:r.status});if(r.status!==0)throw new Error(r.stderr);return JSON.parse(r.stdout);}
const scope={vaultRoot:path.join(root,'vault'),profilePath:path.join(root,'vault/.nyssaai/daily-tasks/profile.json')};
const ctx=call('resolve-context',scope);
const before=call('inspect-records',{projectsRoot:ctx.projectsRoot});
if(before.records.length)throw new Error('Existing records require deduplication before creation');
const history=call('log-query',{projectsRoot:ctx.projectsRoot,limit:1000,offset:0});
if(history.nextOffset!==null)throw new Error('History requires pagination');
if(history.entries.some(e=>e.action.includes('accepted')))throw new Error('Acceptance already recorded');
const manual=path.join(ctx.dailyPlansRoot,'2026-10-09.md'), manualBytes=fs.readFileSync(manual);
fs.writeFileSync(path.join(evidence,'manual-before.md'),manualBytes);
const candidatesPath=path.join(ctx.stateRoot,'candidates.json'), candidates=JSON.parse(fs.readFileSync(candidatesPath,'utf8'));
fs.writeFileSync(path.join(evidence,'candidates-before.json'),JSON.stringify(candidates,null,2));
const ids=[];for(let i=0;i<9;i++){const r=call('new-id');ids.push(typeof r==='string'?r:r.id);}
fs.writeFileSync(path.join(evidence,'generated-ids.json'),JSON.stringify(ids));
const [projectId,milestoneId,linkedinId,resumeId,mDoD,lDoD,rDoD,operationId,eventId]=ids;
if(ids.some(x=>!x))throw new Error('Unexpected new-id shape');
const time=call('activity-time',{}), stamp=time.recorded_at, owner='synthetic@example.test';
const project=path.join(ctx.projectsRoot,'job-search'), folder=path.join(project,'m1-career-materials');
const header=(id,type,title,state,parent='')=>`---\nid: ${id}\ntype: ${type}\nrecord_version: 2\ntitle: "${title}"\n${type}-state: not-started\nowner: "${owner}"\n${parent}created_at: "${stamp}"\nupdated_at: "${stamp}"\n---\n`;
const docs=[
 {id:projectId,type:'project',path:path.join(project,'project-index.md'),text:header(projectId,'project','Job Search','')+'# Job Search\n\nPrepare reviewed career materials for the job search.\n\n## Project Summary\n\n| Milestone | Task | Description | Owner | Due Date |\n| --- | --- | --- | --- | --- |\n'+`| [ ] [[m1-career-materials/m1-career-materials\\|Career materials]] <!-- ref: ${milestoneId} --> | | Both reviewed artifacts linked. | ${owner} | — |\n| | [ ] [[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]] <!-- ref: ${linkedinId} --> | Update headline. | ${owner} | — |\n| | [ ] [[m1-career-materials/t2-update-resume\\|Update resume]] <!-- ref: ${resumeId} --> | Update summary. | ${owner} | — |\n`},
 {id:milestoneId,type:'milestone',project_id:projectId,path:path.join(folder,'m1-career-materials.md'),text:header(milestoneId,'milestone','Career materials','',`project_id: "${projectId}"\n`)+`# M1 — Career materials\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${projectId} -->\n\n## Outcome\n\nPrepare reviewed LinkedIn headline and resume summary.\n\n## Definition of Done\n\n- [ ] Both reviewed artifacts linked. <!-- id: ${mDoD} -->\n\n## Tasks\n\n- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${linkedinId} -->\n- [ ] [[t2-update-resume|Update resume]] <!-- ref: ${resumeId} -->\n`}
];
for(const [id,title,num,slug,requirement,dod,criterion] of [[linkedinId,'Update LinkedIn',1,'linkedin','Update headline.','Reviewed headline.',lDoD],[resumeId,'Update resume',2,'resume','Update summary.','Reviewed summary.',rDoD]]) docs.push({id,type:'task',project_id:projectId,milestone_id:milestoneId,path:path.join(folder,`t${num}-update-${slug}.md`),text:header(id,'task',title,'',`project_id: "${projectId}"\nmilestone_id: "${milestoneId}"\n`)+`# M1-T${num} — ${title}\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: ${milestoneId} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${projectId} -->\n\n## Requirements\n\n${requirement}\n\n## Definition of Done\n\n- [ ] ${dod} <!-- id: ${criterion} -->\n\n## Inputs\n\nSource artifact to be supplied before execution. Local inputs belong in [inputs](inputs/).\n\n## Output and delivery\n\nLink the reviewed artifact from [outputs](outputs/) in the task result and milestone.\n\n## Verification\n\nRecord the owner's review of the ${slug==='linkedin'?'headline':'summary'} before checking its criterion.\n\n## Result\n\nAwaiting execution and review.\n`});
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const words='I explicitly accept this batch: create Job Search project, M1 Career materials milestone, Update LinkedIn task (requirement: update headline; DoD: reviewed headline), and Update resume task (requirement: update summary; DoD: reviewed summary). Milestone DoD: both reviewed artifacts linked. Owner synthetic@example.test; all accepted work not started and unchecked. Accept no other work.';
const event={id:eventId,operation_id:operationId,action:'work.batch.accepted',record_ids:docs.map(d=>d.id),actor:{kind:'person',id:owner},...time,original_words:words,before:{records:[],candidate_dispositions:candidates.candidates.map(c=>({id:c.id,accepted:c.accepted,disposition:c.disposition}))},after:{acceptance_source:'current explicit user instruction',records:docs.map(({text,...d})=>({...d,owner,[d.type+'-state']:'not-started'}))}};
const checkpoint={schemaVersion:2,operation_id:operationId,contextBinding:ctx.planningBinding,event,files:docs.map(d=>({path:d.path,before:null,after:hash(d.text)})),protectedFiles:[{path:manual,sha256:hash(manualBytes)}]};
const operationPath=path.join(ctx.stateRoot,'operations',operationId+'.json');fs.mkdirSync(path.dirname(operationPath),{recursive:true});fs.writeFileSync(operationPath,JSON.stringify(checkpoint,null,2)+'\n');fs.writeFileSync(path.join(evidence,'checkpoint.json'),JSON.stringify(checkpoint,null,2));
fs.mkdirSync(path.join(folder,'inputs'),{recursive:true});fs.mkdirSync(path.join(folder,'outputs'),{recursive:true});
for(const d of docs){
 if(d.type==='milestone'||d.type==='task') {const n=call('next-record-number',{projectsRoot:ctx.projectsRoot,type:d.type,parentId:d.type==='milestone'?projectId:milestoneId});const expected=d.type==='milestone'||d.id===linkedinId?1:2;if(n.number!==expected)throw new Error('Unexpected allocation');}
 if(fs.existsSync(d.path))throw new Error('Destination collision');fs.writeFileSync(d.path,d.text);fs.writeFileSync(path.join(evidence,path.basename(d.path)),d.text);
}
call('invalidate-project-index',{vaultRoot:ctx.vaultRoot});
const actual=call('inspect-records',{projectsRoot:ctx.projectsRoot});
const valid=call('validate-records',{records:actual.records});const links=call('check-links',{records:actual.records});
fs.writeFileSync(path.join(evidence,'validation-summary.json'),JSON.stringify({valid,links},null,2));
if(actual.diagnostics.length||valid.valid===false||links.valid===false||links.diagnostics?.length)throw new Error('Validation requires review');
call('log-append',{projectsRoot:ctx.projectsRoot,entry:event});
const queried=call('log-query',{projectsRoot:ctx.projectsRoot,action:event.action,limit:1000,offset:0});
if(JSON.stringify(queried.entries.find(e=>e.id===eventId))!==JSON.stringify(event))throw new Error('Exact event mismatch');
const verify=call('operation-verify',{...scope,operationPath});if(verify.status!=='verified')throw new Error('Operation not verified');
const complete=call('operation-complete',{...scope,operationPath});
for(const c of candidates.candidates){c.accepted=true;c.disposition='accepted';c.record_id=c.id==='candidate:linkedin-update'?linkedinId:resumeId;c.project=projectId;c.milestone=milestoneId;c.acceptance_source='current explicit user instruction';c.accepted_at=stamp;c.operation_id=operationId;c.unresolved_facts=[];}
fs.writeFileSync(candidatesPath,JSON.stringify(candidates,null,2)+'\n');fs.writeFileSync(path.join(evidence,'candidates-after.json'),JSON.stringify(candidates,null,2));
const checkinPath=path.join(ctx.stateRoot,'checkin.json');const checkin=JSON.parse(fs.readFileSync(checkinPath,'utf8'));checkin.unresolvedCandidateIds=[];checkin.nextStep='Named batch accepted and created; manual daily note preserved. No daily selections requested.';checkin.status='accepted-batch-applied';fs.writeFileSync(checkinPath,JSON.stringify(checkin,null,2)+'\n');
call('inspect-records',{projectsRoot:ctx.projectsRoot});call('log-query',{projectsRoot:ctx.projectsRoot,limit:1000,offset:0});
if(!manualBytes.equals(fs.readFileSync(manual)))throw new Error('Manual note changed');fs.writeFileSync(path.join(evidence,'manual-after.md'),manualBytes);
fs.writeFileSync(path.join(evidence,'actions.json'),JSON.stringify({actions,complete,created:docs.map(d=>({id:d.id,path:d.path})),acceptanceOnlyNow:true,manualPreserved:true},null,2));
console.log(JSON.stringify({created:docs.map(d=>d.path),complete}));
