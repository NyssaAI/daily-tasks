---
id: 01a121fc-b19d-7524-a486-5942d76dec45
type: project
record_version: 2
title: "Job Search"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T18:46:11.500Z"
updated_at: "2026-10-09T18:46:11.500Z"
---
# Job Search

Prepare reviewed career materials for the job search.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a121fc-b1cb-7a52-b79e-4a5491c55b40 --> | | Both reviewed artifacts linked. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a121fc-b1f7-74b3-b4a2-458b7429a863 --> | Update headline. | synthetic@example.test | — |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a121fc-b224-762f-8bfe-45b84eb0666c --> | Update summary. | synthetic@example.test | — |
