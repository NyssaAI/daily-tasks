---
id: 01a121fc-b1f7-74b3-b4a2-458b7429a863
type: task
record_version: 2
title: "Update LinkedIn"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a121fc-b19d-7524-a486-5942d76dec45"
milestone_id: "01a121fc-b1cb-7a52-b79e-4a5491c55b40"
created_at: "2026-10-09T18:46:11.500Z"
updated_at: "2026-10-09T18:46:11.500Z"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a121fc-b1cb-7a52-b79e-4a5491c55b40 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a121fc-b19d-7524-a486-5942d76dec45 -->

## Requirements

Update headline.

## Definition of Done

- [ ] Reviewed headline. <!-- id: 01a121fc-b27a-7438-b547-413d0f8c3c98 -->

## Inputs

Source artifact to be supplied before execution. Local inputs belong in [inputs](inputs/).

## Output and delivery

Link the reviewed artifact from [outputs](outputs/) in the task result and milestone.

## Verification

Record the owner's review of the headline before checking its criterion.

## Result

Awaiting execution and review.
