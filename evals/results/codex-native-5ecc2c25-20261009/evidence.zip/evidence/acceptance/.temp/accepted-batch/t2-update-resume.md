---
id: 01a121fc-b224-762f-8bfe-45b84eb0666c
type: task
record_version: 2
title: "Update resume"
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a121fc-b19d-7524-a486-5942d76dec45"
milestone_id: "01a121fc-b1cb-7a52-b79e-4a5491c55b40"
created_at: "2026-10-09T18:46:11.500Z"
updated_at: "2026-10-09T18:46:11.500Z"
---
# M1-T2 — Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a121fc-b1cb-7a52-b79e-4a5491c55b40 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a121fc-b19d-7524-a486-5942d76dec45 -->

## Requirements

Update summary.

## Definition of Done

- [ ] Reviewed summary. <!-- id: 01a121fc-b2a7-7467-ab0f-f7375bf0b446 -->

## Inputs

Source artifact to be supplied before execution. Local inputs belong in [inputs](inputs/).

## Output and delivery

Link the reviewed artifact from [outputs](outputs/) in the task result and milestone.

## Verification

Record the owner's review of the summary before checking its criterion.

## Result

Awaiting execution and review.
