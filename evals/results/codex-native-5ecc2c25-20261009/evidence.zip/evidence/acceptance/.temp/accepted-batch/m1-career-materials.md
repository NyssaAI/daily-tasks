---
id: 01a121fc-b1cb-7a52-b79e-4a5491c55b40
type: milestone
record_version: 2
title: "Career materials"
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a121fc-b19d-7524-a486-5942d76dec45"
created_at: "2026-10-09T18:46:11.500Z"
updated_at: "2026-10-09T18:46:11.500Z"
---
# M1 — Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a121fc-b19d-7524-a486-5942d76dec45 -->

## Outcome

Prepare reviewed LinkedIn headline and resume summary.

## Definition of Done

- [ ] Both reviewed artifacts linked. <!-- id: 01a121fc-b24e-79dd-accb-d39251f1d7b0 -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a121fc-b1f7-74b3-b4a2-458b7429a863 -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a121fc-b224-762f-8bfe-45b84eb0666c -->
