import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const scratch = path.resolve('.temp');
const packet = JSON.parse(fs.readFileSync(path.join(scratch, 'prepare-result.json'), 'utf8'));
const note = path.join(packet.context.dailyPlansRoot, '2026-10-09.md');
const before = fs.readFileSync(path.join(scratch, 'manual-plan-before.md'));
const current = fs.readFileSync(note);
if (!before.equals(current)) throw new Error('Manual note changed; suspend capture');
const source = 'native-request:acceptance:possible-career-updates';
const candidates = [
  {id:'candidate:linkedin-update', title:'Update LinkedIn', kind:'possible-task', disposition:'unresolved', accepted:false, owner:packet.context.profile.user.email, project:null, milestone:null, target_date:null, source_keys:[source+'#linkedin'], sources:[{key:source+'#linkedin', text:'I might want to update LinkedIn and resume sometime.'}], unresolved_facts:['Whether to accept','Parent project and milestone','Scope and definition of done']},
  {id:'candidate:resume-update', title:'Improve resume', kind:'possible-task', disposition:'unresolved', accepted:false, owner:packet.context.profile.user.email, project:null, milestone:null, target_date:null, source_keys:[source+'#resume','Daily/2026-10-09.md#checkbox:maybe-improve-my-resume'], sources:[{key:source+'#resume',text:'I might want to update LinkedIn and resume sometime.'},{key:'Daily/2026-10-09.md#checkbox:maybe-improve-my-resume',path:'Daily/2026-10-09.md',text:'Maybe improve my resume'}], unresolved_facts:['Whether to accept','Parent project and milestone','Scope and definition of done']}
];
const hash = crypto.createHash('sha256').update(current).digest('hex');
fs.writeFileSync(path.join(packet.context.stateRoot,'candidates.json'),JSON.stringify({schemaVersion:1,planningBinding:packet.context.planningBinding,candidates},null,2)+'\n');
fs.writeFileSync(path.join(packet.context.stateRoot,'checkin.json'),JSON.stringify({schemaVersion:1,localDate:packet.context.localDate,planningBinding:packet.context.planningBinding,vaultRoot:packet.context.vaultRoot,projectsRoot:packet.context.projectsRoot,dailyPlansRoot:packet.context.dailyPlansRoot,pendingOperationIds:[],unresolvedCandidateIds:candidates.map(c=>c.id),unresolvedConflictIds:[],processedSourceVersions:[{source:source,version:'current-request'},{path:note,sha256:hash}],nextStep:'Review two unresolved candidates only when the user chooses; obtain affirmative acceptance and parent scope before creating work.',status:'pending-candidate-decisions',manualPlanPreserved:true,managedPlanCreated:false},null,2)+'\n');
fs.copyFileSync(note,path.join(scratch,'manual-plan-after.md'));
fs.writeFileSync(path.join(scratch,'actions.json'),JSON.stringify({actions:['Read installed capture/check-in/setup instructions and referenced contracts','Reuse vault-only profile','Run installed CLI planning-prepare, record scan, checklist parse, log-query, maintenance-inspect','Merge resume mentions into one unresolved candidate','Persist two unaccepted candidates and resumable check-in state','Preserve manual note byte-for-byte'],before:{records:0,candidates:0},after:{records:0,candidates:2,accepted:0},manualPlan:{path:note,beforeSha256:hash,afterSha256:hash,unchanged:true},limitations:['No managed plan created or rollover receipt claimed','Maintenance inspection blocked by missing reconciliation baseline; no success advanced'],logWrites:0},null,2)+'\n');
console.log(JSON.stringify({savedCandidates:2,accepted:0,manualPlanUnchanged:true}));
