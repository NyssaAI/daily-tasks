---
id: "01a121fb-891d-7e96-8ae8-5c20c049d86c"
type: blocker
record_version: 2
title: "Await approval"
blocker-state: "resolved"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:44:55.240Z"
updated_at: "2026-10-09T18:45:01.674Z"
resolved_at: "2026-10-09T18:45:01.674Z"
---
# Await approval

Await external approval of both reviewed career artifacts.

## Resolution condition
Explicit approval of both artifacts is received.

## Resolution evidence
Synthetic reviewed approval of both artifacts received under user authorization.

## Blocks
- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->
