---
id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
type: "project"
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T18:46:01.580Z"
project-state: "completed"
resolved_at: "2026-10-09T18:46:01.580Z"
---
# Job Search

Prepare career materials for the job search.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [x] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 --> | | Both reviewed artifacts linked. | Synthetic User | — |
| | [x] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 --> | Draft a headline. | Synthetic User | — |
| | [x] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 --> | Draft a summary. | Synthetic User | — |
