import fs from 'node:fs';
const source=fs.readFileSync('.temp/continue.mjs','utf8');
let prefix=source.slice(0,source.indexOf('const pendingDir='));
prefix+=`function closeParents(){closure(m,true,'Final eligible milestone');transition(m,'completed','Final complete milestone');closure(p,true,'Final eligible project');transition(p,'completed','Final complete project');}\ncloseParents();\n`;
prefix+=source.slice(source.indexOf('const final=scan();'));
fs.writeFileSync('.temp/finish.mjs',prefix);
