# Retained runner failures

Initial CLI attempts used relative input paths and were rejected with `--input requires an absolute JSON file`; all subsequent numbered inputs use absolute paths.

The first workflow stopped after writing the temporary resume cancellation, before logging, because the evidence runner incorrectly required zero diagnostics. The CLI returned `cancelled-prerequisite` with the message that the dependency remains informational. The pending checkpoint, original before/after bytes and CLI result are retained. Recovery preserved its operation ID and timestamps, added concrete observed cancellation snapshots, appended the event through the CLI and verified/completed the pending operation. The closure check then allowed LinkedIn completion with the cancelled dependency.

The continuation stopped after successfully completing the restored resume because its local `closeParents` helper was omitted. No pending operation remained. The final continuation performs only the remaining parent closure and final checks.
