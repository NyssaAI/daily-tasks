import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-guarded-full8/codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4';
const files=['skills/daily-tasks/SKILL.md','skills/daily-tasks-records/SKILL.md','skills/daily-tasks-setup/SKILL.md','skills/daily-tasks/references/cli.md','skills/daily-tasks/references/operations.md','skills/daily-tasks/references/verification.md','skills/daily-tasks/references/records.md','skills/daily-tasks/assets/blocker.md','bin/daily-tasks.mjs'];
fs.writeFileSync('.temp/installed-instructions.json',JSON.stringify({node:process.version,host:'Current native Codex session; host build and model not exposed',sources:files.map(f=>{const p=path.join(bundle,f);return {path:p,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')};}),scenarioSource:'D:/repos/NyssaAI/daily-tasks/evals/README.md',scope:'Only current case, installed bundle and referenced README read. No previous attempts or regression tests read.'},null,2));
