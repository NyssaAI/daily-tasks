import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=process.cwd(), temp=path.join(root,'.temp'), vault=path.join(root,'vault');
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-guarded-full8/codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4';
export const read=p=>fs.readFileSync(p,'utf8');
export const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
export const write=(p,s)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);};
export const json=(p,v)=>write(p,JSON.stringify(v,null,2)+'\n');
export const scope={vaultRoot:vault,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json'),homeRoot:root};
export function cli(label,operation,input){
 const inputPath=path.join(temp,label+'.input.json');
 if(input!==undefined)json(inputPath,input);
 const args=[path.join(pkg,'bin/daily-tasks.mjs'),operation,...(input===undefined?[]:['--input',inputPath])];
 const r=spawnSync(process.execPath,args,{encoding:'utf8'});
 json(path.join(temp,label+'.execution.json'),{command:process.execPath,args,status:r.status,stdout:r.stdout,stderr:r.stderr});
 if(r.status!==0)throw Error(label+': '+r.stderr);
 const v=JSON.parse(r.stdout);json(path.join(temp,label+'.result.json'),v);return v;
}
