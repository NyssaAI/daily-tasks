---
id: "01a121fd-2e84-7304-b1c5-3b33c5fcdfe1"
type: task
record_version: 2
title: "Independent note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
created_at: "2026-10-09T18:47:17.519Z"
updated_at: "2026-10-09T18:47:17.519Z"
---
# M1-T3 — Independent note

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Produce a local note.

## Definition of Done

- [ ] Reviewed note. <!-- id: 01a121fd-2eb0-73ad-a872-51428d33de08 -->

## Scope and constraints

Authorized synthetic local work; preserve pending task2 conflict.

## Inputs

Current user acceptance and attestation of reviewed synthetic evidence.

## Output and delivery

Local Markdown note in outputs/independent-note.md, linked here after delivery.

## Verification

Verify the local note exists and link the user's review attestation.

## Result

Accepted; local note pending.
