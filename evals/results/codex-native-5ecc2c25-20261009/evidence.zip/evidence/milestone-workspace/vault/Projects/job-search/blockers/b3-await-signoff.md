---
id: "01a121fb-9c47-7c43-8f77-3193d65312ef"
type: "blocker"
record_version: 2
title: "Await signoff"
blocker-state: "open"
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T18:45:00.149Z"
updated_at: "2026-10-09T18:45:00.149Z"
---
# Await signoff

Waiting for signoff.

## Resolution condition

User signoff received.

## Resolution evidence

Pending.

## Blocks
