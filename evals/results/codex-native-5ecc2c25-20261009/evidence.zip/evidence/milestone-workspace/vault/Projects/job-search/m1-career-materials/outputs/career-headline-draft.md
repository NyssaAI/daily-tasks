# LinkedIn headline draft

Career professional preparing for the next opportunity

Synthetic draft based on the LinkedIn source and shared style guide; review pending.
