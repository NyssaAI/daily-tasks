# Resume summary draft

Career professional preparing for the next opportunity, with a focused summary for the job search.

Uses the headline draft in its existing output location, resume source, and shared style guide. Synthetic sources provide no career facts; review pending.
