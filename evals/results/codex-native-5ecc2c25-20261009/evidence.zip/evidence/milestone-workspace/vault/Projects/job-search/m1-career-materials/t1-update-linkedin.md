---
id: "01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8"
type: "task"
record_version: 2
title: "Update LinkedIn"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:41:50.392Z"
updated_at: "2026-10-09T18:44:39.498Z"
task-state: "cancelled"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
milestone_id: "01a1211c-fc13-750e-993c-51e78d20ea25"
document-maturity: "reviewed"
---
# M1-T1 — Update LinkedIn

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a1211c-fc13-750e-993c-51e78d20ea25 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a1211c-fbe7-727c-885c-bd3fcf926af2 -->

## Requirements

Draft a headline.

## Definition of Done

- [ ] A reviewed headline is saved locally. <!-- id: 01a1211c-fcde-77f4-84d8-63271f429f17 -->

## Inputs

- [LinkedIn source](inputs/linkedin-source.txt) — original attachments/a/source.txt.
- [Shared style guide](inputs/shared-style-guide.txt) — original attachments/shared.txt.

## Output and delivery

Draft artifact: [Headline](outputs/career-headline-draft.md). Save the headline locally in outputs/. Link the actual artifact here and from the milestone after review.

## Verification

Confirm the headline was reviewed and exists locally. Record review evidence and link the artifact before marking the criterion satisfied.

## Result

Local draft: [Headline](outputs/career-headline-draft.md). User review is pending.

## Cancellation

Explicitly cancelled by user at 2026-10-09T18:44:39.498Z. Draft retained.

## Blocked by

- [[../blockers/b2-await-source|Await source]] <!-- ref: 01a121fb-97ce-7dcf-bc66-ee2163399d7d -->
