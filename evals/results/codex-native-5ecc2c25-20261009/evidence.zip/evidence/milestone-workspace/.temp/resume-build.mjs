import fs from 'node:fs';
const source=fs.readFileSync('.temp/scenario7.mjs','utf8');
const pre=source.slice(0,source.indexOf("const a=read("));
const cleaned=pre.replace("let serial=0;", "let serial=100;").replace(/check\('initial numbered[\s\S]*?cli\('log-query',\{projectsRoot:projects\}\); cli\('inspect-records',\{projectsRoot:projects\}\);/, '');
const fix=`
let one,two;
const allocation={number:3}, t3=path.join(m,'t3-polish-summary.md'), t3id=read(t3).match(/^id: "([^"]+)"/m)[1];
let milestone=read(mf), p=read(pfile);
const mr1=milestone.split(/\\r?\\n/).find(x=>x.includes('[[t1-')),mr2=milestone.split(/\\r?\\n/).find(x=>x.includes('[[t2-'));
milestone=milestone.replace(mr1+'\\n'+mr2,mr2+'\\n'+mr1.replace('- [ ]','- [-]').replace('[[t1-update-linkedin|Update LinkedIn]]','~~[[t1-update-linkedin|Update LinkedIn]]~~')+'\\n- [ ] [[t3-polish-summary|Polish summary]] <!-- ref: '+t3id+' -->');
const pr1=p.split(/\\r?\\n/).find(x=>x.includes('/t1-')),pr2=p.split(/\\r?\\n/).find(x=>x.includes('/t2-'));
p=p.replace(pr1+'\\n'+pr2,pr2+'\\n'+pr1.replace('[ ]','[-]').replace('[[m1-career-materials/t1-update-linkedin\\\\|Update LinkedIn]]','~~[[m1-career-materials/t1-update-linkedin\\\\|Update LinkedIn]]~~')+'\\n| | [ ] [[m1-career-materials/t3-polish-summary\\\\|Polish summary]] <!-- ref: '+t3id+' --> | Polish summary. | Synthetic User | — |');
batch('views.reordered',[[mf,milestone],[pfile,p]],[],[],'Reorder tasks and refresh cancelled task and accepted t3 views.');
const a=read(path.join(root,'attachments/a/source.txt')),b=read(path.join(root,'attachments/b/source.txt')),shared=read(path.join(root,'attachments/shared.txt'));
const out1=path.join(m,'outputs/linkedin-headline-draft.md'),out2=path.join(m,'outputs/resume-summary-draft.md');
const inventory=()=>cli('project-index',{vaultRoot:vault,projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot,timezone:context.timezone,forceRefresh:true});
`;
fs.writeFileSync('.temp/scenario7-continuation.mjs',cleaned+fix+source.slice(source.indexOf("check('reorder stable")));
