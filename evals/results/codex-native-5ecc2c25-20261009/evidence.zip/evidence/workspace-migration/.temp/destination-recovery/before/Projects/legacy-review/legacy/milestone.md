---
id: "01a121fc-1465-7dba-9137-e856ad7ee1e4"
type: "milestone"
title: "Review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
milestone-state: "not-started"
project_id: "01a121fc-1431-72a7-9b83-21dd1685eed0"
---
# Review

**Project:** [[../project-index|Legacy review]] <!-- ref: 01a121fc-1431-72a7-9b83-21dd1685eed0 -->

## Acceptance
[[definition-of-done|Review acceptance]] <!-- ref: 01a121fc-14a3-70a0-866f-6c0d97369a0d -->

## Tasks
- [ ] [[ready-task|Prepared review]] <!-- ref: 01a121fc-14d1-718e-8cb5-76b43349e8a9 -->
- [x] [[completed-task|Completed legacy task]] <!-- ref: 01a121fc-1501-7f8c-9e3c-162f49c97be2 -->
- [ ] [[unresolved-task|Unresolved legacy task]] <!-- ref: 01a121fc-152d-70b3-b97e-20517f2ed5ea -->
