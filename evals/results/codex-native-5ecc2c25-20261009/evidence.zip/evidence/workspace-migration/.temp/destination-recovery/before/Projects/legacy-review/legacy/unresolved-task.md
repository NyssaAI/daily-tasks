---
id: "01a121fc-152d-70b3-b97e-20517f2ed5ea"
type: "task"
title: "Unresolved legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121fc-1431-72a7-9b83-21dd1685eed0"
milestone_id: "01a121fc-1465-7dba-9137-e856ad7ee1e4"
---
# Unresolved legacy task

**Milestone:** [[milestone|Review]] <!-- ref: 01a121fc-1465-7dba-9137-e856ad7ee1e4 -->

## Requirements
Review the prepared material.

## References
[[definition-of-done#Definition of Done|Review acceptance]] <!-- ref: 01a121fc-14a3-70a0-866f-6c0d97369a0d -->
[[definition-of-done#Definition of Done|Approval criterion]] <!-- ref: 01a121fc-1584-716e-8632-2b63d5d82c29 -->

Unrelated task prose must survive.
