---
id: "01a121fc-14d1-718e-8cb5-76b43349e8a9"
type: "task"
record_version: 2
title: "Prepared review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121fc-1431-72a7-9b83-21dd1685eed0"
milestone_id: "01a121fc-1465-7dba-9137-e856ad7ee1e4"
---
# Prepared review

**Milestone:** [[m1-review|Review]] <!-- ref: 01a121fc-1465-7dba-9137-e856ad7ee1e4 -->

## Requirements
Review the prepared material.

## Definition of Done
- [ ] Prepared material reviewed. <!-- id: 01a121fc-15b1-7311-ab24-1e2731b460bb -->

## References
[[m1-review#Definition of Done|Review acceptance]] <!-- ref: 01a121fc-1465-7dba-9137-e856ad7ee1e4 -->
[[m1-review#Definition of Done|Approval criterion]] <!-- ref: 01a121fc-1584-716e-8632-2b63d5d82c29 -->

Unrelated task prose must survive.
