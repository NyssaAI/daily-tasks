---
id: "01a121fc-1559-7b75-a86d-971f068ad5d6"
type: "blocker"
title: "Approval"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
blocker-state: "open"
project_id: "01a121fc-1431-72a7-9b83-21dd1685eed0"
---
# Approval

## Resolution condition
External approver sends release authorization.

## Blocks
- [[../m1-review/m1-review|Review acceptance]] <!-- ref: 01a121fc-1465-7dba-9137-e856ad7ee1e4 -->
