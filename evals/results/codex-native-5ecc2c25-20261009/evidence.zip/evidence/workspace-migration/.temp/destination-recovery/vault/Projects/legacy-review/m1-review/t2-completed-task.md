---
id: "01a121fc-1501-7f8c-9e3c-162f49c97be2"
type: "task"
title: "Completed legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "completed"
project_id: "01a121fc-1431-72a7-9b83-21dd1685eed0"
milestone_id: "01a121fc-1465-7dba-9137-e856ad7ee1e4"
started_at: "2026-10-01T16:00:00.000Z"
resolved_at: "2026-10-02T15:00:00.000Z"
---
# Completed legacy task

**Milestone:** [[m1-review|Review]] <!-- ref: 01a121fc-1465-7dba-9137-e856ad7ee1e4 -->

## Requirements
Review the prepared material.

## References
[[m1-review#Definition of Done|Review acceptance]] <!-- ref: 01a121fc-1465-7dba-9137-e856ad7ee1e4 -->
[[m1-review#Definition of Done|Approval criterion]] <!-- ref: 01a121fc-1584-716e-8632-2b63d5d82c29 -->

Unrelated task prose must survive.
