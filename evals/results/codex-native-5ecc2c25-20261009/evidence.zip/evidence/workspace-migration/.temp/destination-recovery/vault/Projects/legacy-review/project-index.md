---
id: "01a121fc-1431-72a7-9b83-21dd1685eed0"
type: "project"
title: "Legacy review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "not-started"
---
# Legacy review

## Milestones
- [ ] [[m1-review/m1-review|Review]] <!-- ref: 01a121fc-1465-7dba-9137-e856ad7ee1e4 -->

Unrelated project prose must survive.
