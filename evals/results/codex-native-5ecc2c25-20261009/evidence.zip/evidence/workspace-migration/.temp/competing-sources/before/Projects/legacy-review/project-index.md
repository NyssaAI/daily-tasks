---
id: "01a121fd-43fb-748b-af53-7cf083554232"
type: "project"
title: "Legacy review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "not-started"
---
# Legacy review

## Milestones
- [ ] [[legacy/milestone|Review]] <!-- ref: 01a121fd-442a-7c9b-89dd-8df26dbaf340 -->

Unrelated project prose must survive.
