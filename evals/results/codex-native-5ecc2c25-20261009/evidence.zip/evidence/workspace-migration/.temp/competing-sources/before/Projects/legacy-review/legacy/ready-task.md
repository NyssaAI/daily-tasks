---
id: "01a121fd-4485-7010-99d1-020927f1c11f"
type: "task"
title: "Prepared review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121fd-43fb-748b-af53-7cf083554232"
milestone_id: "01a121fd-442a-7c9b-89dd-8df26dbaf340"
---
# Prepared review

**Milestone:** [[milestone|Review]] <!-- ref: 01a121fd-442a-7c9b-89dd-8df26dbaf340 -->

## Requirements
Review the prepared material.

## Definition of Done
- [ ] Prepared material reviewed. <!-- id: 01a121fd-456b-7490-9f70-7505081a79d1 -->

## References
[[definition-of-done#Definition of Done|Review acceptance]] <!-- ref: 01a121fd-4459-7260-bb57-02d7ff95c2a0 -->
[[definition-of-done#Definition of Done|Approval criterion]] <!-- ref: 01a121fd-453e-728d-84d6-d15cf4509c11 -->

Unrelated task prose must survive.
