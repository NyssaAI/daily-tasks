---
id: "01a121fd-44e1-7953-817f-dbc8e0679960"
type: "task"
title: "Unresolved legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121fd-43fb-748b-af53-7cf083554232"
milestone_id: "01a121fd-442a-7c9b-89dd-8df26dbaf340"
---
# Unresolved legacy task

**Milestone:** [[milestone|Review]] <!-- ref: 01a121fd-442a-7c9b-89dd-8df26dbaf340 -->

## Requirements
Review the prepared material.

## References
[[definition-of-done#Definition of Done|Review acceptance]] <!-- ref: 01a121fd-4459-7260-bb57-02d7ff95c2a0 -->
[[definition-of-done#Definition of Done|Approval criterion]] <!-- ref: 01a121fd-453e-728d-84d6-d15cf4509c11 -->

Unrelated task prose must survive.
