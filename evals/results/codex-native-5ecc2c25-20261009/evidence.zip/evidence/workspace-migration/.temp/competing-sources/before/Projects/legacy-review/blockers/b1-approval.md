---
id: "01a121fd-4510-7523-936a-07ff3143129b"
type: "blocker"
title: "Approval"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
blocker-state: "open"
project_id: "01a121fd-43fb-748b-af53-7cf083554232"
---
# Approval

## Resolution condition
External approver sends release authorization.

## Blocks
- [[../legacy/definition-of-done|Review acceptance]] <!-- ref: 01a121fd-4459-7260-bb57-02d7ff95c2a0 -->
