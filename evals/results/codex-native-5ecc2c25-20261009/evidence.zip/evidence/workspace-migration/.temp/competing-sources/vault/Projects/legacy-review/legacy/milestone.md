---
id: "01a121fd-442a-7c9b-89dd-8df26dbaf340"
type: "milestone"
title: "Review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
milestone-state: "not-started"
project_id: "01a121fd-43fb-748b-af53-7cf083554232"
---
# Review

**Project:** [[../project-index|Legacy review]] <!-- ref: 01a121fd-43fb-748b-af53-7cf083554232 -->

## Acceptance
[[definition-of-done|Review acceptance]] <!-- ref: 01a121fd-4459-7260-bb57-02d7ff95c2a0 -->

## Tasks
- [ ] [[ready-task|Prepared review]] <!-- ref: 01a121fd-4485-7010-99d1-020927f1c11f -->
- [x] [[completed-task|Completed legacy task]] <!-- ref: 01a121fd-44b1-7a0b-8da1-7ede43c84558 -->
- [ ] [[unresolved-task|Unresolved legacy task]] <!-- ref: 01a121fd-44e1-7953-817f-dbc8e0679960 -->

## Definition of Done
- [ ] Independently embedded review requirement. <!-- id: 01a121fd-931e-7670-b517-07962a712d07 -->
