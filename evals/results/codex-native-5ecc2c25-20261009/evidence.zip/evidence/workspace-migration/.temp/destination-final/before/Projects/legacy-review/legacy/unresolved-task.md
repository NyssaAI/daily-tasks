---
id: "01a121fc-5c7f-7ec5-8520-ae9e8607e110"
type: "task"
title: "Unresolved legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121fc-5ba1-7d32-a384-aef9398eb30f"
milestone_id: "01a121fc-5bcd-7234-94b6-b8832986f2d7"
---
# Unresolved legacy task

**Milestone:** [[milestone|Review]] <!-- ref: 01a121fc-5bcd-7234-94b6-b8832986f2d7 -->

## Requirements
Review the prepared material.

## References
[[definition-of-done#Definition of Done|Review acceptance]] <!-- ref: 01a121fc-5bfa-74ae-9aba-6b71b0d734fd -->
[[definition-of-done#Definition of Done|Approval criterion]] <!-- ref: 01a121fc-5d30-79cf-ae6a-e88cab032049 -->

Unrelated task prose must survive.
