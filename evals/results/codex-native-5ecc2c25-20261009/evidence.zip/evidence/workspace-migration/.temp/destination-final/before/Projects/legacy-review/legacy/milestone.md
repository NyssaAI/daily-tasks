---
id: "01a121fc-5bcd-7234-94b6-b8832986f2d7"
type: "milestone"
title: "Review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
milestone-state: "not-started"
project_id: "01a121fc-5ba1-7d32-a384-aef9398eb30f"
---
# Review

**Project:** [[../project-index|Legacy review]] <!-- ref: 01a121fc-5ba1-7d32-a384-aef9398eb30f -->

## Acceptance
[[definition-of-done|Review acceptance]] <!-- ref: 01a121fc-5bfa-74ae-9aba-6b71b0d734fd -->

## Tasks
- [ ] [[ready-task|Prepared review]] <!-- ref: 01a121fc-5c25-74c3-8e79-7242e3121c05 -->
- [x] [[completed-task|Completed legacy task]] <!-- ref: 01a121fc-5c52-77bd-9c19-c00294437b12 -->
- [ ] [[unresolved-task|Unresolved legacy task]] <!-- ref: 01a121fc-5c7f-7ec5-8520-ae9e8607e110 -->
