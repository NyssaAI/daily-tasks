---
id: "01a121fc-5cc9-73cf-8617-84505c823bc0"
type: "blocker"
title: "Approval"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
blocker-state: "open"
project_id: "01a121fc-5ba1-7d32-a384-aef9398eb30f"
---
# Approval

## Resolution condition
External approver sends release authorization.

## Blocks
- [[../legacy/definition-of-done|Review acceptance]] <!-- ref: 01a121fc-5bfa-74ae-9aba-6b71b0d734fd -->
