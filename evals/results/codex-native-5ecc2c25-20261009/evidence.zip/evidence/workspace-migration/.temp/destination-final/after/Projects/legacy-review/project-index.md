---
id: "01a121fc-5ba1-7d32-a384-aef9398eb30f"
type: "project"
title: "Legacy review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "not-started"
---
# Legacy review

## Milestones
- [ ] [[m1-review/m1-review|Review]] <!-- ref: 01a121fc-5bcd-7234-94b6-b8832986f2d7 -->

Unrelated project prose must survive.
