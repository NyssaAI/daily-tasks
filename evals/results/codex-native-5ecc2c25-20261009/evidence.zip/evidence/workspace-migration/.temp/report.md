# Scenario8 workspace migration

Executed in this fresh native Codex tool session using the explicitly invoked installed Daily Tasks instructions and installed CLI. No previous attempts, regression tests, repository implementation or personal directories were read. Host version, model and authentication details were not exposed; this report does not assert those facts or packaging-based activation.

39/39 bounded workflow evidence checks passed. See [assertions](assertions.json). These are checks of actual files and queried events, not regression-test counts or an agent score.

The supplied vault now contains [the migrated review milestone](../vault/Projects/legacy-review/m1-review/m1-review.md). Its old standalone DoD was removed only after an allowed retirement response and live navigation inspection. Milestone, task and criterion identities, lifecycle fields, history, shared evidence and reciprocal blocker relationships were preserved. Task and daily-plan criterion links retain the criterion UUID and navigate to the milestone heading. Main-vault completion, event uniqueness and navigation checks: {"oneExactEvent":true,"noDuplicateLiveRecords":true,"completed":true,"navigationClean":true}.

Independent destination-final, source-stop and log-stop fixtures stopped in separate processes after destination persistence, source removal and log append. Each resumed its saved pending operation, completed through migration-complete, and retried with one exact migration event and no duplicate live records. Actual file effects, interruption points and recovery observations are in each actions.jsonl; subprocess retry commands/results in invocation files.

Unexpected-edit and case-collision remain pending conflicts. Their original/new user bytes were preserved and no migration event or completion was recorded. The Windows collision used M1-REVIEW.MD against m1-review.md. Competing-sources closure reports both embedded and standalone DoD authority.

The completed legacy task still has its completed history, no invented task criteria and no record_version promotion. The unresolved task remains readable, not-started and pending conversion. Accepted task-specific criteria were requested through the native question tool and have not been supplied.

Two preliminary current-run fixtures were refused retirement when relative evidence paths changed exact criterion text or provenance content. They remain pending; all refusal responses and affected bytes are retained. Later fixtures preserved shared evidence in place and exact source text. Preliminary standalone fixtures also reported a missing legacy project parent; the main-vault fixture includes that parent. No installed bundle fixes were made.

Evidence: instructions-evidence.json contains the actual loaded instruction paths and hashes. cli/ holds structured installed CLI inputs, command arrays, stdout, stderr and exit codes. Per-fixture before/after directories contain only declared non-log files; history was captured solely through log-query. Recovery bytes for the main-vault operation were persisted in project .temp before writes. No direct log reads, hashes or edits were used.
