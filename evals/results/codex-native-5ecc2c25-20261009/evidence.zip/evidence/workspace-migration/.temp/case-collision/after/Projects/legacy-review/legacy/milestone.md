---
id: "01a121fd-40be-75d1-8e89-d49d9e45d0d2"
type: "milestone"
title: "Review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
milestone-state: "not-started"
project_id: "01a121fd-4091-7c53-a528-85aa720bdf9a"
---
# Review

**Project:** [[../project-index|Legacy review]] <!-- ref: 01a121fd-4091-7c53-a528-85aa720bdf9a -->

## Acceptance
[[definition-of-done|Review acceptance]] <!-- ref: 01a121fd-40ea-7670-aa84-e1c32382f52b -->

## Tasks
- [ ] [[ready-task|Prepared review]] <!-- ref: 01a121fd-4115-7a0e-b855-e2e0e93a9d69 -->
- [x] [[completed-task|Completed legacy task]] <!-- ref: 01a121fd-4143-7d10-abe7-b5c8bc99425d -->
- [ ] [[unresolved-task|Unresolved legacy task]] <!-- ref: 01a121fd-4170-7935-9288-48756d1a2752 -->
