---
id: "01a121fd-4091-7c53-a528-85aa720bdf9a"
type: "project"
title: "Legacy review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "not-started"
---
# Legacy review

## Milestones
- [ ] [[legacy/milestone|Review]] <!-- ref: 01a121fd-40be-75d1-8e89-d49d9e45d0d2 -->

Unrelated project prose must survive.
