Unrelated Windows case-insensitive collision. Preserve these bytes.
