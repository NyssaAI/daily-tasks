---
id: "01a121fd-4115-7a0e-b855-e2e0e93a9d69"
type: "task"
title: "Prepared review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121fd-4091-7c53-a528-85aa720bdf9a"
milestone_id: "01a121fd-40be-75d1-8e89-d49d9e45d0d2"
---
# Prepared review

**Milestone:** [[milestone|Review]] <!-- ref: 01a121fd-40be-75d1-8e89-d49d9e45d0d2 -->

## Requirements
Review the prepared material.

## Definition of Done
- [ ] Prepared material reviewed. <!-- id: 01a121fd-41f8-7e75-977d-3c6410e0aad0 -->

## References
[[definition-of-done#Definition of Done|Review acceptance]] <!-- ref: 01a121fd-40ea-7670-aa84-e1c32382f52b -->
[[definition-of-done#Definition of Done|Approval criterion]] <!-- ref: 01a121fd-41cb-7044-af6c-4b4025440556 -->

Unrelated task prose must survive.
