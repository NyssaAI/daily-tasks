---
id: "01a121fd-4143-7d10-abe7-b5c8bc99425d"
type: "task"
title: "Completed legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "completed"
project_id: "01a121fd-4091-7c53-a528-85aa720bdf9a"
milestone_id: "01a121fd-40be-75d1-8e89-d49d9e45d0d2"
started_at: "2026-10-01T16:00:00.000Z"
resolved_at: "2026-10-02T15:00:00.000Z"
---
# Completed legacy task

**Milestone:** [[milestone|Review]] <!-- ref: 01a121fd-40be-75d1-8e89-d49d9e45d0d2 -->

## Requirements
Review the prepared material.

## References
[[definition-of-done#Definition of Done|Review acceptance]] <!-- ref: 01a121fd-40ea-7670-aa84-e1c32382f52b -->
[[definition-of-done#Definition of Done|Approval criterion]] <!-- ref: 01a121fd-41cb-7044-af6c-4b4025440556 -->

Unrelated task prose must survive.
