---
id: "01a121fd-4170-7935-9288-48756d1a2752"
type: "task"
title: "Unresolved legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121fd-4091-7c53-a528-85aa720bdf9a"
milestone_id: "01a121fd-40be-75d1-8e89-d49d9e45d0d2"
---
# Unresolved legacy task

**Milestone:** [[milestone|Review]] <!-- ref: 01a121fd-40be-75d1-8e89-d49d9e45d0d2 -->

## Requirements
Review the prepared material.

## References
[[definition-of-done#Definition of Done|Review acceptance]] <!-- ref: 01a121fd-40ea-7670-aa84-e1c32382f52b -->
[[definition-of-done#Definition of Done|Approval criterion]] <!-- ref: 01a121fd-41cb-7044-af6c-4b4025440556 -->

Unrelated task prose must survive.
