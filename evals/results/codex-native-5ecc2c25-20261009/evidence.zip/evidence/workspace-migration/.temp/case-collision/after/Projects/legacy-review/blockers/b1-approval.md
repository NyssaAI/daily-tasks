---
id: "01a121fd-419e-731c-9560-3d1ae307f3cf"
type: "blocker"
title: "Approval"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
blocker-state: "open"
project_id: "01a121fd-4091-7c53-a528-85aa720bdf9a"
---
# Approval

## Resolution condition
External approver sends release authorization.

## Blocks
- [[../legacy/definition-of-done|Review acceptance]] <!-- ref: 01a121fd-40ea-7670-aa84-e1c32382f52b -->
