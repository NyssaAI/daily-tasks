---
id: "01a121fb-9e0b-7251-be64-6b4fca69df77"
type: "milestone"
title: "Review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
milestone-state: "not-started"
project_id: "01a121fb-9ddb-7b6e-82b0-1e719aeea953"
---
# Review

**Project:** [[../project-index|Legacy review]] <!-- ref: 01a121fb-9ddb-7b6e-82b0-1e719aeea953 -->

## Acceptance
[[definition-of-done|Review acceptance]] <!-- ref: 01a121fb-9e3b-7cb7-8dda-bea668e8405f -->

## Tasks
- [ ] [[ready-task|Prepared review]] <!-- ref: 01a121fb-9e6a-709b-abd3-8ec39cdcf6da -->
- [x] [[completed-task|Completed legacy task]] <!-- ref: 01a121fb-9e9a-7137-9381-8a1f032dab54 -->
- [ ] [[unresolved-task|Unresolved legacy task]] <!-- ref: 01a121fb-9ecd-7784-84ae-100bd4308dc3 -->
