---
id: "01a121fb-9eff-725f-bc93-cf06b90498bc"
type: "blocker"
title: "Approval"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
blocker-state: "open"
project_id: "01a121fb-9ddb-7b6e-82b0-1e719aeea953"
---
# Approval

## Resolution condition
External approver sends release authorization.

## Blocks
- [[../legacy/definition-of-done|Review acceptance]] <!-- ref: 01a121fb-9e3b-7cb7-8dda-bea668e8405f -->
