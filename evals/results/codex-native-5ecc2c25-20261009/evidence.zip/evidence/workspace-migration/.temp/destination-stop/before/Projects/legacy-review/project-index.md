---
id: "01a121fb-9ddb-7b6e-82b0-1e719aeea953"
type: "project"
title: "Legacy review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
project-state: "not-started"
---
# Legacy review

## Milestones
- [ ] [[legacy/milestone|Review]] <!-- ref: 01a121fb-9e0b-7251-be64-6b4fca69df77 -->

Unrelated project prose must survive.
