---
id: "01a121fb-9ecd-7784-84ae-100bd4308dc3"
type: "task"
title: "Unresolved legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121fb-9ddb-7b6e-82b0-1e719aeea953"
milestone_id: "01a121fb-9e0b-7251-be64-6b4fca69df77"
---
# Unresolved legacy task

**Milestone:** [[milestone|Review]] <!-- ref: 01a121fb-9e0b-7251-be64-6b4fca69df77 -->

## Requirements
Review the prepared material.

## References
[[definition-of-done#Definition of Done|Review acceptance]] <!-- ref: 01a121fb-9e3b-7cb7-8dda-bea668e8405f -->
[[definition-of-done#Definition of Done|Approval criterion]] <!-- ref: 01a121fb-9f2f-7443-ac4a-dc383e21b442 -->

Unrelated task prose must survive.
