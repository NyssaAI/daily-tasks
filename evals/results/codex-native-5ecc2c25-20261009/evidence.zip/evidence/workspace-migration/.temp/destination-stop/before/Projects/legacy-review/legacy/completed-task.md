---
id: "01a121fb-9e9a-7137-9381-8a1f032dab54"
type: "task"
title: "Completed legacy task"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "completed"
project_id: "01a121fb-9ddb-7b6e-82b0-1e719aeea953"
milestone_id: "01a121fb-9e0b-7251-be64-6b4fca69df77"
started_at: "2026-10-01T16:00:00.000Z"
resolved_at: "2026-10-02T15:00:00.000Z"
---
# Completed legacy task

**Milestone:** [[milestone|Review]] <!-- ref: 01a121fb-9e0b-7251-be64-6b4fca69df77 -->

## Requirements
Review the prepared material.

## References
[[definition-of-done#Definition of Done|Review acceptance]] <!-- ref: 01a121fb-9e3b-7cb7-8dda-bea668e8405f -->
[[definition-of-done#Definition of Done|Approval criterion]] <!-- ref: 01a121fb-9f2f-7443-ac4a-dc383e21b442 -->

Unrelated task prose must survive.
