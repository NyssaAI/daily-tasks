---
id: "01a121fb-9e6a-709b-abd3-8ec39cdcf6da"
type: "task"
record_version: 2
title: "Prepared review"
owner: "synthetic@example.test"
created_at: "2026-10-01T15:00:00.000Z"
updated_at: "2026-10-02T15:00:00.000Z"
task-state: "not-started"
project_id: "01a121fb-9ddb-7b6e-82b0-1e719aeea953"
milestone_id: "01a121fb-9e0b-7251-be64-6b4fca69df77"
---
# Prepared review

**Milestone:** [[m1-review|Review]] <!-- ref: 01a121fb-9e0b-7251-be64-6b4fca69df77 -->

## Requirements
Review the prepared material.

## Definition of Done
- [ ] Prepared material reviewed. <!-- id: 01a121fb-9f5d-77e8-a4b1-cb358b4aebb9 -->

## References
[[m1-review#Definition of Done|Review acceptance]] <!-- ref: 01a121fb-9e0b-7251-be64-6b4fca69df77 -->
[[m1-review#Definition of Done|Approval criterion]] <!-- ref: 01a121fb-9f2f-7443-ac4a-dc383e21b442 -->

Unrelated task prose must survive.
