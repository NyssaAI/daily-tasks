import fs from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=process.cwd(),cwd=path.join(root,'01-common-root'),evidence=path.join(cwd,'.temp/native-workflow');
const cli=path.resolve(root,'../../codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs');
const scope=JSON.parse(await fs.readFile(path.join(evidence,'02-resolve-context.input.json'),'utf8'));
const operation=JSON.parse(await fs.readFile(path.join(evidence,'pending-operation.json'),'utf8'));
const context=JSON.parse(JSON.parse(await fs.readFile(path.join(evidence,'02-resolve-context.result.json'),'utf8')).stdout);
const operationPath=path.join(context.stateRoot,'operations',operation.operation_id+'.json');
let seq=30;
async function call(op,input){const label=String(++seq)+'-'+op,p=path.join(evidence,label+'.input.json');await fs.writeFile(p,JSON.stringify(input,null,2)+'\n');const args=[cli,op,'--input',p],r=spawnSync(process.execPath,args,{cwd,encoding:'utf8'});await fs.writeFile(path.join(evidence,label+'.result.json'),JSON.stringify({cwd,command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2)+'\n');if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
await call('inspect-navigation',{projectsRoot:context.projectsRoot});
const verify=await call('operation-verify',{...scope,operationPath});
console.log(JSON.stringify(verify));if(verify.status!=='verified')throw Error('Incomplete verification');
const complete=await call('operation-complete',{...scope,operationPath});
await call('log-query',{projectsRoot:context.projectsRoot});
const beforeProfile=await fs.readFile(path.join(evidence,'before/common/.nyssaai/daily-tasks/profile.json'));
if(!beforeProfile.equals(await fs.readFile(context.profilePath)))throw Error('Profile changed');
const manifest=[];
async function walk(dir){for(const item of await fs.readdir(dir,{withFileTypes:true})){if(item.name==='.temp'||item.name==='.daily-tasks')continue;const p=path.join(dir,item.name),rel=path.relative(cwd,p);if(item.isDirectory()){manifest.push({path:rel,type:'directory'});await walk(p);}else if(item.isFile()){const b=await fs.readFile(p),dest=path.join(evidence,'after',rel);await fs.mkdir(path.dirname(dest),{recursive:true});await fs.writeFile(dest,b);manifest.push({path:rel,type:'file',sha256:createHash('sha256').update(b).digest('hex')});}}}
await walk(cwd);await fs.writeFile(path.join(evidence,'after.manifest.json'),JSON.stringify(manifest,null,2)+'\n');
await fs.writeFile(path.join(evidence,'outcome.json'),JSON.stringify({milestonePath:operation.files[1].path,projectPath:operation.files[0].path,configRoot:context.configRoot,stateRoot:context.stateRoot,dailyPlansRoot:context.dailyPlansRoot,projectsRoot:context.projectsRoot,timezone:context.timezone,existingProfilePreserved:true,profileBytesUnchanged:true,noTasksCreated:true,verify,complete,recovery:'Navigation checked projects only because no daily plan directory exists or was requested.'},null,2)+'\n');
console.log(JSON.stringify(complete));
