All four independent accepted milestone requests were executed from their respective case cwd using the installed Daily Tasks 0.3.4 CLI.

Each Job Search project now links M1 — update LinkedIn and resume, with unchecked DoD “reviewed career materials”, owner Synthetic User (synthetic@example.test), and state not-started. No tasks or daily plans were requested or created. Milestone workspaces include flat inputs/ and outputs/.

| Case | Configuration directory (relative to case) | Resolved daily output directory (relative to case) | Completion |
| --- | --- | --- | --- |
| 01-common-root | common/.nyssaai/daily-tasks | vault/Daily | completed |
| 02-no-profile | common/.nyssaai/daily-tasks | vault/2-areas/daily-plans | completed |
| 03-explicit-legacy | vault/.nyssa/daily-tasks | vault/Daily | completed |
| 04-vault-only-legacy | vault/.nyssa/daily-tasks | vault/Daily | completed |

Projects: each case’s vault/Projects. Operating state: each case’s vault/.nyssaai/daily-tasks. Timezone: America/Chicago. Case 02 initialized common/.nyssaai/daily-tasks/profile.json with empty priorities. Existing profile bytes in cases 01, 03 and 04 were preserved; neither legacy profile was migrated. Cases 01 and 02 supplied no configRoot argument. Case 04 supplied no profile pointer or configRoot.

Evidence in each case’s .temp/native-workflow includes before/after byte snapshots and manifests (raw logs excluded), actual CLI inputs, commands, exit status/stdout/stderr, CLI log-query results, retained operation checkpoint, and outcome. Newly authored execution and recovery actions remain in this case root’s .temp/. No previous attempts, regression tests, or personal directories were read. The installed package has no README.md at its root; installed skills and their referenced documents governed the workflow.

Case 01 retained one failed inspect-navigation invocation against the nonexistent configured daily directory. Recovery checked project navigation without a daily directory, then operation-verify returned verified and operation-complete returned completed. No unresolved checkpoint or conflict remains.
