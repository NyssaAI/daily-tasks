import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';

// Newly authored from the installed setup, records, capture and verification instructions.
const root=process.cwd();
const bundle=path.resolve(root,'../../codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4');
const cli=path.join(bundle,'bin/daily-tasks.mjs');
const hash=b=>createHash('sha256').update(b).digest('hex');
const names=['02-no-profile','03-explicit-legacy','04-vault-only-legacy'];
async function exists(p){try{await fs.access(p);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
for(const name of names){
 const cwd=path.join(root,name), evidence=path.join(cwd,'.temp/native-workflow');
 await fs.mkdir(evidence,{recursive:true});
 let seq=0;
 async function call(op,input){
  const label=String(++seq).padStart(2,'0')+'-'+op;
  const args=[cli,op];
  if(input!==undefined){const p=path.join(evidence,label+'.input.json');await fs.writeFile(p,JSON.stringify(input,null,2)+'\n');args.push('--input',p);}
  const r=spawnSync(process.execPath,args,{cwd,encoding:'utf8'});
  await fs.writeFile(path.join(evidence,label+'.result.json'),JSON.stringify({cwd,command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2)+'\n');
  if(r.status!==0)throw new Error(name+' '+op+': '+r.stderr);
  return JSON.parse(r.stdout);
 }
 async function snapshot(label){
  const manifest=[];
  async function walk(dir){for(const item of await fs.readdir(dir,{withFileTypes:true})){
   if(item.name==='.temp'||item.name==='.daily-tasks')continue;
   const p=path.join(dir,item.name),rel=path.relative(cwd,p);
   if(item.isDirectory()){manifest.push({path:rel,type:'directory'});await walk(p);}
   else if(item.isFile()){const b=await fs.readFile(p);const dest=path.join(evidence,label,rel);await fs.mkdir(path.dirname(dest),{recursive:true});await fs.writeFile(dest,b);manifest.push({path:rel,type:'file',sha256:hash(b)});}
   else throw new Error('Unexpected nonordinary file '+p);
  }}
  await walk(cwd);await fs.writeFile(path.join(evidence,label+'.manifest.json'),JSON.stringify(manifest,null,2)+'\n');
 }
 await snapshot('before');
 await fs.writeFile(path.join(evidence,'runtime.json'),JSON.stringify({node:process.version,bundle,cwd,request:'Create M1: update LinkedIn and resume in this project',definitionOfDone:'reviewed career materials',acceptance:'Direct user instruction; no extra tasks',discovery:name.startsWith('01')||name.startsWith('02')?'Accepted common .nyssaai root determines conventional profile pointer; no configRoot input':name.startsWith('03')?'Explicit legacy profile pointer':'Known vault conventional then legacy discovery',operatingState:'Vault .nyssaai/daily-tasks as requested; existing legacy preferences preserved'},null,2)+'\n');
 await call('--help');
 const vault=path.join(cwd,'vault');
 const scope={vaultRoot:vault,homeRoot:path.join(cwd,'synthetic-home'),stateRoot:path.join(vault,'.nyssaai/daily-tasks')};
 if(name.startsWith('01')||name.startsWith('02'))scope.profilePath=path.join(cwd,'common/.nyssaai/daily-tasks/profile.json');
 if(name.startsWith('03'))scope.profilePath=path.join(vault,'.nyssa/daily-tasks/profile.json');
 let context=await call('resolve-context',scope);
 let setupEvent;
 if(!context.configured){
  if(name!=='02-no-profile')throw new Error('Unexpected missing configuration');
  const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
  const checked=await call('validate-profile',profile);if(!checked.valid)throw new Error(JSON.stringify(checked));
  await fs.writeFile(path.join(evidence,'profile-before.json'),'null\n');
  await fs.mkdir(path.dirname(scope.profilePath),{recursive:true});await fs.writeFile(scope.profilePath,JSON.stringify(profile,null,2)+'\n');
  const t=await call('activity-time',{});
  setupEvent={id:(await call('new-id')).id,operation_id:(await call('new-id')).id,action:'profile.configured',record_ids:[],actor:{kind:'person',id:'synthetic@example.test'},...t,original_words:'Initialize conventional accepted common scope with empty priorities; Synthetic User synthetic@example.test America/Chicago',before:null,after:profile};
  context=await call('resolve-context',scope);
 }
 await call('validate-profile',context.profile);
 const originalProfile=await fs.readFile(context.profilePath);
 const scan=await call('inspect-records',{projectsRoot:context.projectsRoot});
 await fs.writeFile(path.join(evidence,'inspection-shape.json'),JSON.stringify(scan,null,2)+'\n');
 const projectPath=path.join(context.projectsRoot,'job-search/project-index.md');
 const beforeProject=await fs.readFile(projectPath,'utf8');
 const parsed=await call('parse-record',{markdown:beforeProject,path:projectPath});
 await fs.writeFile(path.join(evidence,'parsed-project.json'),JSON.stringify(parsed,null,2)+'\n');
 const projectId=/^id:\s*"?([0-9a-f-]+)"?\r?$/m.exec(beforeProject)[1];
 const number=await call('next-record-number',{projectsRoot:context.projectsRoot,type:'milestone',parentId:projectId});
 if(number.number!==1)throw new Error('M1 allocation unavailable '+JSON.stringify(number));
 const mid=(await call('new-id')).id, criterion=(await call('new-id')).id;
 if(!mid||!criterion)throw new Error('Check new-id output');
 const timing=await call('activity-time',{});
 const stem='m1-update-linkedin-and-resume';
 const milestonePath=path.join(path.dirname(projectPath),stem,stem+'.md');
 if(await exists(milestonePath))throw new Error('Destination exists');
 const title='update LinkedIn and resume';
 const template=await fs.readFile(path.join(bundle,'skills/daily-tasks/assets/milestone.md'),'utf8');
 await fs.writeFile(path.join(evidence,'installed-milestone-template.md'),template);
 const milestone=`---\nid: "${mid}"\ntype: milestone\nrecord_version: 2\ntitle: "${title}"\ndocument-maturity: reviewed\nmilestone-state: not-started\nowner: "synthetic@example.test"\nproject_id: "${projectId}"\ncreated_at: "${timing.activity_at}"\nupdated_at: "${timing.activity_at}"\n---\n# M1 — ${title}\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${projectId} -->\n\n## Outcome\n\nUpdate LinkedIn and resume for the job search.\n\n## Definition of Done\n\n- [ ] reviewed career materials <!-- id: ${criterion} -->\n\n## Tasks\n\nNo tasks accepted.\n`;
 const afterProject=beforeProject.replace(/^updated_at:.*$/m,`updated_at: "${timing.activity_at}"`).replace('No milestones yet.',`- [[${stem}/${stem}|M1 — ${title}]] <!-- ref: ${mid} -->`);
 const event={id:(await call('new-id')).id,operation_id:(await call('new-id')).id,action:'milestone.accepted',record_ids:[mid],actor:{kind:'person',id:'synthetic@example.test'},...timing,original_words:'Create M1: update LinkedIn and resume in this project; DoD reviewed career materials; no extra tasks',before:null,after:{id:mid,type:'milestone',title,owner:'synthetic@example.test',project_id:projectId,path:milestonePath,'milestone-state':'not-started',definitionOfDone:'reviewed career materials',acceptance_source:'Direct user request'}};
 const operation={schemaVersion:2,operation_id:event.operation_id,contextBinding:context.planningBinding,event,files:[{path:projectPath,before:hash(beforeProject),after:hash(afterProject)},{path:milestonePath,before:null,after:hash(milestone)}]};
 const operationPath=path.join(context.stateRoot,'operations',event.operation_id+'.json');
 await fs.mkdir(path.dirname(operationPath),{recursive:true});
 await fs.writeFile(operationPath,JSON.stringify(operation,null,2)+'\n');
 await fs.writeFile(path.join(evidence,'pending-operation.json'),JSON.stringify(operation,null,2)+'\n');
 if(await fs.readFile(projectPath,'utf8')!==beforeProject)throw new Error('Concurrent project edit');
 await fs.mkdir(path.join(path.dirname(milestonePath),'inputs'),{recursive:true});await fs.mkdir(path.join(path.dirname(milestonePath),'outputs'),{recursive:true});
 await fs.writeFile(milestonePath,milestone,{flag:'wx'});await fs.writeFile(projectPath,afterProject);
 const actualScan=await call('inspect-records',{projectsRoot:context.projectsRoot});
 if(actualScan.diagnostics?.length)throw new Error('Record diagnostics '+JSON.stringify(actualScan.diagnostics));
 if(setupEvent)await call('log-append',{projectsRoot:context.projectsRoot,entry:setupEvent});
 await call('log-append',{projectsRoot:context.projectsRoot,entry:event});
 await call('invalidate-project-index',{vaultRoot:context.vaultRoot});
 const query=await call('log-query',{projectsRoot:context.projectsRoot});
 await fs.writeFile(path.join(evidence,'queried-log.json'),JSON.stringify(query,null,2)+'\n');
 await call('inspect-navigation',{projectsRoot:context.projectsRoot});
 const verify=await call('operation-verify',{...scope,operationPath});
 if(verify.status!=='verified')throw new Error('Verification incomplete '+JSON.stringify(verify));
 const complete=await call('operation-complete',{...scope,operationPath});
 if(await exists(operationPath))throw new Error('Checkpoint remains '+JSON.stringify(complete));
 if(!originalProfile.equals(await fs.readFile(context.profilePath)))throw new Error('Profile bytes changed');
 await snapshot('after');
 await fs.writeFile(path.join(evidence,'outcome.json'),JSON.stringify({milestonePath,projectPath,configRoot:context.configRoot,stateRoot:context.stateRoot,dailyPlansRoot:context.dailyPlansRoot,projectsRoot:context.projectsRoot,timezone:context.timezone,existingProfilePreserved:!setupEvent,profileBytesUnchanged:true,noTasksCreated:true,verify,complete},null,2)+'\n');
 console.log(JSON.stringify({name,milestonePath,verify,complete}));
}
