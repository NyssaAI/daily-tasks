import fs from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=process.cwd(),cli=path.resolve(root,'../../codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs');
const names=['01-common-root','02-no-profile','03-explicit-legacy','04-vault-only-legacy'];
const rows=[];
for(const name of names){
 const cwd=path.join(root,name),ev=path.join(cwd,'.temp/native-workflow'),outcome=JSON.parse(await fs.readFile(path.join(ev,'outcome.json'),'utf8'));
 async function call(op,input){const p=path.join(ev,'final-'+op+'.input.json');await fs.writeFile(p,JSON.stringify(input,null,2)+'\n');const args=[cli,op,'--input',p],r=spawnSync(process.execPath,args,{cwd,encoding:'utf8'});await fs.writeFile(path.join(ev,'final-'+op+'.result.json'),JSON.stringify({cwd,command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr},null,2)+'\n');if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
 const scan=await call('inspect-records',{projectsRoot:outcome.projectsRoot});
 if(scan.records.length!==2||scan.records.filter(r=>r.type==='milestone').length!==1||scan.records.some(r=>r.type==='task'))throw Error('Unexpected record set');
 const validation=await call('validate-records',{records:scan.records});
 const links=await call('check-links',{records:scan.records});
 const log=await call('log-query',{projectsRoot:outcome.projectsRoot});
 await fs.writeFile(path.join(ev,'final-validation.json'),JSON.stringify({validation,links,log},null,2)+'\n');
 console.log(JSON.stringify({name,validation,links}));
 rows.push(`| ${name} | ${path.relative(cwd,outcome.configRoot).replaceAll('\\','/')} | ${path.relative(cwd,outcome.dailyPlansRoot).replaceAll('\\','/')} | ${outcome.complete.status} |`);
}
await fs.writeFile(path.join(root,'.temp/results.md'),`All four independent accepted milestone requests were executed from their respective case cwd using the installed Daily Tasks 0.3.4 CLI.\n\nEach Job Search project now links M1 — update LinkedIn and resume, with unchecked DoD “reviewed career materials”, owner Synthetic User (synthetic@example.test), and state not-started. No tasks or daily plans were requested or created. Milestone workspaces include flat inputs/ and outputs/.\n\n| Case | Configuration directory (relative to case) | Resolved daily output directory (relative to case) | Completion |\n| --- | --- | --- | --- |\n${rows.join('\n')}\n\nProjects: each case’s vault/Projects. Operating state: each case’s vault/.nyssaai/daily-tasks. Timezone: America/Chicago. Case 02 initialized common/.nyssaai/daily-tasks/profile.json with empty priorities. Existing profile bytes in cases 01, 03 and 04 were preserved; neither legacy profile was migrated. Cases 01 and 02 supplied no configRoot argument. Case 04 supplied no profile pointer or configRoot.\n\nEvidence in each case’s .temp/native-workflow includes before/after byte snapshots and manifests (raw logs excluded), actual CLI inputs, commands, exit status/stdout/stderr, CLI log-query results, retained operation checkpoint, and outcome. Newly authored execution and recovery actions remain in this case root’s .temp/. No previous attempts, regression tests, or personal directories were read. The installed package has no README.md at its root; installed skills and their referenced documents governed the workflow.\n\nCase 01 retained one failed inspect-navigation invocation against the nonexistent configured daily directory. Recovery checked project navigation without a daily directory, then operation-verify returned verified and operation-complete returned completed. No unresolved checkpoint or conflict remains.\n`);
