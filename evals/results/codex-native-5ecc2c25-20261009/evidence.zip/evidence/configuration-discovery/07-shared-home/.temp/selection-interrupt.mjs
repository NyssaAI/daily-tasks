import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(),temp=path.join(root,'.temp'),cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-guarded-full8/codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs';
let seq=50;const write=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
function call(op,input){const p=path.join(temp,String(++seq).padStart(2,'0')+'-'+op);let args=[cli,op];if(input!==undefined){write(p+'.input.json',input);args.push('--input',p+'.input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(p+'.result.json',r.stdout||r.stderr);write(p+'.execution.json',{args,status:r.status,stderr:r.stderr});if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const hash=t=>crypto.createHash('sha256').update(t).digest('hex'),id=()=>call('new-id').id;
const ctx=JSON.parse(fs.readFileSync(path.join(temp,'context.json'),'utf8')),scope={vaultRoot:ctx.vaultRoot,homeRoot:ctx.homeRoot,profilePath:ctx.profilePath};
const actor={kind:'person',id:ctx.profile.user.email};
function event(action,record_ids,words,after,before){return {id:id(),operation_id:id(),action,record_ids,actor,...call('activity-time',{}),original_words:words,...(before?{before}:{}),after};}


const ids=JSON.parse(fs.readFileSync(path.join(temp,'record-identities.json'),'utf8')),packet=JSON.parse(fs.readFileSync(path.join(temp,'review-packet.json'),'utf8')),proposal=JSON.parse(fs.readFileSync(path.join(temp,'selection-proposal.json'),'utf8'));
if(proposal.conflicts.length||proposal.effects.length!==1)throw Error('No authorized effect');
const dest=proposal.effects[0].to.path,before=fs.readFileSync(dest,'utf8'),canonical=fs.readFileSync(ids.tp,'utf8');
const ev=event('plan.selection',[ids.tid],'Select Routing note today',{date:packet.context.localDate,selectedIds:[ids.tid],path:dest},{date:packet.context.localDate,selectedIds:[],path:dest});
const relative=path.relative(path.dirname(dest),ids.tp).replaceAll('\\','/').replace(/\.md$/,'');
const row=`#### Job Search / update LinkedIn and resume\n\n| # | Status | Project | Milestone | Task | Due Date |\n| --- | --- | --- | --- | --- | --- |\n| 1 | [ ] | Job Search | update LinkedIn and resume | [[${relative}\\|Routing note]] <!-- ref: ${ids.tid} --> | — |`;
const after=before.replace('No work selected.',row).replace(/updated_at: "[^"]+"/,`updated_at: "${ev.recorded_at}"`);
const baselinePath=path.join(ctx.stateRoot,'reconciliation.json'),baseText=fs.existsSync(baselinePath)?fs.readFileSync(baselinePath,'utf8'):null,base=baseText?JSON.parse(baseText):{schemaVersion:1,records:{}};
base.records[ids.tid]={canonical:{state:'not-started',owner:'synthetic@example.test'},views:{[dest]:{hash:hash(after),selected:true,checked:false}}};
const op={schemaVersion:2,operation_id:ev.operation_id,contextBinding:ctx.planningBinding,event:ev,files:[{path:dest,before:hash(before),after:hash(after)},{path:ids.tp,before:hash(canonical),after:hash(canonical)}],protectedFiles:[ids.mp,ids.proj].map(p=>({path:p,sha256:hash(fs.readFileSync(p))})),baseline:{beforeHash:baseText===null?null:hash(baseText),beforeText:baseText,value:base},selection:{date:packet.context.localDate,planId:packet.current.id,expectedCreatedAt:before.match(/created_at: "([^"]+)"/)[1],beforeSelectedIds:[],afterSelectedIds:[ids.tid],mappingPath:packet.state.review.path,mapping:packet.review.mapping}};
const operationPath=path.join(ctx.stateRoot,'operations',ev.operation_id+'.json');
write(path.join(temp,'selection-before.md'),before);write(path.join(ctx.projectsRoot,'job-search','.temp','selection-before.md'),before);write(path.join(temp,'selection-after.md'),after);write(path.join(temp,'selection-log-pending.input.json'),{projectsRoot:ctx.projectsRoot,entry:ev});write(operationPath,op);write(path.join(temp,'selection-checkpoint.json'),op);
if(hash(fs.readFileSync(dest,'utf8'))!==op.files[0].before)throw Error('Destination changed');write(dest,after);
call('invalidate-project-index',{vaultRoot:ctx.vaultRoot});
const actual=fs.readFileSync(dest,'utf8');if(hash(actual)!==op.files[0].after)throw Error('Destination not persisted');
const query=call('log-query',{projectsRoot:ctx.projectsRoot,action:'plan.selection'});const verify=call('operation-verify',{...scope,operationPath});
write(path.join(temp,'resume-paths.json'),{stage:'interrupted-after-destination-persistence',operationPath,destination:dest,profilePath:ctx.profilePath,configRoot:ctx.configRoot,stateRoot:ctx.stateRoot,projectsRoot:ctx.projectsRoot,vaultRoot:ctx.vaultRoot,reviewMapping:packet.state.review.path,inventory:path.join(ctx.vaultRoot,'.temp','daily-tasks','project-index.json'),baselinePath,pendingLogInput:path.join(temp,'selection-log-pending.input.json'),remaining:['append exact checkpoint event through log-append','query and compare complete event payload','verify and complete operation to save baseline and clear checkpoint','reprepare inventory and save selected recap mapping'],logQuery:query,verification:verify});
console.log(JSON.stringify({operationPath,destination:dest,verification:verify,logQuery:query},null,2));
