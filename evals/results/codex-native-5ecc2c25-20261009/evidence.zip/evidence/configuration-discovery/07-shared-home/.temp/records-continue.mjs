import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(),temp=path.join(root,'.temp'),cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-guarded-full8/codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4/bin/daily-tasks.mjs';
let seq=22;const write=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
function call(op,input){const p=path.join(temp,String(++seq).padStart(2,'0')+'-'+op);let args=[cli,op];if(input!==undefined){write(p+'.input.json',input);args.push('--input',p+'.input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(p+'.result.json',r.stdout||r.stderr);write(p+'.execution.json',{args,status:r.status,stderr:r.stderr});if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const hash=t=>crypto.createHash('sha256').update(t).digest('hex'),id=()=>call('new-id').id;
const ctx=JSON.parse(fs.readFileSync(path.join(temp,'context.json'),'utf8')),scope={vaultRoot:ctx.vaultRoot,homeRoot:ctx.homeRoot,profilePath:ctx.profilePath};
const actor={kind:'person',id:ctx.profile.user.email};
function event(action,record_ids,words,after,before){return {id:id(),operation_id:id(),action,record_ids,actor,...call('activity-time',{}),original_words:words,...(before?{before}:{}),after};}
const projectId='01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4';
const saved=n=>JSON.parse(fs.readFileSync(path.join(temp,n+'-new-id.result.json'),'utf8')).id;
const mid=saved('18'),tid=saved('19'),mc=saved('20'),tc=saved('21');
const ev=event('records.accepted',[mid,tid],'Create M1: update LinkedIn and resume, DoD reviewed career materials. Explicitly accept sole Routing note task (requirement local routing test note, DoD reviewed routing note).',{records:[]});
const stamp=ev.recorded_at,proj=path.join(ctx.projectsRoot,'job-search','project-index.md'),folder=path.join(path.dirname(proj),'m1-update-linkedin-and-resume'),mp=path.join(folder,'m1-update-linkedin-and-resume.md'),tp=path.join(folder,'t1-routing-note.md');
const front=(type,rid,title,state,extra)=>`---\nid: ${rid}\ntype: ${type}\nrecord_version: 2\ntitle: "${title}"\ndocument-maturity: reviewed\n${type}-state: ${state}\nowner: "synthetic@example.test"\nproject_id: "${projectId}"\n${extra}created_at: "${stamp}"\nupdated_at: "${stamp}"\n---\n`;
const milestone=front('milestone',mid,'update LinkedIn and resume','not-started','')+`# M1 — update LinkedIn and resume\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${projectId} -->\n\n## Outcome\n\nUpdate LinkedIn and resume for the Job Search project.\n\n## Definition of Done\n\n- [ ] reviewed career materials <!-- id: ${mc} -->\n\n## Tasks\n\n- [ ] [[t1-routing-note|Routing note]] <!-- ref: ${tid} -->\n`;
const task=front('task',tid,'Routing note','not-started',`milestone_id: "${mid}"\n`)+`# M1-T1 — Routing note\n\n**Milestone:** [[m1-update-linkedin-and-resume|update LinkedIn and resume]] <!-- ref: ${mid} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${projectId} -->\n\n## Requirements\n\nlocal routing test note\n\n## Definition of Done\n\n- [ ] reviewed routing note <!-- id: ${tc} -->\n\n## Output and delivery\n\nLocal Markdown artifact: [[outputs/routing-note.md|routing-note.md]].\n\n## Verification\n\nReview the local routing note against the requirement and record review evidence before completion.\n`;
const before=fs.readFileSync(proj,'utf8');const after=before.replace('No milestones yet.',`- [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — update LinkedIn and resume]] <!-- ref: ${mid} -->\n\n## Tasks\n\n- [ ] [[m1-update-linkedin-and-resume/t1-routing-note|Routing note]] <!-- ref: ${tid} -->`).replace(/updated_at: "[^"]+"/,`updated_at: "${stamp}"`);
ev.after.records=[{id:mid,type:'milestone',path:mp,project_id:projectId},{id:tid,type:'task',path:tp,project_id:projectId,milestone_id:mid}];
const files=[{path:proj,before:hash(before),after:hash(after)},{path:mp,before:null,after:hash(milestone)},{path:tp,before:null,after:hash(task)}];
const op={schemaVersion:2,operation_id:ev.operation_id,contextBinding:ctx.planningBinding,event:ev,files};const opath=path.join(ctx.stateRoot,'operations',ev.operation_id+'.json');
write(path.join(temp,'records-before.json'),{[proj]:before,[mp]:null,[tp]:null});write(path.join(path.dirname(proj),'.temp','project-before.md'),before);write(opath,op);write(path.join(temp,'records-checkpoint.json'),op);
if(hash(fs.readFileSync(proj,'utf8'))!==files[0].before||fs.existsSync(mp)||fs.existsSync(tp))throw Error('Source changed');
write(mp,milestone); const tn=call('next-record-number',{projectsRoot:ctx.projectsRoot,type:'task',parentId:mid});if(tn.number!==1)throw Error(JSON.stringify(tn));write(tp,task);write(proj,after);fs.mkdirSync(path.join(folder,'inputs'),{recursive:true});fs.mkdirSync(path.join(folder,'outputs'),{recursive:true});
write(path.join(temp,'records-after.json'),{[proj]:after,[mp]:milestone,[tp]:task});call('invalidate-project-index',{vaultRoot:ctx.vaultRoot});
const inspected=call('inspect-records',{projectsRoot:ctx.projectsRoot});write(path.join(temp,'record-identities.json'),{mid,tid,mp,tp,proj});
call('log-append',{projectsRoot:ctx.projectsRoot,entry:ev});call('log-query',{projectsRoot:ctx.projectsRoot});
const verified=call('operation-verify',{...scope,operationPath:opath});if(verified.status!=='verified')throw Error(JSON.stringify(verified));call('operation-complete',{...scope,operationPath:opath});
const packet=call('planning-prepare',scope);write(path.join(temp,'prepare.json'),packet);

