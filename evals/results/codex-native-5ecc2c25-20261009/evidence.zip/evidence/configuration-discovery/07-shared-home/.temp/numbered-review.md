Open projects: 1          Open tasks: 1          Late tasks: 0

This is your first check-in today. Review the work carried forward, then choose which available tasks to add. Status marks show progress; the sections indicate whether work is selected for today. [x] means completed, never merely selected.

## Already selected

No work selected.

## Available tasks

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | update LinkedIn and resume | [Routing note](D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-guarded-full8/cases/configuration-discovery/07-shared-home/vault-a/Projects/job-search/m1-update-linkedin-and-resume/t1-routing-note.md) | — |

Reply by row number and symbol or description:

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled

Planning actions: add 1 · show details for 1 · keep selections
