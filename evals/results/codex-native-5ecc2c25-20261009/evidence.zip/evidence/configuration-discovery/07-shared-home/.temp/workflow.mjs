import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), temp=path.join(root,'.temp'), pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-guarded-full8/codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4';
const cli=path.join(pkg,'bin/daily-tasks.mjs');
let seq=0;
const write=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
function call(op,input){const prefix=path.join(temp,String(++seq).padStart(2,'0')+'-'+op);let args=[cli,op];if(input!==undefined){write(prefix+'.input.json',input);args.push('--input',prefix+'.input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});write(prefix+'.result.json',r.stdout||r.stderr);write(prefix+'.execution.json',{executable:process.execPath,args,status:r.status,stderr:r.stderr});if(r.status)throw Error(r.stderr);return JSON.parse(r.stdout);}
const hash=t=>crypto.createHash('sha256').update(t).digest('hex');
const vault=path.join(root,'vault-a'), home=path.join(root,'synthetic-home'), config=path.join(home,'.nyssaai','daily-tasks'), profilePath=path.join(config,'profile.json');
const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:'.',projectsRoot:'./Projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
const valid=call('validate-profile',profile);if(!valid.valid)throw Error(JSON.stringify(valid));write(profilePath,profile);
const scope={vaultRoot:vault,homeRoot:home,configRoot:config,profilePath};const ctx=call('resolve-context',scope);write(path.join(temp,'context.json'),ctx);
const timing=call('activity-time',{});const id=()=>call('new-id').id;
write(path.join(temp,'initial.json'),{ctx,timing,idSample:call('new-id')});
