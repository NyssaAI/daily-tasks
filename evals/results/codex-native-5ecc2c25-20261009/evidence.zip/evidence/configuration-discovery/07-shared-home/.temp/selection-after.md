---
id: 01a121fb-9b6d-7f8d-81e8-1ed1f8ea629a
type: daily-plan
title: "Daily plan 2026.10.09"
document-maturity: reviewed
timezone: "America/Chicago"
created_at: "2026-10-09T18:44:59.931Z"
updated_at: "2026-10-09T18:45:49.828Z"
---
# Daily plan — 2026.10.09

Open projects: 1          Open tasks: 1          Late tasks: 0

**Timezone:** America/Chicago

## Selected for today

### My work

#### Job Search / update LinkedIn and resume

| # | Status | Project | Milestone | Task | Due Date |
| --- | --- | --- | --- | --- | --- |
| 1 | [ ] | Job Search | update LinkedIn and resume | [[../../Projects/job-search/m1-update-linkedin-and-resume/t1-routing-note\|Routing note]] <!-- ref: 01a121fa-cd12-7691-a003-3cd29371200b --> | — |

### Delegated work

No delegated work selected.

Legend: [ ] not started · [>] in progress · [x] completed · [-] cancelled
