---
id: 01a121fa-cd12-7691-a003-3cd29371200b
type: task
record_version: 2
title: "Routing note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
milestone_id: "01a121fa-cce5-7cd2-8539-5d6a79e4bc36"
created_at: "2026-10-09T18:44:20.697Z"
updated_at: "2026-10-09T18:44:20.697Z"
---
# M1-T1 — Routing note

**Milestone:** [[m1-update-linkedin-and-resume|update LinkedIn and resume]] <!-- ref: 01a121fa-cce5-7cd2-8539-5d6a79e4bc36 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Requirements

local routing test note

## Definition of Done

- [ ] reviewed routing note <!-- id: 01a121fa-cd6e-7c94-8499-e937bc308557 -->

## Output and delivery

Local Markdown artifact: [[outputs/routing-note.md|routing-note.md]].

## Verification

Review the local routing note against the requirement and record review evidence before completion.
