---
id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:11.958Z"
updated_at: "2026-10-09T18:44:20.697Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — update LinkedIn and resume]] <!-- ref: 01a121fa-cce5-7cd2-8539-5d6a79e4bc36 -->

## Tasks

- [ ] [[m1-update-linkedin-and-resume/t1-routing-note|Routing note]] <!-- ref: 01a121fa-cd12-7691-a003-3cd29371200b -->
