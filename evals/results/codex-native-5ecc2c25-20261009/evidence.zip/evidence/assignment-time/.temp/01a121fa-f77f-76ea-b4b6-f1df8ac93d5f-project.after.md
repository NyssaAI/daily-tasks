---
id: 01a121fa-f243-7759-91b7-a24aa97827a8
type: project
title: "Demo"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T18:44:16.881Z"
updated_at: "2026-10-09T18:44:16.881Z"
---
# Demo

Prepare and review a paragraph. Timezone: America/Chicago.

## Project Summary

- [ ] [[m1-draft/m1-draft|M1 Draft]] <!-- ref: 01a121fa-f26e-7b1d-9b80-c06795672e8b -->
- [>] [[m1-draft/t1-draft-note|Draft note]] <!-- ref: 01a121fa-f299-7188-a6e0-b7f4cdd959c8 --> — Owner: Synthetic User
- [ ] [[m1-draft/t2-review-note|Review note]] <!-- ref: 01a121fa-f2c5-723b-aaa3-6df2d4c790b1 --> — Owner: Synthetic User; assignee: Editor
