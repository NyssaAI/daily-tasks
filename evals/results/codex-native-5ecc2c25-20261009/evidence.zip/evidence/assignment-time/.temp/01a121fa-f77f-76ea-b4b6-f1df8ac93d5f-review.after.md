---
id: 01a121fa-f2c5-723b-aaa3-6df2d4c790b1
type: task
record_version: 2
title: "Review note"
task-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T18:44:16.881Z"
updated_at: "2026-10-09T18:44:17.834Z"
project_id: "01a121fa-f243-7759-91b7-a24aa97827a8"
milestone_id: "01a121fa-f26e-7b1d-9b80-c06795672e8b"
assignee: "Editor"
---
# M1-T2 — Review note

**Milestone:** [[m1-draft|Draft]] <!-- ref: 01a121fa-f26e-7b1d-9b80-c06795672e8b -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a121fa-f243-7759-91b7-a24aa97827a8 -->

## Requirements

Inspect the paragraph.

## Definition of Done

- [ ] Recorded review. <!-- id: 01a121fa-f31c-74bd-a18e-f83fb4b55223 -->

## Inputs

No supplied files. Local inputs: inputs/.

## Output and delivery

Local note work; outputs/ holds any deliverables.
