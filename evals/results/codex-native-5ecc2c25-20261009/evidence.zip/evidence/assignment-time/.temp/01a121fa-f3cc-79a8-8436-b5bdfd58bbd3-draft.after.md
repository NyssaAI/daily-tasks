---
id: 01a121fa-f299-7188-a6e0-b7f4cdd959c8
type: task
record_version: 2
title: "Draft note"
task-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T18:44:16.881Z"
updated_at: "2026-10-09T18:44:16.881Z"
project_id: "01a121fa-f243-7759-91b7-a24aa97827a8"
milestone_id: "01a121fa-f26e-7b1d-9b80-c06795672e8b"
---
# M1-T1 — Draft note

**Milestone:** [[m1-draft|Draft]] <!-- ref: 01a121fa-f26e-7b1d-9b80-c06795672e8b -->

**Project:** [[../project-index|Demo]] <!-- ref: 01a121fa-f243-7759-91b7-a24aa97827a8 -->

## Requirements

Write a paragraph.

## Definition of Done

- [ ] Reviewed paragraph. <!-- id: 01a121fa-f2f0-7017-bea6-6c894f7cdc92 -->

## Inputs

No supplied files. Local inputs: inputs/.

## Output and delivery

Local note work; outputs/ holds any deliverables.
