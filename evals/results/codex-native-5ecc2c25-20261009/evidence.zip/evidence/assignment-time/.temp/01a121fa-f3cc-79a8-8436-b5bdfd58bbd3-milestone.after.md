---
id: 01a121fa-f26e-7b1d-9b80-c06795672e8b
type: milestone
record_version: 2
title: "Draft"
milestone-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T18:44:16.881Z"
updated_at: "2026-10-09T18:44:16.881Z"
project_id: "01a121fa-f243-7759-91b7-a24aa97827a8"
---
# M1 — Draft

**Project:** [[../project-index|Demo]] <!-- ref: 01a121fa-f243-7759-91b7-a24aa97827a8 -->

## Outcome

Draft and review a paragraph.

## Definition of Done

- [ ] Both task definitions of done are satisfied. <!-- id: 01a121fa-f345-79ae-9a59-73af0a41bdbd -->

## Tasks

- [ ] [[t1-draft-note|Draft note]] <!-- ref: 01a121fa-f299-7188-a6e0-b7f4cdd959c8 -->
- [ ] [[t2-review-note|Review note]] <!-- ref: 01a121fa-f2c5-723b-aaa3-6df2d4c790b1 -->
