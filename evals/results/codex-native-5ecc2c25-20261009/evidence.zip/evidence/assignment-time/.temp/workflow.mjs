import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const cwd=process.cwd(), scratch=path.join(cwd,'.temp'), vault=path.join(cwd,'vault');
const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/release-034-guarded-full8/codex-home/plugins/cache/daily-tasks-release-034-guarded-full8/daily-tasks/0.3.4';
const cli=path.join(bundle,'bin/daily-tasks.mjs');
let seq=fs.readdirSync(scratch).filter(n=>/^\d+-.*\.result\.json$/.test(n)).reduce((a,n)=>Math.max(a,Number(n.split('-')[0])),0);
function save(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
function call(op,input){const label=String(++seq).padStart(3,'0')+'-'+op, p=path.join(scratch,label+'.input.json');if(input!==undefined)save(p,input);const args=[cli,op,...(input===undefined?[]:['--input',p])];const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(path.join(scratch,label+'.result.json'),{command:[process.execPath,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
const id=()=>{const r=call('new-id');return typeof r==='string'?r:r.id;};
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const projects=path.join(vault,'1-projects'),config=path.join(vault,'.nyssaai/daily-tasks');
if(!fs.existsSync(path.join(scratch,'before.json')))save(path.join(scratch,'before.json'),{vault,entries:fs.readdirSync(vault),owner:'synthetic@example.test',scope:'this vault only',node:process.version,installedBundle:bundle,skills:['daily-tasks','daily-tasks-setup','daily-tasks-records'].map(s=>path.join(bundle,'skills',s,'SKILL.md'))});
const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.test'},timezone:'America/Chicago',priorities:[],vaultRoot:vault,projectsRoot:projects,dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
const valid=call('validate-profile',profile);if(!valid.valid)throw Error(JSON.stringify(valid));
save(path.join(config,'profile.json'),profile);
fs.mkdirSync(projects,{recursive:true});fs.mkdirSync(path.join(vault,'2-areas/daily-plans'),{recursive:true});
const scope={vaultRoot:vault,configRoot:config};
const context=call('resolve-context',scope);save(path.join(scratch,'context.json'),context);
const time=()=>call('activity-time',{});
function event(action,ids,t,before,after,words,actor={kind:'person',id:'synthetic@example.test'}){return {id:id(),operation_id:id(),action,record_ids:ids,actor,activity_at:t.activity_at,recorded_at:t.recorded_at,time_defaulted:t.time_defaulted,...(words?{original_words:words}:{}),before,after};}
const setupTime=time();call('log-append',{projectsRoot:projects,entry:event('profile.configured',[],setupTime,null,profile,'Configure this vault only')});
const pid=id(),mid=id(),draft=id(),review=id(),dc=id(),rc=id(),mc=id();
save(path.join(scratch,'identities.json'),{pid,mid,draft,review,dc,rc,mc});
const project=path.join(projects,'demo'),mroot=path.join(project,'m1-draft');
const paths={project:path.join(project,'project-index.md'),milestone:path.join(mroot,'m1-draft.md'),draft:path.join(mroot,'t1-draft-note.md'),review:path.join(mroot,'t2-review-note.md')};
const created=time();
const fm=(type,uuid,title,state,t,extra='')=>`---\nid: ${uuid}\ntype: ${type}\n${type==='project'?'':'record_version: 2\n'}title: "${title}"\n${type}-state: ${state}\nowner: "synthetic@example.test"\ncreated_at: "${t.activity_at}"\nupdated_at: "${t.recorded_at}"\n${extra}---\n`;
const task=(uuid,title,num,req,dod,criterion,assignee)=>fm('task',uuid,title,'not-started',created,`project_id: "${pid}"\nmilestone_id: "${mid}"\n${assignee?`assignee: "${assignee}"\n`:''}`)+`# M1-T${num} — ${title}\n\n**Milestone:** [[m1-draft|Draft]] <!-- ref: ${mid} -->\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${pid} -->\n\n## Requirements\n\n${req}\n\n## Definition of Done\n\n- [ ] ${dod} <!-- id: ${criterion} -->\n\n## Inputs\n\nNo supplied files. Local inputs: inputs/.\n\n## Output and delivery\n\nLocal note work; outputs/ holds any deliverables.\n`;
let texts={project:fm('project',pid,'Demo','not-started',created)+`# Demo\n\nPrepare and review a paragraph. Timezone: America/Chicago.\n\n## Project Summary\n\n- [ ] [[m1-draft/m1-draft|M1 Draft]] <!-- ref: ${mid} -->\n- [ ] [[m1-draft/t1-draft-note|Draft note]] <!-- ref: ${draft} --> — Owner: Synthetic User\n- [ ] [[m1-draft/t2-review-note|Review note]] <!-- ref: ${review} --> — Owner: Synthetic User; assignee: Reviewer\n`,milestone:fm('milestone',mid,'Draft','not-started',created,`project_id: "${pid}"\n`)+`# M1 — Draft\n\n**Project:** [[../project-index|Demo]] <!-- ref: ${pid} -->\n\n## Outcome\n\nDraft and review a paragraph.\n\n## Definition of Done\n\n- [ ] Both task definitions of done are satisfied. <!-- id: ${mc} -->\n\n## Tasks\n\n- [ ] [[t1-draft-note|Draft note]] <!-- ref: ${draft} -->\n- [ ] [[t2-review-note|Review note]] <!-- ref: ${review} -->\n`,draft:task(draft,'Draft note',1,'Write a paragraph.','Reviewed paragraph.',dc),review:task(review,'Review note',2,'Inspect the paragraph.','Recorded review.',rc,'Reviewer')};
function transaction(ev,next){const files=Object.entries(next).map(([k,text])=>({path:paths[k],before:fs.existsSync(paths[k])?hash(fs.readFileSync(paths[k],'utf8')):null,after:hash(text)}));const operationPath=path.join(context.stateRoot,'operations',ev.operation_id+'.json');const checkpoint={schemaVersion:2,operation_id:ev.operation_id,contextBinding:context.planningBinding,event:ev,files};save(operationPath,checkpoint);save(path.join(scratch,ev.operation_id+'.checkpoint.json'),checkpoint);for(const [k,text]of Object.entries(next)){const f=files.find(f=>f.path===paths[k]);const old=fs.existsSync(paths[k])?fs.readFileSync(paths[k],'utf8'):null;if((old===null?null:hash(old))!==f.before)throw Error('Before changed');save(path.join(scratch,ev.operation_id+'-'+k+'.before.md'),old??'ABSENT\n');save(paths[k],text);save(path.join(scratch,ev.operation_id+'-'+k+'.after.md'),text);}
call('invalidate-project-index',{vaultRoot:vault});const inspection=call('inspect-records',{projectsRoot:projects});save(path.join(scratch,ev.operation_id+'.inspection.json'),inspection);call('log-append',{projectsRoot:projects,entry:ev});call('log-query',{projectsRoot:projects,action:ev.action});const checked=call('operation-verify',{...scope,operationPath});if(checked.status!=='verified')throw Error(JSON.stringify(checked));const completed=call('operation-complete',{...scope,operationPath});save(path.join(scratch,ev.operation_id+'.completion.json'),completed);}
transaction(event('records.accepted',[pid,mid,draft,review],created,null,{project:'Demo',milestone:'M1 Draft',tasks:['Draft note','Review note'],owner:'synthetic@example.test',draftAssignee:null,reviewAssignee:'Reviewer'},'Explicitly create project Demo, M1 Draft, Draft note and Review note'),texts);
for(const folder of ['inputs','outputs'])fs.mkdirSync(path.join(mroot,folder),{recursive:true});
const start=call('activity-time',{reported:'earlier this morning'});save(path.join(scratch,'start-time-exact.json'),start);
const beforeDraft=texts.draft;
texts.draft=texts.draft.replace('task-state: not-started','task-state: in-progress').replace(`updated_at: "${created.recorded_at}"`,`updated_at: "${start.recorded_at}"\nstarted_at: "${start.activity_at}"`);
texts.project=texts.project.replace('- [ ] [[m1-draft/t1-draft-note','- [>] [[m1-draft/t1-draft-note');texts.milestone=texts.milestone.replace('- [ ] [[t1-draft-note','- [>] [[t1-draft-note');
transaction(event('task.started',[draft],start,{state:'not-started',started_at:null},{state:'in-progress',started_at:start.activity_at},'earlier this morning'),{draft:texts.draft,project:texts.project,milestone:texts.milestone});
const assign=time();texts.review=texts.review.replace('assignee: "Reviewer"','assignee: "Editor"').replace(`updated_at: "${created.recorded_at}"`,`updated_at: "${assign.recorded_at}"`);texts.project=texts.project.replace('assignee: Reviewer','assignee: Editor');
transaction(event('task.reassigned',[review],assign,{owner:'synthetic@example.test',assignee:'Reviewer',state:'not-started'},{owner:'synthetic@example.test',assignee:'Editor',state:'not-started'},'Acting as agent reassign Review note to Editor',{kind:'agent',id:'Codex'}),{review:texts.review,project:texts.project});
call('format-time',{time:start.activity_at,timezone:'America/Chicago'});
call('inspect-records',{projectsRoot:projects});call('inspect-navigation',{projectsRoot:projects,dailyPlansRoot:context.dailyPlansRoot});call('log-query',{projectsRoot:projects});
save(path.join(scratch,'after.json'),{paths,profile,start,records:texts,ownershipDecision:'Only human direction changes owner; agent reassignment retained Synthetic User on every record.'});
console.log(JSON.stringify({paths,start,context},null,2));
