# Attempt notes

Corrected harness assumptions: absolute CLI input paths; DoD reason wording; reopened parents use in-progress; unchanged daily note retains CRLF. Execution resumed after committed case 10 without replay. Captured snapshot Buffer arrays were losslessly decoded to original Markdown bytes and every changed before/after hash verified against its checkpoint.

The original-reconciliation.json enrollment snapshot was overwritten during the initial assertion retry; it contains current-vault enrollment, not the initial foreign-path baselines. Initial foreign-path state was read in the host transcript. No foreign vault was accessed. Canonical record before/after evidence is complete.
