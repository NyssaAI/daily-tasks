---
id: "01a12125-8f07-738f-bb1a-b031e17a0106"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:12.056Z"
updated_at: "2026-10-09T15:12:33.373Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — Update LinkedIn and resume]] <!-- ref: 01a12139-1bb4-70aa-a669-9efab4c35476 -->
