import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const scope = 'D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/acceptance';
const cli = 'D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/codex-home/plugins/cache/daily-tasks-native-eval/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const vault = `${scope}/vault`;
export function call(operation, input) {
  const inputPath = `${scope}/.temp/${operation}-input.json`;
  if (input !== undefined) fs.writeFileSync(inputPath, JSON.stringify(input, null, 2));
  const args = [cli, operation, ...(input === undefined ? [] : ['--input', inputPath])];
  const result = spawnSync(process.execPath, args, {encoding:'utf8'});
  fs.appendFileSync(`${scope}/.temp/cli-actions.jsonl`, JSON.stringify({command:process.execPath,args,input,exitCode:result.status,stdout:result.stdout,stderr:result.stderr})+'\n');
  if (result.status !== 0) throw new Error(result.stderr);
  const output = JSON.parse(result.stdout);
  fs.writeFileSync(`${scope}/.temp/${operation}-result.json`,JSON.stringify(output,null,2));
  return output;
}
if (process.argv[1] === path.resolve(import.meta.filename)) {
  console.log(JSON.stringify({
    records:call('inspect-records',{projectsRoot:`${vault}/Projects`}),
    checklist:call('parse-checklist',{markdown:fs.readFileSync(`${vault}/Daily/2026-10-09.md`,'utf8')}),
    log:call('log-query',{projectsRoot:`${vault}/Projects`})
  },null,2));
}
