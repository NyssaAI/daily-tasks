---
id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:11.958Z"
updated_at: "2026-10-09T15:07:11.438Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1 — Update LinkedIn and resume]] <!-- ref: 01a12134-31c1-75ad-b57c-ad026235703c -->

### Tasks

- [ ] [[m1-update-linkedin-and-resume/t1-routing-note|Routing note]] <!-- ref: 01a12134-31ec-724e-8e1e-a4294ba42dce -->
