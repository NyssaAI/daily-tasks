---
id: "01a12125-84da-767f-85fe-ac147d7ce5e7"
type: project
record_version: 2
title: "Job Search"
owner: "synthetic@example.test"
created_at: "2026-10-09T14:51:09.455Z"
updated_at: "2026-10-09T15:06:02.313Z"
project-state: not-started
---
# Job Search

Prepare career materials for the job search.

## Project Summary

- [[m1-update-linkedin-and-resume/m1-update-linkedin-and-resume|M1: update LinkedIn and resume]] <!-- ref: 01a12133-240f-7f70-bce1-a07356e4b202 -->
