---
id: 01a12131-fa2b-780d-a2f7-6a23ddb2fa15
type: project
title: "Job Search"
owner: "synthetic@example.invalid"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
project-state: not-started
---
# Job Search

Synthetic accepted project.

## Project Summary

- [ ] [[m1-accepted-work/m1-accepted-work|Accepted work]] <!-- ref: 01a12131-fa54-745b-b320-4b2442df3896 -->
- [ ] [[m1-accepted-work/t1-a|A]] <!-- ref: 01a12131-fa7e-7cc5-bd65-7d3aec89ee35 -->
- [ ] [[m1-accepted-work/t2-b|B]] <!-- ref: 01a12131-fade-78c8-b56f-b60ad26d9a71 -->
- [ ] [[m1-accepted-work/t3-review-draft|Review draft]] <!-- ref: 01a12131-fb3c-72dd-99a4-1d4dda619a74 -->
- [x] [[m1-accepted-work/t4-past-work|Past work]] <!-- ref: 01a12131-fb94-7857-a852-7521c5996fc5 -->
- [-] [[m1-accepted-work/t5-abandoned-work|Abandoned work]] <!-- ref: 01a12131-fbe9-7eaf-bc2f-1c46c6d5a07b -->
- [ ] [[m1-accepted-work/t6-deselected-work|Deselected work]] <!-- ref: 01a12131-fc3d-75b1-a4ee-17345034fd3d -->
