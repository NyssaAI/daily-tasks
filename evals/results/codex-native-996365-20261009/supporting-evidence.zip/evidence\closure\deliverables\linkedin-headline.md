# Synthetic reviewed LinkedIn headline

Software engineer building dependable tools for practical workflows.

Review: Codex checked that this is a headline and is saved locally, under explicit synthetic-review authorization.
