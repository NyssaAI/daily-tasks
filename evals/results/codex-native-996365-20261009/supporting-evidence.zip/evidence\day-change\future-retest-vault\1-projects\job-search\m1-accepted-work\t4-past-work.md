---
id: 01a12131-fb94-7857-a852-7521c5996fc5
type: task
title: "Past work"
owner: "synthetic@example.invalid"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
resolved_at: "2026-10-05T16:00:00Z"
record_version: 2
document-maturity: reviewed
task-state: completed
project_id: "01a12131-fa2b-780d-a2f7-6a23ddb2fa15"
milestone_id: "01a12131-fa54-745b-b320-4b2442df3896"
---
# Past work

**Milestone:** [[m1-accepted-work|Accepted work]] <!-- ref: 01a12131-fa54-745b-b320-4b2442df3896 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12131-fa2b-780d-a2f7-6a23ddb2fa15 -->

## Requirements

Past synthetic result.

## Definition of Done

- [x] Reviewed result. <!-- id: 01a12131-fbc0-73eb-9e39-94a11dd9a037 -->

## Result

User attests: past synthetic result reviewed.
