import fs from 'node:fs';import path from 'node:path';
import {root,save,read,json,cli,mon,fri,id,plan,planPath,prepare,append,event,snap} from './session.mjs';
const f=json(path.join(root,'fixture.json'));
for(const name of ['skipped','tuesday','recovery','future']){
 const v=path.join(root,name+'-vault');fs.cpSync(f.vault,v,{recursive:true,filter:p=>!['.temp','.daily-tasks'].includes(path.basename(p))});
 const pp=path.join(v,'.nyssaai/daily-tasks/profile.json'),profile=json(pp);profile.vaultRoot=v;save(pp,profile);
 const bp=path.join(v,'.nyssaai/daily-tasks/reconciliation.json');save(bp,read(bp).replaceAll(f.vault.replaceAll('\\','\\\\'),v.replaceAll('\\','\\\\')));
 append(v,event(mon,'fixture.branch',f.tasks.map(t=>t.id),{source:'Skill-authored Monday fixture',branch:name,synthetic:true}));
 snap(name+'-before',v);
}
const v=path.join(root,'skipped-vault');let p=prepare(v,fri,'friday-missing');
console.log(JSON.stringify({status:p.status,current:p.current,previous:p.previous,rollover:p.rollover},null,2));
