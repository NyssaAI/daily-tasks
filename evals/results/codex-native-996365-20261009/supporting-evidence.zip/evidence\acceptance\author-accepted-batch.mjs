import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd();
const vault='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/final-acceptance/vault';
const plugin='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/codex-home/plugins/cache/daily-tasks-native-eval/daily-tasks/0.3.3';
const evidence=path.join(root,'.temp','accepted-batch');
fs.mkdirSync(evidence,{recursive:true});
let seq=0;
function cli(op,input){
 const tag=String(++seq).padStart(2,'0')+'-'+op;
 const args=[path.join(plugin,'bin/daily-tasks.mjs'),op];
 if(input!==undefined){const file=path.join(evidence,tag+'-input.json');fs.writeFileSync(file,JSON.stringify(input,null,2));args.push('--input',file);}
 const r=spawnSync(process.execPath,args,{encoding:'utf8'});
 fs.writeFileSync(path.join(evidence,tag+'-result.json'),r.stdout);
 fs.appendFileSync(path.join(evidence,'actions.jsonl'),JSON.stringify({op,args,status:r.status,stderr:r.stderr})+'\n');
 if(r.status!==0)throw Error(r.stderr);
 return JSON.parse(r.stdout);
}
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function snapshot(stage){
 const files=[];
 function visit(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,item.name);if(item.isDirectory())visit(p);else if(!p.includes(path.sep+'.daily-tasks'+path.sep)){const b=fs.readFileSync(p),rel=path.relative(vault,p);files.push({path:rel,sha256:hash(b)});const dest=path.join(evidence,stage,rel);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,b);}}}
 visit(vault);fs.writeFileSync(path.join(evidence,stage+'-files.json'),JSON.stringify(files,null,2));return files;
}
const before=snapshot('before');
const ctx=cli('resolve-context',{vaultRoot:vault,configRoot:path.join(vault,'.nyssaai/daily-tasks')});
const recordsBefore=cli('inspect-records',{projectsRoot:ctx.projectsRoot});
const logsBefore=cli('log-query',{projectsRoot:ctx.projectsRoot,limit:1000});
if(recordsBefore.records.length)throw Error('Existing records require identity review');
const state=ctx.stateRoot;
for(const f of ['reconciliation.json'])if(fs.existsSync(path.join(state,f)))throw Error('Existing baselines require review');
const opsDir=path.join(state,'operations');
if(fs.existsSync(opsDir)&&fs.readdirSync(opsDir).length)throw Error('Pending operation requires recovery');
function id(){const r=cli('new-id');return r.id;}
const ids={project:id(),milestone:id(),linkedin:id(),resume:id(),milestoneCriterion:id(),linkedinCriterion:id(),resumeCriterion:id(),operation:id(),event:id()};
const timing=cli('activity-time',{});
const at=timing.activity_at, owner='synthetic@example.test';
const projectDir=path.join(ctx.projectsRoot,'job-search'), mDir=path.join(projectDir,'m1-career-materials');
const fm=(type,title,uuid,extra='')=>'---\nid: '+uuid+'\ntype: '+type+'\nrecord_version: 2\ntitle: '+JSON.stringify(title)+'\n'+type+'-state: not-started\nowner: "'+owner+'"\n'+extra+'created_at: "'+at+'"\nupdated_at: "'+at+'"\n---\n';
const project=fm('project','Job Search',ids.project)+'# Job Search\n\nPrepare career materials for a job search.\n\n## Project Summary\n\n| Milestone | Task | Description | Owner | Due Date |\n| --- | --- | --- | --- | --- |\n| [ ] [[m1-career-materials/m1-career-materials\\|Career materials]] <!-- ref: '+ids.milestone+' --> | | Both reviewed artifacts linked. | '+owner+' | � |\n| | [ ] [[m1-career-materials/t1-update-linkedin\\|Update LinkedIn]] <!-- ref: '+ids.linkedin+' --> | Draft headline. | '+owner+' | � |\n| | [ ] [[m1-career-materials/t2-update-resume\\|Update resume]] <!-- ref: '+ids.resume+' --> | Draft summary. | '+owner+' | � |\n';
const milestone=fm('milestone','Career materials',ids.milestone,'document-maturity: reviewed\nproject_id: "'+ids.project+'"\n')+'# M1 � Career materials\n\n**Project:** [[../project-index|Job Search]] <!-- ref: '+ids.project+' -->\n\n## Outcome\n\nPrepare a reviewed LinkedIn headline and resume summary saved locally.\n\n## Definition of Done\n\n- [ ] Both reviewed artifacts linked. <!-- id: '+ids.milestoneCriterion+' -->\n\n## Tasks\n\n- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: '+ids.linkedin+' -->\n- [ ] [[t2-update-resume|Update resume]] <!-- ref: '+ids.resume+' -->\n';
function task(title,uuid,num,requirement,dod,criterion){
 return fm('task',title,uuid,'document-maturity: reviewed\nproject_id: "'+ids.project+'"\nmilestone_id: "'+ids.milestone+'"\n')+'# M1-T'+num+' � '+title+'\n\n**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: '+ids.milestone+' -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: '+ids.project+' -->\n\n## Requirements\n\n'+requirement+'\n\n## Definition of Done\n\n- [ ] '+dod+' <!-- id: '+criterion+' -->\n\n## Inputs\n\nNo input files supplied. Local input files belong in inputs/ beside this task.\n\n## Output and delivery\n\nSave the reviewed artifact locally in outputs/ beside this task, and link it from the Result section and milestone.\n\n## Verification\n\nConfirm review and that the artifact is saved locally. DoD satisfaction requires an explicit decision.\n\n## Result\n\nPending execution.\n';
}
const planned=[
 {path:path.join(projectDir,'project-index.md'),after:project},
 {path:path.join(mDir,'m1-career-materials.md'),after:milestone},
 {path:path.join(mDir,'t1-update-linkedin.md'),after:task('Update LinkedIn',ids.linkedin,1,'Draft headline.','Reviewed headline saved locally.',ids.linkedinCriterion)},
 {path:path.join(mDir,'t2-update-resume.md'),after:task('Update resume',ids.resume,2,'Draft summary.','Reviewed summary saved locally.',ids.resumeCriterion)}
];
const acceptance='I explicitly accept the batch: Job Search project, M1 Career materials milestone, Update LinkedIn task (requirement draft headline, DoD reviewed headline saved locally) and Update resume task (requirement draft summary, DoD reviewed summary saved locally). Milestone DoD both reviewed artifacts linked. Create only these records, owner synthetic@example.test, all not-started with unchecked DoD and required metadata/UUIDv7. Preserve manual checkbox.';
const entry={id:ids.event,operation_id:ids.operation,action:'batch.accepted',record_ids:[ids.project,ids.milestone,ids.linkedin,ids.resume],actor:{kind:'person',id:owner},...timing,original_words:acceptance,after:{acceptance_source:'Current user explicit batch acceptance',records:planned.map((r,i)=>({id:[ids.project,ids.milestone,ids.linkedin,ids.resume][i],path:r.path,state:'not-started'}))}};
const candidatePath=path.join(state,'candidates.json'), candidateBefore=fs.readFileSync(candidatePath,'utf8'), candidates=JSON.parse(candidateBefore);
for(const c of candidates.candidates){
 const uuid=c.key==='native-acceptance:linkedin-update'?ids.linkedin:c.key==='native-acceptance:resume-update'?ids.resume:null;
 if(uuid){c.disposition='accepted';c.record_id=uuid;c.project=ids.project;c.milestone=ids.milestone;c.acceptance={source:'Current user explicit batch acceptance',operation_id:ids.operation,accepted_at:at};c.unresolved=[];}
}
candidates.updated_at=timing.recorded_at;
planned.push({path:candidatePath,before:candidateBefore,after:JSON.stringify(candidates,null,2)+'\n'});
const operation={operation_id:ids.operation,planningBinding:ctx.planningBinding,context:{vaultRoot:ctx.vaultRoot,projectsRoot:ctx.projectsRoot,dailyPlansRoot:ctx.dailyPlansRoot,stateRoot:state},entry,changes:planned.map(r=>({key:r.path,before:r.before===undefined?{present:false}:{present:true,value:r.before},after:{present:true,value:r.after},beforeHash:r.before===undefined?null:hash(r.before),afterHash:hash(r.after)})),intended_fields:{owner,state:'not-started',DoD:'unchecked'},status:'pending'};
fs.mkdirSync(opsDir,{recursive:true});
const checkpoint=path.join(opsDir,ids.operation+'.json');fs.writeFileSync(checkpoint,JSON.stringify(operation,null,2));
fs.writeFileSync(path.join(evidence,'pending-operation.json'),JSON.stringify(operation,null,2));
for(const r of planned){
 if(r.before===undefined?fs.existsSync(r.path):fs.readFileSync(r.path,'utf8')!==r.before)throw Error('Write conflict: '+r.path);
 fs.mkdirSync(path.dirname(r.path),{recursive:true});fs.writeFileSync(r.path,r.after);
}
for(const dir of ['inputs','outputs'])fs.mkdirSync(path.join(mDir,dir),{recursive:true});
cli('invalidate-project-index',{vaultRoot:ctx.vaultRoot});
const inspected=cli('inspect-records',{projectsRoot:ctx.projectsRoot});
const validation=cli('validate-records',{records:inspected.records});
const links=cli('check-links',{records:inspected.records});
fs.writeFileSync(path.join(evidence,'validation-summary.json'),JSON.stringify({inspected,validation,links},null,2));
console.log(JSON.stringify({ids,inspected,validation,links},null,2));
