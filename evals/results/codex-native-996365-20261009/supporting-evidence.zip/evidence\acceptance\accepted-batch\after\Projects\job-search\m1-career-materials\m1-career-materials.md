---
id: 01a12134-7622-739e-8c07-16ad987b3c1f
type: milestone
record_version: 2
title: "Career materials"
milestone-state: not-started
owner: "synthetic@example.test"
document-maturity: reviewed
project_id: "01a12134-75f3-7530-851f-4dfbb9b447b2"
created_at: "2026-10-09T15:07:29.025Z"
updated_at: "2026-10-09T15:07:29.025Z"
---
# M1 � Career materials

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12134-75f3-7530-851f-4dfbb9b447b2 -->

## Outcome

Prepare a reviewed LinkedIn headline and resume summary saved locally.

## Definition of Done

- [ ] Both reviewed artifacts linked. <!-- id: 01a12134-76aa-781d-ac17-1474bd97a26e -->

## Tasks

- [ ] [[t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a12134-764f-7dbe-a917-7c7527f13bbb -->
- [ ] [[t2-update-resume|Update resume]] <!-- ref: 01a12134-767e-7fa0-ae7f-8cbb2416f080 -->
