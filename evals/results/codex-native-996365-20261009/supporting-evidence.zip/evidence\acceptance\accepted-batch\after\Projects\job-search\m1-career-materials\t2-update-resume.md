---
id: 01a12134-767e-7fa0-ae7f-8cbb2416f080
type: task
record_version: 2
title: "Update resume"
task-state: not-started
owner: "synthetic@example.test"
document-maturity: reviewed
project_id: "01a12134-75f3-7530-851f-4dfbb9b447b2"
milestone_id: "01a12134-7622-739e-8c07-16ad987b3c1f"
created_at: "2026-10-09T15:07:29.025Z"
updated_at: "2026-10-09T15:07:29.025Z"
---
# M1-T2 � Update resume

**Milestone:** [[m1-career-materials|Career materials]] <!-- ref: 01a12134-7622-739e-8c07-16ad987b3c1f -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12134-75f3-7530-851f-4dfbb9b447b2 -->

## Requirements

Draft summary.

## Definition of Done

- [ ] Reviewed summary saved locally. <!-- id: 01a12134-76ff-7116-8917-0bc062c4b963 -->

## Inputs

No input files supplied. Local input files belong in inputs/ beside this task.

## Output and delivery

Save the reviewed artifact locally in outputs/ beside this task, and link it from the Result section and milestone.

## Verification

Confirm review and that the artifact is saved locally. DoD satisfaction requires an explicit decision.

## Result

Pending execution.
