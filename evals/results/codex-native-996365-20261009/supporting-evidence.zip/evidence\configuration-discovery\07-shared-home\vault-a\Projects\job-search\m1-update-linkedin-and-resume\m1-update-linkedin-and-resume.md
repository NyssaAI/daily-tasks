---
id: "01a12134-31c1-75ad-b57c-ad026235703c"
type: milestone
record_version: 2
title: "Update LinkedIn and resume"
document-maturity: reviewed
milestone-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
created_at: "2026-10-09T15:07:11.438Z"
updated_at: "2026-10-09T15:07:11.438Z"
---
# M1 — Update LinkedIn and resume

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Outcome

Update LinkedIn and resume for the job search.

## Definition of Done

- [ ] Reviewed career materials. <!-- id: 01a12134-3219-700c-9bb9-a5c9cb37937d -->

## Tasks

- [ ] [[t1-routing-note|Routing note]] <!-- ref: 01a12134-31ec-724e-8e1e-a4294ba42dce -->
