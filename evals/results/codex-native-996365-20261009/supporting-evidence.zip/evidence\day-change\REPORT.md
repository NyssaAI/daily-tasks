Scenario 4 was executed in the current native Codex session using the installed Daily Tasks 0.3.3 skills. All 33 requested and supporting assertion checks passed. The initial full workflow attempt is **FAIL**, retained because the native Markdown author changed the original creation timestamp in two pre-created plans. Current files were repaired and two new actual rollover operations passed identity/creation-time preservation checks. No installed source was changed.

The setup log append also initially failed with MISSING_ROOT; its actual stderr/exit status remains in cli/0007-log-append-result.json. After creating the synthetic projects directory, setup continued. This was an authoring error, not a demonstrated CLI defect.

Friday after skipped days created only Friday and carried A (own) and C (Reviewer). D/E remained terminal on Monday; F stayed deselected. Tuesday preserved B, its plan UUID and prose, carried A once, and kept A removed on repeat. An actual saved checkpoint interrupted after destination persistence resumed with the exact original event payload, IDs and GMT timestamps; retry preserved hashes and returned duplicate=true with exactly one log entry. A completion attempt with the pending checkpoint was rejected. Friday honored the earlier future A removal even though Monday still selected unfinished A. No scheduling, estimates, deadlines or time fitting were added.

Declared clocks: Monday 2026-10-05T16:00:00Z, Tuesday 2026-10-06T16:00:00Z, Friday 2026-10-09T16:00:00Z. All workflow decisions used those full GMT clocks; resolved zone America/Chicago. Actual worker/host completion timestamps are recorded separately.

The installed skill catalog and read paths establish use in this native session. Exact host version and root model ID were not exposed. A skill-required read-only gpt-6-luna worker ran through the actual spawn tool. Parent verification confirmed eight records per vault, no record/link diagnostics, no pending checkpoints, and matching source/baseline hashes. No separate host launch, phone activation or other acceptance scenario is claimed. No prior eval fixture, harness, deterministic test suite or previous transcript was replayed.

[Result](result.json) · [Assertions](assertions.json) · [Retained failures](genuine-failures.json) · [Provenance](provenance.json) · [Installed source hashes](installed-source-inventory.json) · [Maintenance](maintenance-parent-verification.json). Native-authored action files, operation checkpoints, snapshots and every CLI input/stdout/stderr/exit status are retained in this scratch directory. Log content was queried/appended only through the installed CLI; snapshot log evidence comes from log-query.

| # | Assertion | Result | Evidence |
| --- | --- | --- | --- |
| 1 | Monday selected D/E while open | PASS | snapshots/monday-selected-open |
| 2 | D completion has satisfied own DoD and user-attested result | PASS | D-closure.json; snapshots/monday-final |
| 3 | E cancellation preserves unsatisfied criteria | PASS | snapshots/monday-final |
| 4 | Terminal D/E remain visible Monday | PASS | snapshots/monday-final |
| 5 | F explicitly selected then removed while canonical stays open | PASS | snapshots/monday-selected-open; snapshots/monday-final |
| 6 | Friday missing-plan packet is not a carry proposal | PASS | friday-missing.json |
| 7 | Managed empty Friday exists before actual carry preparation | PASS | snapshots/friday-managed-empty; friday-empty.json |
| 8 | Skipped days create only Friday, no Tuesday/Wednesday/Thursday | PASS | snapshots/friday-complete |
| 9 | Friday carries only unfinished selected A/C; no B/D/E/F | PASS | friday-carry-proposal.json; snapshots/friday-complete |
| 10 | Friday own A and delegated C remain separate with Reviewer assignment | PASS | snapshots/friday-complete |
| 11 | Carry provenance records Monday and retains history | PASS | friday-carry-proposal.json; snapshots/friday-complete |
| 12 | No scheduling or timeframe fitting | PASS | All final plans and inspect-records CLI evidence |
| 13 | Friday repeat preserves selections and one rollover log | PASS | friday-repeat.json; CLI log-query |
| 14 | Tuesday was pre-created with B on Monday | PASS | snapshots/tuesday-precreated-with-B |
| 15 | Tuesday retains B, plan identity and prose; A carries once | PASS | snapshots/tuesday-precreated-with-B; snapshots/tuesday-merged |
| 16 | Repeated Tuesday before removal adds no duplicate A | PASS | tuesday-repeat-before-removal.json |
| 17 | Remove A then repeat Tuesday keeps A removed and B retained | PASS | tuesday-repeat-after-removal.json; snapshots/tuesday-final |
| 18 | Removal preserves existing Tuesday completion receipt | PASS | tuesday-remove-packet.json; Tuesday rollover state |
| 19 | Actual rollover checkpoint retained at destination interruption | PASS | recovery-original-checkpoint.json; snapshots/recovery-interrupted-after-destination |
| 20 | No false receipt after destination persistence | PASS | recovery-false-receipt-result.json; recovery-interruption-state.json; recovery-before-log.json |
| 21 | Recovery classifies persisted destination already-applied | PASS | recovery-classification.json |
| 22 | Resume preserves exact original event payload and both GMT timestamps | PASS | recovery-exact-event.json |
| 23 | Recovery retry has one event, no duplicate rows, no pending checkpoint | PASS | recovery-retry-append.json; recovery-retry-packet.json; snapshots/recovery-retry |
| 24 | Retry changes neither destination nor completion receipt | PASS | recovery-exact-event.json; snapshots/recovery-retry |
| 25 | Future A removal persisted before Friday without completion receipt | PASS | future-remove-proposal.json; snapshots/future-removed-before-Friday |
| 26 | Friday honors future removal even with unfinished A still on Monday | PASS | future-Friday-proposal.json; snapshots/future-Friday-final |
| 27 | Repeated Friday preserves future removal and one carry event | PASS | future-Friday-repeat.json; CLI log-query |
| 28 | Creation metadata regression retained, not erased | PASS | genuine-failures.json; original failed snapshots |
| 29 | Corrected new rollover retains pre-created identity and creation timestamp | PASS | tuesday-retest-metadata-before/after.json; future-retest-metadata-before/after.json |
| 30 | All decision timestamps use declared full GMT clocks | PASS | All CLI log-query evidence |
| 31 | Timezone resolves America/Chicago with correct simulated local days | PASS | Preparation packets |
| 32 | Only accepted six tasks exist, no implicit extra work | PASS | initial-inspect.json; final inspect-records CLI |
| 33 | All CLI IDs are UUIDv7 | PASS | CLI new-id transcripts |
