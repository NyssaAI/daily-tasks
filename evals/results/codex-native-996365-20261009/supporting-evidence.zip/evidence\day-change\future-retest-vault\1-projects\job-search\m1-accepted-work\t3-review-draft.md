---
id: 01a12131-fb3c-72dd-99a4-1d4dda619a74
type: task
title: "Review draft"
owner: "synthetic@example.invalid"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
record_version: 2
document-maturity: reviewed
task-state: not-started
project_id: "01a12131-fa2b-780d-a2f7-6a23ddb2fa15"
milestone_id: "01a12131-fa54-745b-b320-4b2442df3896"
assignee: "Reviewer"
---
# Review draft

**Milestone:** [[m1-accepted-work|Accepted work]] <!-- ref: 01a12131-fa54-745b-b320-4b2442df3896 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12131-fa2b-780d-a2f7-6a23ddb2fa15 -->

## Requirements

Inspect draft.

## Definition of Done

- [ ] Recorded review. <!-- id: 01a12131-fb68-7766-8ff0-88d1b3a3ba80 -->
