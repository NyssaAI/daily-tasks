---
id: 01a12131-fbe9-7eaf-bc2f-1c46c6d5a07b
type: task
title: "Abandoned work"
owner: "synthetic@example.invalid"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
resolved_at: "2026-10-05T16:00:00Z"
record_version: 2
document-maturity: reviewed
task-state: cancelled
project_id: "01a12131-fa2b-780d-a2f7-6a23ddb2fa15"
milestone_id: "01a12131-fa54-745b-b320-4b2442df3896"
---
# Abandoned work

**Milestone:** [[m1-accepted-work|Accepted work]] <!-- ref: 01a12131-fa54-745b-b320-4b2442df3896 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12131-fa2b-780d-a2f7-6a23ddb2fa15 -->

## Requirements

Draft work.

## Definition of Done

- [ ] Reviewed result. <!-- id: 01a12131-fc17-7b60-b44d-ae247b4808b8 -->
