import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {isDeepStrictEqual} from 'node:util';
const root=process.cwd(), evidence=path.join(root,'.temp/accepted-batch');
const op=JSON.parse(fs.readFileSync(path.join(evidence,'pending-operation.json'),'utf8'));
const ctx=op.context, cliPath='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/codex-home/plugins/cache/daily-tasks-native-eval/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
let seq=30;
function cli(name,input){
 const tag=++seq+'-'+name, p=path.join(evidence,tag+'-input.json');fs.writeFileSync(p,JSON.stringify(input,null,2));
 const r=spawnSync(process.execPath,[cliPath,name,'--input',p],{encoding:'utf8'});
 fs.writeFileSync(path.join(evidence,tag+'-result.json'),r.stdout);
 fs.appendFileSync(path.join(evidence,'actions.jsonl'),JSON.stringify({op:name,input:p,status:r.status,stderr:r.stderr})+'\n');
 if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);
}
const summary=JSON.parse(fs.readFileSync(path.join(evidence,'validation-summary.json'),'utf8'));
if([summary.inspected,summary.validation,summary.links].some(r=>r.diagnostics.length))throw Error('Diagnostics require resolution');
for(const change of op.changes)if(hash(fs.readFileSync(change.key))!==change.afterHash)throw Error('Changed since validation');
const timingFile=fs.readdirSync(evidence).find(n=>n.endsWith('-activity-time-result.json'));
const timing=JSON.parse(fs.readFileSync(path.join(evidence,timingFile),'utf8'));
if(op.entry.activity_at!==timing.activity_at||op.entry.recorded_at!==timing.recorded_at)throw Error('Timing mismatch');
cli('log-append',{projectsRoot:ctx.projectsRoot,entry:op.entry});
const allEntries=[];let offset=0, query;
do{query=cli('log-query',{projectsRoot:ctx.projectsRoot,limit:1000,offset});allEntries.push(...query.entries);offset=query.nextOffset;}while(offset!==null);
fs.writeFileSync(path.join(evidence,'full-log-after.json'),JSON.stringify(allEntries,null,2));
const logged=allEntries.find(e=>e.id===op.entry.id);
if(!isDeepStrictEqual(logged,op.entry))throw Error('Log payload mismatch');
const records=cli('inspect-records',{projectsRoot:ctx.projectsRoot});
cli('validate-records',{records:records.records});cli('check-links',{records:records.records});
const baseline={schema_version:1,planningBinding:op.planningBinding,records:{}};
for(const r of records.records){
 const views={};
 for(const view of records.records){
  const projection=view.projections.find(p=>p.id===r.id);
  if(projection)views[view.path]={lastRendered:{state:r.state,checked:projection.checked},source:{state:r.state},sha256:hash(fs.readFileSync(view.path))};
 }
 baseline.records[r.id]={canonical:{state:r.state,owner:r.owner,updated_at:r.updated_at},path:r.path,sha256:hash(fs.readFileSync(r.path)),views};
}
const baselinePath=path.join(ctx.stateRoot,'reconciliation.json');
if(fs.existsSync(baselinePath))throw Error('Unexpected baseline');
fs.writeFileSync(baselinePath,JSON.stringify(baseline,null,2)+'\n');
fs.writeFileSync(path.join(evidence,'reconciliation-after.json'),JSON.stringify(baseline,null,2));
const after=[];
function visit(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,item.name);if(item.isDirectory())visit(p);else if(!p.includes(path.sep+'.daily-tasks'+path.sep)&&!p.includes(path.sep+'operations'+path.sep)){const b=fs.readFileSync(p),rel=path.relative(ctx.vaultRoot,p),dest=path.join(evidence,'after',rel);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,b);after.push({path:rel,sha256:hash(b)});}}}
visit(ctx.vaultRoot);
fs.writeFileSync(path.join(evidence,'after-files.json'),JSON.stringify(after,null,2));
const before=JSON.parse(fs.readFileSync(path.join(evidence,'before-files.json'),'utf8'));
const manual=path.join('Daily','2026-10-09.md'), profile=path.join('.nyssaai','daily-tasks','profile.json');
const unchanged=rel=>before.find(f=>f.path===rel).sha256===after.find(f=>f.path===rel).sha256;
const verification={recordCount:records.records.length,allNotStarted:records.records.every(r=>r.state==='not-started'),ownerCorrect:records.records.every(r=>r.owner==='synthetic@example.test'),allDoDUnchecked:records.records.every(r=>r.criteria.every(c=>!c.checked)),manualPlanUnchanged:unchanged(manual),profileUnchanged:unchanged(profile),fullAcceptancePayloadVerified:true,fullLogEntryCount:allEntries.length,unresolvedCandidateCount:0};
if(Object.values(verification).includes(false))throw Error('Verification failed');
fs.writeFileSync(path.join(evidence,'verification.json'),JSON.stringify(verification,null,2));
fs.writeFileSync(path.join(evidence,'completed-operation.json'),JSON.stringify({...op,status:'complete'},null,2));
fs.unlinkSync(path.join(ctx.stateRoot,'operations',op.operation_id+'.json'));
console.log(JSON.stringify(verification,null,2));
