# Installed Daily Tasks: four synthetic requests

Completed using the installed 0.3.3 skills and CLI. The workflow in `run-four.mjs` was authored for this request from the installed Setup, Records, record template, operation protocol and CLI reference. No prior scripts or tests were replayed. Only cases 01–04 were accessed; no personal directories were used. No questions were needed.

Each project now contains `m1-update-linkedin-and-resume/m1-update-linkedin-and-resume.md`, with one unchecked milestone DoD criterion: **reviewed career materials**. Each milestone is owned by synthetic@example.test and remains not-started. Project navigation was updated, and empty sibling inputs/ and outputs/ directories were created. No tasks or daily selections were created.

| Case | Configuration resolution | Daily-plan output, relative to CASE | Profile outcome |
| --- | --- | --- | --- |
| 01-common-root | Accepted common/.nyssaai root → daily-tasks/profile.json; supplied derived profilePath, no configRoot argument | vault/Daily | Existing bytes preserved |
| 02-no-profile | Accepted common/.nyssaai root → new daily-tasks/profile.json | vault/2-areas/daily-plans | Validated and saved Synthetic User, synthetic@example.test, America/Chicago, empty priorities |
| 03-explicit-legacy | Explicit vault/.nyssa/daily-tasks/profile.json pointer | vault/Daily | Existing bytes preserved; no migration |
| 04-vault-only-legacy | Known vault; CLI discovery found legacy profile, with neither profilePath nor configRoot supplied | vault/Daily | Existing bytes preserved; no migration |

Daily-plan destinations were resolved and recorded; no daily-plan creation was requested. Preferences and operating state contain no accepted work documents. Cases 01–02 use vault/.nyssaai/daily-tasks for operating state. Cases 03–04 retain vault/.nyssa/daily-tasks operating state under the installed resolver's legacy convention.

For each case, `.temp/evidence/` contains:

- `before.json` and `after.json`: file paths, byte sizes, SHA-256 hashes and non-log contents. Log contents were never read directly; snapshots retain only their hashes and sizes.
- `actions.json`: exact CLI commands, inputs, outputs, exit codes and authored file actions.
- `resolved-context.json`: independent resolved vault, configuration, state, project and daily-plan roots.
- `inspection.json`, `validation.json`: canonical record inspection and empty record/link diagnostics.
- CLI log-query result files: initial history and final queried entries; the full milestone event payload was compared with the pending operation before completion.
- `result.json`: per-case outcomes and resolved destinations.

The transaction saved a pending operation before Markdown writes, checked original content immediately before updating it, authored the milestone and project link, invalidated the project cache, validated records and links, appended/query-verified the decision through the installed log CLI, established reconciliation baselines, and removed the completed checkpoint. Case 02 also logged its explicit profile setup. IDs and actual GMT timestamps came from the installed CLI.

This demonstrates persisted workflow results through installed skills and CLI. It does not claim automatic host activation from packaging or CLI execution.
