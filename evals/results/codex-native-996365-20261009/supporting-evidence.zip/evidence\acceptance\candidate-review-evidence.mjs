import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=process.cwd(), vault=path.join(root,'vault'), evidence=path.join(root,'.temp','candidate-review-evidence');
fs.mkdirSync(evidence,{recursive:true});
const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/codex-home/plugins/cache/daily-tasks-native-eval/daily-tasks/0.3.3/bin/daily-tasks.mjs';
const paths=['Daily/2026-10-09.md','.nyssaai/daily-tasks/candidates.json','.nyssaai/daily-tasks/profile.json'];
function snapshot(stage){
 const items=paths.map(rel=>{const b=fs.readFileSync(path.join(vault,rel));fs.writeFileSync(path.join(evidence,stage+'-'+path.basename(rel)),b);return {path:rel,sha256:crypto.createHash('sha256').update(b).digest('hex')};});
 fs.writeFileSync(path.join(evidence,stage+'-hashes.json'),JSON.stringify(items,null,2));return items;
}
function call(op,input,stage){
 const name=stage+'-'+op, file=path.join(evidence,name+'-input.json');
 fs.writeFileSync(file,JSON.stringify(input,null,2));
 const r=spawnSync(process.execPath,[cli,op,'--input',file],{encoding:'utf8'});
 fs.writeFileSync(path.join(evidence,name+'-result.json'),r.stdout);
 fs.writeFileSync(path.join(evidence,name+'-execution.json'),JSON.stringify({status:r.status,stderr:r.stderr},null,2));
 if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);
}
const before=snapshot('before');
const context=call('resolve-context',{vaultRoot:vault,configRoot:path.join(vault,'.nyssaai/daily-tasks')},'before');
const input={projectsRoot:context.projectsRoot};
const recordsBefore=call('inspect-records',input,'before');
const logsBefore=call('log-query',{...input,limit:1000},'before');
const rows=call('parse-checklist',{markdown:fs.readFileSync(path.join(vault,paths[0]),'utf8')},'before');
const candidates=JSON.parse(fs.readFileSync(path.join(vault,paths[1]),'utf8'));
const recordsAfter=call('inspect-records',input,'after');
const logsAfter=call('log-query',{...input,limit:1000},'after');
const after=snapshot('after');
const result={candidateCount:candidates.candidates.length,candidateKeys:candidates.candidates.map(c=>c.key),manualRows:rows,filesUnchanged:JSON.stringify(before)===JSON.stringify(after),recordsUnchanged:JSON.stringify(recordsBefore)===JSON.stringify(recordsAfter),logsUnchanged:JSON.stringify(logsBefore)===JSON.stringify(logsAfter),records:recordsAfter,acceptedRecordsCreated:0};
fs.writeFileSync(path.join(evidence,'verification.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({context,verification:result,logQuery:logsAfter},null,2));
