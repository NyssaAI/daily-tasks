---
id: 01a12131-fc3d-75b1-a4ee-17345034fd3d
type: task
title: "Deselected work"
owner: "synthetic@example.invalid"
created_at: "2026-10-05T16:00:00Z"
updated_at: "2026-10-05T16:00:00Z"
record_version: 2
document-maturity: reviewed
task-state: not-started
project_id: "01a12131-fa2b-780d-a2f7-6a23ddb2fa15"
milestone_id: "01a12131-fa54-745b-b320-4b2442df3896"
---
# Deselected work

**Milestone:** [[m1-accepted-work|Accepted work]] <!-- ref: 01a12131-fa54-745b-b320-4b2442df3896 -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12131-fa2b-780d-a2f7-6a23ddb2fa15 -->

## Requirements

Optional draft.

## Definition of Done

- [ ] Reviewed draft. <!-- id: 01a12131-fc68-7e4d-8881-68cae8833df9 -->
