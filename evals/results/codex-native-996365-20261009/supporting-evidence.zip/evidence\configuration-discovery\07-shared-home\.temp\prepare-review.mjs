import fs from 'node:fs';import path from 'node:path';import {call,save,hash,opts} from './session.mjs';
const c=JSON.parse(fs.readFileSync('.temp/context.json'));const created=JSON.parse(fs.readFileSync('.temp/created.json'));const inspected=JSON.parse(fs.readFileSync('.temp/records-inspected.json'));
save('.temp/validation.json',call('validate-records',{records:inspected.records}));save('.temp/links.json',call('check-links',{records:inspected.records}));
const queried=call('log-query',{projectsRoot:c.projectsRoot});
save('.temp/log-verified.json',queried);
console.log(JSON.stringify(queried));
const baseline={schemaVersion:1,records:{}};
for(const r of inspected.records){baseline.records[r.id]={canonical:{state:r.state,owner:r.owner},path:r.path,sha256:hash(fs.readFileSync(r.path)),views:{}};}
for(const r of inspected.records)for(const view of inspected.records)if(view.projections.some(p=>p.id===r.id))baseline.records[r.id].views[view.path]={state:r.state,checked:false,sha256:hash(fs.readFileSync(view.path))};
save(path.join(c.stateRoot,'reconciliation.json'),baseline);save('.temp/records-completed-checkpoint.json',JSON.parse(fs.readFileSync(created.checkpoint)));fs.unlinkSync(created.checkpoint);
save(path.join(c.stateRoot,'maintenance.json'),{lastFullReconcileAt:new Date().toISOString(),model:'gpt-6-luna',executionEvidence:'vault-a/.temp/maintenance/inspect-output.json',parentVerification:'.temp/records-inspected.json',diagnostics:[]});
const p=call('planning-prepare',opts); const planId=call('new-id').id;const op=call('new-id').id;const eid=call('new-id').id;const timing=call('activity-time',{});
const display=call('format-time',{time:timing.recorded_at,timezone:c.timezone});save('.temp/display-time.json',display);
const md=`---\nid: "${planId}"\ntype: daily-plan\ntitle: "Daily plan ${p.context.localDate}"\ndocument-maturity: reviewed\ntimezone: "America/Chicago"\ncreated_at: "${timing.recorded_at}"\nupdated_at: "${timing.recorded_at}"\n---\n# Daily plan — ${p.context.localDate}\n\nOpen projects: 1          Open tasks: 1          Late tasks: 0\n\n**Timezone:** America/Chicago\n\n## Selected for today\n\n### My work\n\nNo work selected.\n\n### Delegated work\n\nNo delegated work selected.\n\nLegend: [ ] not started · [>] in progress · [x] completed · [-] cancelled\n`;
const event={id:eid,operation_id:op,action:'plan.created',record_ids:[planId],actor:{kind:'person',id:'synthetic@example.test'},...timing,original_words:'Show numbered planning review for A',after:{date:p.context.localDate,selected:[]}};
const cp=path.join(c.stateRoot,'operations',`${op}.json`);save(cp,{schemaVersion:1,operation_id:op,planningBinding:c.planningBinding,context:c,event,files:[{path:p.current.path,before:null,beforeHash:null,after:md,afterHash:hash(md)}],status:'pending'});
if(fs.existsSync(p.current.path))throw Error('plan appeared');save(p.current.path,md);call('invalidate-project-index',{vaultRoot:c.vaultRoot});call('log-append',{projectsRoot:c.projectsRoot,entry:event});save('.temp/plan-created-log.json',call('log-query',{projectsRoot:c.projectsRoot}));
baseline.plans={[p.current.path]:{id:planId,selected:[],sha256:hash(md)}};save(path.join(c.stateRoot,'reconciliation.json'),baseline);save('.temp/plan-created-checkpoint.json',JSON.parse(fs.readFileSync(cp)));fs.unlinkSync(cp);
function stateInput(packet,action){return {...opts,now:packet.context.now,action,expectedPlanHash:packet.current.sha256,expectedPreviousHash:packet.previous?.sha256??null,expectedInventoryHash:packet.inventoryHash,expectedStateHash:packet.state[action==='save-review'?'review':'rollover'].sha256,...(action==='save-review'?{expectedReviewHash:packet.reviewHash}:{})};}
let packet=call('planning-prepare',opts);save('.temp/rollover-packet.json',packet);save('.temp/rollover-result.json',call('planning-state',stateInput(packet,'complete-rollover')));
packet=call('planning-prepare',opts);save('.temp/review-packet.json',packet);save('.temp/review-save-result.json',call('planning-state',stateInput(packet,'save-review')));console.log(JSON.stringify(packet.review));
