import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root=process.cwd(), evidence=path.join(root,'.temp/supplied-record-closure');
const vault=path.join(root,'vault'), projects=path.join(vault,'Projects'), state=path.join(vault,'.nyssaai/daily-tasks');
const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/codex-home/plugins/cache/daily-tasks-native-eval/daily-tasks/0.3.3';
const cli=path.join(bundle,'bin/daily-tasks.mjs');
const project=path.join(projects,'job-search'), work=path.join(project,'m1-career-materials');
const files={p:path.join(project,'project-index.md'),m:path.join(work,'m1-career-materials.md'),a:path.join(work,'t1-update-linkedin.md'),b:path.join(work,'t2-update-resume.md'),x:path.join(project,'blockers/b1-await-approval.md')};
const ids={p:'01a1211c-fbe7-727c-885c-bd3fcf926af2',m:'01a1211c-fc13-750e-993c-51e78d20ea25',a:'01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8',b:'01a1211c-fc6d-7e56-b639-7133ec8fe4d6'};
let n=fs.existsSync(path.join(evidence,'cli'))?fs.readdirSync(path.join(evidence,'cli')).length:0, step=0; const assertions=[];
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const save=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
function call(op,input={}){const prefix=path.join(evidence,'cli',String(++n).padStart(4,'0')+'-'+op);save(prefix+'.input.json',input);const r=spawnSync(process.execPath,[cli,op,'--input',prefix+'.input.json'],{encoding:'utf8'});save(prefix+'.result.json',{command:[process.execPath,cli,op,'--input',prefix+'.input.json'],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});assert.equal(r.status,0,r.stderr);return JSON.parse(r.stdout);}
const read=()=>call('inspect-records',{projectsRoot:projects});
const text=k=>fs.readFileSync(files[k],'utf8');
const field=(s,k,v)=>{const line=k+': '+JSON.stringify(v);const re=new RegExp('^'+k+':.*$','m');return re.test(s)?s.replace(re,line):s.replace(/\r?\n---\r?\n/, '\n'+line+'\n---\n');};
const clear=(s,k)=>s.replace(new RegExp('^'+k+':.*\\r?\\n','m'),'');
const dod=(s,checked)=>s.replace(/(- \[)[ x](\].*<!-- id:)/g,'$1'+(checked?'x':' ')+'$2');
const setState=(s,type,value,time)=>{s=field(field(s,type+'-state',value),'updated_at',time);return ['completed','cancelled','resolved'].includes(value)?field(s,'resolved_at',time):clear(s,'resolved_at');};
function check(label,k,allowed,reason){const r=call('check-closure',{recordId:ids[k],records:read().records});assert.equal(r.allowed,allowed,label+': '+JSON.stringify(r));if(reason)assert.match(JSON.stringify(r.reasons),reason);assertions.push({label,pass:true,result:r});return r;}
function snapshot(dir){for(const [k,p] of Object.entries(files))if(fs.existsSync(p))save(path.join(dir,path.relative(vault,p)),fs.readFileSync(p));}
function baseline(records){const out={schema_version:1,planningBinding:context.planningBinding,records:{}};for(const r of records){const fields={title:r.title,owner:r.owner,[r.type+'-state']:r.state};out.records[r.id]={canonical:{fields,path:r.path,sha256:hash(fs.readFileSync(r.path))},views:{}};for(const v of records)if(v.projections.some(p=>p.id===r.id))out.records[r.id].views[v.path]={fields:{[r.type+'-state']:r.state},sha256:hash(fs.readFileSync(v.path))};}save(path.join(state,'reconciliation.json'),out);}
function transaction(label,edit,{reopen=[]}={}){
 const dir=path.join(evidence,'cases',String(++step).padStart(2,'0')+'-'+label);snapshot(path.join(dir,'before'));
 const before=Object.fromEntries(Object.entries(files).map(([k,p])=>[k,fs.existsSync(p)?fs.readFileSync(p,'utf8'):null]));
 const time=call('activity-time',{}), op=call('new-id').id, eventId=call('new-id').id;
 let after={...before}; edit(after,time.activity_at);
 if(reopen.length){const records=Object.entries(after).filter(([,s])=>s!==null).map(([k,s])=>call('parse-record',{markdown:s,path:files[k]}));const proposal=call('reopen-ancestors',{records,changedIds:reopen.map(k=>ids[k])});save(path.join(dir,'reopen-proposal.json'),proposal);for(const r of proposal.records){const k=Object.keys(ids).find(k=>ids[k]===r.id);if(k && r.state!==records.find(x=>x.id===r.id).state)after[k]=setState(after[k],r.type,r.state,time.activity_at);}}
 const proposed=Object.entries(after).filter(([,s])=>s!==null).map(([k,s])=>call('parse-record',{markdown:s,path:files[k]}));
 // Refresh parent projections after canonical effects, retaining titles and prose.
 for(const k of ['m','p'])after[k]=after[k].split('\n').map(line=>{const ref=line.match(/<!-- ref: ([\w-]+) -->/);const r=ref&&proposed.find(r=>r.id===ref[1]);if(!r||!line.includes('[ ]')&&!line.includes('[x]')&&!line.includes('[-]')&&!line.includes('[>]'))return line;const mark={completed:'x',cancelled:'-', 'in-progress':'>','not-started':' '}[r.state];return line.replace(/\[[ x>\-]\]/,'['+mark+']');}).join('\n');
 const changes=Object.entries(after).filter(([k,s])=>s!==before[k]).map(([k,s])=>({key:files[k],before:{present:before[k]!==null,...(before[k]===null?{}:{value:hash(before[k])})},after:{present:s!==null,...(s===null?{}:{value:hash(s)})},before_sha256:before[k]===null?null:hash(before[k]),after_sha256:s===null?null:hash(s),intended_change:label}));
 const entry={id:eventId,operation_id:op,action:'closure.acceptance.'+label,record_ids:Object.values(ids),actor:{kind:'agent',id:'codex'},...time,original_words:'User authorized exact supplied-record closure acceptance',before:Object.fromEntries(changes.map(c=>[c.key,c.before_sha256])),after:{reason:label,files:Object.fromEntries(changes.map(c=>[c.key,c.after_sha256]))}};
 const checkpoint={operation_id:op,planningBinding:context.planningBinding,status:'pending',changes,entry};const cp=path.join(state,'operations',op+'.json');save(cp,checkpoint);save(path.join(dir,'checkpoint.json'),checkpoint);
 for(const k of ['a','b','x','m','p'])if(after[k]!==before[k]){assert.equal(fs.existsSync(files[k])?text(k):null,before[k]);save(files[k],after[k]);}
 call('invalidate-project-index',{vaultRoot:vault});
 const actual=read();save(path.join(dir,'inspection.json'),actual);
 const validation=call('validate-records',{records:actual.records}), links=call('check-links',{records:actual.records});save(path.join(dir,'validation.json'),{validation,links});
 call('log-append',{projectsRoot:projects,entry});const query=call('log-query',{projectsRoot:projects,action:entry.action,limit:1000});save(path.join(dir,'log-query.json'),query);assert.ok(JSON.stringify(query).includes(eventId));
 const events=Array.isArray(query)?query:query.entries;assert.deepEqual(events.find(e=>e.id===eventId),entry);
 baseline(actual.records);snapshot(path.join(dir,'after'));save(path.join(dir,'completed.json'),{...checkpoint,status:'completed'});fs.unlinkSync(cp);console.log(label);
}
const context=call('resolve-context',{vaultRoot:vault});step=24;ids.x=read().records.find(r=>r.type==='blocker').id;assertions.push(...JSON.parse(fs.readFileSync(path.join(evidence,'assertions.json'),'utf8')));
function close(k,label){check(label+' eligibility',k,true);transaction(label,(s,t)=>{s[k]=setState(s[k],k==='p'?'project':k==='m'?'milestone':'task','completed',t);});}

transaction('isolated-milestone-dod-gate',(s,t)=>{s.m=field(dod(s.m,false),'updated_at',t);},{reopen:['m']});
check('milestone DoD alone gates closure with completed tasks and resolved blocker','m',false,/definition of done/i);
transaction('restore-isolated-milestone-dod',(s,t)=>{s.m=field(dod(s.m,true),'updated_at',t);});
close('m','final-verified-complete-milestone');close('p','final-verified-complete-project');
const final=read();assert.equal(final.records.length,5);assert.deepEqual(call('validate-records',{records:final.records}).diagnostics,[]);assert.deepEqual(call('check-links',{records:final.records}).diagnostics,[]);
const history=[];
for(const name of fs.readdirSync(path.join(evidence,'cases'))){const dir=path.join(evidence,'cases',name);const cp=JSON.parse(fs.readFileSync(path.join(dir,'checkpoint.json'),'utf8'));for(const change of cp.changes){const relative=path.relative(vault,change.key);const b=path.join(dir,'before',relative),a=path.join(dir,'after',relative);const extract=p=>{if(!fs.existsSync(p))return null;const s=fs.readFileSync(p,'utf8');const out={};for(const field of ['id','task-state','milestone-state','project-state','blocker-state','updated_at','resolved_at']){const m=s.match(new RegExp('^'+field+': (.*)$','m'));if(m)out[field]=m[1];}return out;};history.push({operation_id:cp.operation_id,path:change.key,before:extract(b),after:extract(a)});}}
const timing=call('activity-time',{}), operation_id=call('new-id').id;
const entry={id:call('new-id').id,operation_id,action:'closure.acceptance.lifecycle-history',record_ids:Object.values(ids),actor:{kind:'agent',id:'codex'},...timing,after:{reason:'Retain exact lifecycle values from committed supplied-record before/after evidence',history}};
const cp=path.join(state,'operations',operation_id+'.json');save(cp,{operation_id,planningBinding:context.planningBinding,changes:[],entry,status:'pending'});call('log-append',{projectsRoot:projects,entry});const query=call('log-query',{projectsRoot:projects,action:entry.action,limit:1000});assert.deepEqual(query.entries.find(e=>e.id===entry.id),entry);save(path.join(evidence,'lifecycle-history-query.json'),query);fs.unlinkSync(cp);
save(path.join(evidence,'assertions.json'),assertions);save(path.join(evidence,'final-log-query.json'),call('log-query',{projectsRoot:projects,limit:1000}));snapshot(path.join(evidence,'final'));
const sources=['skills/daily-tasks/SKILL.md','skills/daily-tasks-records/SKILL.md','skills/daily-tasks-setup/SKILL.md','skills/daily-tasks/references/records.md','skills/daily-tasks/references/operations.md','skills/daily-tasks/references/cli.md','bin/daily-tasks.mjs'];save(path.join(evidence,'sources.json'),{node:process.version,installedBundle:bundle,sources:sources.map(p=>({path:path.join(bundle,p),sha256:hash(fs.readFileSync(path.join(bundle,p)))})),readme:{path:'D:/repos/NyssaAI/daily-tasks/evals/README.md',sha256:hash(fs.readFileSync('D:/repos/NyssaAI/daily-tasks/evals/README.md'))}});
const validations=[];for(const name of fs.readdirSync(path.join(evidence,'cases'))){const v=JSON.parse(fs.readFileSync(path.join(evidence,'cases',name,'validation.json'),'utf8'));assert.deepEqual(v.validation.diagnostics,[]);assert.ok(v.links.diagnostics.every(d=>d.code==='cancelled-prerequisite'));validations.push({case:name,...v});}save(path.join(evidence,'validation-summary.json'),validations);
assert.equal(fs.readFileSync(path.join(vault,'Daily/2026-10-09.md'),'utf8'),'# Friday\n\n- [ ] Maybe improve my resume\n');
console.log(JSON.stringify({pass:true,cases:step,checks:assertions.length}));
