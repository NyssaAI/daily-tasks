import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root=path.resolve('.temp/day-change');
export const pkg='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/codex-home/plugins/cache/daily-tasks-native-eval/daily-tasks/0.3.3';
export const mon='2026-10-05T16:00:00Z',tue='2026-10-06T16:00:00Z',fri='2026-10-09T16:00:00Z';
export const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
export function save(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
export function read(p){return fs.readFileSync(p,'utf8');}
export function json(p){return JSON.parse(read(p));}
let seq=fs.existsSync(path.join(root,'sequence.json'))?json(path.join(root,'sequence.json')):0;
export function cli(op,input){const n=String(++seq).padStart(4,'0'),stem=path.join(root,'cli',n+'-'+op);save(path.join(root,'sequence.json'),seq);const args=[pkg+'/bin/daily-tasks.mjs',op];if(input){save(stem+'-input.json',input);args.push('--input',stem+'-input.json');}const r=spawnSync(process.execPath,args,{encoding:'utf8'});save(stem+'-result.json',{status:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(op+': '+r.stderr);return JSON.parse(r.stdout);}
export function id(){const r=cli('new-id');return typeof r==='string'?r:r.id;}
export function snap(label,vault){const dest=path.join(root,'snapshots',label);fs.mkdirSync(dest,{recursive:true});fs.cpSync(vault,path.join(dest,'vault'),{recursive:true,filter:p=>!p.includes(path.sep+'.daily-tasks'+path.sep)&&path.basename(p)!=='.daily-tasks'});save(path.join(dest,'log-query.json'),cli('log-query',{projectsRoot:path.join(vault,'1-projects'),limit:1000}));}
export function context(vault,now){return {vaultRoot:vault,profilePath:path.join(vault,'.nyssaai/daily-tasks/profile.json'),homeRoot:path.join(root,'synthetic-home'),now};}
export function prepare(vault,now,label){const p=cli('planning-prepare',context(vault,now));save(path.join(root,label+'.json'),p);return p;}
export function invalidate(vault){cli('invalidate-project-index',{vaultRoot:vault});}
export function activity(now){return cli('activity-time',{now});}
export function event(now,action,ids,after){const t=activity(now);return {id:id(),operation_id:id(),action,record_ids:ids,actor:{kind:'person',id:'synthetic@example.invalid'},...t,after};}
export function append(vault,entry){return cli('log-append',{projectsRoot:path.join(vault,'1-projects'),entry});}
export function front(type,title,uuid,now,extra=''){return `---\nid: ${uuid}\ntype: ${type}\ntitle: "${title}"\nowner: "synthetic@example.invalid"\ncreated_at: "${now}"\nupdated_at: "${now}"\n${extra}---\n`;}
export function plan(vault,date,uuid,now,tasks,carry=[]){const rows=group=>tasks.filter(t=>(t.key==='C')===group).map(t=>`| ${tasks.indexOf(t)+1} | ${t.state==='completed'?'[x]':t.state==='cancelled'?'[-]':'[ ]'} | Job Search | Accepted work | ${carry.includes(t.key)?'↺ ':''}[[../../1-projects/job-search/m1-accepted-work/${t.file.slice(0,-3)}\\|${t.state==='cancelled'?'~~'+t.title+'~~':t.title}]] <!-- ref: ${t.id} --> | — |`).join('\n')||'No work selected.';return front('daily-plan','Daily plan '+date,uuid,now,'document-maturity: reviewed\ntimezone: "America/Chicago"\n')+`# Daily plan — ${date}\n\n**Timezone:** America/Chicago\n**Updated:** 11:00 America/Chicago\n\n## Selected for today\n\n### My work\n\n| # | Status | Project | Milestone | Task | Due Date |\n| --- | --- | --- | --- | --- | --- |\n${rows(false)}\n\n### Delegated work\n\n| # | Status | Project | Milestone | Task | Due Date |\n| --- | --- | --- | --- | --- | --- |\n${rows(true)}\n\nLegend: [ ] not started · [>] in progress · [x] completed · [-] cancelled · ↺ carried forward\n\n## Notes and references\n\nSynthetic acceptance: preserve this prose.\n`;}
export const planPath=(v,d)=>path.join(v,'2-areas/daily-plans',d+'-daily-plan.md');
