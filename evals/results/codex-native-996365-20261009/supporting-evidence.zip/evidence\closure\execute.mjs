import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root=process.cwd(), evidence=path.join(root,'.temp/supplied-record-closure');
const vault=path.join(root,'vault'), projects=path.join(vault,'Projects'), state=path.join(vault,'.nyssaai/daily-tasks');
const bundle='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/codex-home/plugins/cache/daily-tasks-native-eval/daily-tasks/0.3.3';
const cli=path.join(bundle,'bin/daily-tasks.mjs');
const project=path.join(projects,'job-search'), work=path.join(project,'m1-career-materials');
const files={p:path.join(project,'project-index.md'),m:path.join(work,'m1-career-materials.md'),a:path.join(work,'t1-update-linkedin.md'),b:path.join(work,'t2-update-resume.md'),x:path.join(project,'blockers/b1-await-approval.md')};
const ids={p:'01a1211c-fbe7-727c-885c-bd3fcf926af2',m:'01a1211c-fc13-750e-993c-51e78d20ea25',a:'01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8',b:'01a1211c-fc6d-7e56-b639-7133ec8fe4d6'};
let n=fs.existsSync(path.join(evidence,'cli'))?fs.readdirSync(path.join(evidence,'cli')).length:0, step=0; const assertions=[];
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const save=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
function call(op,input={}){const prefix=path.join(evidence,'cli',String(++n).padStart(4,'0')+'-'+op);save(prefix+'.input.json',input);const r=spawnSync(process.execPath,[cli,op,'--input',prefix+'.input.json'],{encoding:'utf8'});save(prefix+'.result.json',{command:[process.execPath,cli,op,'--input',prefix+'.input.json'],exitCode:r.status,stdout:r.stdout,stderr:r.stderr});assert.equal(r.status,0,r.stderr);return JSON.parse(r.stdout);}
const read=()=>call('inspect-records',{projectsRoot:projects});
const text=k=>fs.readFileSync(files[k],'utf8');
const field=(s,k,v)=>{const line=k+': '+JSON.stringify(v);const re=new RegExp('^'+k+':.*$','m');return re.test(s)?s.replace(re,line):s.replace(/\r?\n---\r?\n/, '\n'+line+'\n---\n');};
const clear=(s,k)=>s.replace(new RegExp('^'+k+':.*\\r?\\n','m'),'');
const dod=(s,checked)=>s.replace(/(- \[)[ x](\].*<!-- id:)/g,'$1'+(checked?'x':' ')+'$2');
const setState=(s,type,value,time)=>{s=field(field(s,type+'-state',value),'updated_at',time);return ['completed','cancelled','resolved'].includes(value)?field(s,'resolved_at',time):clear(s,'resolved_at');};
function check(label,k,allowed,reason){const r=call('check-closure',{recordId:ids[k],records:read().records});assert.equal(r.allowed,allowed,label+': '+JSON.stringify(r));if(reason)assert.match(JSON.stringify(r.reasons),reason);assertions.push({label,pass:true,result:r});return r;}
function snapshot(dir){for(const [k,p] of Object.entries(files))if(fs.existsSync(p))save(path.join(dir,path.relative(vault,p)),fs.readFileSync(p));}
function baseline(records){const out={schema_version:1,planningBinding:context.planningBinding,records:{}};for(const r of records){const fields={title:r.title,owner:r.owner,[r.type+'-state']:r.state};out.records[r.id]={canonical:{fields,path:r.path,sha256:hash(fs.readFileSync(r.path))},views:{}};for(const v of records)if(v.projections.some(p=>p.id===r.id))out.records[r.id].views[v.path]={fields:{[r.type+'-state']:r.state},sha256:hash(fs.readFileSync(v.path))};}save(path.join(state,'reconciliation.json'),out);}
function transaction(label,edit,{reopen=[]}={}){
 const dir=path.join(evidence,'cases',String(++step).padStart(2,'0')+'-'+label);snapshot(path.join(dir,'before'));
 const before=Object.fromEntries(Object.entries(files).map(([k,p])=>[k,fs.existsSync(p)?fs.readFileSync(p,'utf8'):null]));
 const time=call('activity-time',{}), op=call('new-id').id, eventId=call('new-id').id;
 let after={...before}; edit(after,time.activity_at);
 if(reopen.length){const records=Object.entries(after).filter(([,s])=>s!==null).map(([k,s])=>call('parse-record',{markdown:s,path:files[k]}));const proposal=call('reopen-ancestors',{records,changedIds:reopen.map(k=>ids[k])});save(path.join(dir,'reopen-proposal.json'),proposal);for(const r of proposal.records){const k=Object.keys(ids).find(k=>ids[k]===r.id);if(k && r.state!==records.find(x=>x.id===r.id).state)after[k]=setState(after[k],r.type,r.state,time.activity_at);}}
 const proposed=Object.entries(after).filter(([,s])=>s!==null).map(([k,s])=>call('parse-record',{markdown:s,path:files[k]}));
 // Refresh parent projections after canonical effects, retaining titles and prose.
 for(const k of ['m','p'])after[k]=after[k].split('\n').map(line=>{const ref=line.match(/<!-- ref: ([\w-]+) -->/);const r=ref&&proposed.find(r=>r.id===ref[1]);if(!r||!line.includes('[ ]')&&!line.includes('[x]')&&!line.includes('[-]')&&!line.includes('[>]'))return line;const mark={completed:'x',cancelled:'-', 'in-progress':'>','not-started':' '}[r.state];return line.replace(/\[[ x>\-]\]/,'['+mark+']');}).join('\n');
 const changes=Object.entries(after).filter(([k,s])=>s!==before[k]).map(([k,s])=>({key:files[k],before:{present:before[k]!==null,...(before[k]===null?{}:{value:hash(before[k])})},after:{present:s!==null,...(s===null?{}:{value:hash(s)})},before_sha256:before[k]===null?null:hash(before[k]),after_sha256:s===null?null:hash(s),intended_change:label}));
 const entry={id:eventId,operation_id:op,action:'closure.acceptance.'+label,record_ids:Object.values(ids),actor:{kind:'agent',id:'codex'},...time,original_words:'User authorized exact supplied-record closure acceptance',before:Object.fromEntries(changes.map(c=>[c.key,c.before_sha256])),after:{reason:label,files:Object.fromEntries(changes.map(c=>[c.key,c.after_sha256]))}};
 const checkpoint={operation_id:op,planningBinding:context.planningBinding,status:'pending',changes,entry};const cp=path.join(state,'operations',op+'.json');save(cp,checkpoint);save(path.join(dir,'checkpoint.json'),checkpoint);
 for(const k of ['a','b','x','m','p'])if(after[k]!==before[k]){assert.equal(fs.existsSync(files[k])?text(k):null,before[k]);save(files[k],after[k]);}
 call('invalidate-project-index',{vaultRoot:vault});
 const actual=read();save(path.join(dir,'inspection.json'),actual);
 const validation=call('validate-records',{records:actual.records}), links=call('check-links',{records:actual.records});save(path.join(dir,'validation.json'),{validation,links});
 call('log-append',{projectsRoot:projects,entry});const query=call('log-query',{projectsRoot:projects,action:entry.action,limit:1000});save(path.join(dir,'log-query.json'),query);assert.ok(JSON.stringify(query).includes(eventId));
 const events=Array.isArray(query)?query:query.entries;assert.deepEqual(events.find(e=>e.id===eventId),entry);
 baseline(actual.records);snapshot(path.join(dir,'after'));save(path.join(dir,'completed.json'),{...checkpoint,status:'completed'});fs.unlinkSync(cp);console.log(label);
}
const context=call('resolve-context',{vaultRoot:vault});save(path.join(evidence,'resolved-context.json'),context);
if(!fs.existsSync(path.join(evidence,'original-reconciliation.json')))save(path.join(evidence,'original-reconciliation.json'),fs.readFileSync(path.join(state,'reconciliation.json')));
snapshot(path.join(evidence,'initial'));const initial=read();assert.deepEqual(new Set(initial.records.map(r=>r.id)),new Set(Object.values(ids)));baseline(initial.records);
call('log-query',{projectsRoot:projects,limit:1000});
check('task DoD gates closure','a',false,/dod|definition of done|criterion|criteria/i);check('milestone DoD gates closure','m',false,/dod|definition of done|criterion|criteria/i);check('project unresolved milestone gates closure','p',false);
ids.x=call('new-id').id;
transaction('shared-blocker-and-evidence',(s,t)=>{
 s.x=`---\nid: "${ids.x}"\ntype: blocker\nrecord_version: 2\ntitle: "Await approval"\nblocker-state: open\nowner: "synthetic@example.test"\nproject_id: "${ids.p}"\ncreated_at: "${t}"\nupdated_at: "${t}"\n---\n# Await approval\n\nAwait synthetic reviewer approval of both career artifacts.\n\n## Resolution condition\nThe synthetic reviewer approves both artifacts.\n\n## Resolution evidence\nPending.\n\n## Blocks\n- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: ${ids.a} -->\n- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: ${ids.b} -->\n`;
 for(const [k,name] of [['a','linkedin-headline'],['b','resume-summary']]){s[k]=dod(s[k],true).replace(/Work has not started; no artifact has been produced or reviewed\./,'Synthetic reviewed evidence: ['+name+'](outputs/'+name+'.md). Reviewed for the existing criterion by Codex under explicit acceptance-test authorization.').replace('Link the actual artifact here and from the milestone after review.','Reviewed artifact: ['+name+'](outputs/'+name+'.md).');s[k]+=`\n## Blocked by\n- [[../blockers/b1-await-approval|Await approval]] <!-- ref: ${ids.x} -->\n`;}
 s.m+='\n## Reviewed artifacts\n- [Reviewed headline](outputs/linkedin-headline.md)\n- [Reviewed summary](outputs/resume-summary.md)\n';
});
// These are local authorized deliverables, not additional accepted records.
save(path.join(work,'outputs/linkedin-headline.md'),'# Synthetic reviewed LinkedIn headline\n\nSoftware engineer building dependable tools for practical workflows.\n\nReview: Codex checked that this is a headline and is saved locally, under explicit synthetic-review authorization.\n');
save(path.join(work,'outputs/resume-summary.md'),'# Synthetic reviewed resume summary\n\nSoftware engineer focused on clear, maintainable applications and dependable delivery. Experienced in translating requirements into practical tools and verifying behavior.\n\nReview: Codex checked that this is a summary and is saved locally, under explicit synthetic-review authorization.\n');
check('shared blocker gates LinkedIn','a',false,/block/i);check('shared blocker gates resume','b',false,/block/i);check('shared blocker gates milestone','m',false,/block/i);check('shared blocker gates project','p',false,/block/i);
transaction('resolve-blocker',(s,t)=>{s.x=setState(s.x,'blocker','resolved',t).replace('Pending.','Synthetic reviewer approved both linked local artifacts under user authorization.');});
check('LinkedIn eligible after blocker resolution','a',true);check('resume eligible after blocker resolution','b',true);
transaction('cancelled-prerequisite',(s,t)=>{s.a=setState(s.a,'task','cancelled',t);s.a+=`\n## Required by\n- [[t2-update-resume|Update resume]] <!-- ref: ${ids.b} -->\n`;s.b+=`\n## Depends on\n- [[t1-update-linkedin|Update LinkedIn]] <!-- ref: ${ids.a} -->\n`;});
check('cancelled prerequisite is informational','b',true);
transaction('restore-prerequisite',(s,t)=>{s.a=setState(s.a,'task','not-started',t);},{reopen:['a']});
transaction('satisfy-milestone-dod',(s,t)=>{s.m=field(dod(s.m,true),'updated_at',t);});
check('unresolved children gate milestone with satisfied DoD','m',false,/child|task|unresolved/i);
function close(k,label){check(label+' eligibility',k,true);transaction(label,(s,t)=>{s[k]=setState(s[k],k==='p'?'project':k==='m'?'milestone':'task','completed',t);});}
close('a','complete-linkedin');close('b','complete-resume');close('m','complete-milestone');close('p','complete-project');
function states(label,expected){const rs=read().records;for(const [k,v]of Object.entries(expected))assert.equal(rs.find(r=>r.id===ids[k]).state,v,label+' '+k);assertions.push({label,pass:true,states:expected});}
transaction('reopen-shared-blocker',(s,t)=>{s.x=setState(s.x,'blocker','open',t);},{reopen:['x']});
states('blocker reopening preserves completed tasks and reopens parents',{a:'completed',b:'completed',m:'not-started',p:'not-started',x:'open'});
transaction('reresolve-blocker',(s,t)=>{s.x=setState(s.x,'blocker','resolved',t);});close('m','recomplete-milestone-after-blocker');close('p','recomplete-project-after-blocker');
transaction('uncheck-milestone-dod',(s,t)=>{s.m=field(dod(s.m,false),'updated_at',t);},{reopen:['m']});
states('milestone DoD reopening preserves tasks and reopens parents',{a:'completed',b:'completed',m:'not-started',p:'not-started'});
transaction('recheck-milestone-dod',(s,t)=>{s.m=field(dod(s.m,true),'updated_at',t);});close('m','recomplete-milestone-after-dod');close('p','recomplete-project-after-dod');
transaction('uncheck-task-dod',(s,t)=>{s.a=field(dod(s.a,false),'updated_at',t);},{reopen:['a']});
states('task DoD reopening reopens task and parents',{a:'not-started',b:'completed',m:'not-started',p:'not-started'});check('unchecked task DoD prevents recompletion','a',false);
const originalSection=text('a').match(/## Definition of Done\r?\n[\s\S]*?(?=\r?\n## )/)[0];
transaction('empty-task-dod',(s,t)=>{s.a=field(s.a.replace(/## Definition of Done\r?\n[\s\S]*?(?=\r?\n## )/,'## Definition of Done\n'),'updated_at',t);});check('empty v2 task DoD cannot complete same LinkedIn ID','a',false,/dod|definition of done|criteria/i);
transaction('missing-task-dod',(s,t)=>{s.a=field(s.a.replace(/## Definition of Done\r?\n[\s\S]*?(?=\r?\n## )/,''),'updated_at',t);});check('missing v2 task DoD cannot complete same LinkedIn ID','a',false,/dod|definition of done|criteria/i);
transaction('restore-task-dod',(s,t)=>{s.a=field(s.a.replace('## Inputs',dod(originalSection,true)+'\n## Inputs'),'updated_at',t);});
close('a','final-complete-linkedin');close('m','final-complete-milestone');close('p','final-complete-project');
states('final supplied work completed',{a:'completed',b:'completed',m:'completed',p:'completed',x:'resolved'});
const final=read();assert.equal(final.records.length,5);assert.equal(final.diagnostics.length,0);
save(path.join(evidence,'assertions.json'),assertions);save(path.join(evidence,'final-log-query.json'),call('log-query',{projectsRoot:projects,limit:1000}));snapshot(path.join(evidence,'final'));
save(path.join(evidence,'REPORT.md'),`# Supplied-record closure acceptance\n\nPASS: ${assertions.length} assertions across ${step} committed Markdown cases.\n\nOnly the supplied Job Search project, Career materials milestone, Update LinkedIn and Update resume tasks were used. One authorized shared Await approval blocker was added. Empty and missing DoD were exercised on Update LinkedIn, then its original criterion ID restored. Final tasks and parents are completed; blocker resolved.\n\nEach cases/ directory retains exact before/after Markdown, hashed checkpoint, CLI inspection, validation, reopening proposal where applicable, and verified decision-log query. cli/ retains every structured input, command, exit code, stdout and stderr. assertions.json records every assertion and actual result. Initial foreign-path baselines were preserved as original-reconciliation.json and replaced with current-vault baselines without accessing that foreign vault. Daily plan candidate prose was untouched.\n\nThis is installed-skill-authored acceptance in the current host, with CLI integrity evidence. It does not establish fresh authenticated host/plugin discovery, phone continuity, or all eight scenarios.\n`);
console.log(JSON.stringify({pass:true,assertions:assertions.length,cases:step}));
