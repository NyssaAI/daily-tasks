import path from 'node:path';import {root,save,read,json,mon,tue,fri,planPath,snap} from './session.mjs';import {transaction} from './transactions.mjs';import {saveReview} from './rollover.mjs';
const failures=[];
for(const [branch,date,originalTime,now,snapshot] of [['tuesday','2026.10.06',mon,tue,'tuesday-precreated-with-B'],['future','2026.10.09',tue,fri,'future-added-A-B']]){
 const v=path.join(root,branch+'-vault'),pp=planPath(v,date),old=read(pp),original=read(planPath(path.join(root,'snapshots',snapshot,'vault'),date)).match(/^created_at: .*$/m)[0],actual=old.match(/^created_at: .*$/m)[0];
 failures.push({assertion:'Preserve existing plan creation timestamp',branch,expected:original,actual,passed:false,sourceSnapshot:snapshot,failedSnapshot:branch==='tuesday'?'tuesday-final':'future-Friday-final',cause:'Native author replaced creation timestamp while rendering rollover',classification:'Native workflow authoring failure; not attributed to deterministic CLI',repair:'Restore actual original metadata; keep failure evidence'});
 transaction(v,now,'plan.metadata-corrected',[],[{path:pp,text:old.replace(/^created_at: .*$/m,original)}],{field:'created_at',before:actual,after:original,reason:'Restore pre-created plan metadata from saved original snapshot'});saveReview(v,now,branch+'-metadata-repaired');snap(branch+'-repaired',v);
}
save(path.join(root,'genuine-failures.json'),{initialSetupFailure:{operation:'log-append',code:'MISSING_ROOT',retained:'cli/0007-log-append-result.json',cause:'Native setup author appended before creating projects directory',recovered:true},workflowFailures:failures});
console.log('Retained two metadata failures and repaired current files.');
