import fs from 'node:fs';
import path from 'node:path';
import {root,pkg,save,read,json,sha,cli,id,front,mon,event,append,plan,planPath,invalidate,snap,prepare} from './session.mjs';
const v=path.join(root,'monday-vault');
const profile={schema_version:1,user:{name:'Synthetic User',email:'synthetic@example.invalid'},timezone:'America/Chicago',priorities:[],vaultRoot:v,projectsRoot:'./1-projects',dailyPlansRelative:'2-areas/daily-plans',projectIndex:{ttlSeconds:14400}};
const validated=cli('validate-profile',profile);if(!validated.valid)throw Error(JSON.stringify(validated));
save(path.join(v,'.nyssaai/daily-tasks/profile.json'),profile);
fs.mkdirSync(path.join(v,'1-projects'),{recursive:true});
append(v,event(mon,'profile.setup',[],{scope:'synthetic vault only',timezone:'America/Chicago'}));
const pid=id(),mid=id();
const specs=[['A','A','Synthetic task A','Reviewed synthetic A'],['B','B','Synthetic task B','Reviewed synthetic B'],['C','Review draft','Inspect draft','Recorded review'],['D','Past work','Past synthetic result','Reviewed result'],['E','Abandoned work','Draft work','Reviewed result'],['F','Deselected work','Optional draft','Reviewed draft']];
const tasks=specs.map(([key,title,req,dod],i)=>({key,title,req,dod,id:id(),criterion:id(),file:`t${i+1}-${key==='A'||key==='B'?key.toLowerCase():title.toLowerCase().replaceAll(' ','-')}.md`,state:'not-started'}));
const project=path.join(v,'1-projects/job-search'),milestone=path.join(project,'m1-accepted-work');
const taskDoc=t=>front('task',t.title,t.id,mon,`record_version: 2\ndocument-maturity: reviewed\ntask-state: ${t.state}\nproject_id: "${pid}"\nmilestone_id: "${mid}"\n${t.key==='C'?'assignee: "Reviewer"\n':''}`)+`# ${t.title}\n\n**Milestone:** [[m1-accepted-work|Accepted work]] <!-- ref: ${mid} -->\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${pid} -->\n\n## Requirements\n\n${t.req}.\n\n## Definition of Done\n\n- [ ] ${t.dod}. <!-- id: ${t.criterion} -->\n`;
const views=()=>[
{path:path.join(project,'project-index.md'),text:front('project','Job Search',pid,mon,'project-state: not-started\n')+`# Job Search\n\nSynthetic accepted project.\n\n## Project Summary\n\n- [ ] [[m1-accepted-work/m1-accepted-work|Accepted work]] <!-- ref: ${mid} -->\n`+tasks.map(t=>`- ${t.state==='completed'?'[x]':t.state==='cancelled'?'[-]':'[ ]'} [[m1-accepted-work/${t.file.slice(0,-3)}|${t.title}]] <!-- ref: ${t.id} -->`).join('\n')+'\n'},
{path:path.join(milestone,'m1-accepted-work.md'),text:front('milestone','Accepted work',mid,mon,`record_version: 2\nmilestone-state: not-started\nproject_id: "${pid}"\n`)+`# Accepted work\n\n**Project:** [[../project-index|Job Search]] <!-- ref: ${pid} -->\n\n## Outcome\n\nSynthetic day-change acceptance workspace.\n\n## Definition of Done\n\n- [ ] Day-change assertions reviewed. <!-- id: ${id()} -->\n\n## Tasks\n\n`+tasks.map(t=>`- ${t.state==='completed'?'[x]':t.state==='cancelled'?'[-]':'[ ]'} [[${t.file.slice(0,-3)}|${t.title}]] <!-- ref: ${t.id} -->`).join('\n')+'\n'}];
const entry=event(mon,'records.accepted',[pid,mid,...tasks.map(t=>t.id)],{acceptance:'User directly accepted synthetic Job Search A/B and C/D/E/F; fixture milestone is a synthetic grouping',tasks:tasks.map(({key,title,req,dod})=>({key,title,req,dod}))});
const files=[...views(),...tasks.map(t=>({path:path.join(milestone,t.file),text:taskDoc(t)}))];
const opPath=path.join(v,'.nyssaai/daily-tasks/operations',entry.operation_id+'.json');
save(opPath,{operation_id:entry.operation_id,event:entry,acceptance:'Current user instruction',files:files.map(f=>({...f,beforeHash:null,afterHash:sha(f.text)}))});
for(const f of files){if(fs.existsSync(f.path))throw Error('Collision');save(f.path,f.text);}
fs.mkdirSync(path.join(milestone,'inputs'),{recursive:true});fs.mkdirSync(path.join(milestone,'outputs'),{recursive:true});
const inspected=cli('inspect-records',{projectsRoot:path.join(v,'1-projects')});save(path.join(root,'initial-inspect.json'),inspected);
append(v,entry);invalidate(v);save(path.join(root,'accepted-checkpoint.json'),json(opPath));fs.unlinkSync(opPath);
save(path.join(root,'fixture.json'),{vault:v,pid,mid,project,milestone,tasks});
console.log(JSON.stringify({validated,inspected},null,2));
