---
id: "01a12134-31ec-724e-8e1e-a4294ba42dce"
type: task
record_version: 2
title: "Routing note"
document-maturity: reviewed
task-state: not-started
owner: "synthetic@example.test"
project_id: "01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4"
milestone_id: "01a12134-31c1-75ad-b57c-ad026235703c"
created_at: "2026-10-09T15:07:11.438Z"
updated_at: "2026-10-09T15:07:11.438Z"
---
# M1-T1 — Routing note

**Milestone:** [[m1-update-linkedin-and-resume|Update LinkedIn and resume]] <!-- ref: 01a12134-31c1-75ad-b57c-ad026235703c -->

**Project:** [[../project-index|Job Search]] <!-- ref: 01a12125-8ea3-7c9a-8c3a-d4f9f8813ca4 -->

## Requirements

Local routing test note.

## Definition of Done

- [ ] Reviewed routing note. <!-- id: 01a12134-3246-7c7d-b32e-4db6770cf273 -->

## Output and delivery

Local routing note in the milestone's flat outputs/ directory.

## Verification

Review the routing note against the local routing test requirement.
