import fs from 'node:fs';import path from 'node:path';import {root,save,json,fri,snap,prepare,cli,context} from './session.mjs';import {missingToday,startRollover} from './rollover.mjs';
const v=path.join(root,'recovery-vault');missingToday(v,fri,'2026.10.09','recovery');const cp=startRollover(v,fri,'2026.10.09','recovery',['A','C']);save(path.join(root,'recovery-pointer.json'),{vault:v,checkpoint:cp.p});snap('recovery-interrupted-after-destination',v);
const p=prepare(v,fri,'recovery-pending');console.log(JSON.stringify({pending:p.pendingOperations,state:p.state.rollover,rollover:p.rollover}));
const input={...context(v,fri),action:'complete-rollover',expectedPlanHash:p.current.sha256,expectedPreviousHash:p.previous.sha256,expectedInventoryHash:p.inventoryHash,expectedStateHash:p.state.rollover.sha256};
try{const r=cli('planning-state',input);save(path.join(root,'recovery-false-receipt-result.json'),{unexpectedSuccess:r});}catch(e){save(path.join(root,'recovery-false-receipt-result.json'),{rejected:true,error:e.message});}
if(fs.existsSync(p.state.rollover.path))save(path.join(root,'recovery-interruption-state.json'),json(p.state.rollover.path));else save(path.join(root,'recovery-interruption-state.json'),{absent:true});
console.log('INTERRUPTED: destination persisted; original checkpoint retained; no recovery performed in this process.');
