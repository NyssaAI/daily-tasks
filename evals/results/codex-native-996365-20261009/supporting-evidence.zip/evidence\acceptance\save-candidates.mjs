import fs from 'node:fs';
import {call} from './review-candidates.mjs';
const vault = 'D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/acceptance/vault';
const root = `${vault}/.nyssaai/daily-tasks`;
const time = call('activity-time', {});
const candidates = [
  {key:'native-acceptance:linkedin-update',title:'Update LinkedIn',type:'task',disposition:'pending-acceptance',owner:'synthetic@example.test',project:null,milestone:null,sources:[{key:'user-request:linkedin',reference:'Current user request',text:'I might want to update my LinkedIn and resume sometime'}],unresolved:['Acceptance','Accepted parent project and milestone','Scope and definition of done']},
  {key:'native-acceptance:resume-update',title:'Update resume',type:'task',disposition:'pending-acceptance',owner:'synthetic@example.test',project:null,milestone:null,sources:[{key:'user-request:resume',reference:'Current user request',text:'I might want to update my LinkedIn and resume sometime'},{key:'Daily/2026-10-09.md:checkbox:Maybe improve my resume',reference:'Daily/2026-10-09.md:3',text:'Maybe improve my resume'}],unresolved:['Acceptance','Accepted parent project and milestone','Scope and definition of done']}
];
fs.mkdirSync(root,{recursive:true});
fs.writeFileSync(`${root}/candidates.json`,JSON.stringify({schema_version:1,updated_at:time.recorded_at,candidates},null,2)+'\n');
console.log(JSON.stringify(JSON.parse(fs.readFileSync(`${root}/candidates.json`,'utf8')),null,2));
