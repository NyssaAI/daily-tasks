import fs from 'node:fs';import path from 'node:path';
import {root,save,read,json,cli,id,mon,plan,planPath,prepare,snap,context} from './session.mjs';
import {transaction,baseline} from './transactions.mjs';
const f=json(path.join(root,'fixture.json')),v=f.vault,ts=f.tasks;
const missing=prepare(v,mon,'monday-missing');console.log('missing packet',JSON.stringify({current:missing.current,rollover:missing.rollover,keys:Object.keys(missing)}));
const planId=id(),pp=planPath(v,'2026.10.05');
transaction(v,mon,'plan.created',[],[{path:pp,text:plan(v,'2026.10.05',planId,mon,[])}],{date:'2026.10.05',selected:[]});
let p=prepare(v,mon,'monday-empty');
const shared={...context(v,mon),expectedPlanHash:p.current.sha256,expectedPreviousHash:p.previous?.sha256??null,expectedStateHash:p.state.rollover.sha256,expectedInventoryHash:p.inventoryHash,action:'complete-rollover'};
console.log('no-change',cli('planning-state',shared));
transaction(v,mon,'plan.selected',ts.filter(t=>t.key!=='B').map(t=>t.id),[{path:pp,text:plan(v,'2026.10.05',planId,mon,ts.filter(t=>t.key!=='B'))}],{selected:['A','C','D','E','F'],allOpen:true});
snap('monday-selected-open',v);
for(const key of ['D','E']){
 const t=ts.find(t=>t.key===key),tp=path.join(f.milestone,t.file),before=read(tp);let proposed=before;
 if(key==='D'){proposed=proposed.replace('- [ ] Reviewed result.','- [x] Reviewed result.')+'\n## Result\n\nUser attests: past synthetic result reviewed.\n';const r=cli('parse-record',{markdown:proposed,path:tp});const records=cli('inspect-records',{projectsRoot:path.join(v,'1-projects')}).records.map(x=>x.id===t.id?r:x);const closure=cli('check-closure',{recordId:t.id,records});save(path.join(root,'D-closure.json'),closure);if(!closure.allowed)throw Error(JSON.stringify(closure));}
 t.state=key==='D'?'completed':'cancelled';proposed=proposed.replace('task-state: not-started','task-state: '+t.state).replace('updated_at: "'+mon+'"','updated_at: "'+mon+'"\nresolved_at: "'+mon+'"');
 const files=[{path:tp,text:proposed}];for(const vp of [path.join(f.project,'project-index.md'),path.join(f.milestone,'m1-accepted-work.md')])files.push({path:vp,text:read(vp).split('\n').map(line=>line.includes('<!-- ref: '+t.id+' -->')?line.replace('- [ ]','- '+(key==='D'?'[x]':'[-]')):line).join('\n')});
 files.push({path:pp,text:plan(v,'2026.10.05',planId,mon,ts.filter(x=>x.key!=='B'))});transaction(v,mon,'task.'+t.state,[t.id],files,{state:t.state,reason:key==='D'?'User attests reviewed past synthetic result':'Explicit user cancellation; DoD remains unchecked'});
}
transaction(v,mon,'plan.deselected',[ts.find(t=>t.key==='F').id],[{path:pp,text:plan(v,'2026.10.05',planId,mon,ts.filter(t=>!['B','F'].includes(t.key)))},{path:path.join(v,'.nyssaai/daily-tasks/rollover/2026.10.05.json'),text:JSON.stringify({...json(path.join(v,'.nyssaai/daily-tasks/rollover/2026.10.05.json')),removedIds:[ts.find(t=>t.key==='F').id]},null,2)+'\n'}],{removed:['F'],taskRemainsOpen:true});
save(path.join(root,'fixture.json'),f);snap('monday-final',v);console.log('Monday complete');
