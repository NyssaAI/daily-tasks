---
id: "01a12139-3817-7341-8f18-ac1dafea696c"
type: blocker
record_version: 2
title: "Await approval"
blocker-state: open
owner: "synthetic@example.test"
project_id: "01a1211c-fbe7-727c-885c-bd3fcf926af2"
created_at: "2026-10-09T15:12:40.516Z"
updated_at: "2026-10-09T15:12:40.516Z"
---
# Await approval

Await synthetic reviewer approval of both career artifacts.

## Resolution condition
The synthetic reviewer approves both artifacts.

## Resolution evidence
Pending.

## Blocks
- [[../m1-career-materials/t1-update-linkedin|Update LinkedIn]] <!-- ref: 01a1211c-fc3f-7cdf-a7aa-b0aa50ee3fc8 -->
- [[../m1-career-materials/t2-update-resume|Update resume]] <!-- ref: 01a1211c-fc6d-7e56-b639-7133ec8fe4d6 -->
