---
id: 01a12134-75f3-7530-851f-4dfbb9b447b2
type: project
record_version: 2
title: "Job Search"
project-state: not-started
owner: "synthetic@example.test"
created_at: "2026-10-09T15:07:29.025Z"
updated_at: "2026-10-09T15:07:29.025Z"
---
# Job Search

Prepare career materials for a job search.

## Project Summary

| Milestone | Task | Description | Owner | Due Date |
| --- | --- | --- | --- | --- |
| [ ] [[m1-career-materials/m1-career-materials\|Career materials]] <!-- ref: 01a12134-7622-739e-8c07-16ad987b3c1f --> | | Both reviewed artifacts linked. | synthetic@example.test | � |
| | [ ] [[m1-career-materials/t1-update-linkedin\|Update LinkedIn]] <!-- ref: 01a12134-764f-7dbe-a917-7c7527f13bbb --> | Draft headline. | synthetic@example.test | � |
| | [ ] [[m1-career-materials/t2-update-resume\|Update resume]] <!-- ref: 01a12134-767e-7fa0-ae7f-8cbb2416f080 --> | Draft summary. | synthetic@example.test | � |
