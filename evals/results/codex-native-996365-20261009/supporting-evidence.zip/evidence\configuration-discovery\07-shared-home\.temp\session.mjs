import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export const root=process.cwd();
export const cli='D:/repos/NyssaAI/daily-tasks/.temp/native-acceptance/codex-home/plugins/cache/daily-tasks-native-eval/daily-tasks/0.3.3/bin/daily-tasks.mjs';
export const opts={vaultRoot:path.join(root,'vault-a'),homeRoot:path.join(root,'synthetic-home'),profilePath:path.join(root,'synthetic-home/.nyssaai/daily-tasks/profile.json')};
export const save=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2));};
export const hash=s=>createHash('sha256').update(s).digest('hex');
let seq=0;
export function call(op,input){const p=path.join(root,'.temp',`${process.env.PHASE||'session'}-${++seq}-${op}.input.json`);if(input)save(p,input);const r=spawnSync(process.execPath,[cli,op,...(input?['--input',p]:[])],{encoding:'utf8'});save(p.replace('.input.json','.result.json'),{exitCode:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout);}
